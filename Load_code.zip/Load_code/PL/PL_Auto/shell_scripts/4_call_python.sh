echo At Server 1
snapshot_date=$1
n_horizon_weeks=$2
token=$3
env_url=$4
sales_order_api=$5
holiday_grains_api=$6
seasonal_grains_api=$7
korean_calendar_api=$8
data_path=$9
job_id=${10}
promo_api=${11}
pos_api=${12}
replicate_promo_in_future=${13}
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/'
/opt/anaconda3/bin/python 4_preCortex_processing.py $snapshot_date $n_horizon_weeks $token $env_url $sales_order_api $holiday_grains_api $seasonal_grains_api $korean_calendar_api $data_path $job_id $promo_api $pos_api $replicate_promo_in_future
#chmod -R 777 /efs/datascience/MerckDE6/data/output/cortex_data/
echo 4th python script and 2nd shell script finished ..