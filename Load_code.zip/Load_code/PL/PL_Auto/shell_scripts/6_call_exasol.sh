#!/bin/sh
if [ $# -ne 1 ]
then
echo "Please enter jobid"
exit 1
else
jobid=$1
fi
echo "jobid" $jobid
if [ -f /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/SQL_scripts/6_export_db.sql ]
then
mv /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/SQL_scripts/6_export_db.sql /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/SQL_scripts/6_export_db.sql.previousversion
fi

sed "s/var_jobid/$jobid/gi" /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/SQL_scripts/6_import_data_to_exasol.sql >> /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/SQL_scripts/6_export_db.sql
chmod 755 /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/SQL_scripts/6_export_db.sql
