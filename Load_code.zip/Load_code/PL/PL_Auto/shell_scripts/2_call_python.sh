echo At Server 1
snapshot_date=$1
token=$2
env_url=$3
sales_order_api=$4
data_path=$5
job_id=$6
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/'
/opt/anaconda3/bin/python 2_seasonal_segmentation.py $snapshot_date $token $env_url $sales_order_api $data_path $job_id
#chmod -R 777 /efs/datascience/MerckDE6/data/output/cortex_data/
echo 2nd python script and 2nd shell script finished ..