echo At Server 1
snapshot_date=$1
token=$2
env_url=$3
sales_order_full_api=$4
material_dimension_api=$5
data_path=$6
job_id=$7
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/'
/opt/anaconda3/bin/python 6_market_basket_analysis.py $snapshot_date $token $env_url $sales_order_full_api $material_dimension_api $data_path $job_id
#chmod -R 777 /efs/datascience/MerckDE6/data/output/cortex_data/
echo 6th python script and 2nd shell script finished ..