echo At Server 1
snapshot_date=$1
token=$2
env_url=$3
sales_order_daily_api=$4
korean_calendar_api=$5
data_path=$6
job_id=$7
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/'
/opt/anaconda3/bin/python 3_holiday_segmentation.py $snapshot_date $token $env_url $sales_order_daily_api $korean_calendar_api $data_path $job_id
#chmod -R 777 /efs/datascience/MerckDE6/data/output/cortex_data/
echo 3rd python script and 2nd shell script finished ...