echo At Server 1
snapshot_date=$1
token=$2
env_url=$3
sales_order_api=$4
covid_index_api=$5
data_path=$6
job_id=$7
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/'
/opt/anaconda3/bin/python 1_covid_correlation_analysis.py $snapshot_date $token $env_url $sales_order_api $covid_index_api $data_path $job_id
#chmod -R 777 /efs/datascience/MerckDE6/data/output/cortex_data/
echo 1st python script and shell script finished ..