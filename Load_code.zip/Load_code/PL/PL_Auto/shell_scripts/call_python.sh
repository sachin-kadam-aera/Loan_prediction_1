echo At Server 1
snapshot_date=$1
n_horizon_weeks=$2
token=$3
env_url=$4
sales_order_api=$5
korean_calendar_api=$6
data_path=$7
job_id=$8
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/'
/opt/anaconda3/bin/python _simple_test_script.py $snapshot_date $n_horizon_weeks $token $env_url $sales_order_api $korean_calendar_api $data_path $job_id
#chmod -R 777 /efs/datascience/MerckDE6/data/output/cortex_data/
echo sample scripts shell script finished ..