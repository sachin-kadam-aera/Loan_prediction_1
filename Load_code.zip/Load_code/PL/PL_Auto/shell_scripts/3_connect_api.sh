#!/bin/bash
set -o errexit
USER1=$(whoami)
snapshot_date=$1
token=$2
env_url=$3
sales_order_daily_api=$4
korean_calendar_api=$5
data_path=$6
job_id=$7
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"
echo SSH passed to target server, moving on..
echo "This script call UATIRL 10.110.6.149 (https://dsserver01-uatirl-cortex.aeratechnology.com/script/run/) script"
echo "3rd shell script is running..."
echo $snapshot_date

HOST='https://dsserver01-uatirl-cortex.aeratechnology.com/script/run/'
success_response="Server is running"
status_message="success"
chmod -R 777 /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/shell_scripts/'
response=$(curl -s $HOST | cut -d '"' -f 2)

echo $response


if [[ "$response" == "$success_response" ]];
	then
		echo "Running Script..."
                status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/shell_scripts/3_call_python.sh '$snapshot_date' '$token' '$env_url' '$sales_order_daily_api' '$korean_calendar_api' '$data_path' '$job_id' "}' )
                echo "status output"$status
		#status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/shell_scripts/call_python.sh '$snapshot_date' '$n_horizon_weeks' '$token' '$env_url' '$sales_order_api' '$korean_calendar_api' '$data_path' '$job_id' "}' | jq -r '.status' )
	if [[ "$status" == "$status_message" ]];
		then
		echo "Successfully executed the 3rd shell script"
	else
		echo "Unable to execute the 3rd shell script"
	fi
else
	echo "Unable to connect to server"
fi
