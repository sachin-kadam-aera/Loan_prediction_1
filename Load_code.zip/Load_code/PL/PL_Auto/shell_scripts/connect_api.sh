#!/bin/bash
set -o errexit
USER1=$(whoami)
snapshot_date=$1
n_horizon_weeks=$2
token=$3
env_url=$4
sales_order_api=$5
korean_calendar_api=$6
data_path=$7
job_id=$8
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"
echo SSH passed to target server, moving on..
echo "This script call PROD 10.110.6.149 (https://dsserver03-produs-cortex.aeratechnology.com/script/run/) script"
echo $snapshot_date

HOST='https://dsserver01-uatirl-cortex.aeratechnology.com/script/run/'
success_response="Server is running"
status_message="success"
chmod -R 777 /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/
cd '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/shell_scripts/'
response=$(curl -s $HOST | cut -d '"' -f 2)

echo $response


if [[ "$response" == "$success_response" ]];
	then
		echo "Running Script..."
                status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/shell_scripts/call_python.sh '$snapshot_date' '$n_horizon_weeks' '$token' '$env_url' '$sales_order_api' '$korean_calendar_api' '$data_path' '$job_id' "}' )
                echo "status output"$status
		#status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/shell_scripts/call_python.sh '$snapshot_date' '$n_horizon_weeks' '$token' '$env_url' '$sales_order_api' '$korean_calendar_api' '$data_path' '$job_id' "}' | jq -r '.status' )
	if [[ "$status" == "$status_message" ]];
		then
		echo "Successfully executed the script"
	else
		echo "Unable to execute the script"
	fi
else
	echo "Unable to connect to server"
fi
