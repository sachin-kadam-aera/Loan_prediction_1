#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  1 10:50:29 2022

@author: sandeepdhankhar
"""

print('Loading libraries')

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import datetime
import itertools
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python '/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/3_holiday_segmentation.py' '2022-01-17' 'dd852f627ce956bf6ce037821bdbb1fb' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains-daily' 'DSSeasonDailyLevelForAutomationTesting' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python "/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/3_holiday_segmentation.py" '2022-01-17' '12f7c322d93d088c753a7619165a02be' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains-daily' 'DSSeasonDailyLevelForAutomationTesting' '/efs/datascience/Pulmuone4A7' 'test' 

'''

#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-08-29'
    token = 'c6e29e6885701206256b5076cf5bffc0'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_daily_api = 'high-forecastability-grains-daily'
    korean_calendar_api = 'korean-calendar-api'
    data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test'
    job_id = '27May2022'
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    token = sys.argv[2]
    env_url = sys.argv[3]
    sales_order_daily_api = sys.argv[4]
    korean_calendar_api = sys.argv[5]
    data_path = sys.argv[6]
    job_id = sys.argv[7]
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

################## General ##################

def glimpse(df):
    
    Data_Type = df.dtypes
    Missing_Values = df.isnull().sum()
    Unique_Values = df.nunique()

    df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
    df_out.columns = ['Data Type','Missing Values','Unique Values']
    
    return df_out

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path

def add_reporting_and_snapshot_dates(data,snapshot_date):
    data['Reporting_datetime'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data['Snapshot_date'] = snapshot_date
    return data

################## Sales Order Processing ##################

def reducing_data_till_snapshot_date(sales_order,snapshot_date,dateCol = 'Week Starting'):
    return sales_order[sales_order[dateCol] < snapshot_date]

def apply_basic_prepcoc_steps(sales_order, dateCol = 'Week Starting'):
    sales_order.rename(columns = {'Channel Group':'Channel'}, inplace=True) # renaming column
    sales_order = sales_order.loc[sales_order['ABC Class'].isin(['A','B']), # keep only A,B segment
                                  ['Material Number','Channel',dateCol,'Order Item Quantity']] # filter columns
    sales_order[dateCol] = pd.to_datetime(sales_order[dateCol],infer_datetime_format=True) # change dtype of date column
    sales_order = sales_order.sort_values(by = ['Material Number','Channel',dateCol]).reset_index(drop = True) # sort by grain and date
    return sales_order

################## Segmentation - Event Driven / Holidays ##################

def get_holiday_wise_peak_sales():
    '''
    This dictionary is prepared on the basis of customer's input
    
    n => number of days to consider after holiday (for during season)
    p => number of days to consider before holiday (for during season)
    pre => number of days to consider for pre-season period
    post => number of days to consider for post-season period

    Returns
    -------
    peak_event_dict : dictionary
        DESCRIPTION -> Holiday wise per/during/post seasonal period.

    '''
    peak_event_dict = {'BUDDA_BDAY':{'n':3,'p':3,'pre':7,'post':7},
                   'CHILDRENS_DAY':{'n':3,'p':3,'pre':7,'post':7}, 
                   'CHOBOK':{'n':3,'p':7,'pre':7,'post':7}, 
                   'CHRISTMAS':{'n':3,'p':7,'pre':7,'post':7}, 
                   'CHUSEOK':{'n':1,'p':7,'pre':7,'post':7},
                   'HANGUL_DAY':{'n':3,'p':3,'pre':7,'post':7}, 
                   'INDEPENDENCE_DAY':{'n':3,'p':3,'pre':7,'post':7}, 
                   'JUNGBOK':{'n':3,'p':7,'pre':7,'post':7}, 
                   'LUNARNY':{'n':3,'p':3,'pre':7,'post':7}, 
                   'MALBOK':{'n':3,'p':7,'pre':7,'post':7},
                   'MEMORIAL_DAY':{'n':3,'p':3,'pre':7,'post':7}, 
                   'NAT_FOUNDATION_DAY':{'n':3,'p':3,'pre':7,'post':7}, 
                   'NAT_LIBERATION_DAY':{'n':3,'p':3,'pre':7,'post':7},
                   'PUBLICHOLIDAY':{'n':3,'p':3,'pre':7,'post':7}, 
                   'SOLARNY':{'n':1,'p':7,'pre':7,'post':7}, 
                   'WINTERSOLSTICE':{'n':3,'p':7,'pre':7,'post':7}}
    return peak_event_dict


def format_korean_calendar(korean_calendar):
    korean_calendar['Date'] = pd.to_datetime(korean_calendar['Date'])
    korean_calendar = korean_calendar.sort_values(by = 'Date')
    exclude_cols = ['FALL','SPRING','SUMMER','WINTER']
    korean_calendar.drop(columns = exclude_cols, inplace = True)
    return korean_calendar

def get_season_label(s_name,n,p,pre,post,season_info):
    
    '''
    s_name = 'BUDDA_BDAY'
    n = 7
    p = 7
    pre = 10
    post = 10
    '''
    
    #1. Finding holiday dates
    s_occurence = season_info.loc[season_info[s_name] == 1, 'Date']

    df_list = list()

    for s_date in s_occurence:
        #print(s_date)
        #s_date = s_occurence.reset_index(drop = True)[0]

        # Label during season period
        p_dates = pd.date_range(end = s_date,periods = p,freq = 'D')
        n_dates = pd.date_range(start = s_date + pd.tseries.offsets.DateOffset(days = 1),periods = n,freq = 'D')
        label_season = p_dates.union(n_dates)

        # Label non-seasonal period
        label_non_season_pre = pd.date_range(start = p_dates.min() - pd.tseries.offsets.DateOffset(days = (pre)), 
                                             periods = pre, freq = 'D')
        label_non_season_post = pd.date_range(start = n_dates.max() +  pd.tseries.offsets.DateOffset(days = 1), 
                                             periods = post, freq = 'D')

        # Seasonal year
        s_year = s_date.year

        # Label info
        len_season = len(label_season)
        len_non_season_pre = len(label_non_season_pre)
        len_non_season_post = len(label_non_season_post)

        label_info = pd.DataFrame({'Date' : label_season.union_many([label_non_season_pre,label_non_season_post]),
                                  'Season_label' : list(itertools.repeat('non-season-pre',len_non_season_pre)) + 
                                   list(itertools.repeat('season',len_season)) + 
                                   list(itertools.repeat('non-season-post',len_non_season_post)),
                                  'Season_year' : itertools.repeat(s_year,len_non_season_pre + len_season + len_non_season_post)})

        df_list.append(label_info)

    master_label_info = pd.concat(df_list)
    return master_label_info

def get_rule_based_res(s_name,data,master_label_info,shift_perc = 5):
    '''
    s_name = 'BUDDA_BDAY'
    data = sales_order_daily
    master_label_info=master_label_info
    shift_perc = 5
    '''

    data_with_label = pd.merge(data,master_label_info,how = 'inner', on = 'Date')
    season_sales = data_with_label.groupby(['Channel','Material Number','Season_year','Season_label']).agg(
        mean_sales = ('Order Item Quantity','mean')).reset_index()
    peak_info = season_sales.pivot(index = ['Channel','Material Number','Season_year'], columns = 'Season_label', 
                                   values = 'mean_sales').reset_index().dropna(axis=0)
    peak_info['during_min_pre'] = peak_info['season'] - peak_info['non-season-pre']
    peak_info['during_min_post'] = peak_info['season'] - peak_info['non-season-post']
    peak_info['pre_to_during_inc_per'] = np.round(peak_info['during_min_pre']*100/peak_info['non-season-pre'])
    peak_info['post_to_during_inc_per'] = np.round(peak_info['during_min_post']*100/peak_info['non-season-post'])

    def is_peak_event(row,shift_perc):
        if ((row['pre_to_during_inc_per'] > shift_perc) & (row['post_to_during_inc_per'] > shift_perc)):
            return 1
        else:
            return 0

    peak_info['is_peak'] = peak_info.apply(is_peak_event,shift_perc = shift_perc, axis = 1)
    peak_info['n_years_peak'] = peak_info.groupby(['Channel','Material Number'])['is_peak'].transform(lambda x: x.sum())
    peak_info['n_years_in_data'] = peak_info.groupby(['Channel','Material Number'])['is_peak'].transform(lambda x: x.count())
    peak_info['all_years_peak'] = peak_info.apply(lambda x: 1 if (x['n_years_peak'] == x['n_years_in_data']) else 0,axis = 1)
    peak_info = peak_info[peak_info['n_years_in_data'] > 1] # should have more than 1 year of data
    peak_info['season_name'] = s_name

    grains_impacted_during_holiday = peak_info.loc[peak_info['all_years_peak'] == 1,
                                                   ['season_name','Channel','Material Number','n_years_peak',
                                                    'n_years_in_data']].drop_duplicates()
    
    # Print
    print('{s_name} => {n} grains impacted'.format(s_name = s_name,n = grains_impacted_during_holiday.shape[0]))
    
    return grains_impacted_during_holiday

def create_dataframe_for_visualization(data,master_label_info,rule_res,s_name):
    '''
    data = sales_order_daily
    master_label_info = master_label_info
    rule_res = holiday_impact_res
    s_name = 'BUDDA_BDAY'
    '''
    data_with_label = pd.merge(data,master_label_info, # Attaching pre/during/post season labels
                               how='left',
                               on=['Date'])
    data_with_label = pd.merge(data_with_label,rule_res, # Keeping only holiday impacted grains
                               how='inner',
                               on=['Channel','Material Number']) 
    # Calculating avg sales in a season
    data_with_label['Season_label'].fillna('',inplace=True)
    data_with_label['order_quantity_season'] = data_with_label.groupby( 
        ['Channel','Material Number','Season_label'])['Order Item Quantity'].transform(lambda x : x.mean())
    data_with_label['order_quantity_season'] = data_with_label.apply(lambda x: np.nan if x['Season_label'] == '' else x['order_quantity_season'],axis=1)
    
    data_with_label = data_with_label[['season_name','Material Number','Channel','Date','Season_label',
                                       'Order Item Quantity','order_quantity_season']]
    return data_with_label

################## All segmentation code wrapped under this single function ##################
def run_holiday_segmentation(sales_order_daily,korean_calendar,snapshot_date,peak_event_dict):
    # Sales order daily preprocessing
    print('Sales order preprocessing started..')
    sales_order_daily = apply_basic_prepcoc_steps(sales_order_daily,dateCol = 'Date')
    sales_order_daily = reducing_data_till_snapshot_date(sales_order_daily,snapshot_date,dateCol = 'Date') # limiting data till snapshot date

    # Holiday impact analysis
    print('Holiday impact analysis started..')
    holiday_impact_df_list = list()
    dashboard_df_list = list()

    season_info = format_korean_calendar(korean_calendar)
    holiday_names = season_info.columns[season_info.columns != 'Date']

    for holiday in holiday_names :
        n = peak_event_dict[holiday]['n']
        p = peak_event_dict[holiday]['p']
        pre = peak_event_dict[holiday]['pre']
        post = peak_event_dict[holiday]['post']
        master_label_info = get_season_label(holiday,n,p,pre,post,season_info) # Get pre,during,post season labels
        holiday_impact_res = get_rule_based_res(holiday,data=sales_order_daily,master_label_info=master_label_info,shift_perc=10)
        input_for_dashboard = create_dataframe_for_visualization(sales_order_daily,master_label_info,holiday_impact_res,holiday)

        holiday_impact_df_list.append(holiday_impact_res)
        dashboard_df_list.append(input_for_dashboard)

    holiday_segmentation = pd.concat(holiday_impact_df_list)
    dashboard_holiday_visualization = pd.concat(dashboard_df_list)
    
    # Add reporting and snapshot date
    dashboard_holiday_visualization = add_reporting_and_snapshot_dates(dashboard_holiday_visualization,snapshot_date)
    
    print('Holiday segmentation completed. Exiting function run_holiday_segmentation().')
    
    return (holiday_segmentation,dashboard_holiday_visualization)


#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------
print('Reading data..')
sales_order_daily = pd.read_csv(env_url + sales_order_daily_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
korean_calendar = pd.read_csv(env_url + korean_calendar_api + '?accessToken=' + token)
peak_event_dict = get_holiday_wise_peak_sales()

#------------------------------------------------------------
#                Execute code and save output
#------------------------------------------------------------

holiday_segmentation,dashboard_holiday_visualization = run_holiday_segmentation(sales_order_daily,korean_calendar,snapshot_date,peak_event_dict)
output_file_path = get_output_path(data_path,job_id)
dashboard_holiday_visualization.to_csv(os.path.join(output_file_path,'3_holiday_segmentation.csv.gz'),index=False,compression = 'gzip')
'''
holiday_segmentation -> no need to save it as a csv.
dashboard_holiday_visualization -> this can be used to retreive information contained in holiday_segmentation.
'''
print('Python execution completed.')

