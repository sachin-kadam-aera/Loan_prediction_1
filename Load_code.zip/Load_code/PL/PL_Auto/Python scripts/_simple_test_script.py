#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 27 13:23:16 2022

@author: sandeepdhankhar
"""

import pandas as pd
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python "/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/_simple_test_script.py" '2022-01-17' '52' 'bf1aeddeafc141766be5655c81b8a37b' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'DSSeasonDailyLevelForAutomationTesting' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python '/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/_simple_test_script.py' '2022-01-17' '52' 'e543775859604da3724d4f487a23db93' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'DSSeasonDailyLevelForAutomationTesting' '/efs/datascience/testing' '27May2022' 

'''


#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-01-17'
    n_horizon_weeks = int('52')
    token = 'bf1aeddeafc141766be5655c81b8a37b'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_api = 'high-forecastability-grains'
    korean_calendar_api = 'DSSeasonDailyLevelForAutomationTesting'
    data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test'
    job_id = '27May2022'
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    n_horizon_weeks = int(sys.argv[2])
    token = sys.argv[3]
    env_url = sys.argv[4]
    sales_order_api = sys.argv[5]
    korean_calendar_api = sys.argv[6]
    data_path = sys.argv[7]
    job_id = sys.argv[8]
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path


#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------

sales_order = pd.read_csv(env_url + sales_order_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
korean_calendar = pd.read_csv(env_url + korean_calendar_api + '?accessToken=' + token)

#------------------------------------------------------------
#                Execute code and save output
#------------------------------------------------------------

output_file_path = get_output_path(data_path,job_id)
sales_order.to_csv(os.path.join(output_file_path,'sales_order.csv.gz'),index=False,compression = 'gzip')
korean_calendar.to_csv(os.path.join(output_file_path,'korean_calendar.csv.gz'),index=False,compression = 'gzip')
print('Python execution completed.')
