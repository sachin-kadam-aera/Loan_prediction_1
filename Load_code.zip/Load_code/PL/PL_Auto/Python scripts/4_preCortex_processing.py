#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 27 12:02:22 2022

@author: sandeepdhankhar
"""

print('Loading libraries')

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import datetime
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python '/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/4_preCortex_processing.py' '2022-01-17' '52' '3a121877505f7b396179b325c7d2ecf1' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'grains-impacted-during-holidays' 'grains-impacted-due-to-seasonality' 'DSSeasonDailyLevelForAutomationTesting' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python "/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/4_preCortex_processing.py" '2022-01-17' '52' '12f7c322d93d088c753a7619165a02be' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'grains-impacted-during-holidays' 'grains-impacted-due-to-seasonality'  'DSSeasonDailyLevelForAutomationTesting' '/efs/datascience/Pulmuone4A7' 'test' 

'''

#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-08-22'
    n_horizon_weeks = int('52')
    token = '1fa84df92ec712011ce1d6de33d44853'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_api = 'high-forecastability-grains'
    holiday_grains_api = 'grains-impacted-during-holidays'
    seasonal_grains_api = 'grains-impacted-due-to-seasonality'
    korean_calendar_api = 'korean-calendar-api'
    data_path = '/Users/sachinkadam/Pulmuone/KT/TestRun'
    job_id = '8Aug2022'
    promo_api = 'promo-week-api'
    pos_api = 'pos-sales'
    replicate_promo_in_future = int('1')
    
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    n_horizon_weeks = int(sys.argv[2])
    token = sys.argv[3]
    env_url = sys.argv[4]
    sales_order_api = sys.argv[5]
    holiday_grains_api = sys.argv[6]
    seasonal_grains_api = sys.argv[7]
    korean_calendar_api = sys.argv[8]
    data_path = sys.argv[9]
    job_id = sys.argv[10]
    promo_api = sys.argv[11]
    pos_api = sys.argv[12]
    replicate_promo_in_future = int(sys.argv[13])
    
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

################## General ##################

def glimpse(df):
    
    Data_Type = df.dtypes
    Missing_Values = df.isnull().sum()
    Unique_Values = df.nunique()

    df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
    df_out.columns = ['Data Type','Missing Values','Unique Values']
    
    return df_out

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path

def add_reporting_and_snapshot_dates(data,snapshot_date):
    data['Reporting_datetime'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data['Snapshot_date'] = snapshot_date
    return data

################## Sales Order Processing ##################

def reducing_data_till_snapshot_date(sales_order,snapshot_date):
    return sales_order[sales_order['Week Starting'] < snapshot_date]

def add_outlier_treated_sales_2mad(single_grain,window = 52):
    # NOT A VERY USEFUL METHOD
    single_grain['order_qty_lag_1'] = single_grain['Order Item Quantity'].shift(1)
    single_grain['rolling_median'] = single_grain['order_qty_lag_1'].transform(lambda x: x.rolling(window, 1).median())
    single_grain['abs_dev'] = abs(single_grain['rolling_median'] - single_grain['Order Item Quantity'])
    single_grain['median_abs_dev'] = single_grain['abs_dev'].median()
    single_grain['outlier_flag'] = np.where(single_grain['abs_dev'] >= 2* single_grain['median_abs_dev'],1,0)
    single_grain['outlier_treated_qty'] = np.where(single_grain['outlier_flag'] == 1, np.nan, single_grain['Order Item Quantity'])
    single_grain['outlier_treated_qty'] = np.round(single_grain['outlier_treated_qty'].interpolate())
    return single_grain[['Channel','Material Number','Week Starting','Order Item Quantity','outlier_flag','outlier_treated_qty']]

def apply_basic_prepcoc_steps(sales_order):
    sales_order.rename(columns = {'Channel Group':'Channel'}, inplace=True) # renaming column
    sales_order = sales_order[['Material Number','Channel','Week Starting','Order Item Quantity']] # filter columns
    sales_order['Week Starting'] = pd.to_datetime(sales_order['Week Starting'],infer_datetime_format=True) # change dtype of date column
    sales_order = sales_order.sort_values(by = ['Material Number','Channel','Week Starting']).reset_index(drop = True) # sort by grain and date
    return sales_order

def add_future_timestamps_for_multivariate(sales_order,snapshot_date,n_horizon_weeks):
    # Creating future dates
    future_timestamps = pd.DataFrame({'Week Starting' : pd.date_range(start = pd.to_datetime(snapshot_date), #+ pd.tseries.offsets.DateOffset(days = 7),
                                                                      periods = n_horizon_weeks, 
                                                                      freq = 'W-MON'),
                                      'Cross_Join_Key' : 1})
    # Finding unique grains in the sales order
    distinct_grains = sales_order[['Material Number','Channel']].drop_duplicates()
    distinct_grains['Cross_Join_Key'] = 1
    # Cross joining - this is creating timestamp against each grain
    future_timestamps_per_grain = pd.merge(distinct_grains, future_timestamps, on ='Cross_Join_Key').drop("Cross_Join_Key", 1)
    # Row bind with sales order
    enhanced_sales_order = pd.concat([sales_order,future_timestamps_per_grain], ignore_index=True).fillna(0)
    return enhanced_sales_order

def add_iso_year_week_col(date):
    iso_calendar = date.isocalendar()
    year = str(iso_calendar[0])
    week = str(iso_calendar[1])
    padded_week = [week if len(week) == 2 else '0' + week][0] # pad zero to single digit week. eg, week 1 should be 01
    return (year + padded_week)


################## Korean Calendar preprocessing ##################
def apply_basic_prepcoc_korean_cal(korean_calendar):    
    exclude_seaonal_flags = ['FALL','SUMMER','WINTER','SPRING']
    korean_calendar.drop(columns = exclude_seaonal_flags, inplace=True) # droping cols
    korean_calendar['Date'] = pd.to_datetime(korean_calendar['Date']) # converting to pandas datetime
    korean_calendar = korean_calendar.sort_values('Date').reset_index(drop = True) # sorting by date
    calendar_events = [x for x in korean_calendar.columns if x not in 'Date'] # extracting holiday names
    return (korean_calendar,calendar_events)

def create_lag_lead_features_korean_cal(korean_calendar,calendar_events):
    # Looping over each holiday to generate features
    for holiday_name in calendar_events:    
        '''
        Flag calculation logic -- 
        if a holiday starts on day 10 then
            holiday's impact is considered on days 10,11,12
            pre holiday impact is considered on days 7,8,9
            post holiday impact is considered on days 13,14,15
        '''
        korean_calendar[holiday_name] = korean_calendar[holiday_name] + korean_calendar[holiday_name].shift(1).fillna(0) + korean_calendar[holiday_name].shift(2).fillna(0)
        korean_calendar[holiday_name +'_pre'] = korean_calendar[holiday_name].shift(-3).fillna(0)
        korean_calendar[holiday_name +'_post'] = korean_calendar[holiday_name].shift(3).fillna(0)
    return korean_calendar

def create_week_starting_date_korean_cal(korean_calendar):
    # This works only if week starting date is monday
    korean_calendar['Week Starting'] = korean_calendar.apply(lambda x: x['Date']  - datetime.timedelta(days=x['Date'].weekday() % 7), 
                                                             axis = 1)
    return korean_calendar

def aggregate_to_weekly_level_korean_cal(korean_calendar):
    korean_calendar = korean_calendar.groupby('Week Starting').sum().reset_index()
    return korean_calendar

def add_segmentation_info(final_op,holiday_grains,seasonal_grains):
    impacted_grains = pd.concat([holiday_grains[['Channel','Material Number']],
                                 seasonal_grains[['Channel','Material Number']]]).drop_duplicates()
    impacted_grains['Grain Type'] = 'seasonal-segment'
    # Add
    final_op = pd.merge(final_op,impacted_grains, how = 'left', on = ['Channel','Material Number'])
    final_op['Grain Type'] = final_op['Grain Type'].fillna('non-seasonal-segment')
    return final_op
    
################## POS preprocessing ##################
def apply_basic_prepcoc_steps_pos(pos_sales):
    pos_sales = pos_sales[~(pos_sales.isnull().any(axis=1))] # remove rows with na values
    pos_sales.rename(columns = {'Channel Group Level Code':'Channel','Quantity':'POS_Quantity'}, inplace=True) # renaming column
    pos_sales['Week Starting'] = pd.to_datetime(pos_sales['Week Starting'],infer_datetime_format=True) # change dtype of date column
    pos_sales = pos_sales.sort_values(by = ['Material Number','Channel','Week Starting']).reset_index(drop = True) # sort by grain and date
    return pos_sales

def impute_missing_time_periods(singleGrain):
    singleGrain = singleGrain.set_index('Week Starting')
    newIndex = pd.date_range(start = min(singleGrain.index),end = max(singleGrain.index),freq='W-MON')
    singleGrain = singleGrain.reindex(index = newIndex)
    singleGrain.index.name = 'Week Starting'
    singleGrain[['Material Number','Channel']] = singleGrain[['Material Number','Channel']].fillna(method = 'ffill')
    singleGrain['POS_Quantity'] = singleGrain['POS_Quantity'].fillna(0)
    return singleGrain.reset_index()

def add_pos_features(sales_order,pos_sales):
    # Add to sales order
    sales_order = pd.merge(sales_order,pos_sales,on=['Channel','Material Number','Week Starting'],how='left')
    # Create lag features
    sales_order = sales_order.sort_values(by = ['Channel','Material Number','Week Starting']) # sort data
    sales_order['POS_Quantity_lag1'] = sales_order.groupby(['Channel','Material Number'])['POS_Quantity'].shift(1)
    sales_order['POS_Quantity_lag2'] = sales_order.groupby(['Channel','Material Number'])['POS_Quantity'].shift(2)
    sales_order['POS_Quantity_lag3'] = sales_order.groupby(['Channel','Material Number'])['POS_Quantity'].shift(3)
    sales_order['POS_Quantity_lag4'] = sales_order.groupby(['Channel','Material Number'])['POS_Quantity'].shift(4)
    sales_order.drop('POS_Quantity',axis=1,inplace=True) # drop POS
    # Forward fill values in future
    ffill_cols = ['POS_Quantity_lag1','POS_Quantity_lag2','POS_Quantity_lag3','POS_Quantity_lag4']
    sales_order[ffill_cols] = sales_order.groupby(['Material Number','Channel'])[ffill_cols].ffill()
    return sales_order

################## Promotions preprocessing ##################
def apply_basic_prepcoc_steps_promo(promo_info):
    promo_info.rename(columns = {'Channel Group':'Channel'}, inplace=True) # renaming column
    promo_info['Week Starting'] = pd.to_datetime(promo_info['Week Starting'],infer_datetime_format=True) # change dtype of date column
    promo_info = promo_info.sort_values(by = ['Material Number','Channel','Week Starting']).reset_index(drop = True) # sort by grain and date
    return promo_info

def apply_promo_filter(promo_info,discount_cutoff):
    promo_info = promo_info[(promo_info['Discount'] > discount_cutoff) & (promo_info['Selling Price'] > 0)] # select promo if discount is greater than certain value
    promo_info = promo_info[promo_info['Promo Type'] != 'Not Set'] # ignore not set promo
    promo_info['Promo Flag'] = 1
    promo_info = promo_info[['Channel','Material Number','Week Starting','Discount','Promo Flag']]
    return promo_info

def aggregate_promo_at_week_level(promo_info):
    promo_info = promo_info.groupby(['Channel','Material Number','Week Starting']).agg(
        {'Discount': 'mean','Promo Flag': 'max'}).reset_index()
    return promo_info

def create_future_promo_plan(promo_info):
    # Get historical promo plan
    latest_52_weeks_promo = promo_info.loc[promo_info['Week Starting'] > promo_info['Week Starting'].max() - datetime.timedelta(days = 7*52),
                                 ['Channel','Material Number','Week Starting','Discount','Promo Flag']]
    # Create future promo plan (same as observed in historical plan)
    future_52_weeks_promo = latest_52_weeks_promo
    future_52_weeks_promo['Week Starting'] = future_52_weeks_promo['Week Starting'] + datetime.timedelta(days = 7*52)
    return future_52_weeks_promo

def add_promo_features(sales_order,promo_info,future_promo_plan,replicate_promo_in_future):
    if replicate_promo_in_future == 1:
        promo = pd.concat([promo_info,future_promo_plan])
    else:
        promo = promo_info
    sales_order = pd.merge(sales_order,promo,on=['Material Number','Channel','Week Starting'],how='left')
    sales_order = sales_order.fillna({'Discount':0,'Promo Flag':0})
    return sales_order    

################## All preprocessng wrapped under this single function ##################
                             
def preCortex_processing(sales_order,korean_calendar,snapshot_date,holiday_grains,seasonal_grains,pos_sales,promo_info,replicate_promo_in_future,n_horizon_weeks):
    ## Process all data here using functions

    # Sales order preprocessing
    print('Sales order preprocessing started')
    sales_order = apply_basic_prepcoc_steps(sales_order)
    sales_order = reducing_data_till_snapshot_date(sales_order,snapshot_date) # limiting data till snapshot date
    sales_order = sales_order.groupby(['Channel','Material Number']).apply(add_outlier_treated_sales_2mad) # outlier treatment per group
    sales_order = add_future_timestamps_for_multivariate(sales_order,snapshot_date,n_horizon_weeks)
    sales_order['iso_year_week'] = sales_order.apply(lambda x: add_iso_year_week_col(x['Week Starting']),axis = 1)
    sales_order.head()

    # Korean calendar preprocessing
    print('Korean calendar preprocessing started')
    korean_calendar,calendar_events = apply_basic_prepcoc_korean_cal(korean_calendar)
    korean_calendar = create_lag_lead_features_korean_cal(korean_calendar,calendar_events) # feature engineering
    korean_calendar = create_week_starting_date_korean_cal(korean_calendar) # works only when week start date is Monday
    korean_calendar = aggregate_to_weekly_level_korean_cal(korean_calendar) # agg to weekly level

    # Merge all datasets with sales order as left table
    final_op = pd.merge(sales_order,korean_calendar,how = 'left', on = 'Week Starting').fillna(0)
    
    # Add segmentation info
    final_op = add_segmentation_info(final_op,holiday_grains,seasonal_grains)
    
    # Add reporting and snapshot date
    final_op = add_reporting_and_snapshot_dates(final_op,snapshot_date)
    print(final_op.shape)
    
    
    # Add POS data
    print('POS preprocessing started')
    pos_sales = apply_basic_prepcoc_steps_pos(pos_sales)
    pos_sales = reducing_data_till_snapshot_date(pos_sales,snapshot_date)
    pos_sales = pos_sales.groupby(['Material Number','Channel']).apply(lambda x: impute_missing_time_periods(x)).reset_index(drop=True)
    final_op = add_pos_features(final_op,pos_sales)
    print(final_op.shape)
    
    # Add promo data
    print('Promo preprocessing started')
    promo_info = apply_basic_prepcoc_steps_promo(promo_info)
    promo_info = reducing_data_till_snapshot_date(promo_info,snapshot_date)
    promo_info = apply_promo_filter(promo_info,10)
    promo_info = aggregate_promo_at_week_level(promo_info)
    future_promo_plan = create_future_promo_plan(promo_info) # assuming promo will be exactly same as last year
    final_op = add_promo_features(final_op,promo_info,future_promo_plan,replicate_promo_in_future) # add to sales order
    print(final_op.shape)
    
    print('Preprocessing completed. Exiting function preCortex_processing()')
    
    return(final_op)


#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------
print('Reading data..')
sales_order = pd.read_csv(env_url + sales_order_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
korean_calendar = pd.read_csv(env_url + korean_calendar_api + '?accessToken=' + token)
holiday_grains = pd.read_csv(env_url + holiday_grains_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
seasonal_grains = pd.read_csv(env_url + seasonal_grains_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
promo_info = pd.read_csv(env_url + promo_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
pos_sales = pd.read_csv(env_url + pos_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})

#------------------------------------------------------------
#                Execute code and save output
#------------------------------------------------------------

final_op = preCortex_processing(sales_order,korean_calendar,snapshot_date,holiday_grains,seasonal_grains,pos_sales,promo_info,replicate_promo_in_future,n_horizon_weeks)
output_file_path = get_output_path(data_path,job_id)

final_op = final_op[['Channel', 'Material Number', 'Week Starting', 'Order Item Quantity','outlier_flag', 'outlier_treated_qty', 'iso_year_week', 'BUDDA_BDAY','CHILDRENS_DAY',
                     'CHRISTMAS','CHOBOK','CHUSEOK','HANGUL_DAY','INDEPENDENCE_DAY', 'JUNGBOK', 'LUNARNY', 'MALBOK', 'MEMORIAL_DAY','NAT_FOUNDATION_DAY', 'NAT_LIBERATION_DAY', 'SOLARNY', 'WINTERSOLSTICE',
                     'BUDDA_BDAY_pre', 'BUDDA_BDAY_post', 'CHILDRENS_DAY_pre','CHILDRENS_DAY_post','CHRISTMAS_pre','CHRISTMAS_post','CHOBOK_pre', 'CHOBOK_post','CHUSEOK_pre', 'CHUSEOK_post',
                     'HANGUL_DAY_pre','HANGUL_DAY_post', 'INDEPENDENCE_DAY_pre', 'INDEPENDENCE_DAY_post','JUNGBOK_pre', 'JUNGBOK_post', 'LUNARNY_pre', 'LUNARNY_post','MALBOK_pre', 'MALBOK_post', 'MEMORIAL_DAY_pre', 'MEMORIAL_DAY_post',
                     'NAT_FOUNDATION_DAY_pre', 'NAT_FOUNDATION_DAY_post','NAT_LIBERATION_DAY_pre', 'NAT_LIBERATION_DAY_post', 'SOLARNY_pre','SOLARNY_post', 'WINTERSOLSTICE_pre', 'WINTERSOLSTICE_post',
                     'Grain Type', 'Reporting_datetime', 'Snapshot_date','POS_Quantity_lag1', 'POS_Quantity_lag2', 'POS_Quantity_lag3','POS_Quantity_lag4', 'Discount', 'Promo Flag']]

final_op.to_csv(os.path.join(output_file_path,'4_preProcessing_op.csv.gz'),index=False,compression = 'gzip')
print('Python execution completed.')









