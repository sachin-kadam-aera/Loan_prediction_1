#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 21:52:48 2022

@author: sandeepdhankhar
"""

print('Loading libraries')

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import datetime
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python '/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/4_preCortex_processing.py' '2022-01-17' '52' '3a121877505f7b396179b325c7d2ecf1' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'grains-impacted-during-holidays' 'grains-impacted-due-to-seasonality' 'DSSeasonDailyLevelForAutomationTesting' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python "/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/4_preCortex_processing.py" '2022-01-17' '52' '12f7c322d93d088c753a7619165a02be' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'grains-impacted-during-holidays' 'grains-impacted-due-to-seasonality'  'DSSeasonDailyLevelForAutomationTesting' '/efs/datascience/Pulmuone4A7' 'test' 

'''

#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 0

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-08-25'
    token = 'befa31875850b39a0156f65ba091330d'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_api = 'high-forecastability-grains'
    promo_api = 'promo-week-api'
    data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test'
    job_id = '8Aug2022'
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    token = sys.argv[3]
    env_url = sys.argv[4]
    sales_order_api = sys.argv[5]
    promo_api = sys.argv[8]
    data_path = sys.argv[9]
    job_id = sys.argv[10]
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

################## General ##################

def glimpse(df):
    
    Data_Type = df.dtypes
    Missing_Values = df.isnull().sum()
    Unique_Values = df.nunique()

    df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
    df_out.columns = ['Data Type','Missing Values','Unique Values']
    
    return df_out

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path

def add_reporting_and_snapshot_dates(data,snapshot_date):
    data['Reporting_datetime'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data['Snapshot_date'] = snapshot_date
    return data

################## Sales Order Processing ##################

def reducing_data_till_snapshot_date(sales_order,snapshot_date):
    return sales_order[sales_order['Week Starting'] < snapshot_date]


def apply_basic_prepcoc_steps(sales_order):
    sales_order.rename(columns = {'Channel Group':'Channel'}, inplace=True) # renaming column
    sales_order = sales_order[['Material Number','Channel','ABC Class','Week Starting','Order Item Quantity']] # filter columns
    sales_order['Week Starting'] = pd.to_datetime(sales_order['Week Starting'],infer_datetime_format=True) # change dtype of date column
    sales_order = sales_order.sort_values(by = ['Material Number','Channel','Week Starting']).reset_index(drop = True) # sort by grain and date
    return sales_order



################## All preprocessng wrapped under this single function ##################
                             
def promo_analysis(sales_order,promo_history,discount_cutoff):
    ## Process all data here using functions

    # Sales order preprocessing
    print('Sales order preprocessing started')
    sales_order = apply_basic_prepcoc_steps(sales_order)
    sales_order = reducing_data_till_snapshot_date(sales_order,snapshot_date) # limiting data till snapshot date

    # Promo preprocessing
    print('Promo preprocessing started')
    promo_history['Week Starting'] = pd.to_datetime(promo_history['Week Starting'],infer_datetime_format=True) # change dtype of date column
    promo_history = promo_history[(promo_history['Discount'] > discount_cutoff) & (promo_history['Selling Price'] > 0)]    
    promo_history['Promo Flag'] = 1
    
    # Merge all promo with sales order
    final_op = pd.merge(sales_order,promo_history,left_on=['Material Number', 'Channel', 'Week Starting'],
                        right_on=['Material Number', 'Channel Group', 'Week Starting'],how='left')
    final_op = final_op[final_op['ABC Class'] == 'A']    
    print('Promo Analysis completed. Exiting function promo_analysis()')

    return(final_op)


#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------
print('Reading data..')
sales_order = pd.read_csv(env_url + sales_order_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
promo_history = pd.read_csv(env_url + promo_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})

#------------------------------------------------------------
#                Execute code and save output
#------------------------------------------------------------


final_op = promo_analysis(sales_order,promo_history,20)
output_file_path = get_output_path(data_path,job_id)
final_op.to_csv('/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/3 Data/_Implementation/4 Promo Analysis/sales_with_promo.csv', index=False)
print('Python execution completed.')













