#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 29 10:47:59 2022

@author: sandeepdhankhar
"""

print('Loading libraries')

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python '/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/6_market_basket_analysis.py' '2022-06-06' 'a4df63d4fcd2260d334807e0428f3b71' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'all-grains-to-be-forecasted' 'material-hierarchy' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python "/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/6_market_basket_analysis.py" '2022-06-06' 'dd01a319b50ab4e1e606aa4000bb554d' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'all-grains-to-be-forecasted' 'material-hierarchy' '/efs/datascience/Pulmuone4A7' 'test' 

'''

#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-06-06'    
    token = '7a07551796aa9710f1ca698ec8c07b6f'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_full_api = 'all-grains-to-be-forecasted'
    material_dimension_api = 'material-hierarchy'
    data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test'
    job_id = '27May2022'
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    token = sys.argv[2]
    env_url = sys.argv[3]
    sales_order_full_api = sys.argv[4]
    material_dimension_api = sys.argv[5]
    data_path = sys.argv[6]
    job_id = sys.argv[7]
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

################## General ##################

def glimpse(df):
    
    Data_Type = df.dtypes
    Missing_Values = df.isnull().sum()
    Unique_Values = df.nunique()

    df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
    df_out.columns = ['Data Type','Missing Values','Unique Values']
    
    return df_out

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path

def add_reporting_and_snapshot_dates(data,snapshot_date):
    data['Reporting_datetime'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data['Snapshot_date'] = snapshot_date
    return data

def get_user_inputs(correlation_hierarchy, correlation_num_of_weeks):
    return ({'corr_hier':correlation_hierarchy, 'corr_weeks':correlation_num_of_weeks})

def rename_columns(sales_order,material_dimension):
    sales_order.columns = sales_order.columns.str.replace(' ','_').str.lower()
    material_dimension.columns = material_dimension.columns.str.replace(' ','_').str.lower()
    return (sales_order,material_dimension)

def reducing_data_till_snapshot_date(sales_order,snapshot_date):
    sales_order['week_starting'] = pd.to_datetime(sales_order['week_starting'])
    return sales_order[sales_order['week_starting'] < snapshot_date]

def data_processing(material_dimension,sales_order,user_ip_dict):

    ## Sales order processing
    # Find maximum date
    latest_date = max(sales_order['week_starting'])

    # Keep grains meeting data criteria
    sales_order = sales_order[(sales_order['abc_class'].isin(['A','B'])) & 
                             (sales_order['intermittency_per_grain'] < 30) &
                             (sales_order['weeks_per_grain'] >= user_ip_dict['corr_weeks']) &
                             (sales_order['week_starting'] >= (latest_date - timedelta(days = 7*user_ip_dict['corr_weeks'])))]

    # Keep limited columns
    sales_order['Grain'] = sales_order['channel_group'] + '-' + sales_order['material_number']
    sales_order = sales_order[['Grain','material_number','week_starting','order_item_quantity']].sort_values(by = 'week_starting')

    ## Material dimension processing
    material_dimension = material_dimension[['material_number',user_ip_dict['corr_hier']]]

    ## Merge
    corr_ip = pd.merge(sales_order,material_dimension,on = 'material_number')
    
    return corr_ip

def calculate_pairwise_correlation(cat_grains):
    # Find correlation
    #cat = 'PM Category - 까스류(C)'
    #cat_grains = corr_ip[corr_ip[user_ip_dict['corr_hier']] == cat]
    cat_grains_pivot = cat_grains.pivot(index = 'week_starting', columns = 'Grain', values = 'order_item_quantity')
    corr_op = cat_grains_pivot.corr().reset_index()
    corr_op = pd.melt(corr_op, id_vars= 'Grain', var_name = 'Grain2', value_name = 'correlation')
    # Remove self correlation
    corr_op = corr_op[corr_op['Grain'] != corr_op['Grain2']]
    # Remove duplicate pairs
    unique_pair = pd.DataFrame(np.sort(corr_op[['Grain','Grain2']], axis=1))
    unique_pair.columns = ['Grain','Grain2']
    unique_pair = unique_pair[~unique_pair.duplicated()]
    corr_op = pd.merge(corr_op,unique_pair,on = ['Grain','Grain2'])
    return corr_op

def run_correlation(corr_ip,user_ip_dict):
    all_categories = corr_ip[user_ip_dict['corr_hier']].unique()
    df_list = []

    # Find pairwise correlation in each category
    for cat in all_categories:
        # cat = 'PM Category - 까스류(C)'
        cat_grains = corr_ip[corr_ip[user_ip_dict['corr_hier']] == cat]
        cat_correl = calculate_pairwise_correlation(cat_grains)
        df_list.append(cat_correl)

    final_op = pd.concat(df_list)
    
    # Final formmating
    final_op = final_op[['Grain','Grain2','correlation']]    
    final_op.rename(columns = {'Grain':'Grain1'},inplace = True)
    final_op[['Channel1','Material1']] = final_op['Grain1'].str.split('-',1,expand = True)
    final_op[['Channel2','Material2']] = final_op['Grain2'].str.split('-',1,expand = True)
    
    return final_op

def add_sales_order_details(sales_order,final_op):
    sales_order['Grain'] = sales_order['channel_group'] + '-' + sales_order['material_number']
    sales_order = sales_order[['Grain','week_starting','order_item_quantity']].sort_values(by = 'week_starting')
    # Get grain1 and grain2 sales
    grain1_sales = sales_order[sales_order['Grain'].isin(final_op['Grain1'])]
    grain2_sales = sales_order[sales_order['Grain'].isin(final_op['Grain2'])]
    # Attach grain1 and grain2 sales
    final_op_with_sales = pd.merge(final_op,grain1_sales, left_on='Grain1',right_on='Grain')
    final_op_with_sales.drop(['Grain'],axis=1,inplace=True)
    final_op_with_sales.rename(columns={'order_item_quantity':'grain1_qty'},inplace=True)
    final_op_with_sales = pd.merge(final_op_with_sales,grain2_sales,
                                   left_on=['Grain2','week_starting'],right_on=['Grain','week_starting'])
    final_op_with_sales.drop(['Grain'],axis=1,inplace=True)
    final_op_with_sales.rename(columns={'order_item_quantity':'grain2_qty'},inplace=True)
    return final_op_with_sales

################## All preprocessng wrapped under this single function ##################
def main(sales_order,material_dimension,user_ip_dict,snapshot_date):
    # Column rename
    print('Renaming columns..')
    sales_order,material_dimension = rename_columns(sales_order,material_dimension)
    # Execute
    print('Processing data..')
    sales_order = reducing_data_till_snapshot_date(sales_order,snapshot_date)
    corr_ip = data_processing(material_dimension,sales_order,user_ip_dict)
    print('Running correlation between product pairs..')
    corr_op = run_correlation(corr_ip,user_ip_dict)
    corr_op = add_reporting_and_snapshot_dates(corr_op,snapshot_date)
    print('Adding sales order details with correlation..')
    corr_op_with_sales = add_sales_order_details(sales_order,corr_op)
    return corr_op_with_sales



#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------
print('Reading data..')
    
sales_order = pd.read_csv(env_url + sales_order_full_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
material_dimension = pd.read_csv(env_url + material_dimension_api + '?accessToken=' + token, dtype = {'Material number' :'str'})
user_ip_dict = get_user_inputs('hierarchy_level_3_description',52)


#------------------------------------------------------------
#                Execute code and save output
#------------------------------------------------------------

final_op = main(sales_order,material_dimension,user_ip_dict,snapshot_date)
output_file_path = get_output_path(data_path,job_id)
print('Writing data..')
final_op.to_csv(os.path.join(output_file_path,'6_market_basket.csv.gz'),index=False,compression = 'gzip')
print('Python execution completed.')








