#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 25 21:52:48 2022

@author: sandeepdhankhar
"""

print('Loading libraries')

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
from scipy import stats
import numpy as np
import datetime
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python '/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/4_preCortex_processing.py' '2022-01-17' '52' '3a121877505f7b396179b325c7d2ecf1' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'grains-impacted-during-holidays' 'grains-impacted-due-to-seasonality' 'DSSeasonDailyLevelForAutomationTesting' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python "/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/4_preCortex_processing.py" '2022-01-17' '52' '12f7c322d93d088c753a7619165a02be' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'grains-impacted-during-holidays' 'grains-impacted-due-to-seasonality'  'DSSeasonDailyLevelForAutomationTesting' '/efs/datascience/Pulmuone4A7' 'test' 

'''

#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 0

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-08-25'
    token = '36538a7c9149849810c6da1e930fd456'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_api = 'high-forecastability-grains'
    pos_api = 'pos-sales'
    data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test'
    job_id = '8Aug2022'
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    token = sys.argv[3]
    env_url = sys.argv[4]
    sales_order_api = sys.argv[5]
    promo_api = sys.argv[8]
    data_path = sys.argv[9]
    job_id = sys.argv[10]
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

################## General ##################

def glimpse(df):
    
    Data_Type = df.dtypes
    Missing_Values = df.isnull().sum()
    Unique_Values = df.nunique()

    df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
    df_out.columns = ['Data Type','Missing Values','Unique Values']
    
    return df_out

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path

def add_reporting_and_snapshot_dates(data,snapshot_date):
    data['Reporting_datetime'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data['Snapshot_date'] = snapshot_date
    return data

################## Sales Order Processing ##################

def reducing_data_till_snapshot_date(sales_order,snapshot_date):
    return sales_order[sales_order['Week Starting'] < snapshot_date]


def apply_basic_prepcoc_steps(sales_order):
    sales_order.rename(columns = {'Channel Group':'Channel'}, inplace=True) # renaming column
    sales_order = sales_order[['Material Number','Channel','ABC Class','Intermittency Per Grain','Week Starting','Order Item Quantity']] # filter columns
    sales_order['Week Starting'] = pd.to_datetime(sales_order['Week Starting'],infer_datetime_format=True) # change dtype of date column
    sales_order = sales_order.sort_values(by = ['Material Number','Channel','Week Starting']).reset_index(drop = True) # sort by grain and date
    return sales_order

def filter_grains_for_correlation(sales_order):
    '''
    Correlation can be spurious if the data properties are not good.
    Therefore, ensure good quality data by applying the following filters -
    ABC - Only AB segment
    Intermittency - Grains with intermittency <= 20%
    '''
    
    sales_order = sales_order[~((sales_order['ABC Class'] == 'C') | 
                                (sales_order['Intermittency Per Grain'] > 20))]
    return sales_order

def get_lag_features(final_op):
    final_op = final_op.sort_values(by =['Material Number', 'Channel', 'Week Starting']) # sort
    final_op['POS_Quantity_lag_1'] = final_op.groupby(['Material Number','Channel'])['POS_Quantity'].shift(1)
    final_op['POS_Quantity_lag_2'] = final_op.groupby(['Material Number','Channel'])['POS_Quantity'].shift(2)
    final_op['POS_Quantity_lag_3'] = final_op.groupby(['Material Number','Channel'])['POS_Quantity'].shift(3)
    final_op['POS_Quantity_lag_4'] = final_op.groupby(['Material Number','Channel'])['POS_Quantity'].shift(4)
    return final_op


################## Correlation analysis ##################

def get_correlation_and_significance(single_grain,col_name,lag):
    '''
    Correlation is significant if
    p_value <= 0.05 and abs(corr_coef) >= 0.5
    '''
    try:
        single_grain = single_grain[lag:] # remove nan value created introduced by lag feature creation
        correlation, cor_significance = stats.pearsonr(single_grain['Order Item Quantity'],single_grain[col_name])
        cor_significance = 1 if ((cor_significance <= 0.05) & (abs(correlation) >= 0.5)) else 0
        res = pd.Series({(col_name + '_cor') : correlation,(col_name + '_cor_significance') : cor_significance})
        return res
    except:
        pass

def get_correlation_summary(final_op):
    # Calculate correation at lag 0,1,2,3,4
    lag_0_corr = final_op.groupby(['Material Number', 'Channel']).apply(
        lambda x: get_correlation_and_significance(x,'POS_Quantity',0))
    lag_1_corr = final_op.groupby(['Material Number', 'Channel']).apply(
        lambda x: get_correlation_and_significance(x,'POS_Quantity_lag_1',1))
    lag_2_corr = final_op.groupby(['Material Number', 'Channel']).apply(
        lambda x: get_correlation_and_significance(x,'POS_Quantity_lag_2',2))
    lag_3_corr = final_op.groupby(['Material Number', 'Channel']).apply(
        lambda x: get_correlation_and_significance(x,'POS_Quantity_lag_3',3))
    lag_4_corr = final_op.groupby(['Material Number', 'Channel']).apply(
        lambda x: get_correlation_and_significance(x,'POS_Quantity_lag_4',4))
    # Merge outputs
    corr_op = pd.merge(lag_0_corr,lag_1_corr,left_index=True, right_index=True).merge(
                        lag_2_corr,left_index=True, right_index=True).merge(
                            lag_3_corr,left_index=True, right_index=True).merge(
                                lag_4_corr,left_index=True, right_index=True)
    # Print
    col_sum = corr_op.sum()
    print('Total grains considered for correlation =>',corr_op.shape[0])
    print('Significant correlation at lag 0 =>',col_sum['POS_Quantity_cor_significance'])
    print('Significant correlation at lag 1 =>',col_sum['POS_Quantity_lag_1_cor_significance'])
    print('Significant correlation at lag 2 =>',col_sum['POS_Quantity_lag_2_cor_significance'])
    print('Significant correlation at lag 3 =>',col_sum['POS_Quantity_lag_3_cor_significance'])
    print('Significant correlation at lag 4 =>',col_sum['POS_Quantity_lag_4_cor_significance'])
                          
    return (corr_op)

################## All preprocessng wrapped under this single function ##################
                             
def pos_analysis(sales_order,pos_history):
    ## Process all data here using functions

    # Sales order preprocessing
    print('Sales order preprocessing started..')
    sales_order = apply_basic_prepcoc_steps(sales_order)
    sales_order = reducing_data_till_snapshot_date(sales_order,snapshot_date) # limiting data till snapshot date
    sales_order = filter_grains_for_correlation(sales_order)

    # POS preprocessing
    print('POS preprocessing started..')
    pos_history['Week Starting'] = pd.to_datetime(pos_history['Week Starting'],infer_datetime_format=True) # change dtype of date column
    pos_history.rename(columns = {'Quantity':'POS_Quantity'},inplace=True)
    pos_history = reducing_data_till_snapshot_date(pos_history,snapshot_date) # limiting data till snapshot date
    
    # Merge POS with sales order
    final_op = pd.merge(sales_order,pos_history,left_on=['Material Number', 'Channel', 'Week Starting'],
                        right_on=['Material Number', 'Channel Group Level Code', 'Week Starting'],
                        how='inner').fillna(0)
    final_op = get_lag_features(final_op)
    
    # Find correlation
    corr_summary = get_correlation_summary(final_op).reset_index()
    
    # Merge for visualisation
    final_op = pd.merge(final_op,corr_summary,on = ['Material Number', 'Channel'])
    print('POS Analysis completed. Exiting function pos_analysis()..')

    return(corr_summary, final_op)


#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------
print('Reading data..')
sales_order = pd.read_csv(env_url + sales_order_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
pos_history = pd.read_csv(env_url + pos_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})

#-----------------------------------------s-------------------
#                Execute code and save output
#------------------------------------------------------------

corr_summary, final_op = pos_analysis(sales_order,pos_history)
output_file_path = get_output_path(data_path,job_id)
final_op.to_csv('/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/3 Data/_Implementation/5 POS Analysis/pos_op.csv',index=False)
print('Python execution completed.')











