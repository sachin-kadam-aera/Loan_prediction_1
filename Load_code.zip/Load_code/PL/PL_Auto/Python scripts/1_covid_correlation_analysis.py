#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Jun  2 15:35:21 2022

@author: sandeepdhankhar
"""

print('Loading libraries')

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import datetime
from scipy import stats
import functools
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python '/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/1_covid_correlation_analysis.py' '2022-01-17' 'dd852f627ce956bf6ce037821bdbb1fb' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'korea-covid-indices' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python "/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/1_covid_correlation_analysis.py" '2022-01-17' '12f7c322d93d088c753a7619165a02be' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' 'korea-covid-indices' '/efs/datascience/Pulmuone4A7' 'test' 

'''

#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-06-06'
    token = '9264890f090d92b04bff774327d6a992'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_api = 'high-forecastability-grains'
    covid_index_api = 'korea-covid-indices'
    data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test'
    job_id = '27May2022'
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    token = sys.argv[2]
    env_url = sys.argv[3]
    sales_order_api = sys.argv[4]
    covid_index_api = sys.argv[5]
    data_path = sys.argv[6]
    job_id = sys.argv[7]
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

################## General ##################

def glimpse(df):
    
    Data_Type = df.dtypes
    Missing_Values = df.isnull().sum()
    Unique_Values = df.nunique()

    df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
    df_out.columns = ['Data Type','Missing Values','Unique Values']
    
    return df_out

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path

def add_reporting_and_snapshot_dates(data,snapshot_date):
    data['Reporting_datetime'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data['Snapshot_date'] = snapshot_date
    return data
    

################## Sales order pre-processing ##################

def reducing_data_till_snapshot_date(sales_order,snapshot_date):
    return sales_order[sales_order['Week Starting'] < snapshot_date]

def apply_basic_prepcoc_steps(sales_order):
    #sales_order = sales_order[['Material Number','Channel','Week Starting','Order Item Quantity']] # filter columns
    sales_order.rename(columns = {'Channel Group':'Channel'}, inplace=True) # renaming column
    sales_order['Week Starting'] = pd.to_datetime(sales_order['Week Starting'],infer_datetime_format=True) # change dtype of date column
    sales_order = sales_order.sort_values(by = ['Material Number','Channel','Week Starting']).reset_index(drop = True) # sort by grain and date
    return sales_order

def xyz_definition(record):
    if record['COV'] <= 0.5:
        return'X'
    elif record['COV'] > 0.5 and record['COV']<=0.75:
        return 'Y'
    else:
        return 'Z'

def get_xyz_class(data):
    xyz_class = data.groupby(['Material Number','Channel'])['Order Item Quantity'].agg(
                              ['mean','std']).rename(columns={'mean':'Mean'}).reset_index()
    xyz_class['COV'] = xyz_class['std']/xyz_class['Mean']
    xyz_class['XYZ Class'] = xyz_class.apply(xyz_definition, axis=1)
    return xyz_class[['Material Number','Channel','XYZ Class']]

def add_xyz_class(sales_order):
    xyz_class = get_xyz_class(sales_order)
    sales_order = pd.merge(sales_order,xyz_class,on = ['Material Number','Channel'])
    return sales_order

def filter_grains_for_correlation(sales_order):
    '''
    Correlation can be spurious if the data properties are not good.
    Therefore, ensure good quality data by applying the following filters -
    ABC - Only AB segment
    XYZ - Only XY segment
    Intermittency - Grains with intermittency <= 20%
    '''
    
    sales_order = sales_order[~((sales_order['ABC Class'] == 'C') | (sales_order['XYZ Class'] == 'Z') | 
                                (sales_order['Intermittency Per Grain'] > 20))]
    return sales_order

################## Covid Index pre-processing ##################

def clean_covid_indices(covid_indices):    
    covid_indices['Date'] = pd.to_datetime(covid_indices['Date']) # datetime conversion
    covid_indices.sort_values('Date', inplace = True) # sort by date
    covid_indices = covid_indices[covid_indices['Date'] >= '2020-01-24'] # date when first covid case was reported in korea
    covid_indices.fillna(method = 'ffill', inplace = True) # fill missing values by last observed
    return covid_indices

def aggregate_covid_indices_to_weekly_level(covid_indices):
    # finding week starting - This works only if week starting date is monday
    covid_indices['Week Starting'] = covid_indices.apply(lambda x: x['Date']  - datetime.timedelta(days=x['Date'].weekday() % 7), 
                                                                 axis = 1)
    covid_indices_weekly = covid_indices.groupby(['Week Starting']).agg(new_cases = ('new_cases','sum'),
                                                                        new_deaths = ('new_deaths','sum'),
                                                                        stringency_index = ('Stringency Index','mean'))
    return covid_indices_weekly.reset_index()

################## Correlation analysis ##################

def get_correlation_and_significance(single_grain,index_name):
    '''
    Correlation is significant if
    p_value <= 0.05 and abs(corr_coef) >= 0.5
    '''
    try:
        correlation, cor_significance = stats.pearsonr(single_grain['Order Item Quantity'],single_grain[index_name])
        cor_significance = 1 if ((cor_significance <= 0.05) & (abs(correlation) >= 0.5)) else 0
        res = pd.Series({(index_name + '_cor') : correlation,(index_name + '_cor_significance') : cor_significance})
        return res
    except:
        pass

def get_correlation_summary(sales_order,covid_indices):
    sales_and_covid_idx = pd.merge(sales_order, covid_indices, on = 'Week Starting', how = 'inner') # merge sales and covid idx
    corr_df_list = []
    index_list = ['new_cases','new_deaths', 'stringency_index']
    for index in index_list: # Loop over each index
        corr_test = sales_and_covid_idx.groupby(['Material Number','Channel']).apply(lambda x: 
                                                                             get_correlation_and_significance(x,index))
        corr_df_list.append(corr_test)
    # Merge all dataframes
    df_merged = functools.reduce(lambda  left,right: pd.merge(left,right,on=['Material Number','Channel'],
                                                how='outer'), corr_df_list).reset_index()
    
    print('number of grains per index found to be significantly correlated')
    print(df_merged[['new_cases_cor_significance','new_deaths_cor_significance','stringency_index_cor_significance']].sum())
    
    return sales_and_covid_idx, df_merged

def keep_only_significant_grains(corr_summary):
    significance_cols = [col for col in corr_summary.columns if 'significance' in col]
    corr_summary['any_index_singificant'] = corr_summary[significance_cols].sum(axis = 1)
    corr_summary = corr_summary[corr_summary['any_index_singificant'] > 0]
    return corr_summary

def attach_sales_order_with_correlation(sales_and_covid_idx,corr_summary):
    corr_op = pd.merge(sales_and_covid_idx,corr_summary,on = ['Material Number','Channel'], how = 'inner')
    corr_op = corr_op[['Material Number','Channel','Week Starting','Order Item Quantity','new_cases','new_deaths',
                       'stringency_index','new_cases_cor','new_cases_cor_significance','new_deaths_cor',
                       'new_deaths_cor_significance','stringency_index_cor','stringency_index_cor_significance',
                       'any_index_singificant']]
    
    #print(corr_op[['Material Number','Channel','new_cases_cor_significance','new_deaths_cor_significance',
    #               'stringency_index_cor_significance']].drop_duplicates().sum(numeric_only = True))
    
    return corr_op

################## All correlation analysis wrapped under this single function ##################

def run_correlation_analysis(sales_order,covid_indices,snapshot_date):

    # Sales order preprocessing
    print('Sales order preprocessing started..')
    sales_order = apply_basic_prepcoc_steps(sales_order)
    sales_order = reducing_data_till_snapshot_date(sales_order,snapshot_date) # limiting data till snapshot date
    sales_order = add_xyz_class(sales_order)
    sales_order = filter_grains_for_correlation(sales_order)

    # Covid index preprocessing
    print('Covid index preprocessing started..')
    covid_indices = clean_covid_indices(covid_indices)
    covid_indices = aggregate_covid_indices_to_weekly_level(covid_indices)

    # Correlation test
    print('Running correlation test now..')
    sales_and_covid_idx, corr_summary = get_correlation_summary(sales_order,covid_indices)
    corr_summary = keep_only_significant_grains(corr_summary)
    corr_op = attach_sales_order_with_correlation(sales_and_covid_idx,corr_summary)
    #corr_op = reshape_covid_output(corr_op)

    # Add reporting and snapshot date
    corr_op = add_reporting_and_snapshot_dates(corr_op,snapshot_date)    

    print('Correlation analysis completed. Exiting function run_correlation_analysis()')
    
    return corr_op, corr_summary



#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------
print('Reading data..')
sales_order = pd.read_csv(env_url + sales_order_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})
covid_indices = pd.read_csv(env_url + covid_index_api + '?accessToken=' + token)


#------------------------------------------------------------
#                Execute code and save output
#------------------------------------------------------------

corr_op, corr_summary = run_correlation_analysis(sales_order,covid_indices,snapshot_date)
output_file_path = get_output_path(data_path,job_id)
corr_op.to_csv(os.path.join(output_file_path,'1_correlation_analysis.csv.gz'),index=False,compression = 'gzip')
print('Python execution completed.')









