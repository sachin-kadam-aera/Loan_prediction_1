#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  1 10:50:29 2022

@author: sandeepdhankhar
"""

print('Loading libraries')

import warnings
warnings.filterwarnings('ignore')
import pandas as pd
import numpy as np
import datetime
from statsmodels.tsa.stattools import acf
import statsmodels.formula.api as smf
import sys
import os

#------------------------------------------------------------
#        How to run this script via linux command line
#------------------------------------------------------------

'''

To run on local, use below command (with token updated)
/opt/anaconda3/bin/python '/Users/sandeepdhankhar/Github/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/2_seasonal_segmentation.py' '2022-01-17' 'dd852f627ce956bf6ce037821bdbb1fb' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test' '27May2022' 

To run on DS server, use below command (with token updated)
/opt/anaconda3/bin/python "/efs/datascience/aera-datascience/deploy/ds_services/Pulmuone_Automation/Python scripts/2_seasonal_segmentation.py" '2022-01-17' '12f7c322d93d088c753a7619165a02be' 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/' 'high-forecastability-grains' '/efs/datascience/Pulmuone4A7' 'test' 

'''

#------------------------------------------------------------
#                   Assign input parameters
#------------------------------------------------------------

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

print('DS Server flag set to {}'.format(ds_server_flag))

if ds_server_flag == 0:
    snapshot_date = '2022-01-17'
    token = 'a50ffe5634f4d454a924a4644a2f514d'
    env_url = 'https://app-uatirl01.aeratechnology.com/ispring/client/v3/reports/'
    sales_order_api = 'high-forecastability-grains'
    data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/23 Pulmuone/4 Testing/Python Automation Test'
    job_id = '27May2022'
    
if ds_server_flag == 1:
    snapshot_date = sys.argv[1]
    token = sys.argv[2]
    env_url = sys.argv[3]
    sales_order_api = sys.argv[4]
    data_path = sys.argv[5]
    job_id = sys.argv[6]
    
#------------------------------------------------------------
#                          Functions
#------------------------------------------------------------

################## General ##################

def glimpse(df):
    
    Data_Type = df.dtypes
    Missing_Values = df.isnull().sum()
    Unique_Values = df.nunique()

    df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
    df_out.columns = ['Data Type','Missing Values','Unique Values']
    
    return df_out

def get_output_path(data_path,job_id):
    output_files_path = os.path.join(data_path,job_id,'output')
    #Create the output directory if necessary
    try:
        os.makedirs(output_files_path)
    except:
        pass
    return output_files_path

def add_reporting_and_snapshot_dates(data,snapshot_date):
    data['Reporting_datetime'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data['Snapshot_date'] = snapshot_date
    return data

################## Sales Order Processing ##################

def reducing_data_till_snapshot_date(sales_order,snapshot_date,dateCol = 'Week Starting'):
    return sales_order[sales_order[dateCol] < snapshot_date]

def apply_basic_prepcoc_steps(sales_order, dateCol = 'Week Starting'):
    sales_order.rename(columns = {'Channel Group':'Channel'}, inplace=True) # renaming column
    sales_order = sales_order[['Material Number','Channel',dateCol,'Order Item Quantity']] # filter columns
    sales_order[dateCol] = pd.to_datetime(sales_order[dateCol],infer_datetime_format=True) # change dtype of date column
    sales_order = sales_order.sort_values(by = ['Material Number','Channel',dateCol]).reset_index(drop = True) # sort by grain and date
    return sales_order

def get_iso_week(date):
    iso_calendar = date.isocalendar()
    week = str(iso_calendar[1])
    padded_week = [week if len(week) == 2 else '0' + week][0] # pad zero to single digit week. eg, week 1 should be 01
    return padded_week

def add_iso_week(sales_order):
    sales_order['Week_Number'] = sales_order['Week Starting'].apply(lambda x: get_iso_week(x))
    return sales_order

################## Segmentation - Calendar Seasonality ##################

def test_seasonality(ts, freq):
    '''
    This seasonality detection code is taken from statsmodel library's theta model 
    https://www.statsmodels.org/devel/_modules/statsmodels/tsa/forecasting/theta.html#ThetaModel
    Critical value for Chi Square Test
    https://people.richland.edu/james/lecture/m170/tbl-chi.html
    '''
    rho = acf(ts, nlags=freq, fft=True)
    nobs = ts.shape[0]
    stat = nobs * rho[-1] ** 2 / np.sum(rho[:-1] ** 2)
    # CV is 10% from a chi2(1), 1.645**2
    # has_seasonality = stat > 2.705543454095404
    # CV is 5% from a chi2(1)
    has_seasonality = stat > 3.841
    return has_seasonality

def extract_seasonal_grains(sales_order):
    # Run seasonality test per grain
    is_seasonal = sales_order.groupby(['Material Number','Channel']).apply(
        lambda x: test_seasonality(x['Order Item Quantity'],52)).reset_index(name = 'Seasonality Flag')
    is_seasonal = is_seasonal[is_seasonal['Seasonality Flag'] == True] # keep only True
    print('{num_of_seasonal_grains} found seasonal using Seasonality test'.format(num_of_seasonal_grains = is_seasonal['Seasonality Flag'].sum()))
    # Filter only seasonal grains
    sales_order_seasonal = pd.merge(sales_order,is_seasonal, how = 'inner', on = ['Material Number','Channel'])
    return sales_order_seasonal


################## Segmentation - Extract Seasonal Period ##################

def get_ref_week(single_grain):
    avg_sales_by_week = single_grain.groupby('Week_Number').agg(avg_sales_order = ('Order Item Quantity', 'mean')).reset_index()
    ref_week = avg_sales_by_week.loc[ avg_sales_by_week['avg_sales_order'].idxmin() ,'Week_Number']
    return ref_week

def get_seasonal_weeks_using_ols(single_grain, ref_week, depend_var = "Order_Item_Quantity", independ_var = "Week_Number"):
    reg_formula = "{y} ~ C({x}, Treatment('{ref_week}'))".format(y = depend_var, x = independ_var, ref_week = ref_week)
    res = smf.ols(formula = reg_formula, data = single_grain).fit()
    significant_variables = res.pvalues[res.pvalues <= 0.05].index
    seasonal_weeks = [x[-3:-1] for x in significant_variables]
    return pd.DataFrame({'Seasonal_Weeks' :seasonal_weeks})

def get_seasonal_period_per_grain(single_grain):
    ref_week = get_ref_week(single_grain)
    single_grain.rename(columns = {'Order Item Quantity' : 'Order_Item_Quantity'}, inplace = True) # rename
    seasonal_weeks = get_seasonal_weeks_using_ols(single_grain,ref_week,'Order_Item_Quantity','Week_Number')
    return seasonal_weeks

def extract_seasonal_periods(seasonal_sales_order):
    # Identify weeks that are seasonal per grain
    seasonal_weeks_all_grains = seasonal_sales_order.groupby(['Material Number','Channel']).apply(get_seasonal_period_per_grain).reset_index()
    seasonal_weeks_all_grains.drop(columns = ['level_2'], inplace = True)
    seasonal_weeks_all_grains['Is_seasonal_period'] = 1
    # Attach with sales order
    seasonal_segmentation =  pd.merge(seasonal_sales_order,seasonal_weeks_all_grains,
                                      how='left',
                                      left_on=['Material Number','Channel','Week_Number'], 
                                      right_on = ['Material Number','Channel','Seasonal_Weeks']).fillna(0)
    seasonal_segmentation.drop(columns = 'Seasonal_Weeks',inplace = True)
    return seasonal_segmentation

################## All segmentation code wrapped under this single function ##################

def run_seasonality_segmentation(sales_order,snapshot_date):
    # Sales order preprocessing
    print('Sales order preprocessing started..')
    sales_order = apply_basic_prepcoc_steps(sales_order)
    sales_order = reducing_data_till_snapshot_date(sales_order,snapshot_date) # limiting data till snapshot date
    sales_order = add_iso_week(sales_order)

    # Seasonality Test
    print('Seasonality classification started..')
    seasonal_sales_order = extract_seasonal_grains(sales_order)

    # Identify seasonal period/week
    print('Seasonal period extraction started..')
    seasonal_segmentation = extract_seasonal_periods(seasonal_sales_order)
    
    # Add reporting and snapshot date
    seasonal_segmentation = add_reporting_and_snapshot_dates(seasonal_segmentation,snapshot_date)
    
    print('Segmentation completed. Exiting run_seasonality_segmentation()')
    
    return seasonal_segmentation


#------------------------------------------------------------
#                Read Input data from reports
#------------------------------------------------------------
print('Reading data..')
sales_order = pd.read_csv(env_url + sales_order_api + '?accessToken=' + token, dtype = {'Material Number' :'str'})

#------------------------------------------------------------
#                Execute code and save output
#------------------------------------------------------------

seasonal_segmentation = run_seasonality_segmentation(sales_order,snapshot_date)
output_file_path = get_output_path(data_path,job_id)
seasonal_segmentation.to_csv(os.path.join(output_file_path,'2_seasonal_segmentation.csv.gz'),index=False,compression = 'gzip')
print('Python execution completed.')

