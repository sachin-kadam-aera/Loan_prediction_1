drop table if exists tmp_4_preProcessing_op;
create table tmp_4_preProcessing_op
(
dd_Channel varchar(100), 
dd_Material_Number varchar(100), 
dd_Week_Starting varchar(100), 
ct_Order_Itemd_Quantity decimal(18,4),
ct_outlier_flag decimal(18,4),
ct_outlier_treated_qty decimal(18,4),
dd_iso_year_week varchar(100), 
ct_BUDDA_BDAY decimal(18,4),
ct_CHILDRENS_DAY decimal(18,4), 
ct_CHRISTMAS decimal(18,4), 
ct_CHOBOK decimal(18,4), 
ct_CHUSEOK decimal(18,4), 
ct_HANGUL_DAY decimal(18,4),
ct_INDEPENDENCE_DAY decimal(18,4), 
ct_JUNGBOK decimal(18,4), 
ct_LUNARNY decimal(18,4), 
ct_MALBOK decimal(18,4), 
ct_MEMORIAL_DAY decimal(18,4),
ct_NAT_FOUNDATION_DAY decimal(18,4), 
ct_NAT_LIBERATION_DAY decimal(18,4), 
ct_SOLARNY decimal(18,4),
ct_WINTERSOLSTICE decimal(18,4), 
ct_BUDDA_BDAY_pre decimal(18,4), 
ct_BUDDA_BDAY_post decimal(18,4),
ct_CHILDRENS_DAY_pre decimal(18,4), 
ct_CHILDRENS_DAY_post decimal(18,4), 
ct_CHRISTMAS_pre decimal(18,4),
ct_CHRISTMAS_post decimal(18,4), 
ct_CHOBOK_pre decimal(18,4), 
ct_CHOBOK_post decimal(18,4), 
ct_CHUSEOK_pre decimal(18,4),
ct_CHUSEOK_post decimal(18,4), 
ct_HANGUL_DAY_pre decimal(18,4), 
ct_HANGUL_DAY_post decimal(18,4),
ct_INDEPENDENCE_DAY_pre decimal(18,4), 
ct_INDEPENDENCE_DAY_post decimal(18,4), 
ct_JUNGBOK_pre decimal(18,4),
ct_JUNGBOK_post decimal(18,4), 
ct_LUNARNY_pre decimal(18,4), 
ct_LUNARNY_post decimal(18,4), 
ct_MALBOK_pre decimal(18,4),
ct_MALBOK_post decimal(18,4), 
ct_MEMORIAL_DAY_pre decimal(18,4), 
ct_MEMORIAL_DAY_post decimal(18,4),
ct_NAT_FOUNDATION_DAY_pre decimal(18,4), 
ct_NAT_FOUNDATION_DAY_post decimal(18,4),
ct_NAT_LIBERATION_DAY_pre decimal(18,4),
ct_NAT_LIBERATION_DAY_post decimal(18,4),
ct_SOLARNY_pre decimal(18,4),
ct_SOLARNY_post decimal(18,4), 
ct_WINTERSOLSTICE_pre decimal(18,4), 
ct_WINTERSOLSTICE_post decimal(18,4),
dd_Grain_type varchar(100),
dd_Reporting_datetime varchar(100),
dd_Snapshot_date varchar(100),
ct_POS_Quantity_lag1 decimal(18,4),
ct_POS_Quantity_lag2 decimal(18,4),
ct_POS_Quantity_lag3 decimal(18,4),
ct_POS_Quantity_lag4 decimal(18,4),
ct_Discount decimal(18,4),
ct_Promo_Flag decimal(18,0)
);

IMPORT INTO tmp_4_preProcessing_op
FROM LOCAL CSV FILE '/efs/datascience/Pulmuone4A7/data/var_jobid/output/4_preProcessing_op.csv.gz'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

-- Push into Fact table
DROP TABLE IF EXISTS fact_4_preProcessing_op;
CREATE TABLE fact_4_preProcessing_op AS SELECT * FROM tmp_4_preProcessing_op;

-- Create a column to link material dimension
ALTER TABLE fact_4_preProcessing_op ADD COLUMN dim_Material_ID VARCHAR(255);

-- Create a column to link channel dimension
ALTER TABLE fact_4_preProcessing_op ADD COLUMN dim_channel_group_id varchar(255);