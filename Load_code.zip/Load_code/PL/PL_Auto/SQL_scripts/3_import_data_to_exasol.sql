drop table if exists tmp_3_holiday_segmentation;
create table tmp_3_holiday_segmentation
(
dd_season_name varchar(100),
DD_Material_Number varchar(100),
DD_Channel varchar(100),
DD_date varchar(100),
dd_season_label varchar(100),
ct_Order_Item_Quantity decimal(18,4),
ct_order_qty_season decimal(18,4),
dd_Reporting_datetime varchar(100),
dd_Snapshot_date varchar(100)
);

IMPORT INTO tmp_3_holiday_segmentation
FROM LOCAL CSV FILE '/efs/datascience/Pulmuone4A7/data/var_jobid/output/3_holiday_segmentation.csv.gz'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

-- Push into Fact table
DROP TABLE IF EXISTS fact_3_holiday_segmentation;
CREATE TABLE fact_3_holiday_segmentation AS SELECT * FROM tmp_3_holiday_segmentation;

-- Create a column to link material dimension
ALTER TABLE fact_3_holiday_segmentation ADD COLUMN dim_Material_ID VARCHAR(255);

-- Create a column to link channel dimension
ALTER TABLE fact_3_holiday_segmentation ADD COLUMN dim_channel_group_id varchar(255);