drop table if exists Temp_datapulmuone_salesorder;
create table Temp_datapulmuone_salesorder
(
DD_ABC_Class varchar(5),
DD_Material_Number varchar(100),
DD_Channel varchar(100),
DD_Week_Starting varchar(10),
ct_Order_Item_Quantity decimal(18,0),
ct_Weeks_Per_Grain decimal(18,0),
ct_Intermittency_Per_Grain decimal(18,4)
);

IMPORT INTO Temp_datapulmuone_salesorder
FROM LOCAL CSV FILE '/efs/datascience/Pulmuone4A7/data/var_jobid/output/sales_order.csv.gz'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;
