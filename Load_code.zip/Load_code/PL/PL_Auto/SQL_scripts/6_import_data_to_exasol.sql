drop table if exists tmp_6_market_basket;
create table tmp_6_market_basket
(
    dd_grain1 varchar(100),
    dd_grain2 varchar(100),
    ct_correlaion decimal(18,4),
    dd_channel_group_1 varchar(100),
    dd_material_number_1 varchar(100),
    dd_channel_group_2 varchar(100),
    dd_material_number_2 varchar(100),
    dd_reporting_date varchar(100),
    dd_snapshot_date varchar(100),
    dd_week_starting date,
    ct_order_qty_grain1 decimal(18,2),
    ct_order_qty_grain2 decimal(18,2)
);


IMPORT INTO tmp_6_market_basket
FROM LOCAL CSV FILE '/efs/datascience/Pulmuone4A7/data/var_jobid/output/6_market_basket.csv.gz'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

-- Push into Fact table
DROP TABLE IF EXISTS fact_6_market_basket_op;
CREATE TABLE fact_6_market_basket_op AS SELECT * FROM tmp_6_market_basket;

-- Create a column to link material dimension
ALTER TABLE fact_6_market_basket_op ADD COLUMN dim_Material_ID VARCHAR(255);
ALTER TABLE fact_6_market_basket_op ADD COLUMN dim_Material_ID_2 VARCHAR(255);

ALTER TABLE fact_6_market_basket_op ADD COLUMN dim_channel_group_id varchar(255);
 ALTER TABLE fact_6_market_basket_op ADD COLUMN dim_channel_group_id2 varchar(255);