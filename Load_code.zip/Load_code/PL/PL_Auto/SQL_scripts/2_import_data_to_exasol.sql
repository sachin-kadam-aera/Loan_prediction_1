drop table if exists tmp_2_seasonal_segmentation;
create table tmp_2_seasonal_segmentation
(
DD_Material_Number varchar(100),
dd_channel varchar(100),
DD_Week_Starting varchar(100),
ct_Order_Item_Quantity decimal(18,4),
dd_week_number varchar(100),
dd_seasonality_flag varchar(10),
ct_is_seasonal_period decimal(18,4),
dd_Reporting_datetime varchar(100),
dd_Snapshot_date varchar(100)
);

IMPORT INTO tmp_2_seasonal_segmentation
FROM LOCAL CSV FILE '/efs/datascience/Pulmuone4A7/data/var_jobid/output/2_seasonal_segmentation.csv.gz'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

-- Push into Fact table
DROP TABLE IF EXISTS fact_2_seasonal_segmentation;
CREATE TABLE fact_2_seasonal_segmentation AS SELECT * FROM tmp_2_seasonal_segmentation;

-- Create a column to link material dimension
ALTER TABLE fact_2_seasonal_segmentation ADD COLUMN dim_Material_ID VARCHAR(255);

-- Create a column to link channel dimension
ALTER TABLE fact_2_seasonal_segmentation ADD COLUMN dim_channel_group_id varchar(255);