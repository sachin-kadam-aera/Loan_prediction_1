drop table if exists tmp_1_correlation_analysis;
create table tmp_1_correlation_analysis
(
dd_material_number varchar(100),
dd_channel varchar(100),
dd_week_starting varchar(100),
ct_Order_Item_Quantity decimal(18,4),
ct_new_cases decimal(18,4),
ct_new_deaths decimal(18,4),
ct_stringency_index decimal(18,4),
ct_new_cases_cor decimal(18,4),
ct_new_cases_cor_significance decimal(18,4),
ct_new_deaths_cor decimal(18,4),
ct_new_deaths_cor_significance decimal(18,4),
ct_stringency_index_cor decimal(18,4),
ct_stringency_index_cor_significance decimal(18,4),
ct_any_index_singificant decimal(18,4),
dd_Reporting_datetime varchar(100),
dd_Snapshot_date varchar(100)
);

IMPORT INTO tmp_1_correlation_analysis
FROM LOCAL CSV FILE '/efs/datascience/Pulmuone4A7/data/var_jobid/output/1_correlation_analysis.csv.gz'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

-- Push into Fact table
DROP TABLE IF EXISTS fact_1_correlation_analysis;
CREATE TABLE fact_1_correlation_analysis AS SELECT * FROM tmp_1_correlation_analysis;

-- Create a column to link material dimension
ALTER TABLE fact_1_correlation_analysis ADD COLUMN dim_Material_ID VARCHAR(255);

-- Create a column to link channel dimension
ALTER TABLE fact_1_correlation_analysis ADD COLUMN dim_channel_group_id varchar(255);