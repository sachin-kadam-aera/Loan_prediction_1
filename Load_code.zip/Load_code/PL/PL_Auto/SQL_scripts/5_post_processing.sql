OPEN SCHEMA PULMUONE4A7;


/*
Input tables
	- tmp_forecast_orchestration -> populated through skill (process - 5E1C53FD_2B57_425A_8C50_A247E05ED35F)
	- FACT_AGGREGATED_SALES_ORDERS_EURO -> populated every week with a SQL script (owner - Andrie Ignat)
	- tmp_forecast_op_seasonal -> populated through skill (process - 5E1C53FD_2B57_425A_8C50_A247E05ED35F)
	- tmp_forecast_op_nonseasonal -> populated through skill (process - 5E1C53FD_2B57_425A_8C50_A247E05ED35F)
	
ETL Operations
	1. Compute forecat configuration (last date and horizon date)
	2. Extract data for which naive forecast will be generated !(intermittency <= 50 and no_weeks >=26)
	3. Roll up this data to a weekly level
	4. Compute average sales of these grains in past n weeks
	5. Generate forecast table for these grains - 
	6. Consolidate the forecast from diff sources
		1. tmp_forecast_op -> generated in step 5
		2. tmp_forecast_op_seasonal -> input
		3. tmp_forecast_op_nonseasonal -> input
		4. add reporting date, snapshot date, and job id cols
	7. Extract the shap output for seasonal forecast and save
	8. Save job id information for TF skill
		
Output tables
	- tmp_consolidated_forecast_op
	- tmp_final_shap_op
	- tmp_job_id
 */

/*

tmp_forecast_orchestration -> updated through the skill

-- One time creation script
DROP TABLE IF EXISTS tmp_forecast_orchestration;
CREATE TABLE tmp_forecast_orchestration AS ( 
	SELECT  CURRENT_TIMESTAMP AS REPORTING_DATE,
			TO_DATE('2020-01-01','YYYY-MM-DD') AS SNAPSHOT_DATE,
			TO_NUMBER('22') AS HOLDOUT_DATE,
			TO_NUMBER('22') AS LAST_DATE,
			TO_NUMBER('22') AS HORIZON_DATE,
			TO_NUMBER('22') AS N_WEEKS_FOR_AVG_FORECAST,
			'MONDAY' AS WEEK_STARTING_DAY
);
SELECT * FROM tmp_forecast_orchestration;


*/




/******************** 1. Compute forecat configuration (last date and horizon date) ********************/

-- Calculate last date, holdout date and horizon date
DROP TABLE IF EXISTS tmp_forecast_date_config;
CREATE TABLE tmp_forecast_date_config AS (
	SELECT TO_DATE(TO_CHAR(SELECT LAST_DATE FROM tmp_forecast_orchestration),'IYYYIW') AS LAST_DATE,
			TO_DATE(TO_CHAR(SELECT HORIZON_DATE FROM tmp_forecast_orchestration),'IYYYIW') AS HORIZON_DATE,
			TO_DATE(TO_CHAR(SELECT HOLDOUT_DATE FROM tmp_forecast_orchestration),'IYYYIW') AS HOLDOUT_DATE
	FROM tmp_forecast_orchestration
);


/******************** 2. Extract data for which naive forecast will be generated !(intermittency <= 50 and no_weeks >=26) ********************/

-- Filter low forecastable grains based on condition
DROP TABLE IF EXISTS tmp_low_forecastable_grains;
CREATE TABLE tmp_low_forecastable_grains AS 
	(SELECT DD_MATERIAL_NUMBER ,DD_CHANNEL_GROUP ,DD_DATE ,CT_ORDER_ITEM_QTY 
	FROM FACT_AGGREGATED_SALES_ORDERS_EURO fpse 
	WHERE NOT (CT_INTERMITTENCY_PER_GRAIN <= 50 AND CT_WEEKS_PER_GRAIN >= 26)
);

/******************** 3. Roll up this data to a weekly level ********************/

-- Add weekly date
DROP TABLE IF EXISTS tmp_lfg_week_date;
CREATE TABLE tmp_lfg_week_date AS (
	SELECT * FROM tmp_low_forecastable_grains tlfg
	INNER JOIN 
	(SELECT DATEVALUE ,WEEKSTARTDATE_BASEDONWEEK FROM DIM_SIMPLE_DATE) dsd
	ON tlfg.DD_DATE = dsd.DATEVALUE
);

-- Aggregate to weekly level & sort by channel, material, date
DROP TABLE IF EXISTS tmp_lfg_agg_week_level;
CREATE TABLE tmp_lfg_agg_week_level AS (
	SELECT DD_MATERIAL_NUMBER,DD_CHANNEL_GROUP,WEEKSTARTDATE_BASEDONWEEK, 
			SUM(CT_ORDER_ITEM_QTY) AS CT_ORDER_ITEM_QTY  
	FROM tmp_lfg_week_date
	GROUP BY DD_MATERIAL_NUMBER,DD_CHANNEL_GROUP,WEEKSTARTDATE_BASEDONWEEK
	ORDER BY DD_MATERIAL_NUMBER,DD_CHANNEL_GROUP,WEEKSTARTDATE_BASEDONWEEK
);

/******************** 4. Compute average sales of these grains in past n weeks ********************/

-- Extract last n (12) periods per group 
DROP TABLE IF EXISTS tmp_last_n_weeks_orders;
CREATE TABLE tmp_last_n_weeks_orders AS (
	SELECT * FROM tmp_lfg_agg_week_level
	WHERE WEEKSTARTDATE_BASEDONWEEK BETWEEN  
	ADD_WEEKS((SELECT snapshot_date FROM tmp_forecast_orchestration), -(SELECT N_WEEKS_FOR_AVG_FORECAST FROM tmp_forecast_orchestration)) AND 
	(SELECT snapshot_date FROM tmp_forecast_orchestration)
);


-- Find average sales per group , this will be the forecast
DROP TABLE IF EXISTS tmp_avg_forecast;
CREATE TABLE tmp_avg_forecast AS ( 
	SELECT DD_MATERIAL_NUMBER, DD_CHANNEL_GROUP, 
			SUM(CT_ORDER_ITEM_QTY)/(SELECT N_WEEKS_FOR_AVG_FORECAST FROM tmp_forecast_orchestration) AS AVG_FORECAST
	FROM tmp_last_n_weeks_orders
	GROUP BY DD_MATERIAL_NUMBER, DD_CHANNEL_GROUP
);

/******************** 5. Generate forecast table for these grains ********************/

-- Create forecast period timestamps
DROP TABLE IF EXISTS tmp_date_seq;
CREATE TABLE tmp_date_seq AS (
	select
	 add_days(ADD_DAYS((SELECT LAST_DATE FROM tmp_forecast_date_config), 7), level-1) as dates
	from dual
	connect by level <= days_between((SELECT HORIZON_DATE FROM tmp_forecast_date_config),
	ADD_DAYS((SELECT LAST_DATE FROM tmp_forecast_date_config), 7))+1
	order by local.dates
);
DELETE FROM tmp_date_seq WHERE TRIM(TO_CHAR(dates,'DAY'))  != (SELECT WEEK_STARTING_DAY FROM tmp_forecast_orchestration);

-- Create forecasting table
DROP TABLE IF EXISTS tmp_distinct_grains;
CREATE TABLE tmp_distinct_grains AS (
	SELECT DISTINCT (DD_MATERIAL_NUMBER, DD_CHANNEL_GROUP) FROM tmp_avg_forecast
);

DROP TABLE IF EXISTS tmp_forecast_op_base;
CREATE TABLE tmp_forecast_op_base AS (
	SELECT * FROM tmp_date_seq
	CROSS JOIN tmp_distinct_grains
);

-- Add forecast timestamps to weekly data
INSERT INTO tmp_lfg_agg_week_level (DD_MATERIAL_NUMBER, DD_CHANNEL_GROUP, WEEKSTARTDATE_BASEDONWEEK)
SELECT (DD_MATERIAL_NUMBER, DD_CHANNEL_GROUP, dates) FROM tmp_forecast_op_base;


-- Add avg forecast
DROP TABLE IF EXISTS tmp_forecast_op;
CREATE TABLE tmp_forecast_op AS (
	SELECT tfob.*, taf.avg_forecast FROM tmp_lfg_agg_week_level tfob
	LEFT JOIN tmp_avg_forecast taf
	ON tfob.DD_MATERIAL_NUMBER = taf.DD_MATERIAL_NUMBER AND 
	tfob.DD_CHANNEL_GROUP = taf.DD_CHANNEL_GROUP
);

-- Add forecast algorithm
ALTER TABLE tmp_forecast_op ADD DD_FORECASTALGORITHM VARCHAR(100) UTF8;
UPDATE tmp_forecast_op SET DD_FORECASTALGORITHM = 'FALL_BACK_NAIVE';


/******************** 6. Consolidate the forecast from different sources ********************/

-- Merge the seasonal, non-seasonal, and naive forecast output here
DROP TABLE IF EXISTS tmp_consolidated_forecast_op;
CREATE TABLE tmp_consolidated_forecast_op(
DD_SNAPSHOT_DATE DATE,
DD_REPORTING_DATE TIMESTAMP,
DD_MATERIAL_NUMBER VARCHAR(100) UTF8,
DD_CHANNEL_GROUP VARCHAR(100) UTF8,
DD_FORECASTALGORITHM VARCHAR(100) UTF8,
DD_FORECAST_DATE DATE,
CT_ACTUAL_ORDER_QTY DECIMAL(20,2),
CT_FORECAST_QTY DECIMAL(20,2)
);


--Seasonal
INSERT INTO tmp_consolidated_forecast_op(DD_CHANNEL_GROUP,DD_MATERIAL_NUMBER,DD_FORECASTALGORITHM,DD_FORECAST_DATE,CT_ACTUAL_ORDER_QTY,CT_FORECAST_QTY)
SELECT (DD_GRAIN1, DD_GRAIN2, DD_FORECASTALGORITHM, DD_FORECASTDATE, CT_SALESQUANTITY, CT_FORECASTQUANTITY) FROM tmp_forecast_op_seasonal
WHERE DD_FORECASTRANK = '1';

--Non-seasonal
INSERT INTO tmp_consolidated_forecast_op(DD_CHANNEL_GROUP,DD_MATERIAL_NUMBER,DD_FORECASTALGORITHM,DD_FORECAST_DATE,CT_ACTUAL_ORDER_QTY,CT_FORECAST_QTY)
SELECT (DD_GRAIN1, DD_GRAIN2, DD_FORECASTALGORITHM, DD_FORECASTDATE, CT_SALESQUANTITY, CT_FORECASTQUANTITY) FROM tmp_forecast_op_nonseasonal
WHERE DD_FORECASTRANK = '1';

--Non-forecastable grains (avg forecast)
INSERT INTO tmp_consolidated_forecast_op(DD_MATERIAL_NUMBER,DD_CHANNEL_GROUP,DD_FORECASTALGORITHM,DD_FORECAST_DATE,CT_ACTUAL_ORDER_QTY,CT_FORECAST_QTY)
SELECT (DD_MATERIAL_NUMBER, DD_CHANNEL_GROUP, DD_FORECASTALGORITHM, WEEKSTARTDATE_BASEDONWEEK, CT_ORDER_ITEM_QTY, AVG_FORECAST) FROM tmp_forecast_op;

--Update reporting date, snapshot date
UPDATE tmp_consolidated_forecast_op
SET DD_SNAPSHOT_DATE = (SELECT SNAPSHOT_DATE FROM tmp_forecast_orchestration),
	DD_REPORTING_DATE = (SELECT REPORTING_DATE FROM tmp_forecast_orchestration);

--Update Job id - concatenation of seasoanl & non-seasonal job ids
ALTER TABLE tmp_consolidated_forecast_op ADD DD_JOBID VARCHAR(100) UTF8;
UPDATE tmp_consolidated_forecast_op
SET DD_JOBID = (
SELECT CONCAT((SELECT DISTINCT DD_JOBID FROM tmp_forecast_op_seasonal),'_',(SELECT DISTINCT DD_JOBID FROM tmp_forecast_op_nonseasonal)));

/******************** 7. Extract the shap output for seasonal forecast and save ********************/

-- extract seasonal SHAP output
DROP TABLE IF EXISTS tmp_shap_op;
CREATE TABLE tmp_shap_op AS (
	SELECT * FROM FACT_CORTEX_SHAP_IMPORTANCE 
	WHERE DD_JOBID IN (SELECT DISTINCT DD_JOBID FROM tmp_forecast_op_seasonal )
);

-- extract rank 1 algorithm from shap output
DROP TABLE IF EXISTS tmp_final_shap_op;
CREATE TABLE tmp_final_shap_op AS (
SELECT f.DD_JOBID, f.DD_GRAIN1 ,f.DD_GRAIN2 ,f.DD_GRAIN3 ,f.DD_MODEL , f.DD_FORECASTDATE ,f.DD_IMPORTANTVARIABLE ,f.CT_IMPORTANCE 
FROM tmp_shap_op f
INNER JOIN (SELECT * FROM tmp_forecast_op_seasonal WHERE DD_FORECASTRANK = '1') s
ON  
f.DD_GRAIN1 = s.DD_GRAIN1 AND 
f.DD_GRAIN2 = s.DD_GRAIN2 AND 
f.DD_MODEL = s.DD_FORECASTALGORITHM AND
f.DD_FORECASTDATE = s.DD_FORECASTDATE
);

--update new job id
UPDATE tmp_final_shap_op
SET DD_JOBID = (
SELECT CONCAT((SELECT DISTINCT DD_JOBID FROM tmp_forecast_op_seasonal),'_',(SELECT DISTINCT DD_JOBID FROM tmp_forecast_op_nonseasonal)));

-- insert columns for reporting date, snapshot date, and datE class
ALTER TABLE tmp_final_shap_op ADD DD_SNAPSHOT_DATE DATE;
ALTER TABLE tmp_final_shap_op ADD DD_REPORTING_DATE TIMESTAMP;
ALTER TABLE tmp_final_shap_op ADD DD_DATE_CLASS VARCHAR(10) UTF8;


UPDATE tmp_final_shap_op
SET 
DD_SNAPSHOT_DATE = (SELECT SNAPSHOT_DATE FROM tmp_forecast_orchestration),
DD_REPORTING_DATE = (SELECT REPORTING_DATE FROM tmp_forecast_orchestration),
DD_DATE_CLASS = 
	CASE 
		WHEN DD_FORECASTDATE <= (SELECT SNAPSHOT_DATE FROM tmp_forecast_orchestration) THEN 'TRAIN'
		ELSE 'HORIZON'
	END;



/******************** 8. Save job id information for TF skill ********************/

DROP TABLE IF EXISTS tmp_jobid;
CREATE TABLE tmp_jobid AS (
	SELECT CONCAT((SELECT DISTINCT DD_JOBID FROM tmp_forecast_op_seasonal),'_',(SELECT DISTINCT DD_JOBID FROM tmp_forecast_op_nonseasonal)) 
	AS DD_JOBID
);








