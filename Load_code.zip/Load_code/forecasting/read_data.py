# -*- coding: utf-8 -*-
"""
Created by Anshuman Lall
Reads sales data and generate forecast
"""

import pandas as pd
import numpy as np
import forecast_config
from datetime import datetime
from imputingMissingValues import imputingMissingValues
from validation import data_validation
def read_data(input_file):
    # Get the configuration information
    conf_read_input = forecast_config.getConfig('RunScript')
    input_columns = conf_read_input['input_columns']
    last_date = conf_read_input['last_date']
    minimum_quantity = int(conf_read_input['minimum_quantity'])
    # IMPORT HISTORICAL SALES DATA
    time_frequency = conf_read_input['time_frequency']
    data = pd.read_csv(input_file, sep=conf_read_input["separator"], low_memory=False, header=None, \
                       names=input_columns.split(','), \
                       dtype={'UIN': np.str, 'CompanyCode': np.str})
    if time_frequency=="Monthly":
        data = monthly_datetransformation(data)
    validation_test = data_validation(data)
    if validation_test==False:
        print "Validation Failure, Please check data"
        return False
    data = imputingMissingValues(data,last_date,time_frequency)
    data.to_csv(input_file[:-4]+"_imputed.csv",index=False,header=False)
    data = data.sort_values(['UIN', 'Comop','YYYYMMDD'],ascending=[1,1,1])
    data['Month'] = data.YYYYMMDD.apply(lambda x: str(int(x % 10000)/100).zfill(2))
    data['WeekNumber'] = data.YYYYMMDD.apply(lambda x: datetime.strptime(str(x),'%Y%m%d').strftime('%W'))
#   # print "WeekNumber",data.WeekNumber.unique()
    data.Sales = data.Sales.apply(lambda x: max(minimum_quantity, x))
    return data

def monthly_datetransformation(data):
    try:
        data['YYYYMMDD'] = pd.to_datetime(data['YYYYMMDD'], format='%Y%m').dt.strftime('%Y%m%d')
        return data
    except:
        return data
