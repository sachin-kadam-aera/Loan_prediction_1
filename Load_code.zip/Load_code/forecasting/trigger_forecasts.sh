#!/bin/sh
set -vx
dt=`date '+%Y%m%d.%H_%M'`

echo "Please provide the file that has list of ini files"
read inilist

if [ ! -d logs ]
then
mkdir logs
chmod 775 logs
fi

for i in `cat $inilist`
do
echo "Running for $i : `date`"

if [ ! -f $i ] 
then
echo "File $i not found. Skipping to next ini file"
else
cp $i forecast.ini
logfile=logs/${i}.log.$dt
errfile=logs/${i}.err.$dt
python main.py 1> $logfile 2> $errfile
fi

done
