#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 10 18:13:37 2018

@author: hima
"""


import pandas as pd
from pyper import R
from split_forecast_input import split_forecast_input
from forecast_error import forecast_error
import forecast_config

# Update forecast configuration parameter
conf_read_input = forecast_config.getConfig('RunScript')
time_frequency = conf_read_input['time_frequency']

def generate_auto_ets_fractal(data1,UIN,Comop,last_date,holdout_date,horizon_in_months):
    if len(data1[data1.YYYYMMDD<holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']): # this ensures min. 2 year of data for forecasting
        print UIN, "insufficient historical data"
        return

    if time_frequency == "Monthly":
        time_period=12
    elif time_frequency == "Weekly":
        time_period=53
    else:
        time_period=12
    #Prepare Training and Test dataset
    #horizon_in_months = 24
    data2,X,Y,Xtest,Ytest = split_forecast_input(data1,UIN,Comop,holdout_date,last_date,horizon_in_months)
    
    holdout_months = len(data1) - len(Y)
    #print start_date, end_date
    # Create linear regression object
    r = R(use_pandas = True)
    r.assign("rY",Y)
    r.assign("rholdout_months",holdout_months)
    r.assign("rhorizon_in_months",horizon_in_months)
    r.assign("time_period",time_period)
    r("source('main_aera_fractal.r')")
    #print 'i am going in R'
    r("Y_pred <- generate_forecast_ETS_fractal(rY,rholdout_months,rhorizon_in_months,time_period)")
    try:
        Y_pred1 = pd.DataFrame(r.get("Y_pred"))
        # R to python causes Columns to add whitespaces
        Y_pred1.columns = Y_pred1.columns.str.strip()
    except:
        print "ETS_fractal: UIN =", UIN, "Comop=",Comop, "optimization failure or no data returned from R","ETS Fractal"
        return

    Y_pred1[Y_pred1 < 0] = 0

    Y_compare = forecast_error(data2, Ytest, Y_pred1['Forecast'], holdout_date, last_date)
    # Printing MAPE to confirm correct results during development

    print "ETS_fractal: UIN =", UIN, "Comop=",Comop, "MAPE =",Y_compare.APE.mean(),"Bias= ",Y_compare.Bias_Error.iloc[1]

    # Returns full dataset with 
    # Columns for Forecast, MAPE and Forecast_Type
    Y_return = pd.DataFrame(data2).join(Y_pred1)
    Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
    Y_return['MAPE'] = Y_compare.APE.mean() # This is a single number    
    Y_return['Forecast_Type'] = 'Auto ETS Fractal'

    return Y_return
