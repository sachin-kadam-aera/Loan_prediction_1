rm(list=ls())

if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

promo_file = fread(paste0(wd,"/Output_Files/Promo_data_customer.csv"))
promo_file = data.frame(promo_file)
promo_file = promo_file[,c("DemandCustomer","SKU10","Year","Week_No","DOD","VSOD","INCR_Qty","BASE_Qty")]
promo_file = data.frame(promo_file %>% group_by(DemandCustomer,SKU10,Year,Week_No) %>% 
                          dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=max(INCR_Qty),BASE_Qty=max(BASE_Qty)))

sku_mapping = fread(paste0(wd,"/Output_Files/CZ_SKU_Mapping.csv"))
sku_mapping = sku_mapping[,c("SKU10","PlanToCustomer","CZ_Code")]

customer_mapping = fread(paste0(wd,"/Input_Files/Customer_Mapping.csv"))
sku_mapping = merge(sku_mapping,customer_mapping,by = "PlanToCustomer")
sku_mapping = data.frame(unique(sku_mapping[,c("SKU10","CZ_Code","DemandCustomer")]))
sku_mapping = sku_mapping[!(sku_mapping$DemandCustomer %in% c("ALL OTHERS - US","INTERNATIONAL")),]

sales_data = fread(paste0(wd,"/Output_Files/DF_US_CZ.csv"))
sales_data = data.frame(sales_data)

sales_data_grain = data.frame(unique(sales_data[,c("SKU10","DemandCustomer")]))
sales_data_grain = merge(sales_data_grain,sku_mapping,by =c("SKU10","DemandCustomer"))
sales_data_grain = merge(sales_data_grain,sku_mapping,by =c("CZ_Code","DemandCustomer"))
names(sales_data_grain) = c("CZ_Code","DemandCustomer","Map_SKU10","SKU10")
sales_data_grain$CZ_Code = NULL

promo_file = merge(promo_file,sales_data_grain,by=c("DemandCustomer","SKU10"),all.x = TRUE)
promo_file$Map_SKU10 = ifelse(is.na(promo_file$Map_SKU10),promo_file$SKU10,promo_file$Map_SKU10)
promo_file$SKU10 = promo_file$Map_SKU10
promo_file$Map_SKU10 = NULL

promo_file = data.frame(promo_file %>% group_by(DemandCustomer,SKU10,Year,Week_No) %>% 
                          dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=max(INCR_Qty),BASE_Qty=max(BASE_Qty)))

fwrite(promo_file,paste0(wd,"/Output_Files/Promo_data_customer_update.csv"))
