#Added functionality - Error Handling, User input specification via csv
rm(list = ls())

if(!require(dplyr)) install.packages("dplyr")
if(!require(readxl)) install.packages("readxl")
if(!require(lubridate)) install.packages("lubridate")

nielsen_data = read.csv("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/nileson_raw_data.csv",stringsAsFactors = FALSE)
nielsen_data = data.frame(nielsen_data %>% group_by(Customer,UPC,Year,Week_No) %>% dplyr::summarise(N_Sales = last(N_Sales),N_Base=last(N_Base)))
customer_mapping = read.csv("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/customer_mapping_nielsen.csv",stringsAsFactors = FALSE)
nielsen_data = merge(nielsen_data,customer_mapping, by.x="Customer",by.y = "Customer")
write.csv(nielsen_data,"/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/Nielsen_prep.csv",row.names = FALSE)


