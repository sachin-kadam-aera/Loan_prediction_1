#rm(list=ls())
if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(dplyr)) install.packages("dplyr")
if(!require(readxl)) install.packages("readxl")

wd <- ("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
setwd(paste0(wd))
list.files()
user_input <- read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))
ho_year<- as.numeric(user_input$YEAR)
ho_week<- as.numeric(user_input$WEEK) -1

cz_sales = read.csv(paste(wd, "/Output_Files/CZ_Sales_data.csv",sep =""),stringsAsFactors = FALSE)
SKU_grain = data.frame(unique(cz_sales[,c("SKU10","PLAN_Cust")]),row.names = NULL)

CZSKU_info = data.frame()
for (i in 1:nrow(SKU_grain)){
  #i=1
  print(i)
  sku = SKU_grain$SKU10[i]
  cust = SKU_grain$PLAN_Cust[i]
  sample = cz_sales[cz_sales$SKU10==sku & cz_sales$PLAN_Cust==cust,]
  sample = sample[order(sample$Year,sample$Week_No),]
  sample$Sales_N <- sample$Sales
  sales_th = mean(sample$Sales)*.2
  sample$Sales_N <- ifelse(sample$Sales_N<sales_th,0,sample$Sales_N)
  #plot(sample$Sales,type="line")
  start <- min(which(!sample$Sales_N==0))
  end<-max(which(!sample$Sales_N==0))
  sku_info = sample[1,c("Brand","PLAN_Cust","SKU10","CZ_Code")]
  sample1 <- sample[c(start:end),]
  sample1$Count <- ifelse(sample1$Sales_N>0,0,1)
  sample1$contsales <- 0
  for (j in 2:nrow(sample1)){
    sample1$contsales[j] <- ifelse(sample1$Count[j]==1,1+sample1$contsales[j-1],0)
  }
  Start_Week <- sample$Week_No[start]
  Start_Year <- sample$Year[start]
  End_Week <- sample$Week_No[end]
  End_Year <- sample$Year[end]
  Sales_Week <- nrow(sample1)
  ZeroSales_Week <- sum(sample1$Count)
  MAX_continuesZERO <- max(sample1$contsales)
  #CZ_inst_count = sample1$contsales[sample1$contsales>8]
  sample$sales_k <- sample$Sales
  sample_mean = mean(sample$Sales[sample$Sales>0])
  sample_sd = sd(sample$Sales[sample$Sales>0])
  up_limit = sample_mean + 2*sample_sd
  sample$sales_k = ifelse(sample$sales_k>up_limit,up_limit,sample$sales_k)
  COV = sd(sample$sales_k[sample$sales_k>0])/mean(sample$sales_k[sample$sales_k>0])
  sample$sales_k = NULL
  file <- cbind(sku_info,Start_Year,Start_Week,End_Year,End_Week,Sales_Week,ZeroSales_Week,MAX_continuesZERO,COV)
  CZSKU_info <- rbind(CZSKU_info,file)
}

write.csv(CZSKU_info,paste(wd, "/Output_Files/CZ_SKUinfo_update.csv",sep =""),row.names = FALSE)

CZSKU_select1 = CZSKU_info[CZSKU_info$CZ_Code >= 1000,]
CZSKU_select2 = CZSKU_info[(CZSKU_info$End_Year == ho_year & CZSKU_info$End_Week >= ho_week),]
CZSKU_select2 = CZSKU_select2[CZSKU_select2$CZ_Code < 1000,]
CZSKU_select2 = CZSKU_select2[CZSKU_select2$MAX_continuesZERO < 13,]
CZSKU_select = rbind(CZSKU_select1,CZSKU_select2)
head(CZSKU_select,2)
czcode_select <- CZSKU_select$CZ_Code


sku_master <- read.csv(paste(wd, "/Input_Files/SKU_Master_final.csv",sep =""),stringsAsFactors = FALSE)
Cust_Mapping <- read.csv(paste(wd, "/Input_Files/Customer_Mapping.csv",sep =""),stringsAsFactors = FALSE)
sku_master <- data.frame(sku_master %>% group_by(SKU10) %>%
                           summarise(BSG = last(BSG),UOM = last(UOM),
                                     Price = last(Price_unit),UPC = last(UPC),PPG= last(PPG)))
sku_master <- merge(sku_master,Cust_Mapping)   
sku_master <- sku_master[,c("SKU10","PlanToCustomer","UPC","Price","UOM")]

CZ_prep <- read.csv(paste(wd, "/Output_Files/CZ_prep.csv",sep =""),stringsAsFactors = FALSE)
CZ_code_map <- CZ_prep[CZ_prep$CZ_Code %in% czcode_select,]
CZ_code_map$UPC_Key <- NULL
CZ_code_map$UPC <- NULL
head(CZ_code_map,2)
head(sku_master,2)

CZ_code_map <- merge(sku_master,CZ_code_map, by.x =c("SKU10","PlanToCustomer"),by.y = c("SKU10","PLAN_Cust"),all.x = TRUE)
head(CZ_code_map)
CZ_code_map$CZ_Code <- ifelse(is.na(CZ_code_map$CZ_Code),CZ_code_map$UPC,CZ_code_map$CZ_Code)

write.csv(CZ_code_map,paste(wd, "/Output_Files/CZ_SKU_Mapping.csv",sep =""),row.names = FALSE)


