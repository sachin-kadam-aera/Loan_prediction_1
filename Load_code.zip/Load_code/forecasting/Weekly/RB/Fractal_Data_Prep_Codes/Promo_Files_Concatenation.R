
if(!require(forecast)) install.packages("forecast")
if(!require(data.table)) install.packages("data.table")
library(forecast)
library(data.table)

setwd("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")

mgx1 <- read.csv("MGX_EXPORT_US_01.csv",stringsAsFactors = FALSE)
mgx2 <- read.csv("MGX_EXPORT_US_02.csv",stringsAsFactors = FALSE)
mgx3 <- read.csv("MGX_EXPORT_US_03.csv",stringsAsFactors = FALSE)

mgx <-rbind(mgx1, mgx2,mgx3)

mgx_c <- mgx[(mgx$PROMO_STATUS  %in% c("Committed Approved","Committed Revised","Draft","Committed","Closed")),]

mgx_c = as.data.table(mgx_c)
mgx_c[,SKU:=substring(SKU_CODE,1,11)]
Promo_data_concatenated = mgx_c[,c("PP_CODE","CUST_CODE","PROMO_ID","PROMO_SHIP_START_DT","PROMO_SHIP_END_DT",
                                   "PROMO_NAME","SKU","INCR_QTY","BASE_QTY")]

Promo_data_concatenated_V1 <- Promo_data_concatenated[,list(INCR_QTY = sum(INCR_QTY),
                                                            BASE_QTY = sum(BASE_QTY)),
                             by = c("PP_CODE","CUST_CODE","PROMO_ID","PROMO_SHIP_START_DT","PROMO_SHIP_END_DT",
                                    "PROMO_NAME","SKU")]

Promo_data_concatenated_V1$PROMO_SHIP_START_DT <- as.Date(Promo_data_concatenated_V1$PROMO_SHIP_START_DT,format = "%Y-%m-%d")
Promo_data_concatenated_V1$Year <- year(Promo_data_concatenated_V1$PROMO_SHIP_START_DT) 

Promo_data_concatenated_V2 <- Promo_data_concatenated_V1[Promo_data_concatenated_V1$Year< 2017,]
Promo_data_concatenated_V2$Year  = NULL
write.csv(Promo_data_concatenated_V2,"Promo_data_concatenated_till2016.csv",row.names= FALSE)

