#rm(list=ls())

if(!require(doParallel)) install.packages("doParallel")
setwd("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/")
wd = getwd()
if(!require(data.table)) install.packages("data.table")
library(data.table)

library('lubridate')
library(doParallel)
library(dplyr)
#list.files()
user_input <- read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))

#user_input <- read.csv("User_Input_File_USA.csv")
ho_year<- as.numeric(user_input$YEAR)
ho_week<- as.numeric(user_input$WEEK) -1

Sales_data <- read.csv(paste(wd, "/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),
                       stringsAsFactors = FALSE)
Sales_data <- data.frame(Sales_data %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- Sales_data[order(Sales_data$Sales),]
Sales_data_Brand_Mapping <- data.frame(Sales_data_Brand_Mapping %>% group_by(SKU10) %>% dplyr::summarise(Brand=last(Brand )))
Sales_data$Brand <- NULL
Sales_data <- merge(Sales_data,Sales_data_Brand_Mapping,by="SKU10")
Sales_data <- data.frame(Sales_data %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Sales=sum(Sales)))


#Sales_data <- Sales_data[Sales_data$SKU10 %in% c('19200-00027', '19200-00051', '19200-00062', '19200-00066', '19200-00101', '19200-00202', '19200-00252', '19200-00262', '19200-00300', '19200-00301', '19200-00305', '19200-00311', '19200-00316', '19200-00317', '19200-00318', '19200-00335', '19200-00336', '19200-00338', '19200-00339', '19200-00379', '19200-00381', '19200-00382', '19200-00601', '19200-00706', '19200-00785', '19200-00786', '19200-00888', '19200-00948', '19200-02501', '19200-02522', '19200-02569', '19200-02699', '19200-02845', '19200-02922', '19200-74185', '19200-74186', '19200-75055', '19200-75058', '19200-75352', '19200-75531', '19200-75590', '19200-76878', '19200-76879', '19200-76938', '19200-76940', '19200-77182', '19200-77454', '19200-77500', '19200-77660', '19200-77925', '19200-78033', '19200-78625', '19200-78626', '19200-78630', '19200-78631', '19200-78642', '19200-78816', '19200-78849', '19200-78914', '19200-78915', '19200-78916', '19200-78997', '19200-79056', '19200-79132', '19200-79174', '19200-79196', '19200-79326', '19200-79328', '19200-79329', '19200-79556', '19200-79567', '19200-79568', '19200-79633', '19200-79830', '19200-79831', '19200-79838', '19200-79954', '19200-80078', '19200-80088', '19200-80296', '19200-80306', '19200-80307', '19200-80309', '19200-80310', '19200-80313', '19200-80342', '19200-80373', '19200-80425', '19200-80498', '19200-80783', '19200-80816', '19200-80833', '19200-80834', '19200-80870', '19200-80984', '19200-80985', '19200-81143', '19200-81145', '19200-81146', '19200-81344'),]
#Sales_data <- Sales_data[Sales_data$SKU10 %in% c('19200-00027'),]
#Sales_data <- Sales_data[Sales_data$SKU10== '19200-81145' &Sales_data$PLAN_Cust == 11599071  ,]

Sales_data_v1 <- Sales_data[Sales_data$Year >=2015,]
Sales_data_v1 <- Sales_data_v1[(Sales_data_v1$Year < ho_year) | (Sales_data_v1$Year == ho_year & Sales_data_v1$Week_No <= ho_week) ,]

head(Sales_data_v1,2)


promo_file_siebel <- read.csv(paste(wd, "/Input_Files/siebel_data_prep.csv",sep =""),
                       stringsAsFactors = FALSE)

colnames(promo_file_siebel)<- c("PP_CODE","SKU10","PLAN_Cust","Promo_type","Year","Week_No","BASE_QTY","INCR_QTY")
promo_file_siebel = promo_file_siebel[order(promo_file_siebel$SKU10,promo_file_siebel$PLAN_Cust,promo_file_siebel$Year,promo_file_siebel$Week_No,promo_file_siebel$Promo_type),]

promo_file_siebel_v1 <- as.data.frame(promo_file_siebel %>% group_by(SKU10,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Promo_type = first(Promo_type),INCR_QTY=sum(INCR_QTY), BASE_QTY=sum(BASE_QTY)))
head(promo_file_siebel_v1)

promo_file_siebel <- promo_file_siebel_v1
promo_file_siebel$Promo_Flag = 1

promo_file_siebel_horizon <- promo_file_siebel[(promo_file_siebel$Year> ho_year) | (promo_file_siebel$Year== ho_year &promo_file_siebel$Week_No > ho_week),]

head(promo_file_siebel,2)


promo_file <- merge(Sales_data_v1,promo_file_siebel,by=c("SKU10","PLAN_Cust","Year","Week_No") ,all.x=TRUE)
promo_file <- promo_file[,c("Brand","SKU10",    "PLAN_Cust",    "Year",    "Week_No",    "Sales",    "Promo_type",    "Promo_Flag")]
promo_file[is.na(promo_file$Promo_Flag),"Promo_Flag"] <- 0

head(promo_file,2)


promo_file[is.na(promo_file)] <- "NA"
names(promo_file)

promo_file$Promo <- 0
str(promo_file)

sku_grain <- data.frame(unique(promo_file[,c('Brand','SKU10','PLAN_Cust')]),row.names = NULL)

promo_check_func = function(i){
   # i=1
  print(i)
    brand = sku_grain$Brand[i]
    sku = sku_grain$SKU10[i]
    cust = sku_grain$PLAN_Cust[i]
    sample <- data.frame(promo_file[promo_file$SKU10==sku & promo_file$PLAN_Cust==cust & promo_file$Brand == brand,])
    promo_ids <- unique(sample$Promo_type)
    if (length(promo_ids)>1) {
      promoid_check <- unique(sample$Promo_type)
      if(length(promoid_check[-which(promoid_check=="NA")])>1){
        promoid_check <- promoid_check[-which(promoid_check=="NA")]
        for (k in 1:length(promoid_check)){
          #k=1
          npromo_sample = sample[sample$Promo_type=="NA",]
          npsales_mean = mean(npromo_sample$Sales,na.rm = TRUE)
          promo_id = promoid_check[k]
          promo_sample = sample[sample$Promo_type==promo_id,]
          sales_max = max(promo_sample$Sales,na.rm = TRUE)
          if (sales_max > (1.2*npsales_mean)){
            sample[(sample$Promo_type == promo_id),'Promo']=1
          }
        }
      }
    }
    #sample$select <- i
    #sales_prep <- rbind(sales_prep,sample)
    return(sample)
}

#stopCluster(cl=NULL)
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

#### FUNCTION Call ####
## Run the two lines - after running all other functions ##
promo_prep <- data.frame()
promo_prep <- foreach(p=(1:nrow(sku_grain)),.combine = rbind,.export = c('promo_file'),
                      .packages=c('dplyr','doParallel')) %dopar% promo_check_func(p)



promo_file_prep <- promo_prep[promo_prep$Promo>0 & promo_prep$Year >=2015,]

stopCluster(cl)

promo_file_prep = promo_file_prep[,c("SKU10","PLAN_Cust","Year","Week_No","Promo_type","Promo_Flag","Promo")]

promo_file_siebel_horizon$Promo <- NA
promo_file_siebel_horizon = promo_file_siebel_horizon[,c("SKU10","PLAN_Cust","Year","Week_No","Promo_type","Promo_Flag","Promo")]

promo_file_prep_V1 <- rbind(promo_file_prep,promo_file_siebel_horizon)

promo_file_prep_V1[is.na(promo_file_prep_V1$Promo),"Promo"] <- promo_file_prep_V1[is.na(promo_file_prep_V1$Promo),"Promo_Flag"]

promo_file_prep_V1$Promo_Flag <- NULL
promo_file_prep_V1$Promo_type <- NULL
nrow(unique(promo_file_prep_V1[,c("SKU10","PLAN_Cust")]))
write.csv(promo_file_prep_V1,paste(wd, "/Output_Files/ppg_code_output_allgrainWeek35.csv",sep=""),row.names = FALSE)
