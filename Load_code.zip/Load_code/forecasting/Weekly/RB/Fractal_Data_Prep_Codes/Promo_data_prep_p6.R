rm(list=ls())

if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(smooth)) install.packages("smooth")
if(!require(dplyr)) install.packages("dplyr")
if(!require(data.table)) install.packages("data.table")

wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

sales_file_prep = fread(paste0(wd,"/Output_Files/DF_US_Sales_Siebel_promo.csv"))
sales_file <- sales_file_prep[order(sales_file_prep$SKU10,sales_file_prep$DemandCustomer,sales_file_prep$Year,sales_file_prep$Week_No),]
sales_file = data.frame(sales_file)

sales_file_allother = sales_file[sales_file$DemandCustomer %in% c("ALL OTHERS - US","INTERNATIONAL"),]
sales_file_cust = sales_file[!(sales_file$DemandCustomer %in% c("ALL OTHERS - US","INTERNATIONAL")),]
sales_file_promo = sales_file_cust[sales_file_cust$Promo == 1,]
sales_file_promo$Promo_1 = ifelse(sales_file_promo$VSOD>0,1,0)

sales_file_npromo = sales_file_cust[sales_file_cust$Promo != 1,]
sales_file_npromo = rbind(sales_file_allother,sales_file_npromo)
sales_file_npromo$Promo_1 = ifelse(sales_file_npromo$VSOD>0,1,0)

sales_file_npromo$Promo = 0
sales_file_promo$Promo = 1
sales_file = rbind(sales_file_promo,sales_file_npromo)

user_input = read.csv(paste0(wd,"/Input_Files/User_Input_File_USA.csv"))
forecast_start_week <- unique(user_input$WEEK) - 1
forecast_start_year <- unique(user_input$YEAR)

sku_grain = data.frame(unique(sales_file[,c("SKU10","DemandCustomer")],index = NULL))
basline_cal<-function(i){
  #i=1
  sku = sku_grain$SKU10[i]
  cust = sku_grain$DemandCustomer[i]
  sample = sales_file[sales_file$SKU10==sku & sales_file$DemandCustomer==cust,]
  sample = sample[order(sample$Year,sample$Week_No),]
  sample[is.na(sample)] = 0
  sample$Baseline8 = sample$Sales
  if (nrow(sample)>8){
    for(j in 8:nrow(sample)){
      sample$Baseline8[j] = mean(sample$Sales[(j-7):j])
    }
  }
  return(sample)
}

#stopCluster(cl=NULL)
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

baseline_file <- data.frame()
baseline_file <- foreach(p=(1:nrow(sku_grain)),.combine = rbind,.packages=c('smooth')) %dopar% basline_cal(p)

head(baseline_file,2)
baseline_file$increment8 = baseline_file$Sales-baseline_file$Baseline8
baseline_file$increment8 = ifelse(baseline_file$increment8<0,0,baseline_file$increment8)
baseline_file$VSOD_8 = ifelse(baseline_file$Sales==0,0,baseline_file$increment8/baseline_file$Sales)

baseline_file$VSOD_8_final = ifelse(((baseline_file$Year < forecast_start_year) | (baseline_file$Year==forecast_start_year & baseline_file$Week_No<=forecast_start_week)),
                                    baseline_file$VSOD_8,baseline_file$VSOD)
baseline_file$VSOD_8_final = ifelse(baseline_file$Promo == 1,baseline_file$VSOD_8_final,0)
names(baseline_file)

DF_file = baseline_file[,c("Brand","SKU10","DemandCustomer","Year","Quarter","Month_No",
                           "Week_No","Sales","W_Nielsen","DOD",
                           "VSOD_8_final","Promo")]
baseline_file = baseline_file[,union(names(DF_file),names(baseline_file))]

DF_file_name = paste0("DF_File_withVSOD_",forecast_start_week,"_",forecast_start_year,".csv")
fwrite(DF_file,paste0(wd,"/Output_Files/",DF_file_name))

baseline_file_name = paste0("Baseline_File_withVSOD_",forecast_start_week,"_",forecast_start_year,".csv")
fwrite(baseline_file,paste0(wd,"/Output_Files/",baseline_file_name))

DF_file_PUBLIX = DF_file[DF_file$DemandCustomer=="PUBLIX",]
#fwrite(DF_file,paste0(wd,"/Output_Files/DF_File_withVSOD_All.csv"))
fwrite(DF_file,paste0(wd,"/Output_Files/DF_US_SalesFromFractal.csv"))
fwrite(DF_file_PUBLIX,paste0(wd,"/Output_Files/DF_File_withVSOD_PUBLIX.csv"))
