import pandas as pd

data = pd.read_csv('/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv')
grains = pd.read_csv('/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/grains.csv')

data2 = pd.merge(data,grains,on=['SKU10'],how='inner')
data2.to_csv('/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv',index = False)




