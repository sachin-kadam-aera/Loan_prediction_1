#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  3 19:18:43 2019

@author: vikranthole
"""

import pandas as pd
import sys
import os
import numpy as np

def fractal_to_aera_dataConversion(data):
    all_columns = data.columns
    req_columns  = [u'SKU10','Brand', u'DemandCustomer', u'Year',u'Week_No', u'Sales','Quarter','Month_No']
    feature_columns = list(set(all_columns) - set(req_columns))
    sub = data[req_columns]
    sub['Week_No'] = sub['Week_No'].apply(lambda x: str(x).zfill(2))
    sub['dd_forecastdate'] = sub['Year'].astype('str') + sub['Week_No'].astype('str')
    sub['dd_comp'] = 'abc'
    sub = sub[[u'SKU10', u'DemandCustomer','dd_comp', u'dd_forecastdate', u'Sales','Quarter','Month_No']]
    sub.columns = ['dim_partid','dd_level2','dd_comp','dd_forecastdate','Sales','Quarter','Month_No']
    feature_data = data[feature_columns]
    result = pd.concat([sub, feature_data], axis=1)
    return result




#output = sys.argv[2]
HOLDOUT_PERIOD,YEAR,WEEK = sys.argv[1],sys.argv[2],sys.argv[3]
forecast_start_week = int(WEEK)-1
month = str(YEAR)+str(WEEK).zfill(2)+str(HOLDOUT_PERIOD)

output_folder =  paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0")) +'/'

DF_File_woHO_name = output_folder + "DF_File_woHO_"+ str(forecast_start_week)+"_"+str(YEAR)+".csv"
DF_File_withHO_names = output_folder +"DF_File_withHO_"+ str(forecast_start_week)+"_"+str(YEAR)+".csv"

for input1 in [DF_File_woHO_name,DF_File_withHO_names]:
    if input1 == DF_File_woHO_name:
        data = pd.read_csv(input1)
        grains = pd.read_csv('/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/grains.csv')
        data = pd.merge(data,grains,on=['SKU10'],how='inner')
        
        para = pd.read_csv('/home/fusionops/datascience/forecasting/weekly/RB//Fractal_Codes/Codes_USA/Week_Mapping.csv')
        ho_para = para[para['Week_No'].isin((para[(para['Year']==int(YEAR)) & (para['Week']==int(WEEK))]['Week_No'] - 26))]
        
        holdout_week = ho_para.iloc[0]['Week']
        holdout_year = ho_para.iloc[0]['Year']
        
        sample = data
        sample['YearWeek'] = sample['Year'].astype('str')+ sample['Week_No'].astype('str').str.zfill(2)
        sample = sample[(sample['YearWeek']>=str(holdout_year)+str(holdout_week).zfill(2))]
        #sample['YearWeek'] = sample['Year'].astype('str')+ sample['Week_No'].astype('str').str.zfill(2)
        sample = sample[(sample['YearWeek']<str(YEAR)+str(WEEK).zfill(2))]
        
        sample = sample.groupby(["SKU10","DemandCustomer"]).agg({"Sales":np.sum})
        sample = sample.reset_index()
        sample = sample[sample['Sales']>0]
        sample = sample[["SKU10","DemandCustomer"]]
        
        data4 = pd.merge(sample, data, left_on=[u'SKU10', u'DemandCustomer'], \
                        right_on=[u'SKU10', u'DemandCustomer'], how='inner')
        
        order_col = ["Brand","SKU10","DemandCustomer","Year","Quarter","Month_No","Week_No","Sales"]
        all_col = data4.columns
        remain_col =  list(set(all_col) - set(order_col))
        
        feature_data = data4[remain_col]
        req_data = data4[order_col]
        
        data4 = pd.concat([req_data,feature_data], axis=1)
        data4.drop('YearWeek', axis=1, inplace=True)
        #data4.to_csv(input1,index = False)
        
        # In Linux/Unix
        data4.to_csv('/efs/datascience/Reckitt7B8/data/input/DF_File_woHO.csv',index = False)
        #os.system('cp '+input1+' /efs/datascience/Reckitt7B8/data/input/DF_US_SalesFromFractal.csv')
        data.head()
        
        data.columns
        res = fractal_to_aera_dataConversion(data4)
        min_p_date= res[res['Sales']>0].groupby(['dim_partid', 'dd_level2', u'dd_comp'])['dd_forecastdate'].min().to_dict()
        temp = []
        for key,val in min_p_date.iteritems():
            temp.append(res[(res['dim_partid']==key[0]) & (res['dd_level2']==key[1]) & (res['dd_comp']==key[2]) & (res['dd_forecastdate']>=val)])
        
        res = pd.concat(temp)
        
        res = res.sort_values(['dim_partid', 'dd_level2', 'dd_forecastdate'], ascending=[1,1,1])
        res1 = res[['dim_partid','dd_level2','dd_comp','dd_forecastdate','Sales']]
        res1.to_csv('/efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_skudmdcust_weekly_aera.csv'+month,index = False,header=False)
        res.to_csv('/efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_sku10_weekly_multivariate.csv'+month,index = False,header=False)
    if input1 == DF_File_withHO_names:
        data = pd.read_csv(input1)
        grains = pd.read_csv('/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/grains.csv')
        data = pd.merge(data,grains,on=['SKU10'],how='inner')
        
        para = pd.read_csv('/home/fusionops/datascience/forecasting/weekly/RB//Fractal_Codes/Codes_USA/Week_Mapping.csv')
        ho_para = para[para['Week_No'].isin((para[(para['Year']==int(YEAR)) & (para['Week']==int(WEEK))]['Week_No'] - 26))]
        
        holdout_week = ho_para.iloc[0]['Week']
        holdout_year = ho_para.iloc[0]['Year']
        
        sample = data
        sample['YearWeek'] = sample['Year'].astype('str')+ sample['Week_No'].astype('str').str.zfill(2)
        sample = sample[(sample['YearWeek']>=str(holdout_year)+str(holdout_week).zfill(2))]
        #sample['YearWeek'] = sample['Year'].astype('str')+ sample['Week_No'].astype('str').str.zfill(2)
        sample = sample[(sample['YearWeek']<str(YEAR)+str(WEEK).zfill(2))]
        
        sample = sample.groupby(["SKU10","DemandCustomer"]).agg({"Sales":np.sum})
        sample = sample.reset_index()
        sample = sample[sample['Sales']>0]
        sample = sample[["SKU10","DemandCustomer"]]
        
        data4 = pd.merge(sample, data, left_on=[u'SKU10', u'DemandCustomer'], \
                        right_on=[u'SKU10', u'DemandCustomer'], how='inner')
        
        order_col = ["Brand","SKU10","DemandCustomer","Year","Quarter","Month_No","Week_No","Sales"]
        all_col = data4.columns
        remain_col =  list(set(all_col) - set(order_col))
        
        feature_data = data4[remain_col]
        req_data = data4[order_col]
        
        data4 = pd.concat([req_data,feature_data], axis=1)
        data4.drop('YearWeek', axis=1, inplace=True)
       # data4.to_csv(input1,index = False)
        
        # In Linux/Unix
        data4.to_csv('/efs/datascience/Reckitt7B8/data/input/DF_File_withHO.csv',index = False)
    
        
