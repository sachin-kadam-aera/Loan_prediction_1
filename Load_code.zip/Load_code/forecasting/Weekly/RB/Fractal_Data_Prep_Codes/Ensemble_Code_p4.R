rm(list=ls())

if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(smooth)) install.packages("smooth")
if(!require(dplyr)) install.packages("dplyr")
if(!require(data.table)) install.packages("data.table")
library(stringr)
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

user_input = read.csv(paste0(wd,"/Input_Files/User_Input_File_USA.csv"))
forecast_start_week <- unique(user_input$WEEK) - 1
forecast_start_year <- unique(user_input$YEAR)


fcst_efs_dir =  paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"))
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
subDir = paste("fcst_",toString(forecast_start_year) ,str_pad(toString(forecast_start_week),2,pad = "0"),sep ="")
dir.create(file.path(efs_dir,subDir), showWarnings = FALSE)

input_to_ensemble = paste0(fcst_efs_dir,"/input_to_ensemble.csv")
forecast_result = fread(input_to_ensemble,stringsAsFactors = FALSE)



names(forecast_result) = c("SKU10","DemandCustomer","Year","Week_No","Model","Forecast")
head(forecast_result,2)
str(forecast_result)

forecast_SKU_grains = data.frame(unique(forecast_result[,c("SKU10","DemandCustomer")]))

sales_file = fread(paste0(fcst_efs_dir,"/Forecast_withINCR.csv"),stringsAsFactors = FALSE)
sales_file = merge(sales_file,forecast_SKU_grains,
                   by.x = c("SKU10","DemandCustomer"),
                   by.y = c("SKU10","DemandCustomer"))
sales_file = data.frame(sales_file)
sales_file = sales_file[order(sales_file$SKU10,sales_file$DemandCustomer,sales_file$Year,sales_file$Week_No),]
head(sales_file,2)
sku_grain = data.frame(unique(sales_file[,c("SKU10","DemandCustomer")]))
# head(sales_file,3)

### Ensembling PP
#ensemble_grains = data.frame(ensemble_grains)
#sales_file_ensemble = merge(sales_file,ensemble_grains,by=c("SKU10","DemandCustomer"),all.x = TRUE)
sales_file_ensemble = sales_file
sales_file_ensemble = sales_file_ensemble[order(sales_file_ensemble$SKU10,
                                                sales_file_ensemble$DemandCustomer,
                                                sales_file_ensemble$Year,
                                                sales_file_ensemble$Week_No),]
#sales_file_ensemble$Ensemble = ifelse(is.na(sales_file_ensemble$Ensemble),0,1)
sales_file_ensemble$Promo = ifelse(sales_file_ensemble$INCR_Qty_new>0,1,0)

sales_file_ensemble$Forecast_Ensemble = ifelse(sales_file_ensemble$DemandCustomer=="ALL OTHERS - US",
                                               sales_file_ensemble$Forecast_Final+sales_file$INCR_Qty_new,
                                               sales_file_ensemble$Baseline4+(0.3*sales_file_ensemble$Increment_4+0.7*sales_file_ensemble$INCR_Qty_new))

sales_file_ensemble$Forecast_Ensemble = ifelse((sales_file_ensemble$Promo==1 ),#& sales_file_ensemble$Ensemble==1
                                               sales_file_ensemble$Forecast_Ensemble,
                                               sales_file_ensemble$Forecast_Final)

sales_file_ensemble$Forecast_Ensemble1= sales_file_ensemble$Forecast_Ensemble
sales_file_ensemble$Forecast_Ensemble = ifelse(sales_file_ensemble$Forecast_Ensemble>sales_file_ensemble$Forecast_Final,
                                               sales_file_ensemble$Forecast_Ensemble,sales_file_ensemble$Forecast_Final)
sales_data_all = sales_file_ensemble
sales_file_ensemble = sales_file_ensemble[,c("SKU10","DemandCustomer","Year","Week_No","Forecast_Ensemble")]
head(sales_data_all,2)
head(forecast_result,2)

forecast_file_prep = merge(forecast_result,sales_file_ensemble,
                           by.x = c("SKU10","DemandCustomer","Year","Week_No"),
                           by.y = c("SKU10","DemandCustomer","Year","Week_No"),
                           all.x = TRUE)
head(forecast_file_prep,2)
forecast_file_prep$Forecast_Ensemble = ifelse(is.na(forecast_file_prep$Forecast_Ensemble),forecast_file_prep$Forecast,forecast_file_prep$Forecast_Ensemble)
forecast_file_prep$Forecast_Ensemble = ifelse((forecast_file_prep$Forecast_Ensemble < forecast_file_prep$Forecast),
                                              forecast_file_prep$Forecast,
                                              forecast_file_prep$Forecast_Ensemble)

# forecast_file_prep$Year = NULL
# forecast_file_prep$Week = NULL
# forecast_file_prep$X = NULL

# forecast_file_prep$Forecast_Final = NULL
forecast_file_prep = forecast_file_prep[,c("SKU10","DemandCustomer","Year","Week_No","Model","Forecast_Ensemble")]
names(forecast_file_prep) = c("DD_SKU10","DD_DEMANDCUSTOMER","DD_YEAR","DD_WEEK","DD_FORECASTTYPE","CT_FORECASTQUANTITY")

fwrite(forecast_file_prep,paste0(fcst_efs_dir,"/Forecast_Result_final_ensemble.csv"))
ensemble_output = paste0(fcst_efs_dir,"/output_from_ensemble.csv")
fwrite(forecast_file_prep,ensemble_output)

#sales_file_prep = merge(sales_data_all,sales_file_ensemble,by=c("SKU10","DemandCustomer","Year","Week_No"),all.x = TRUE)
fwrite(sales_data_all,paste0(fcst_efs_dir,"/Promo_SKU_data_check.csv"))
