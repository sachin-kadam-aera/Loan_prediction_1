## To add all extra features and Extrapolate variables
rm(list = ls())
if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
if(!require(dummies)) install.packages("dummies")
if(!require(stringr)) install.packages("stringr")
if(!require(forecast)) install.packages("forecast")

setwd("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
wd = getwd()

## Reading inputation functions
source("Input_Var_imputation.R")

user_input = read.csv(paste0(wd,"/Input_Files/User_Input_File_USA.csv"))
forecast_start_week = user_input$WEEK-1
forecast_start_year = user_input$YEAR
forecast_horizon = user_input$FORECAST_HORIZON
forecast_holdout = user_input$HOLDOUT_PERIOD

## Sales file prepared at Promo_data_prep_p4.R having promotion and nielsen variables
sales_file = data.frame(fread(paste0(wd,"/Output_Files/DF_File_withVSOD_",forecast_start_week,"_",(forecast_start_year),".csv")))

## Addiation features read
extra_varaible = read.csv(paste0(wd,"/Input_Files/Variable_Addition.csv"))

sales_file = merge(sales_file,extra_varaible,by =c("Year","Week_No"))[,union(names(sales_file),names(extra_varaible))]
sales_file = data.frame(sales_file[order(sales_file$SKU10,sales_file$DemandCustomer,sales_file$Year,sales_file$Week_No),])
sales_prep = sales_file

sales_no_nielsen = data.frame(sales_prep %>% group_by(SKU10,DemandCustomer) 
                              %>% dplyr::summarise(Nielsen_Sales= sum(W_Nielsen)))
sales_grain_nonielsen = sales_no_nielsen[sales_no_nielsen$Nielsen_Sales<=0,c("SKU10","DemandCustomer")]
sales_grain_nielsen = sales_no_nielsen[sales_no_nielsen$Nielsen_Sales>0,c("SKU10","DemandCustomer")]


sales_file_woNielsen = merge(sales_prep,sales_grain_nonielsen,by = names(sales_grain_nonielsen))[,names(sales_prep)]
sales_file_nielsen = merge(sales_prep,sales_grain_nielsen,by = names(sales_grain_nielsen))[,names(sales_prep)]
## Adding dummy varaibles for imputation code to run
sales_file_nielsen$W_test = 1
sales_file_nielsen$M_test = 1
sales_file_nielsen$Q_test = 1

sales_grain_nielsen = data.frame(unique(sales_file_nielsen[,c("SKU10","DemandCustomer")]))
## Code start for impute vaibales - Nielsen data
impute_function=function(j){
  #j=74
  sku = sales_grain_nielsen$SKU10[j]
  cust = sales_grain_nielsen$DemandCustomer[j]
  sample = sales_file_nielsen[sales_file_nielsen$SKU10==sku & sales_file_nielsen$DemandCustomer==cust,]
  sample = sample[order(sample$Year,sample$Week_No),]
  DF_sample = sample
  for (i in 1:nrow(sample)){
    sample[i,"Sales"] <- ifelse((sample[i,"Year"] == forecast_start_year&
                                   sample[i,"Week_No"] > forecast_start_week) ||
                                  (sample[i,"Year"] > forecast_start_year), NA, sample[i,"Sales"])}
  sample$rowno = c(1:nrow(sample))
  start = min(which(sample$Sales!=0))
  end = (sample[sample$Year==forecast_start_year & sample$Week_No==forecast_start_week,"rowno"])
  if(!start==Inf){
    train_period = start:(end-forecast_holdout)
    test_period = (end-forecast_holdout+1):end
    forecast_period = union(test_period,c((end):(end+forecast_horizon)))
    actual = sample[test_period,"Sales"]
    actual_all = sample[forecast_period,"Sales"]
    sample_HO = to_convert(sample,length(test_period))
    sample_woHO = sample_HO$hold_out_data
    sample_withHO = sample_HO$test_data
    sample_woHO = sample_woHO[,c("SKU10","DemandCustomer","Year","Week_No","W_Nielsen")]
    sample_withHO = sample_withHO[,c("SKU10","DemandCustomer","Year","Week_No","W_Nielsen")]
    sample_woHO$W_Nielsen = ifelse(sample_woHO$W_Nielsen<0,0,sample_woHO$W_Nielsen)
    sample_withHO$W_Nielsen = ifelse(sample_withHO$W_Nielsen<0,0,sample_withHO$W_Nielsen)
    sample_woHO$Sales = DF_sample$Sales
    sample_withHO$Sales = DF_sample$Sales
    return(list(Frame1=sample_woHO,Frame2=sample_withHO))
  }
}

#Create the clusters 
no_cores = detectCores() - 1
cl = makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

## Run the two lines - after running all other functions ##
DF_data_prep = list()
DF_data_prep = foreach(p=(1:nrow(sales_grain_nielsen)),.combine = custom_combine_function,.export = c('sales_prep'),
                       .packages=c('dplyr','forecast','dummies','plyr','stringr','doParallel')) %dopar% impute_function(p)
stopCluster(cl)

Nielsen_prep_woHO = DF_data_prep$Frame1
Nielsen_prep_withHO = DF_data_prep$Frame2
Nielsen_prep_woHO$Sales = NULL
Nielsen_prep_withHO$Sales = NULL

sales_file_nielsen$W_Nielsen = NULL
sales_file_nielsen$W_test = NULL
sales_file_nielsen$M_test = NULL
sales_file_nielsen$Q_test = NULL
names(sales_file_nielsen)
DF_prep_woHO = merge(sales_file_nielsen,Nielsen_prep_woHO,
                     by = c("SKU10","DemandCustomer","Year","Week_No"))[,names(sales_file_woNielsen)]
DF_prep_withHO = merge(sales_file_nielsen,Nielsen_prep_withHO,
                       by = c("SKU10","DemandCustomer","Year","Week_No"))[,names(sales_file_woNielsen)]
DF_prep_woHO = rbind(sales_file_woNielsen,DF_prep_woHO)
DF_prep_withHO = rbind(sales_file_woNielsen,DF_prep_withHO)

## One hot coding for quarter and month varaibles
DF_prep_woHO = dummy.data.frame(DF_prep_woHO, names = c("Quarter","Month_No"))
DF_prep_withHO = dummy.data.frame(DF_prep_withHO, names = c("Quarter","Month_No"))

##add month and quarter variables
## Week Mapping for Quarter and Month_variables
week_map <- data.frame(Week_No=c(1:53), 
                       Quarter = c(rep(1,13),rep(2,13),rep(3,13),rep(4,14)),
                       Month_No = c(rep(1,4),rep(2,4),rep(3,5),rep(4,4),
                                    rep(5,4),rep(6,5),rep(7,4),rep(8,4),
                                    rep(9,5),rep(10,4),rep(11,4),rep(12,6)))

DF_prep_woHO = merge(DF_prep_woHO,week_map,by="Week_No")
DF_prep_withHO = merge(DF_prep_withHO,week_map,by="Week_No")

DF_prep_woHO =  DF_prep_woHO[order(DF_prep_woHO$Brand,
                                   DF_prep_woHO$DemandCustomer,
                                   DF_prep_woHO$SKU10,
                                   DF_prep_woHO$Year,
                                   DF_prep_woHO$Week_No),]
DF_prep_withHO =  DF_prep_withHO[order(DF_prep_withHO$Brand,
                                       DF_prep_withHO$DemandCustomer,
                                       DF_prep_withHO$SKU10,
                                       DF_prep_withHO$Year,
                                       DF_prep_withHO$Week_No),]
DF_prep_woHO = DF_prep_woHO[,union(c("Brand","SKU10","DemandCustomer","Year","Quarter",
                                     "Month_No","Week_No","Sales","W_Nielsen"),names(DF_prep_woHO))]
DF_prep_withHO = DF_prep_withHO[,union(c("Brand","SKU10","DemandCustomer","Year","Quarter",
                                         "Month_No","Week_No","Sales","W_Nielsen"),names(DF_prep_withHO))]

#names(DF_prep_woHO)
## Final Prep File. This files to be used by Fractal Algo
DF_File_woHO_name = paste0("DF_File_woHO_",(forecast_start_week),"_",(forecast_start_year),".csv")
DF_File_withHO_names = paste0("DF_File_withHO_",(forecast_start_week),"_",(forecast_start_year),".csv")
fwrite(DF_prep_woHO,paste0(wd,"/Output_Files/",DF_File_woHO_name))
fwrite(DF_prep_withHO,paste0(wd,"/Output_Files/",DF_File_withHO_names))

# This has done extrapolation for Holdout + Horizon Period, Trainning is not required as actual data is present. This file to be used for AERA Algo
fwrite(DF_prep_woHO,paste0(wd,"/Output_Files/DF_US_SalesFromFractal.csv"))
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
subDir = paste("fcst_",toString(forecast_start_year) ,str_pad(toString(forecast_start_week),2,pad = "0"),sep ="")
dir.create(file.path(efs_dir,subDir), showWarnings = FALSE)


forecast_start_week <- unique(user_input$WEEK)
forecast_start_year <- unique(user_input$YEAR)
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
subDir = paste("fcst_",toString(forecast_start_year) ,str_pad(toString(forecast_start_week),2,pad = "0"),sep ="")
dir.create(file.path(efs_dir,subDir), showWarnings = FALSE)
file.copy(paste0(wd,"/Output_Files/",DF_File_woHO_name),paste(efs_dir,"/",subDir,sep =""))
file.copy(paste0(wd,"/Output_Files/",DF_File_withHO_names),paste(efs_dir,"/",subDir,sep =""))



