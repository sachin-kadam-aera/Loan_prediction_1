rm(list=ls())
library(stringr)
if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(smooth)) install.packages("smooth")
if(!require(dplyr)) install.packages("dplyr")
if(!require(data.table)) install.packages("data.table")
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

user_input = read.csv(paste0(wd,"/Input_Files/User_Input_File_USA.csv"))
forecast_start_week <- unique(user_input$WEEK) - 1
forecast_start_year <- unique(user_input$YEAR)

sales_file = fread(paste0(wd,"/Output_Files/Baseline_File_withVSOD_",forecast_start_week,"_",forecast_start_year,".csv"),stringsAsFactors = FALSE)
sales_file <- sales_file[order(sales_file$SKU10,sales_file$DemandCustomer,sales_file$Year,sales_file$Week_No),]
head(sales_file,2)

sku_promo_map = fread(paste0(wd,"/Output_Files/SKU_Promo_tag.csv"),stringsAsFactors = FALSE)
sku_promo_map_PP = sku_promo_map[sku_promo_map$Promo_status=="PP",c("SKU10","DemandCustomer")]
sku_promo_map_NP = sku_promo_map[sku_promo_map$Promo_status=="NP",c("SKU10","DemandCustomer")]

sku_mapping = read.csv(paste0(wd,"/Input_Files/SKU_Master_final.csv"),stringsAsFactors = F) 
ppg_mapping  = data.frame(sku_mapping %>% group_by(SKU10) %>% dplyr::summarise(PPG = last(PPG)))

sales_data = merge(sales_file,ppg_mapping,by = c("SKU10"),all.x = TRUE)

ppg_grain = data.frame(unique(sales_data[,c("PPG","DemandCustomer")],index = NULL))
incr_file_prep= data.frame()
for (i in 1:nrow(ppg_grain)){
  #i=1778
  #print(i)
  ppg = ppg_grain$PPG[i]
  cust = ppg_grain$DemandCustomer[i]
  sample = sales_data[sales_data$PPG==ppg & sales_data$DemandCustomer==cust,]
  sku_list = unique(sample$SKU10)
  sample1 = data.frame(sample %>% group_by(PPG,DemandCustomer,Year,Week_No) %>% dplyr::summarise(INCR_Qty=sum(increment8)))
  sample1 = sample1[(sample1$Year<forecast_start_year | (sample1$Year==forecast_start_year & sample1$Week_No <= forecast_start_week)),]
  sample1 = sample1[order(sample1$Year,sample1$Week_No),]
  sample1 = sample1[c((nrow(sample1)-25):nrow(sample1)),]
  names(sample1)
  sample1 = data.frame(sample1 %>% group_by(PPG,DemandCustomer) %>% dplyr::summarise(INCR_Qty_ppg=sum(INCR_Qty)))
  sku_data_prep = data.frame()
  for (j in 1:length(sku_list)){
    #j=1
    sku = sku_list[j]
    sample_sku = sample[sample$SKU10==sku,]
    sample_sku1 = sample_sku[(sample_sku$Year<forecast_start_year | (sample_sku$Year==forecast_start_year & sample_sku$Week_No <= forecast_start_week)),]
    sample_sku1 = sample_sku1[order(sample_sku1$Year,sample_sku1$Week_No),]
    sample_sku1 = sample_sku1[c((nrow(sample_sku1)-25):nrow(sample_sku1)),]
    sample_sku1 = data.frame(sample_sku1 %>% group_by(PPG,SKU10,DemandCustomer) %>% dplyr::summarise(INCR_Qty=sum(increment8)))
    sku_data_prep = rbind(sku_data_prep,sample_sku1)
  }
  sku_data = merge(sample1,sku_data_prep,by = c("PPG","DemandCustomer"))
  sku_data$incr_per = ifelse(sku_data$INCR_Qty_ppg==0,0,sku_data$INCR_Qty/sku_data$INCR_Qty_ppg)
  incr_file_prep = rbind(incr_file_prep,sku_data)
}
head(incr_file_prep)
incr_file_prep = incr_file_prep[,c("SKU10","DemandCustomer","incr_per")]

sales_data = merge(sales_data,incr_file_prep, by =c("SKU10","DemandCustomer"))
sales_data$INCR_Qty_new = sales_data$INCR_Qty*sales_data$incr_per
sku_grain = data.frame(unique(sales_data[,c("SKU10","DemandCustomer")]),row.names = NULL)

### Ensembling PP
sales_file_pp = merge(sales_data,sku_promo_map_PP,by=names(sku_promo_map_PP))
sales_file_pp_hist = sales_file_pp[sales_file_pp$Year<forecast_start_year |
                                     (sales_file_pp$Year==forecast_start_year &
                                        sales_file_pp$Week_No <= forecast_start_week),]
sales_file_pp_hist = sales_file_pp_hist[sales_file_pp_hist$Year>forecast_start_year |
                                          (sales_file_pp_hist$Year==(forecast_start_year-1) &
                                             sales_file_pp_hist$Week_No > forecast_start_week),]
names(sales_file_pp_hist)
sales_file_pp_hist = sales_file_pp_hist %>% group_by(Brand,SKU10,DemandCustomer) %>% 
  dplyr::summarise(INCR_Qty=sum(INCR_Qty_new),Actual_INCR_Qty=sum(incr4))

sales_file_pp_hist$INCR_Qty= as.integer(sales_file_pp_hist$INCR_Qty)
sales_file_pp_hist$ratio = sales_file_pp_hist$INCR_Qty/sales_file_pp_hist$Actual_INCR_Qty
sales_file_pp_hist$Ensemble = ifelse(sales_file_pp_hist$ratio>0.3,ifelse(sales_file_pp_hist$ratio<3,1,0),0)

#sales_file_pp_hist1 = sales_file_pp_hist[sales_file_pp_hist$DemandCustomer=="PUBLIX",]
sales_file_pp_hist = sales_file_pp_hist[sales_file_pp_hist$Ensemble==1 & !(is.na(sales_file_pp_hist$Ensemble)),]
#sales_file_pp_hist = rbind(sales_file_pp_hist1,sales_file_pp_hist2)
sales_file_pp_hist = sales_file_pp_hist[,c("Brand","SKU10","DemandCustomer")]
sales_file_pp_hist = data.frame(sales_file_pp_hist)
sales_file_pp_hist = na.omit(sales_file_pp_hist)
user_input = read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))
forecast_start_week <- unique(user_input$WEEK)
forecast_start_year <- unique(user_input$YEAR)
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
subDir = paste("fcst_",toString(forecast_start_year) ,str_pad(toString(forecast_start_week),2,pad = "0"),sep ="")
dir.create(file.path(efs_dir,subDir), showWarnings = FALSE)

filename = paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"),"/manual_forecastrank.csv")
write.csv(sales_file_pp_hist,filename,row.names = FALSE)

sales_file_pp_hist = sales_file_pp_hist[,c("SKU10","DemandCustomer")]

sku_grain_ensemble = rbind(sales_file_pp_hist,sku_promo_map_NP)
sku_grain_ensemble = unique(sku_grain_ensemble)

fwrite(sales_file_pp_hist,paste0(wd,"/Output_Files/Rank1_XGB.csv"))
ensemble_filename = paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"),"/Ensemble_grains.csv")
sku_grain_ensemble = na.omit(sku_grain_ensemble)
fwrite(sku_grain_ensemble,ensemble_filename,row.names = FALSE) 
