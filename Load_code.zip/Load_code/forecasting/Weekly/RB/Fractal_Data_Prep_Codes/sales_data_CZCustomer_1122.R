rm(list=ls())

wd <- ("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
wd = getwd()

if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
if(!require(tidyr)) install.packages("tidyr")
if(!require(readxl)) install.packages("readxl")
if(!require(lubridate)) install.packages("lubridate")
if(!require(stringr)) install.packages("stringr")
list.files()
user_input <- read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))

#user_input <- read.csv("User_Input_File_USA.csv")
ho_year<- as.numeric(user_input$YEAR)
ho_week<- as.numeric(user_input$WEEK) -1

### Sales Data ###
Sales_file <- read.csv(paste(wd, "/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),stringsAsFactors = FALSE)

Sales_data <- data.frame(Sales_file %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) 
                         %>% dplyr::summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- Sales_data[order(Sales_data$Sales),]
Sales_data_Brand_Mapping <- data.frame(Sales_data_Brand_Mapping 
                                       %>% group_by(SKU10) 
                                       %>% dplyr::summarise(Brand=last(Brand )))
Sales_data$Brand <- NULL
Sales_data <- merge(Sales_data,Sales_data_Brand_Mapping,by="SKU10")
Sales_data <- data.frame(Sales_data %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) 
                         %>% dplyr::summarise(Sales=sum(Sales)))
sales_data <- Sales_data[Sales_data$Year >=2015,]

#write.csv(sales_data,"sales_data_test_WALMARt.csv",row.names = FALSE)
#test <- sales_data[sales_data$PLAN_Cust=="11599791",]
#sum(test$Sales)

### Promo Data ###
promo_data = read.csv(paste(wd, "/Output_Files/ppg_code_output_allgrainWeek35.csv",sep=""),stringsAsFactors = FALSE)
sales_data = merge(sales_data,promo_data,
                   by.x = c("SKU10","PLAN_Cust","Year","Week_No"),
                   by.y = c("SKU10","PLAN_Cust","Year","Week_No"),
                   all.x = TRUE)
sales_data[is.na(sales_data)] = 0
head(sales_data,2)

### SKU and Customer Mapping ###
sku_description = read.csv(paste(wd, "/Output_Files/CZ_SKU_Mapping.csv",sep =""),stringsAsFactors = FALSE)
head(sku_description,2)
customer_Mapping = read.csv(paste(wd, "/Input_Files/Customer_Mapping.csv",sep =""),stringsAsFactors = FALSE)
sales_data = merge(sales_data,sku_description,by.x = c("SKU10","PLAN_Cust"),by.y = c("SKU10","PlanToCustomer"))
head(sales_data,2)

upc_check <- data.frame(unique(sales_data[,c("Brand","PLAN_Cust","UPC","CZ_Code","SKU10")]),row.names = NULL)
grain = data.frame(unique(sales_data[,c("Brand","PLAN_Cust","CZ_Code")]),row.names = NULL)
upc_sales_data<-function(i){
  #i=96
  brand = grain$Brand[i]
  cz_code = grain$CZ_Code[i]
  cust = grain$PLAN_Cust[i]
  sample = sales_data[sales_data$Brand == brand & sales_data$CZ_Code == cz_code & sales_data$PLAN_Cust == cust,]
  #head(sample,2)
  sample$Sales_units = sample$Sales*sample$UOM
  sample = sample[sample$Year>=2015,]
  sample = sample[order(sample$Brand,sample$SKU10,sample$PLAN_Cust,sample$Year,sample$Week_No),]
  names(sample)
  sample_cz = data.frame(sample %>% group_by(Brand,CZ_Code,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Sales= sum(Sales_units), Promo = max(Promo)),row.names = NULL)
  head(sample_cz,2)
  #sample_upc$Sales
  
  sku_list = unique(sample$SKU10)
  sku_latest = data.frame()
  for(j in 1:length(sku_list)){
    #j=1
    sku = sku_list[j]
    samplesku = sample[sample$SKU10==sku,]
    samplesku = samplesku[(samplesku$Year <=(ho_year-1) | (samplesku$Week_No <= ho_week & samplesku$Year==ho_year)),]
    samplesku <- samplesku[order(samplesku$Year,samplesku$Week_No),]
    end = max(which(!samplesku$Sales==0))
    end_sales = samplesku[end,]
    end_sales = cbind(end_sales,End_Week = end)
    sku_latest = rbind(sku_latest,end_sales)
  }
  sku_latest <- sku_latest[order(-sku_latest$Sales),]
  sku_latest <- sku_latest[order(-sku_latest$End_Week),]
  
  sku_select <- sku_latest[1,c("SKU10","UOM","UPC")]
  sample_cz = cbind(sample_cz,sku_select)
  sample_cz$Sales = sample_cz$Sales/sample_cz$UOM
  sample_cz$UOM = NULL
  head(sample_cz,2)
  if(!is.na(sum(sample_cz$Sales))){
    return(sample_cz)
  }
}

#Close any open cluster
#stopCluster(cl=NULL)
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

## Run the two lines - after running all other functions ##
sales_file_upc = data.frame()
sales_file_upc = foreach(p=(1:nrow(grain)),.combine = rbind,.export = c('sales_data'),
                          .packages=c('dplyr','doParallel','snow')) %dopar% upc_sales_data(p)
sales_file_upc$CZ_Code = NULL

# write.csv(sales_file_upc,"Sales_withCZ_272018.csv",row.names = FALSE)
# write.csv(sales_data1,"Sales_withCZ_272018.csv",row.names = FALSE)

sales_file_prep <- sales_file_upc
Promo_file_prep <- sales_file_upc
d1 <- data.frame(unique(sales_file_upc))
head(sales_file_prep,2)
head(Promo_file_prep,2)

Promo_file_prep <- merge(Promo_file_prep,customer_Mapping,by.x ="PLAN_Cust",by.y = "PlanToCustomer")
names(Promo_file_prep)
Promo_file_prep <- Promo_file_prep[,c("SKU10","DemandCustomer","PLAN_Cust","Year","Week_No","Promo")]
Promo_file_prep$PLAN_Cust <- paste("Cust_",Promo_file_prep$PLAN_Cust,sep = "")
Promo_file_prep <- spread(data = Promo_file_prep,key = PLAN_Cust,value = Promo)
Promo_file_prep[is.na(Promo_file_prep)] <- 0

head(Promo_file_prep,2)
head(customer_Mapping,2)
sales_file_prep <- merge(sales_file_prep,customer_Mapping,by.x ="PLAN_Cust",by.y = "PlanToCustomer")
sales_file_prep <- data.frame(sales_file_prep %>% 
                                group_by(Brand,SKU10,DemandCustomer,Year,Week_No,UPC) %>% 
                                dplyr::summarise(Sales=sum(Sales)),row.names = NULL)

nielsen_data = read.csv(paste(wd, "/Input_Files/Nielsen_prep.csv",sep=""),stringsAsFactors = FALSE)
head(nielsen_data,2)

#nielsen_data$N_Incr <- ifelse(nielsen_data$N_Sales-nielsen_data$N_Base<0,0,nielsen_data$N_Sales-nielsen_data$N_Base)
#nielsen_data$VSOD <- ifelse((nielsen_data$N_Sales==0 | nielsen_data$N_Incr<0),0,nielsen_data$N_Incr/nielsen_data$N_Sales)

sales_file_prep$UPC_code_nielsen <- paste(substr(sales_file_prep$UPC,0,(str_length(sales_file_prep$UPC)-1)),sep = "")
head(sales_file_prep,2)

sales_file_prep <- merge(sales_file_prep,nielsen_data,
                         by.x = c("DemandCustomer","UPC_code_nielsen","Year","Week_No"),
                         by.y = c("DemandCustomer","UPC","Year","Week_No"),
                         all.x = TRUE)
sales_file_prep[is.na(sales_file_prep)] = 0
head(sales_file_prep,2)

sales_file_prep <- sales_file_prep[order(sales_file_prep$Brand,sales_file_prep$SKU10,sales_file_prep$Year,sales_file_prep$Week_No),]
head(sales_file_prep,2)

sales_file_prep1 <- sales_file_prep
week_map <- data.frame(Week_No=c(1:53), Quarter = c(rep(1,13),rep(2,13),rep(3,13),rep(4,14)),Month_No = c(rep(1,4),rep(2,4),rep(3,5),rep(4,4),rep(5,4),rep(6,5),rep(7,4),rep(8,4),rep(9,5),rep(10,4),rep(11,4),rep(12,6)))
sales_file_prep <- merge(sales_file_prep,week_map,by="Week_No")
names(sales_file_prep)

grain2 <- data.frame(unique(sales_file_prep[,c("SKU10","DemandCustomer",'Brand')]),row.names = NULL)
sales_final_file <- data.frame()

sales_lag <- function(k){
  #k=1
  brand = grain2$Brand[k]
  sku = grain2$SKU10[k]
  cust = grain2$DemandCustomer[k]
  sample_lag = sales_file_prep[sales_file_prep$DemandCustomer==cust & sales_file_prep$SKU10==sku & sales_file_prep$Brand==brand,]
  sample_lag = sample_lag[order(sample_lag$Year,sample_lag$Week_No),]
  sample_lag$W_sales1 =  lag(sample_lag$Sales)
  sample_lag$W_sales2 =  lag(sample_lag$W_sales1)
  sample_lag$W_sales3 =  lag(sample_lag$W_sales2)
  sample_lag$W_sales4 =  lag(sample_lag$W_sales3)
  #sales_final_file = rbind(sales_final_file,sample_lag)
  return(sample_lag)
}

#Close any open cluster
#stopCluster(cl=NULL)
stopCluster(cl)
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

## Run the two lines - after running all other functions ##
sales_file_wLAG = data.frame()
sales_file_wLAG <- foreach(p=(1:nrow(grain2)),.combine = rbind,.export = c('sales_file_prep'),
                          .packages=c('dplyr','doParallel','snow')) %dopar% sales_lag(p)
sales_file_wLAG = sales_file_wLAG[,c("Brand","SKU10","DemandCustomer","Year",
                                     "Quarter","Month_No","Week_No","Sales",
                                     "N_Sales","W_sales1","W_sales2","W_sales3","W_sales4")]

names(Promo_file_prep)
sales_file_final <- merge(sales_file_wLAG,Promo_file_prep, by = c("SKU10","DemandCustomer","Year","Week_No"), all.x = TRUE)[, union(names(sales_file_wLAG), names(Promo_file_prep))]
sales_file_final[is.na(sales_file_final)] <- 0
names(sales_file_final)[9] <- "W_Nielsen"
#names(sales_file_final)[10] <- "W_VSOD"

# year_week <- data.frame(Year = c(2018,2018,2018),Month_No = c(4,5,6))
# sales_file_wsales <- merge(sales_file_final,year_week, by = c("Year","Month_No"))
# sales_file_wsales <- data.frame(sales_file_wsales %>% group_by(SKU10,DemandCustomer) %>% dplyr::summarise(Sales=sum(Sales)))
# sales_file_wsales <- sales_file_wsales[sales_file_wsales$Sales>0,c(1,2)]
# head(sales_file_wsales,2)
# sales_file_final_prep <- merge(sales_file_final,sales_file_wsales, by = names(sales_file_wsales))[, union(names(sales_file_final), names(sales_file_wsales))]

sales_file_final_prep <- sales_file_final
sales_file_final_prep <- sales_file_final_prep[order(sales_file_final_prep$Brand,
                                                     sales_file_final_prep$DemandCustomer,
                                                     sales_file_final_prep$SKU10,
                                                     sales_file_final_prep$Year,
                                                     sales_file_final_prep$Week_No),]

#nrow(unique(sales_data[,c("SKU10", "PLAN_Cust")]))
#names(sales_file_final_prep)
#sales_file_final_prep <- sales_file_final_prep[,c(1:8)]
stopCluster(cl)
getwd()
write.csv(sales_file_final_prep,paste(wd, "/Output_Files/DF_US_SalesFromFractal.csv",sep=""),row.names = FALSE)
write.csv(sales_file_final_prep,paste(wd, "/Output_Files/DF_US_SalesFromFractal_prevData.csv",sep=""),row.names = FALSE)

data <- data.frame(unique(sales_file_final_prep[,c(1:3)]))
#write.csv(data,"sku_count.csv",row.names = FALSE)


