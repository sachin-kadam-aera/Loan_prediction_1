#hold_t=8

to_convert = function(sample,hold_t){
    start_1 = max(which(!is.na(sample$Sales))) - hold_t +1
    end_1 = max(which(!is.na(sample$Sales)))
    #data1 <- sample[start_1:end_1,]
    
    week_index <- grep("W_",str_sub(names(sample),1,2))
    all_index <- week_index
    
    sample_D <- sample[!names(sample) %in% names(sample)[all_index]]
    sample_D[(end_1+1):NROW(sample),"Sales"]<-NA
    
    sample_w<-sample[names(sample) %in% c("Year","Month_No","Week_No","Quarter",names(sample)[week_index])]
    sample_w_1 <- sample_w[start_1:NROW(sample),] 
    sample_w_1[names(sample_w_1) %in% names(sample)[week_index]] <- NA
    sample_w_1 <- rbind(sample_w[1:(start_1-1),],sample_w_1)
    sample_w_2 <- sample_w[(end_1+1):NROW(sample),] 
    sample_w_2[names(sample_w_2) %in% names(sample)[week_index]] <- NA
    sample_w_2 <- rbind(sample_w[1:end_1,],sample_w_2)
    
    index_1<-max(which(!is.na(sample_w_1[names(sample)[week_index][1]])))+1
    index_2<-max(which(!is.na(sample_w_2[names(sample)[week_index][1]])))
    
    getFilled <- function(ck_ms){
      #ck_ms<-as.numeric(as.character(bk_w_forecast$W_Nielsen))
      first_nonNA = min(which(!is.na(ck_ms)))
      last_nonNA = max(which(!is.na(ck_ms)))
      mid = as.numeric(na.interp(ck_ms[first_nonNA:last_nonNA]))
      flength = length(ck_ms)-last_nonNA
      bflength = first_nonNA-1
      
      if(flength>0){
        mid = tsclean(mid)
        right = (as.numeric(stlf(ts(mid,frequency=13),h=flength,method="arima")$mean))
          }else{
            right<-NULL
          }
      new_filled = c(mid,right)
      
      if(!is.na(sum(new_filled))){
        return(new_filled)
      }else{
        return(rep(NA,length(ck_ms)))
      }
    }
    
    bk_w_hold<-sample_w_1
    bk_w_forecast<-sample_w_2
    set.seed(2017)
    
    Fill_w = as.data.frame(apply(bk_w_hold,2,function(x) getFilled(as.numeric(as.character(x)))))
    Fill_w_2 = as.data.frame(apply(bk_w_forecast,2,function(x) getFilled(as.numeric(as.character(x)))))
    
    Fill = merge(sample_D,Fill_w,by = c("Week_No","Year","Quarter","Month_No"))
    Fill_2 = merge(sample_D,Fill_w_2,by = c("Week_No","Year","Quarter","Month_No"))
    Frame1 = Fill
    Frame1 = Frame1[order(Frame1$Year,Frame1$Week_No),]
    Frame2 = Fill_2
    Frame2 = Frame2[order(Frame2$Year,Frame2$Week_No),]
    return(list(hold_out_data=Frame1,test_data = Frame2))
}

custom_combine_function<-function(F1,F2){
  Frame1<-rbind(F1$Frame1,F2$Frame1)
  Frame2<-rbind(F1$Frame2,F2$Frame2)
  return(list(Frame1=Frame1,Frame2=Frame2))
}


