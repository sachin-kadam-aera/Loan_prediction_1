#rm(list=ls())
if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(dplyr)) install.packages("dplyr")
if(!require(readxl)) install.packages("readxl")

wd <- ("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
setwd(paste0(wd))
list.files()

CZ_Mapping = read.csv(paste(wd, "/Output_Files/CZ_mapping_file.csv",sep =""),stringsAsFactors = FALSE)
CZ_Mapping_UPC = read.csv(paste(wd, "/Output_Files/UPC_Mapping_CZ.csv",sep =""),stringsAsFactors = FALSE)

CZ_Mapping_UPC = CZ_Mapping_UPC[CZ_Mapping_UPC$SKU_count>1,c("cust","sku_list","upc")]
names(CZ_Mapping_UPC) = c("PLAN_Cust","SKU10","UPC")
CZ_Mapping_UPC$UPC_Key = paste(CZ_Mapping_UPC$PLAN_Cust,CZ_Mapping_UPC$UPC,sep = "_")
CZ_Mapping_UPC = data.frame(unique(CZ_Mapping_UPC))
head(CZ_Mapping_UPC,2)

CZ_Map = CZ_Mapping[,c("PLAN_Cust","SKU10","UPC","Map_SKU10","Map_UPC")]
CZ_Map$Key = paste(CZ_Map$PLAN_Cust,CZ_Map$SKU10,sep = "_")
CZ_Map = CZ_Map[order(CZ_Map$Key),]
head(CZ_Map,2)
CZ_Map$CZ_Code = 1

for (i in 2:nrow(CZ_Map)){
  CZ_Map$CZ_Code[i] = ifelse(CZ_Map$Key[i]==CZ_Map$Key[i-1],CZ_Map$CZ_Code[i-1],CZ_Map$CZ_Code[i-1]+1)
}

names(CZ_Map)
CZ_Map1 = CZ_Map[,c("PLAN_Cust","SKU10","UPC","CZ_Code")]
CZ_Map2 = CZ_Map[,c("PLAN_Cust","Map_SKU10","Map_UPC","CZ_Code")]
names(CZ_Map2) = names(CZ_Map1)
CZ_prep = rbind(CZ_Map1,CZ_Map2)
CZ_prep = data.frame(unique(CZ_prep))
CZ_prep = data.frame(CZ_prep[order(CZ_prep$CZ_Code),],row.names = NULL)

head(CZ_prep,5)
CZ_prep$UPC_Key = paste(CZ_prep$PLAN_Cust,CZ_prep$UPC,sep ="_")
CZ_prep_UPC = CZ_prep[,c("UPC_Key","CZ_Code")]
CZ_prep_UPC = data.frame(unique(CZ_prep_UPC))

CZ_Mapping_UPC = merge(CZ_Mapping_UPC,CZ_prep_UPC,by = "UPC_Key",all.x = TRUE)
CZ_Mapping_UPC = CZ_Mapping_UPC[order(CZ_Mapping_UPC$UPC_Key),]
head(CZ_Mapping_UPC)

CZ_Mapping_UPC$CZ_Code1 <- 1000
for (i in 2:nrow(CZ_Mapping_UPC)){
  CZ_Mapping_UPC$CZ_Code1[i] = ifelse(CZ_Mapping_UPC$UPC[i]==CZ_Mapping_UPC$UPC[i-1],CZ_Mapping_UPC$CZ_Code1[i-1],CZ_Mapping_UPC$CZ_Code1[i-1]+1)
}

CZ_Mapping_UPC$CZ_Code1 <- ifelse(is.na(CZ_Mapping_UPC$CZ_Code),CZ_Mapping_UPC$CZ_Code1,CZ_Mapping_UPC$CZ_Code)
CZ_Mapping_UPC$CZ_Code <- CZ_Mapping_UPC$CZ_Code1
CZ_Mapping_UPC$CZ_Code1 <- NULL

CZ_prep_final = rbind(CZ_prep,CZ_Mapping_UPC)
CZ_prep_final = data.frame(unique(CZ_prep_final),row.names = NULL)
CZ_prep_final = CZ_prep_final[order(CZ_prep_final$CZ_Code),]

write.csv(CZ_prep_final,paste(wd, "/Output_Files/CZ_prep.csv",sep =""),row.names = FALSE)
CZ_prep <- read.csv(paste(wd, "/Output_Files/CZ_prep.csv",sep =""),stringsAsFactors = FALSE)

sales_file <- read.csv(paste(wd, "/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),stringsAsFactors = FALSE)
sales_file[is.na(sales_file)] <- "NA"
sales_file <- data.frame(sales_file %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) 
                         %>% dplyr::summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- sales_file[order(sales_file$Sales),]
Sales_data_Brand_Mapping <- data.frame(Sales_data_Brand_Mapping 
                                       %>% group_by(SKU10) 
                                       %>% dplyr::summarise(Brand=last(Brand )))
sales_file$Brand <- NULL
sales_file <- merge(sales_file,Sales_data_Brand_Mapping,by="SKU10")
sales_file <- data.frame(sales_file %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) 
                         %>% dplyr::summarise(Sales=sum(Sales)))
sales_file <- sales_file[sales_file$Year >=2015,]
Sales_data = merge(sales_file,CZ_prep,by = c("SKU10","PLAN_Cust"))

CZ_grain = data.frame(unique(Sales_data[,c("PLAN_Cust","CZ_Code")]),row.names = NULL)

sku_master <- read.csv(paste(wd, "/Input_Files/SKU_Master_final.csv",sep =""),stringsAsFactors = FALSE)
sku_master <- data.frame(sku_master %>% group_by(SKU10) %>%
                           dplyr::summarise(BSG = last(BSG),CaseToEach = last(UOM),
                                     price_perunit = last(Price_unit),UPC = last(UPC),PPG= last(PPG)))

head(sku_master,2)
sku_master <- sku_master[,c("SKU10","CaseToEach")]
Sales_data = merge(Sales_data,sku_master,by="SKU10")
names(Sales_data)

Sales_data_prep = data.frame()
for (i in 1:nrow(CZ_grain)){
  #i=1
  print(i)
  code_cz = CZ_grain$CZ_Code[i]
  sample = Sales_data[Sales_data$CZ_Code==code_cz,]
  sample$Sales_units = sample$Sales*sample$CaseToEach
  sample = sample[order(sample$Brand,sample$SKU10,sample$PLAN_Cust,sample$Year,sample$Week_No),]
  sample_cz = data.frame(sample %>% group_by(Brand,CZ_Code,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Sales= sum(Sales_units)),row.names = NULL)
  
  sku_list = unique(sample$SKU10)
  sku_latest = data.frame()
  for(j in 1:length(sku_list)){
    #j=1
    sku = sku_list[j]
    samplesku = sample[sample$SKU10==sku,]
    samplesku <- samplesku[order(samplesku$Year,samplesku$Week_No),]
    end = max(which(!samplesku$Sales==0))
    end_sales = samplesku[end,]
    end_sales = cbind(end_sales,End_Week = end)
    sku_latest = rbind(sku_latest,end_sales)
  }
  sku_latest <- sku_latest[order(-sku_latest$Sales),]
  sku_latest <- sku_latest[order(-sku_latest$End_Week),]
  sku_select <- sku_latest[1,c("SKU10","CaseToEach")]
  sample_cz = cbind(sample_cz,sku_select, row.names = NULL)
  sample_cz$Sales = sample_cz$Sales/sample_cz$CaseToEach
  sample_cz$CaseToEach = NULL
  Sales_data_prep = rbind(Sales_data_prep,sample_cz)
}

write.csv(Sales_data_prep,paste(wd, "/Output_Files/CZ_Sales_data.csv",sep =""),row.names = FALSE)
write.csv(Sales_data,paste(wd, "/Output_Files/CZ_Sales_data_raw.csv",sep =""),row.names = FALSE)

