rm(list=ls())

if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
if(!require(tidyr)) install.packages("tidyr")
if(!require(readxl)) install.packages("readxl")
if(!require(lubridate)) install.packages("lubridate")
if(!require(stringr)) install.packages("stringr")
if(!require(data.table)) install.packages("data.table")

wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

list.files()
user_input <- read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))
ho_year<- as.numeric(user_input$YEAR)
ho_week<- as.numeric(user_input$WEEK) -1

### Sales Data ###
sales_file <- read.csv(paste(wd, "/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),stringsAsFactors = FALSE)
sales_file <- data.frame(sales_file %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No)
                         %>% dplyr::summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- sales_file[order(sales_file$Sales),]
Sales_data_Brand_Mapping <- data.frame(Sales_data_Brand_Mapping
                                       %>% group_by(SKU10)
                                       %>% dplyr::summarise(Brand=last(Brand )))
sales_file$Brand <- NULL
sales_file <- merge(sales_file,Sales_data_Brand_Mapping,by="SKU10")
sales_file <- data.frame(sales_file %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No)
                         %>% dplyr::summarise(Sales=sum(Sales)))
sales_file <- sales_file[sales_file$Year >=2015,] 


### SKU and Customer Mapping ###
sku_description = read.csv(paste(wd, "/Output_Files/CZ_SKU_Mapping.csv",sep =""),stringsAsFactors = FALSE)
#head(sku_description,2)
customer_Mapping = read.csv(paste(wd, "/Input_Files/Customer_Mapping.csv",sep =""),stringsAsFactors = FALSE)
sales_data = merge(sales_file,sku_description,by.x = c("SKU10","PLAN_Cust"),by.y = c("SKU10","PlanToCustomer"))
#head(sales_data,2)

upc_check <- data.frame(unique(sales_data[,c("Brand","PLAN_Cust","UPC","CZ_Code","SKU10")]),row.names = NULL)
grain = data.frame(unique(sales_data[,c("Brand","PLAN_Cust","CZ_Code")]),row.names = NULL)
upc_sales_data<-function(i){
  #i=14631
  brand = grain$Brand[i]
  cz_code = grain$CZ_Code[i]
  cust = grain$PLAN_Cust[i]
  sample = sales_data[sales_data$Brand == brand & sales_data$CZ_Code == cz_code & sales_data$PLAN_Cust == cust,]
  #head(sample,2)
  sample$Sales_units = sample$Sales*sample$UOM
  sample = sample[sample$Year>=2015,]
  sample = sample[order(sample$Brand,sample$SKU10,sample$PLAN_Cust,sample$Year,sample$Week_No),]
  names(sample)
  sample_cz = data.frame(sample %>% group_by(Brand,CZ_Code,PLAN_Cust,Year,Week_No) %>% 
                           dplyr::summarise(Sales= sum(Sales_units)),row.names = NULL)
  head(sample_cz,2)
  #sample_cz$Sales
  sku_list = unique(sample$SKU10)
  sku_latest = data.frame()
  for(j in 1:length(sku_list)){
    #j=1
    sku = sku_list[j]
    samplesku = sample[sample$SKU10==sku,]
    samplesku = samplesku[(samplesku$Year <=(ho_year-1) | (samplesku$Week_No <= ho_week & samplesku$Year==ho_year)),]
    samplesku <- samplesku[order(samplesku$Year,samplesku$Week_No),]
    end = max(which(!samplesku$Sales==0))
    end_sales = samplesku[end,]
    end_sales = cbind(end_sales,End_Week = end)
    sku_latest = rbind(sku_latest,end_sales)
  }
  sku_latest <- sku_latest[order(-sku_latest$Sales),]
  sku_latest <- sku_latest[order(-sku_latest$End_Week),]
  sku_select <- sku_latest[1,c("SKU10","UOM","UPC")]
  sample_cz = cbind(sample_cz,sku_select)
  sample_cz$Sales = sample_cz$Sales/sample_cz$UOM
  sample_cz$UOM = NULL
  head(sample_cz,2)
  if(!is.na(sum(sample_cz$Sales))){
    return(sample_cz)
  }
}

#Close any open cluster
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

## Run the two lines - after running all other functions ##
sales_file_upc = data.frame()
sales_file_upc = foreach(p=(1:nrow(grain)),.combine = rbind,.export = c('sales_data'),
                          .packages=c('dplyr','doParallel','snow')) %dopar% upc_sales_data(p)
#stopCluster(cl=NULL)
stopCluster(cl)

sales_file_prep = sales_file_upc
sales_file_prep = merge(sales_file_prep,customer_Mapping,by.x ="PLAN_Cust",by.y = "PlanToCustomer")
sales_file_prep = data.frame(sales_file_prep %>% 
                               group_by(Brand,SKU10,DemandCustomer,Year,Week_No,UPC) %>% 
                               dplyr::summarise(Sales=sum(Sales)),row.names = NULL)
sales_file_prep$UPC_code_nielsen = paste(substr(sales_file_prep$UPC,0,(str_length(sales_file_prep$UPC)-1)),sep = "")

nielsen_data = read.csv(paste(wd, "/Input_Files/Nielsen_prep.csv",sep=""),stringsAsFactors = FALSE)
str(nielsen_data)

nielsen_data$UPC <- as.character(round(as.numeric(trimws(as.character(nielsen_data$UPC))),0))
nielsen_data$N_Sales <- as.numeric(nielsen_data$N_Sales)

sales_file_prep <- merge(sales_file_prep, nielsen_data,
                         by.x = c("DemandCustomer","UPC_code_nielsen","Year","Week_No"),
                         by.y = c("DemandCustomer","UPC","Year","Week_No"),all.x = TRUE)

sales_file_prep <- sales_file_prep[order(sales_file_prep$Brand,sales_file_prep$SKU10,
                                         sales_file_prep$Year,sales_file_prep$Week_No),]

week_map <- data.frame(Week_No=c(1:53), Quarter = c(rep(1,13),rep(2,13),rep(3,13),rep(4,14)),Month_No = c(rep(1,4),rep(2,4),rep(3,5),rep(4,4),rep(5,4),rep(6,5),rep(7,4),rep(8,4),rep(9,5),rep(10,4),rep(11,4),rep(12,6)))
sales_file_prep <- merge(sales_file_prep,week_map,by="Week_No")
sales_file_prep$W_Nielsen = sales_file_prep$N_Sales

sales_file_prep <- sales_file_prep[order(sales_file_prep$Brand,
                                         sales_file_prep$DemandCustomer,
                                         sales_file_prep$SKU10,
                                         sales_file_prep$Year,
                                         sales_file_prep$Week_No),]
sales_file_prep = sales_file_prep[,c("Brand","SKU10","DemandCustomer","Year","Quarter","Month_No",
                                     "Week_No","Sales","W_Nielsen")]
fwrite(sales_file_prep,paste(wd, "/Output_Files/DF_US_CZ.csv",sep =""),row.names = FALSE)
