rm(list=ls())

if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(smooth)) install.packages("smooth")
if(!require(dplyr)) install.packages("dplyr")
if(!require(data.table)) install.packages("data.table")
library(stringr)
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

user_input = read.csv(paste0(wd,"/Input_Files/User_Input_File_USA.csv"))
forecast_start_week <- unique(user_input$WEEK) - 1
forecast_start_year <- unique(user_input$YEAR)
fcst_efs_dir =  paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"))

sales_file = fread(paste0(fcst_efs_dir,"/Forecast_File_prep.csv"),stringsAsFactors = FALSE)
sales_file = sales_file[order(sales_file$SKU10,sales_file$DemandCustomer,sales_file$Year,sales_file$Week_No),]
#sales_file = sales_file[sales_file$DemandCustomer != "ALL OTHERS - US",]

sales_file$Forecast_Final = ifelse((sales_file$Year<forecast_start_year|(sales_file$Year==forecast_start_year & sales_file$Week_No <= forecast_start_week)),sales_file$Sales,sales_file$Forecast)
sales_file$Promo = ifelse(sales_file$VSOD_8_final>0,1,0)

grain = data.frame(unique(sales_file[,c("SKU10","DemandCustomer","Model")]),row.names = NULL)
basline_cal<-function(i){
  #i=81
  sku = grain$SKU10[i]
  cust = grain$DemandCustomer[i]
  model = grain$Model[i]
  sample = sales_file[sales_file$SKU10==sku & sales_file$DemandCustomer==cust & sales_file$Model==model,]
  sample = sample[order(sample$Year,sample$Week_No),]
  sample[is.na(sample)] <- "NAN"
  sample$Promo[1:3] = 0
  sample2 = sample[sample$Promo==0,]
  sample2$Baseline4 <- sample2$Forecast_Final
  if (nrow(sample2)>3){
    for(j in 4:nrow(sample2)){
      #j=4
      sample2$Baseline4[j] = mean(sample2$Forecast_Final[(j-3):j])
    }
  }
  #names(sample2)
  sample2 <- sample2[,c("Year","Week_No","Baseline4")]
  sample <- data.frame(merge(sample,sample2,by.x = c("Year","Week_No"),by.y = c("Year","Week_No"),all.x = TRUE))
  sample <- sample[order(sample$Year,sample$Week_No),]
  for(j in 4:nrow(sample)){
    sample$Baseline4[j] = ifelse(sample$Promo[j]==1,sample$Baseline4[j-1],sample$Baseline4[j])
  }
  return(sample)
}

no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

baseline_file <- data.frame()
baseline_file <- foreach(p=(1:nrow(grain)),.combine = rbind,.packages=c('smooth')) %dopar% basline_cal(p)
stopCluster(cl=NULL)
stopCluster(cl)

baseline_file$Increment_4 = baseline_file$Forecast_Final-baseline_file$Baseline4
baseline_file$Increment_4 = ifelse(baseline_file$Increment_4<0,0,baseline_file$Increment_4)

fwrite(baseline_file,paste0(fcst_efs_dir,"/Forecast_with_incr_result.csv"))
