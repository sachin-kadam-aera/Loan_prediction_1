rm(list=ls())

if(!require(R.utils)) install.packages("R.utils")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
if(!require(data.table)) install.packages("data.table")

wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)


Sales_file <- fread(paste(wd,"/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),stringsAsFactors = FALSE)
sales_data = data.frame(Sales_file)
Sales_data <- data.frame(sales_data %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No)
                         %>% dplyr::summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- Sales_data[order(Sales_data$Sales),]
Sales_data_Brand_Mapping <- data.frame(Sales_data_Brand_Mapping
                                       %>% group_by(SKU10)
                                       %>% dplyr::summarise(Brand=last(Brand )))
Sales_data$Brand <- NULL
Sales_data <- merge(Sales_data,Sales_data_Brand_Mapping,by="SKU10")
Sales_data <- data.frame(Sales_data %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No)
                         %>% dplyr::summarise(Sales=sum(Sales)))
sales_data <- Sales_data[Sales_data$Year >=2015,]
fwrite(sales_data,paste(wd,"/Output_Files/Sales_SKULCPLANCust.csv",sep =""))

