
if(!require(data.table)) install.packages("data.table")
library(data.table)

setwd("/home/kkulkarni/preprocessing/testing/Data_Prep_Codes/Output_Files/")

wd = getwd()

sales_file_final_prep_kk <-as.data.table(read.csv("DF_US_362018_0911_kk.csv"))
sales_file_final_prep_anant <- as.data.table(read.csv("DF_US_362018_0911_19200-96226.csv"))

head(sales_file_final_prep_kk,2)
head(sales_file_final_prep_anant,2)

length(unique(sales_file_final_prep_kk[,c("Brand")]) )
length(unique(sales_file_final_prep_anant[,c("Brand")]) )

length(unique(sales_file_final_prep_kk[,c("SKU10")]) )
length(unique(sales_file_final_prep_anant[,c("SKU10")]) )

length(unique(sales_file_final_prep_kk[,c("DemandCustomer")]) )
length(unique(sales_file_final_prep_anant[,c("DemandCustomer")]) )

length(unique(sales_file_final_prep_kk[,c("Year")]) )
length(unique(sales_file_final_prep_anant[,c("Year")]) )

length(unique(sales_file_final_prep_kk[,c("Quarter")]) )
length(unique(sales_file_final_prep_anant[,c("Quarter")]) )

length(unique(sales_file_final_prep_kk[,c("Month_No")]) )
length(unique(sales_file_final_prep_anant[,c("Month_No")]) )

kk_colsums <- as.data.table(colSums(sales_file_final_prep_kk[,-c("Brand","SKU10","DemandCustomer")],na.rm = FALSE, dims = 1))
kk_colsums$colnames = colnames(sales_file_final_prep_kk[,-c("Brand","SKU10","DemandCustomer")])


anant_colsums <- as.data.table(colSums(sales_file_final_prep_anant[,-c("Brand","SKU10","DemandCustomer")],na.rm = FALSE, dims = 1))
anant_colsums$colnames = colnames(sales_file_final_prep_anant[,-c("Brand","SKU10","DemandCustomer")])
colnames(anant_colsums)[1] <- "V1_anant"

combined_sums <- merge(kk_colsums,anant_colsums,by="colnames")

