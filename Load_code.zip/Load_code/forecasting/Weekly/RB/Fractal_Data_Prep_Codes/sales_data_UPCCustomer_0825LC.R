#rm(list=ls())

setwd("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/")
wd = getwd()
if(!require(data.table)) install.packages("data.table")
library(data.table)

library('lubridate')
library(doParallel)
library(dplyr)
library(tidyr)
library(stringi)
library(stringr)
list.files()
user_input <- read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))

#user_input <- read.csv("User_Input_File_USA.csv")
ho_year<- as.numeric(user_input$YEAR)
ho_week<- as.numeric(user_input$WEEK) -1


#sales_data = read.csv("Sales_data_SKUPLANCust_36.2018.csv",stringsAsFactors = FALSE)
Sales_data <- read.csv(paste(wd, "/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),
                       stringsAsFactors = FALSE)
Sales_data <- data.frame(Sales_data %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- Sales_data[order(Sales_data$Sales),]
Sales_data_Brand_Mapping <- data.frame(Sales_data_Brand_Mapping %>% group_by(SKU10) %>% dplyr::summarise(Brand=last(Brand )))
Sales_data$Brand <- NULL
Sales_data <- merge(Sales_data,Sales_data_Brand_Mapping,by="SKU10")
sales_data <- data.frame(Sales_data %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Sales=sum(Sales)))

#sales_data <- sales_data[sales_data$SKU10 %in% c('19200-00027', '19200-00051', '19200-00062', '19200-00066', '19200-00101', '19200-00202', '19200-00252', '19200-00262', '19200-00300', '19200-00301', '19200-00305', '19200-00311', '19200-00316', '19200-00317', '19200-00318', '19200-00335', '19200-00336', '19200-00338', '19200-00339', '19200-00379', '19200-00381', '19200-00382', '19200-00601', '19200-00706', '19200-00785', '19200-00786', '19200-00888', '19200-00948', '19200-02501', '19200-02522', '19200-02569', '19200-02699', '19200-02845', '19200-02922', '19200-74185', '19200-74186', '19200-75055', '19200-75058', '19200-75352', '19200-75531', '19200-75590', '19200-76878', '19200-76879', '19200-76938', '19200-76940', '19200-77182', '19200-77454', '19200-77500', '19200-77660', '19200-77925', '19200-78033', '19200-78625', '19200-78626', '19200-78630', '19200-78631', '19200-78642', '19200-78816', '19200-78849', '19200-78914', '19200-78915', '19200-78916', '19200-78997', '19200-79056', '19200-79132', '19200-79174', '19200-79196', '19200-79326', '19200-79328', '19200-79329', '19200-79556', '19200-79567', '19200-79568', '19200-79633', '19200-79830', '19200-79831', '19200-79838', '19200-79954', '19200-80078', '19200-80088', '19200-80296', '19200-80306', '19200-80307', '19200-80309', '19200-80310', '19200-80313', '19200-80342', '19200-80373', '19200-80425', '19200-80498', '19200-80783', '19200-80816', '19200-80833', '19200-80834', '19200-80870', '19200-80984', '19200-80985', '19200-81143', '19200-81145', '19200-81146', '19200-81344'),]
sales_data <- sales_data[sales_data$Year >=2015,]

promo_data = read.csv(paste(wd, "/Output_Files/ppg_code_output_allgrainWeek35.csv",sep=""),stringsAsFactors = FALSE)
promo_data = data.frame(unique(promo_data),row.names = NULL)

sku_description = read.csv(paste(wd, "/Input_Files/SKU-Master.csv",sep =""),stringsAsFactors = FALSE)
customer_Mapping = read.csv(paste(wd, "/Input_Files/Customer_Mapping.csv",sep =""),stringsAsFactors = FALSE)

head(sales_data,2)
head(promo_data,2)
head(customer_Mapping,2)

#promo_data <- merge(promo_data,customer_Mapping,by.x = "CUST_CODE",by.y = "PlanToCustomer")
#promo_data$CUST_CODE = NULL

sales_data = merge(sales_data,promo_data,
                            by.x = c("SKU10","PLAN_Cust","Year","Week_No"),
                            by.y = c("SKU10","PLAN_Cust","Year","Week_No"),all.x = TRUE)
sales_data[is.na(sales_data)] = 0

head(sales_data,2)
head(sku_description,2)
sku_description$Price <- NULL
sku_description$Tag <- NULL

sku_description = sku_description[,c("SKU10","UOM","UPC")]
#nrow(data.frame(unique(sku_description$SKU10)))
sales_data = merge(sales_data,sku_description,by = "SKU10")

grain = data.frame(unique(sales_data[,c("Brand","PLAN_Cust","UPC")]),row.names = NULL)
upc_sales_data<-function(i){
  #i=6485
  #print(i)
  brand = grain$Brand[i]
  upc = grain$UPC[i]
  cust = grain$PLAN_Cust[i]
  sample = sales_data[sales_data$Brand == brand & sales_data$UPC == upc & sales_data$PLAN_Cust == cust,]
  sample$Sales_units = sample$Sales*sample$UOM
  sample = sample[sample$Year>=2015,]
  sample = sample[order(sample$Brand,sample$SKU10,sample$PLAN_Cust,sample$Year,sample$Week_No),]
  sample_upc = data.frame(sample %>% group_by(Brand,UPC,PLAN_Cust,Year,Week_No) %>% dplyr::summarise(Sales= sum(Sales_units), Promo = max(Promo)),row.names = NULL)
  #sample_upc$Sales

  sku_list = unique(sample$SKU10)
  sku_latest = data.frame()
  for(j in 1:length(sku_list)){
    #j=1
    sku = sku_list[j]
    samplesku = sample[sample$SKU10==sku,]
    samplesku = samplesku[(samplesku$Year <=(ho_year-1) | (samplesku$Week_No <= ho_week & samplesku$Year==ho_year)),]
    samplesku <- samplesku[order(samplesku$Year,samplesku$Week_No),]
    end = max(which(!samplesku$Sales==0))
    end_sales = samplesku[end,]
    end_sales = cbind(end_sales,End_Week = end)
    sku_latest = rbind(sku_latest,end_sales)
  }
  sku_latest <- sku_latest[order(-sku_latest$Sales),]
  sku_latest <- sku_latest[order(-sku_latest$End_Week),]

  sku_select <- sku_latest[1,c("SKU10","UOM")]
  sample_upc = cbind(sample_upc,sku_select)
  sample_upc$Sales = sample_upc$Sales/sample_upc$UOM
  sample_upc$UOM = NULL

  if(!is.na(sum(sample_upc$Sales))){
    return(sample_upc)
    #sales_file_upc = rbind(sales_file_upc,sample_upc)
  }
}

#7)Create the clusters
#Close any open cluster
#stopCluster(cl=NULL)
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

#8) FUNCTION Call
## Run the two lines - after running all other functions ##
sales_file_upc = data.frame()
sales_file_upc <- foreach(p=(1:nrow(grain)),.combine = rbind,.export = c('sales_data'),
                          .packages=c('dplyr','doParallel','snow')) %dopar% upc_sales_data(p)

write.csv(sales_file_upc,paste(wd, "/Output_Files/Sales_withUPC_36.2018_kk.csv",sep=""),row.names = FALSE)

#sales_file_upc <- read.csv("Sales_withUPC_08.2018.csv",stringsAsFactors = FALSE)
sales_file_prep <- sales_file_upc
Promo_file_prep <- sales_file_upc
head(sales_file_prep,2)
head(Promo_file_prep,2)

Promo_file_prep <- merge(Promo_file_prep,customer_Mapping,by.x ="PLAN_Cust",by.y = "PlanToCustomer")
Promo_file_prep <- Promo_file_prep[,c(8,9,1,4,5,7)]
Promo_file_prep$PLAN_Cust <- paste("Cust_",Promo_file_prep$PLAN_Cust,sep = "")
Promo_file_prep <- spread(data = Promo_file_prep,key = PLAN_Cust,value = Promo)
Promo_file_prep[is.na(Promo_file_prep)] <- 0

head(sales_file_prep,2)
head(customer_Mapping,2)
sales_file_prep <- merge(sales_file_prep,customer_Mapping,by.x ="PLAN_Cust",by.y = "PlanToCustomer")
sales_file_prep <- data.frame(sales_file_prep %>% group_by(Brand,SKU10,DemandCustomer,Year,Week_No,UPC) %>% dplyr::summarise(Sales=sum(Sales)),row.names = NULL)

getwd()
nielsen_data = read.csv(paste(wd, "/Input_Files/Nielsen_prep.csv",sep=""),stringsAsFactors = FALSE)
head(nielsen_data,2)

sales_file_prep$UPC_code_nielsen <- paste(substr(sales_file_prep$UPC,0,(str_length(sales_file_prep$UPC)-1)),sep = "")
head(sales_file_prep,2)

sales_file_prep <- merge(sales_file_prep,nielsen_data,by.x = c("DemandCustomer","UPC_code_nielsen","Year","Week_No"),by.y = c("DemandCustomer","UPC","Year","Week_No"),all.x = TRUE)
sales_file_prep[is.na(sales_file_prep)] = 0
head(sales_file_prep,2)

sales_file_prep <- sales_file_prep[order(sales_file_prep$Brand,sales_file_prep$SKU10,sales_file_prep$Year,sales_file_prep$Week_No),]

head(sales_file_prep,2)

sales_file_prep1 <- sales_file_prep
week_map <- data.frame(Week_No=c(1:53), Quarter = c(rep(1,13),rep(2,13),rep(3,13),rep(4,14)),Month_No = c(rep(1,4),rep(2,4),rep(3,5),rep(4,4),rep(5,4),rep(6,5),rep(7,4),rep(8,4),rep(9,5),rep(10,4),rep(11,4),rep(12,6)))
sales_file_prep <- merge(sales_file_prep,week_map,by="Week_No")
names(sales_file_prep)

grain2 <- data.frame(unique(sales_file_prep[,c("SKU10","DemandCustomer",'Brand')]),row.names = NULL)
sales_final_file <- data.frame()

sales_lag <- function(k){
#for (k in 1:nrow(grain2)){
  #k=1
  brand = grain2$Brand[k]
  sku = grain2$SKU10[k]
  cust = grain2$DemandCustomer[k]
  sample_lag = sales_file_prep[sales_file_prep$DemandCustomer==cust & sales_file_prep$SKU10==sku & sales_file_prep$Brand==brand,]
  sample_lag = sample_lag[order(sample_lag$Year,sample_lag$Week_No),]
  sample_lag$W_sales1 =  lag(sample_lag$Sales)
  sample_lag$W_sales2 =  lag(sample_lag$W_sales1)
  sample_lag$W_sales3 =  lag(sample_lag$W_sales2)
  sample_lag$W_sales4 =  lag(sample_lag$W_sales3)
  #sales_final_file = rbind(sales_final_file,sample_lag)
  return(sample_lag)
}

#7)Create the clusters
#Close any open cluster
#stopCluster(cl=NULL)
#stopCluster(cl)


no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

#8) FUNCTION Call
## Run the two lines - after running all other functions ##
sales_file_wLAG = data.frame()
sales_file_wLAG <- foreach(p=(1:nrow(grain2)),.combine = rbind,.export = c('sales_file_prep'),
                          .packages=c('dplyr','doParallel','snow')) %dopar% sales_lag(p)

names(sales_file_wLAG)
sales_file_wLAG = sales_file_wLAG[,c("Brand","SKU10","DemandCustomer","Year","Quarter","Month_No","Week_No","Sales","N_Sales","W_sales1","W_sales2","W_sales3","W_sales4")]

names(Promo_file_prep)
sales_file_final <- merge(sales_file_wLAG,Promo_file_prep, by = c("SKU10","DemandCustomer","Year","Week_No"), all.x = TRUE)[, union(names(sales_file_wLAG), names(Promo_file_prep))]
sales_file_final[is.na(sales_file_final)] <- 0

names(sales_file_final)[9] <- "W_Nielsen"

#year_week <- data.frame(Year = c(2018,2018,2018),Month_No = c(6,7,8))
#sales_file_wsales <- merge(sales_file_final,year_week, by = c("Year","Month_No"))
#sales_file_wsales <- data.frame(sales_file_wsales %>% group_by(SKU10,DemandCustomer) %>% dplyr::summarise(Sales=sum(Sales)))
#sales_file_wsales <- sales_file_wsales[sales_file_wsales$Sales>0,c(1,2)]

#sales_file_final_prep <- merge(sales_file_final,sales_file_wsales, by = names(sales_file_wsales))[, union(names(sales_file_final), names(sales_file_wsales))]
sales_file_final_prep <- sales_file_final[order(sales_file_final$Brand,
                                                sales_file_final$DemandCustomer,
                                                sales_file_final$SKU10,
                                                sales_file_final$Year,
                                                sales_file_final$Week_No),]

nrow(unique(sales_data[,c("SKU10", "PLAN_Cust")]))

stopCluster(cl)
getwd()
write.csv(sales_file_final_prep,paste(wd, "/Output_Files/DF_US_SalesFromFractal.csv",sep=""),row.names = FALSE)

