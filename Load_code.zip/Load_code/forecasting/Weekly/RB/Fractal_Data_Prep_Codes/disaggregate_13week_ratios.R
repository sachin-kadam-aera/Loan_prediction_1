
#rm(list=ls())
library("dplyr")
library(stringr)
wd <- ("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
list.files()

## Sales_file ##
sales_file = read.csv(paste(wd, "/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),stringsAsFactors = FALSE)
customer_map <- read.csv(paste(wd, "/Input_Files/Customer_Mapping.csv",sep =""),stringsAsFactors = FALSE)

Sales_data = data.frame(sales_file %>% group_by(Brand, SKU10,LC,PLAN_Cust,Year,Week_No) %>% summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- Sales_data[order(Sales_data$Sales),]
Sales_data_Brand_Mapping =  data.frame(Sales_data_Brand_Mapping %>% group_by(SKU10)  %>%dplyr::summarise(Brand=last(Brand)))

Sales_data$Brand <- NULL
Sales_data <- merge(Sales_data,Sales_data_Brand_Mapping,by="SKU10")

Sales_data = data.frame(Sales_data  %>% group_by(Brand, SKU10,LC,PLAN_Cust,Year,Week_No) %>% summarise(Sales=sum(Sales)))
sales_data <- Sales_data[Sales_data$Year >=2015,]

sales_file = merge(sales_data,customer_map,by.x = "PLAN_Cust",by.y = "PlanToCustomer")
sales_file = data.frame(sales_file %>% group_by(Brand,LC,DemandCustomer,SKU10,Year,Week_No) %>% summarise(Sales=sum(Sales)))
sales_file$YearWeek =paste(str_pad(sales_file$Year,4,pad =('0')),str_pad(sales_file$Week_No,2,pad =('0')),sep="")


head(sales_file,6)

## User Input Config ##
user_input = read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))
week_count = 13
ho_year = as.numeric(user_input$YEAR)
ho_week = as.numeric(user_input$WEEK) 

week_mapping = read.csv("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Codes/Codes_USA/Week_Mapping.csv",stringsAsFactors = FALSE)
week_mapping$YearWeek =paste(str_pad(week_mapping$Year,4,pad =('0')),str_pad(week_mapping$Week,2,pad =('0')),sep="")

week_mapping_index_end = unique(week_mapping[week_mapping$Year==ho_year & week_mapping$Week==ho_week,]$Week_No)
week_mapping_index_start = unique(week_mapping[week_mapping$Week_No==(week_mapping_index_end-week_count) ,]$Week_No)

week_mapping_end = unique(week_mapping[week_mapping$Week_No==(toString(week_mapping_index_end)) ,]$YearWeek)
week_mapping_start = unique(week_mapping[week_mapping$Week_No==(week_mapping_index_start) ,]$YearWeek)

sales_data =sales_file[sales_file$YearWeek>=week_mapping_start & sales_file$YearWeek<week_mapping_end ,]


sales_data_LC = data.frame(sales_data %>% group_by(Brand,SKU10,DemandCustomer,LC) %>% summarise(Sales=sum(Sales)))
sales_data_Cust = data.frame(sales_data %>% group_by(Brand,SKU10,DemandCustomer) %>% summarise(Sales_Cust=sum(Sales)))
head(sales_data_Cust,2)

sales_data_prep = merge(sales_data_LC,sales_data_Cust,by =c("Brand","SKU10","DemandCustomer"))
head(sales_data_prep,6)
sales_data_prep$sales_percent = ifelse(sales_data_prep$Sales_Cust==0,0,sales_data_prep$Sales/sales_data_prep$Sales_Cust)
sales_data_prep = sales_data_prep[,c("Brand","SKU10","DemandCustomer","LC","sales_percent")]

forecast_start_week <- unique(user_input$WEEK)
forecast_start_year <- unique(user_input$YEAR)
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
subDir = paste("fcst_",toString(forecast_start_year) ,str_pad(toString(forecast_start_week),2,pad = "0"),sep ="")
dir.create(file.path(efs_dir,subDir), showWarnings = FALSE)

filename = paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"),"/fcst_13weekavg_ratios.csv")
write.csv(sales_data_prep,filename,row.names = FALSE)
