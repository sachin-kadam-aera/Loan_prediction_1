rm(list = ls())

if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
if(!require(memisc)) install.packages("memisc")
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

user_input = read.csv(paste(wd,"/Input_Files/User_Input_File_USA.csv",sep = ""),stringsAsFactors = FALSE)
start_week = unique(user_input$WEEK)-1
start_year = unique(user_input$YEAR)

sales_file = fread(paste0(wd,"/Output_Files/DF_US_Promo_siebel.csv"))
sku_grains_all = data.frame(unique(sales_file[,c("Brand","SKU10","DemandCustomer")],index = NULL))

promo_file = fread(paste0(wd,"/Output_Files/Promo_data_customer_withPromoID.csv"))
promo_file = data.frame(promo_file)
promo_file$Count = ifelse(promo_file$VSOD>0,1,0)
promo_file = promo_file[promo_file$Count>0,]
promo_file = promo_file[promo_file$Year >= 2017,]
promo_file = promo_file[!(promo_file$DemandCustomer %in% c("ALL OTHERS - US","INTERNATIONAL")),]

promo_file_train = promo_file[(promo_file$Year < start_year) | (promo_file$Year == start_year & promo_file$Week_No<= start_week),]
promo_file_test = promo_file[(promo_file$Year > start_year) | (promo_file$Year == start_year & promo_file$Week_No> start_week),]

promo_file_train = data.frame(unique(promo_file_train[,c("SKU10","DemandCustomer","Promo_ID","Count")]),row.names = NULL)
promo_file_test = data.frame(unique(promo_file_test[,c("SKU10","DemandCustomer","Promo_ID","Count")]))

promo_file_train = data.frame(promo_file_train%>%group_by(SKU10,DemandCustomer)%>%dplyr::summarise(Promo_Count_train= sum(Count)))
promo_file_test = data.frame(promo_file_test%>%group_by(SKU10,DemandCustomer)%>%dplyr::summarise(Promo_Count_test= sum(Count)))

promo_file_train$Promo_train = ifelse(promo_file_train$Promo_Count_train >= 3,1,0)
promo_file_test$Promo_test = 1

sku_grains = merge(sku_grains_all,promo_file_train,by= c("SKU10","DemandCustomer"),all.x = TRUE)
sku_grains = merge(sku_grains,promo_file_test,by= c("SKU10","DemandCustomer"),all.x = TRUE)
sku_grains[is.na(sku_grains)] = 0

sku_grains = within(sku_grains,{
  Promo_status=NA
  Promo_status[Promo_train > 0 & Promo_test > 0] = "PP"
  Promo_status[Promo_train == 0 & Promo_test > 0] = "NP"
  #Promo_status[Promo_train > 0 & Promo_test == 0] = "PN"
  #Promo_status[Promo_train == 0 & Promo_test == 0] = "NN"
  Promo_status[Promo_test == 0] = "NN"})

sku_grains$Promo = ifelse(sku_grains$Promo_status =="PP",1,0)

### Intermediate skus tagging
fwrite(sku_grains,paste0(wd,"/Output_Files/SKU_Promo_tag.csv"))

promo_skus = sku_grains
promo_skus = promo_skus[promo_skus$Promo>0,]
promo_skus = promo_skus[,c("SKU10","DemandCustomer")]
promo_skus$Promo = 1

sales_file = data.frame(sales_file)
sales_data = merge(sales_file,promo_skus,by=c("SKU10","DemandCustomer"),
                   all.x = TRUE)[,union(names(sales_file),names(promo_skus))]
head(sales_data,2)
sales_data$Promo = ifelse(is.na(sales_data$Promo),0,1)
sales_data$DOD = ifelse(sales_data$Promo ==1,sales_data$DOD ,0)
sales_data$VSOD = ifelse(sales_data$Promo ==1,sales_data$VSOD ,0)
head(sales_data,2)

fwrite(sales_data,paste0(wd,"/Output_Files/DF_US_Sales_Siebel_promo.csv"))
