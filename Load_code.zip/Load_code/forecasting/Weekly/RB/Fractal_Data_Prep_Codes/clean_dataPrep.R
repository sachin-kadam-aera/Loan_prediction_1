library(filesstrings)
library(stringr)
user_input = read.csv("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/User_Input_File_USA.csv")
data_prep_output = "/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Output_Files/"
fcst_efs_dir =  paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"))

filelist = list.files(data_prep_output, pattern="*.csv")
for (file1 in filelist){
  file.copy(paste0(data_prep_output,file1), paste0(fcst_efs_dir,"/"),overwrite = TRUE)
  file.remove(paste0(data_prep_output,file1))
}
