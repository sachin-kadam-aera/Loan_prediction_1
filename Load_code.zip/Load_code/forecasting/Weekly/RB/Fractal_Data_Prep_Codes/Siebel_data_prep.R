rm(list=ls())
wd = getwd()

Promo_data_concatenated_till2016 <- read.csv(paste(wd, "/Input_Files/Promo_data_concatenated_till2016.csv",sep =""))
promo_file <- read.csv(paste(wd, "/Input_Files/Siebel_data_020718.csv",sep =""), stringsAsFactors = FALSE)

promo_file <- as.data.table(promo_file)
promo_file <- promo_file[(promo_file$PROMO_STATUS  %in% c("Committed Approved","Committed Revised","Draft","Committed","Closed")),]
promo_file$SKU = substring(promo_file$SKU_CODE,1,11)
promo_file = promo_file[,c("PP_CODE","CUST_CODE","PROMO_ID","PROMO_SHIP_START_DT","PROMO_SHIP_END_DT",
                                   "PROMO_NAME","SKU","INCR_QTY","BASE_QTY")]
promo_file <- promo_file[,list(INCR_QTY = sum(INCR_QTY),
                               BASE_QTY = sum(BASE_QTY)),
                            by = c("PP_CODE","CUST_CODE","PROMO_ID","PROMO_SHIP_START_DT",
                                   "PROMO_SHIP_END_DT","PROMO_NAME","SKU")]



promo_file <- rbind(promo_file,Promo_data_concatenated_till2016)
promo_file <- promo_file[promo_file$SKU =="19200-96226",]

head(promo_file,2)
names(promo_file)[3] <- "Promo_type"


sku_grain <- unique(promo_file[,c("PP_CODE","SKU","CUST_CODE","Promo_type")])

#sku_list <- c("19200-84251","19200-79329","19200-81145","19200-82159","19200-79633-31")
#sku_grain2 <- unique(sku_grain[sku_grain$SKU %in% sku_list,])
sku_grain2 <- sku_grain

file_prep <- function(i){
  #i=1
  #print(i)
  #pp_code <- sku_grain2$PP_CODE[i]
  sku <- sku_grain2$SKU[i]
  customer <- sku_grain2$CUST_CODE[i]
  promo_id <- sku_grain2$Promo_type[i]
  sample <- filter(promo_file,SKU==sku,CUST_CODE==customer,Promo_type==promo_id)
  #sample1 <- filter(promo_file,SKU=="19200-82159")
  #sum(sample$INCR_QTY)
  #names(sample)
  #sample <- sample[,c(3,4,8,9)]
  data_withdate <- data.frame()
  for(j in 1:nrow(sample)){
    #j=1
    row1 <- sample[j,]
    if((as.Date(row1$PROMO_SHIP_START_DT) <= as.Date(row1$PROMO_SHIP_END_DT)) & (year(as.Date(row1$PROMO_SHIP_START_DT)) >= 2013)){
      date <- seq(as.Date(row1$PROMO_SHIP_START_DT),as.Date(row1$PROMO_SHIP_END_DT),by='days')
      data1 <- cbind(row1,date)
      #data1$Sales <- data1$Sales/length(date)
      data_withdate <- rbind(data_withdate,data1)
    }
  }
  if(nrow(data_withdate)>0){
    data_withdate$Year <- year(data_withdate$date)
    data_withdate$Week <- week(data_withdate$date)
    data_withdate <- data_withdate %>% group_by(PP_CODE,SKU,CUST_CODE,Promo_type,Year,Week) %>% dplyr::summarise(INCR_QTY=mean(INCR_QTY), BASE_QTY=mean(BASE_QTY))
  }
  data_withdate <- as.data.frame(data_withdate)
  #data_prep <- rbind(data_prep,data_withdate)
  #print(i)
  return(data_withdate)
}
  

#Close any open cluster
# stopCluster(cl=NULL)
# stopCluster(cl)

#7)Create the clusters 
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)


#8) FUNCTION Call 
## Run the two lines - after running all other functions ##
final_final <- data.frame()
final_final <- foreach(p=(1:nrow(sku_grain2)),.combine = rbind,
                       .packages=c('dplyr','lubridate')) %dopar% file_prep(p)

#stopCluster(cl=NULL)
stopCluster(cl)

promo_data_prep <- as.data.frame(final_final %>% group_by(PP_CODE,SKU,CUST_CODE,Promo_type,Year,Week) %>% dplyr::summarise(INCR_QTY=sum(INCR_QTY), BASE_QTY=sum(BASE_QTY)))
getwd()
promo_data <- promo_data_prep[promo_data_prep$Year >= 2016,]



write.csv(promo_data,paste(wd, "/Output_Files/Siebel_Promo_data_prep.csv",sep=""),row.names = FALSE)

