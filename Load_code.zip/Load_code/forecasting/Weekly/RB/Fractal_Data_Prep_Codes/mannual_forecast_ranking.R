if(!require(data.table)) install.packages("data.table")
library(stringr)
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

SKU_Promo_tag =  read.csv(paste(wd, "/Output_Files/SKU_Promo_tag.csv",sep =""))
filtergrains = unique(SKU_Promo_tag[SKU_Promo_tag$Promo_SKU==1 & SKU_Promo_tag$DemandCustomer != 'ALL OTHERS - US',c("Brand","SKU10","DemandCustomer")])
nrow(filtergrains)
user_input = read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))
forecast_start_week <- unique(user_input$WEEK)
forecast_start_year <- unique(user_input$YEAR)
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
subDir = paste("fcst_",toString(forecast_start_year) ,str_pad(toString(forecast_start_week),2,pad = "0"),sep ="")
dir.create(file.path(efs_dir,subDir), showWarnings = FALSE)

filename = paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"),"/manual_forecastrank.csv")
write.csv(filtergrains,filename,row.names = FALSE)
