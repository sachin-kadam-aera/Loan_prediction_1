
rm(list=ls())
if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")

wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

promo_file = fread(paste(wd,"/Input_Files/Promo_data.csv",sep = ""),skip = 3)
promo_file = data.frame(promo_file)
head(promo_file)

# unique(promo_file$Promotion.Status)
### Siebel Data Filter - Cancelled promo, EDLP Promo type ###
promo_file = promo_file[!(promo_file$Promotion.Status %in% c("Cancelled","Scenario")),]
promo_file = promo_file[promo_file$Discount.Tactic != "EDLP Allowance",]
promo_file = unique(promo_file[,c("Promotion.Id",'Promotion',"Ship.Start.Date","Ship.End.Date","Customer.Number",
                                  "Product.Number","Discount.Tactic",'BIP',"Promoted.Price","Est..Baseline.Qty",
                                  "Est..Incremental.Qty")])
promo_file$Ship.Start.Date = ymd(promo_file$Ship.Start.Date)
promo_file$Ship.End.Date = ymd(promo_file$Ship.End.Date)
promo_file = promo_file[year(promo_file$Ship.End.Date)>=2015,]
col_names = c("Promo_ID","Promotion","Promo_ship_start_date","Promo_ship_end_date","PLAN_Cust","PPG","Tactic","BIP","Promo_price","BASE_Qty","INCR_Qty")
colnames(promo_file) = col_names

### Caculation DOD, VSOD ###
promo_file$Promotion = toupper(promo_file$Promotion)
promo_file$DOD = ifelse(promo_file$BIP==0,0,abs(promo_file$Promo_price-promo_file$BIP)/promo_file$BIP)
promo_file$DOD[grep("BOGO",(promo_file$Promotion))] = ifelse(promo_file$DOD[grep("BOGO",(promo_file$Promotion))] < 0.6,
                                                             promo_file$DOD[grep("BOGO",(promo_file$Promotion))],0.5)

# promo_file1 = promo_file[promo_file$PLAN_Cust==11599753,]
# 11599753 - PUBLIX

week_mapping = read.csv(paste(wd,"/Input_Files/Week_Mapping_Promo.csv",sep = ""),stringsAsFactors = F)
week_mapping$Date <- as.Date(week_mapping$Day,format = "%d-%m-%y")
week_mapping = week_mapping[week_mapping$Weekend_Check==1,]
week_mapping <- week_mapping[,c("Date","Year","Week_No")]

sku_mapping = read.csv(paste0(wd,"/Input_Files/PPG_Mapping.csv"),stringsAsFactors = F)
sku_mapping = sku_mapping[,c("SKU10","PPG")]
#cust_mapping$DemandCustomer

ppg_grain = data.frame(unique(promo_file[,c("PPG","PLAN_Cust")]),row.names = NULL)
promo_data = function(j){
  #j=1
  ppg = ppg_grain$PPG[j]
  cust = ppg_grain$PLAN_Cust[j]
  sample = promo_file[promo_file$PLAN_Cust==cust & promo_file$PPG==ppg,]
  data_withdate = data.frame()
  for(i in 1:nrow(sample)){
    #i=1
    row1 = sample[i,]
    date <- seq(row1$Promo_ship_start_date,row1$Promo_ship_end_date,by='days')
    data1 <- cbind(row1,date)
    data_withdate <- rbind(data_withdate,data1)
  }
  data_withdate = data.frame(data_withdate %>% group_by(PPG,PLAN_Cust,date) %>% 
                               dplyr::summarise(DOD=mean(DOD),INCR_Qty=sum(INCR_Qty),BASE_Qty=sum(BASE_Qty)))
  data_withdate = merge(data_withdate,week_mapping,by.x = "date",by.y = "Date")
  data_withdate$Days_count = 1
  data_withdate = data.frame(data_withdate %>% group_by(PPG,PLAN_Cust,Year,Week_No) %>% 
                               dplyr::summarise(DOD=mean(DOD),INCR_Qty=sum(INCR_Qty),BASE_Qty=sum(BASE_Qty),
                                                Days_count=sum(Days_count)))
  data_withdate = data_withdate[data_withdate$Days_count>1,]
  return(data_withdate)
}

no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

## Run the two lines - after running all other functions ##
promo_final <- data.frame()
promo_final <- foreach(p=(1:nrow(ppg_grain)),.combine = rbind,
                       .packages=c('dplyr','lubridate','data.table')) %dopar% promo_data(p)
stopCluster(cl)
# fwrite(promo_final,paste0(wd,"/Output_Files/Promo_data_stage1.csv"))

cust_mapping = fread(paste(wd,"/Input_Files/Customer_Mapping.csv",sep = ""))
promo_prep = merge(promo_final,cust_mapping,by.x="PLAN_Cust",by.y = "PlanToCustomer")[,union(names(promo_final),"DemandCustomer")]
promo_prep$DOD = ifelse(promo_prep$DemandCustomer %in% c("ALL OTHERS - US","INTERNATIONAL"),0,promo_prep$DOD)

promo_prep = merge(promo_prep,sku_mapping,by="PPG")
promo_prep = promo_prep[order(promo_prep$PPG,promo_prep$SKU10,promo_prep$DemandCustomer,
                              promo_prep$PLAN_Cust,promo_prep$Year,promo_prep$Week_No),]

promo_prep = data.frame(promo_prep %>% group_by(PPG,DemandCustomer,SKU10,Year,Week_No) %>% 
                          dplyr::summarise(DOD=max(DOD),INCR_Qty=sum(INCR_Qty),BASE_Qty=sum(BASE_Qty)))
promo_prep$VSOD = ifelse(promo_prep$INCR_Qty==0,0,promo_prep$INCR_Qty/(promo_prep$INCR_Qty+promo_prep$BASE_Qty))
head(promo_prep)

fwrite(promo_prep,paste0(wd,"/Output_Files/Promo_data_customer.csv"))

