rm(list=ls())

if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(smooth)) install.packages("smooth")
if(!require(dplyr)) install.packages("dplyr")
if(!require(data.table)) install.packages("data.table")
library(stringr)
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

user_input = read.csv(paste0(wd,"/Input_Files/User_Input_File_USA.csv"))
forecast_start_week <- unique(user_input$WEEK) - 1
forecast_start_year <- unique(user_input$YEAR)
fcst_efs_dir =  paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"))

sales_file = fread(paste0(fcst_efs_dir,"/Forecast_with_incr_result.csv"),stringsAsFactors = FALSE)
sales_file <- sales_file[order(sales_file$SKU10,sales_file$DemandCustomer,sales_file$Year,sales_file$Week_No),]
head(sales_file,2)

sku_mapping = read.csv(paste0(fcst_efs_dir,"/SKU_Master_final.csv"),stringsAsFactors = F)
ppg_mapping = data.frame(sku_mapping %>% group_by(SKU10) %>% dplyr::summarise(PPG = last(PPG)))

sales_data = merge(sales_file,ppg_mapping,by = c("SKU10"),all.x = TRUE)

ppg_grain = data.frame(unique(sales_data[,c("PPG","DemandCustomer")],index = NULL))
ppg_grain_distribution_func = function(i){
  #i=2
  ppg = ppg_grain$PPG[i]
  cust = ppg_grain$DemandCustomer[i]
  model = ppg_grain$Model[i]
  sample = sales_data[sales_data$PPG==ppg & sales_data$DemandCustomer==cust,]
  sku_list = unique(sample$SKU10)
  sample1 = data.frame(sample %>% group_by(PPG,DemandCustomer,Year,Week_No) %>% dplyr::summarise(INCR_Qty=sum(Increment_4)))
  sample1 = sample1[(sample1$Year<forecast_start_year | (sample1$Year==forecast_start_year & sample1$Week_No <= forecast_start_week)),]
  sample1 = sample1[order(sample1$Year,sample1$Week_No),]
  sample1 = sample1[c((nrow(sample1)-25):nrow(sample1)),]
  names(sample1)
  sample1 = data.frame(sample1 %>% group_by(PPG,DemandCustomer) %>% dplyr::summarise(INCR_Qty_ppg=sum(INCR_Qty)))
  sku_data_prep = data.frame()
  for (j in 1:length(sku_list)){
    #j=1
    sku = sku_list[j]
    sample_sku = sample[sample$SKU10==sku,]
    sample_sku1 = sample_sku[(sample_sku$Year<forecast_start_year | (sample_sku$Year==forecast_start_year & sample_sku$Week_No <= forecast_start_week)),]
    sample_sku1 = sample_sku1[order(sample_sku1$Year,sample_sku1$Week_No),]
    sample_sku1 = sample_sku1[c((nrow(sample_sku1)-25):nrow(sample_sku1)),]
    sample_sku1 = data.frame(sample_sku1 %>% group_by(PPG,SKU10,DemandCustomer) %>% dplyr::summarise(INCR_Qty=sum(Increment_4)))
    sku_data_prep = rbind(sku_data_prep,sample_sku1)
  }
  sku_data = merge(sample1,sku_data_prep,by = c("PPG","DemandCustomer"))
  sku_data$incr_per = ifelse(sku_data$INCR_Qty_ppg==0,0,sku_data$INCR_Qty/sku_data$INCR_Qty_ppg)
  return(sku_data)
}

no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

incr_file_prep= data.frame()
incr_file_prep <- foreach(p=(1:nrow(ppg_grain)),.combine = rbind,.packages=c('dplyr')) %dopar% ppg_grain_distribution_func(p)
stopCluster(cl=NULL)
stopCluster(cl)

incr_file_prep_per = incr_file_prep[,c("SKU10","DemandCustomer","incr_per")]
# head(incr_file_prep_per)
# head(sales_data)
sales_data = merge(sales_data,incr_file_prep_per, by =c("SKU10","DemandCustomer"))
sales_data$INCR_Qty_new = sales_data$INCR_Qty*sales_data$incr_per
head(sales_data,2)

fwrite(sales_data,paste0(fcst_efs_dir,"/Forecast_withINCR.csv"))

