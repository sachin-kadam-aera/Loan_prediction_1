
rm(list=ls())

if(!require(data.table)) install.packages("data.table")
library(stringr)
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

user_input = read.csv(paste0(wd,"/Input_Files/User_Input_File_USA.csv"))
forecast_start_week <- unique(user_input$WEEK) - 1
forecast_start_year <- unique(user_input$YEAR)

fcst_efs_dir =  paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"))

df_code_file_name = paste0("DF_File_withVSOD_",forecast_start_week,"_",forecast_start_year,".csv")

sales_file = fread(paste0(fcst_efs_dir,"/",df_code_file_name),stringsAsFactors = FALSE)
sales_file = sales_file[order(sales_file$SKU10,sales_file$DemandCustomer,sales_file$Year,sales_file$Week_No),]
sales_file = data.frame(sales_file)
# sales_file$INCR_Qty = NULL
# sales_file$BASE_Qty = NULL
head(sales_file,2)
promo_path = paste0(fcst_efs_dir,"/Promo_data_customer.csv")
promo_file = fread(promo_path,stringsAsFactors = FALSE)
promo_file = promo_file[,c("SKU10","DemandCustomer","Year","Week_No","INCR_Qty")]
promo_file = data.frame(promo_file)
head(promo_file,2)

sales_file = merge(sales_file,promo_file,
                   by=c("SKU10","DemandCustomer","Year","Week_No"),
                   all.x = TRUE)[,c(union(names(sales_file),names(promo_file)))]
sales_file$INCR_Qty[is.na(sales_file$INCR_Qty)] = 0
#sales_data = sales_data[sales_data$Promo==1,]

forecast_start_week <- unique(user_input$WEEK)
forecast_start_year <- unique(user_input$YEAR)
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
subDir = paste("fcst_",toString(forecast_start_year) ,str_pad(toString(forecast_start_week),2,pad = "0"),sep ="")
dir.create(file.path(efs_dir,subDir), showWarnings = FALSE)

input_to_ensemble = paste0(fcst_efs_dir,"/input_to_ensemble.csv")

print(input_to_ensemble)
forecast_result = fread(input_to_ensemble,stringsAsFactors = FALSE)


names(forecast_result) = c("SKU10","DemandCustomer","Year","Week_No","Model","Forecast")
head(forecast_result,2)
forecast_result = forecast_result[!is.na(forecast_result$Forecast),]
forecast_result = data.frame(forecast_result)

sales_data = merge(sales_file,forecast_result,by = c("SKU10","DemandCustomer","Year","Week_No"),all.x = TRUE)[,c(union(names(sales_file),names(forecast_result)))]
sales_data = sales_data[order(sales_data$Brand,sales_data$SKU10,sales_data$DemandCustomer,sales_data$Year,sales_data$Week_No),]
sales_data$Forecast[is.na(sales_data$Forecast)] = 0

fwrite(sales_data,paste0(fcst_efs_dir,"/Forecast_File_prep.csv"))
