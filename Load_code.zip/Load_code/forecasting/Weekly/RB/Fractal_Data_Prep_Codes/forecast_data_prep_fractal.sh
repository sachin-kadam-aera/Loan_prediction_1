#!/bin/bash
echo 'Connected forecast07.......'
#Fractal R scripts for Data Preprocessing
cp /efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_skudmdcust_weekly_fractal.csv /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/
cp /efs/datascience/Reckitt7B8/data/input/Customer_Mapping.csv /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/
cp /efs/datascience/Reckitt7B8/data/input/Promo_data.csv /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/
#cp /efs/datascience/Reckitt7B8/data/input/PPG_Mapping.csv /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/
cp /efs/datascience/Reckitt7B8/data/input/SKU_Master_final.csv /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/
cp /efs/datascience/Reckitt7B8/data/input/Nielsen_prep.csv /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/
cd /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/
python create_user_input_file.py $1 $2 $3
cd /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/
R < run_dataprep_part1.R --save
R < run_dataprep_part2.R --save


python fractal2AeraDataConversion.py $1 $2 $3
