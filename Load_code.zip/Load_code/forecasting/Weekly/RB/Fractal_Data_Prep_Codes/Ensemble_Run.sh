#!/bin/bash
cd /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes 
R <Ensemble.R --save
