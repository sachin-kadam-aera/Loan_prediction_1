setwd("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
library(data.table)
library(lubridate)
library(dplyr)

#CZ Logic
source("1_CZ_UPCtag.R")
source("2_CZ_BSGPrice.R")
source("3_CZ_sales_prep_cases.R")
source("4_CZ_Filter.R")

source("1_sales_data_prep.R")
source("2_sales_data_CZCustomer.R")

source("Promo_data_prep_p1.R")
source("Promo_data_prep_p2.R")
source("Promo_data_prep_p3.R")
source("Promo_data_prep_p4_Promo_Tag.R")
source("Promo_data_prep_p5.R")
source("Promo_data_prep_p6_Final_SKU_Tag.R")
source("disaggregate_13week_ratios.R")
