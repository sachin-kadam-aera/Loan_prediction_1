rm(list=ls())

if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

promo_file = fread(paste0(wd,"/Output_Files/Promo_data_customer_update.csv"))
promo_file = data.frame(promo_file)
promo_file = data.frame(promo_file %>% group_by(DemandCustomer,SKU10,Year,Week_No) %>% 
                          dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=max(INCR_Qty),BASE_Qty=max(BASE_Qty)))

sales_data = fread(paste0(wd,"/Output_Files/DF_US_CZ.csv"))
sales_data = data.frame(sales_data)
sales_prep = merge(sales_data,promo_file,
                   by = c("SKU10","DemandCustomer","Year","Week_No"),
                   all.x = TRUE)[,union(names(sales_data),names(promo_file))]
sales_prep$DOD[is.na(sales_prep$DOD)] = 0
sales_prep$VSOD[is.na(sales_prep$VSOD)] = 0
sales_prep$INCR_Qty[is.na(sales_prep$INCR_Qty)] = 0
sales_prep$BASE_Qty[is.na(sales_prep$BASE_Qty)] = 0
sales_prep = sales_prep[order(sales_prep$SKU10,sales_prep$DemandCustomer,sales_prep$Year,sales_prep$Week_No),]

fwrite(sales_prep,paste0(wd,"/Output_Files/DF_US_Promo_siebel.csv"))
