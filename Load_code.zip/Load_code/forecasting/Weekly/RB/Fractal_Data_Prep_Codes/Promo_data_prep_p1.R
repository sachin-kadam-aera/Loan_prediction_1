rm(list=ls())

if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")
library(stringr)
wd ="/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
setwd(wd)

promo_file = fread(paste(wd,"/Input_Files/Promo_data.csv",sep = ""))
promo_file = data.frame(promo_file)
#head(promo_file)

# unique(promo_file$Promotion.Status)
### Siebel Data Filter - Cancelled promo, EDLP Promo type ###
promo_file = promo_file[!(promo_file$Promotion.Status %in% c("Cancelled","Scenario")),]
promo_file = promo_file[promo_file$Discount.Tactic != "EDLP Allowance",]
promo_file = unique(promo_file[,c("Promotion.Id",'Promotion',"Ship.Start.Date","Ship.End.Date","Customer.Number",
                                  "Product.Number","Discount.Tactic",'BIP',"Promoted.Price","Est.Baseline.Qty",
                                  "Est.Incremental.Qty")])
promo_file$Ship.Start.Date = ymd(promo_file$Ship.Start.Date)
promo_file$Ship.End.Date = ymd(promo_file$Ship.End.Date)
promo_file = promo_file[year(promo_file$Ship.End.Date)>=2015,]
col_names = c("Promo_ID","Promotion","Promo_ship_start_date","Promo_ship_end_date","PLAN_Cust","PPG","Tactic","BIP","Promo_price","BASE_Qty","INCR_Qty")
colnames(promo_file) = col_names

### Caculation DOD, VSOD ###
promo_file$Promotion = toupper(promo_file$Promotion)
promo_file$DOD = ifelse(promo_file$BIP==0,0,abs(promo_file$Promo_price-promo_file$BIP)/promo_file$BIP)
promo_file$DOD[grep("BOGO",(promo_file$Promotion))] = ifelse(promo_file$DOD[grep("BOGO",(promo_file$Promotion))] > 0.3,
                                                             promo_file$DOD[grep("BOGO",(promo_file$Promotion))],0.5)
promo_file$VSOD = ifelse(promo_file$INCR_Qty==0,0,abs(promo_file$INCR_Qty/(promo_file$INCR_Qty+promo_file$BASE_Qty)))
promo_file$BASE_Qty = ifelse(promo_file$INCR_Qty>0,promo_file$BASE_Qty,0)
promo_file = promo_file[promo_file$INCR_Qty>0,]

week_mapping = read.csv(paste(wd,"/Input_Files/Week_Mapping_Promo.csv",sep = ""),stringsAsFactors = F)
week_mapping$Date <- as.Date(week_mapping$Day,format = "%d-%m-%y")
week_mapping = week_mapping[week_mapping$Weekend_Check==1,]
week_mapping <- week_mapping[,c("Date","Year","Week_No")]

sku_mapping = read.csv(paste0(wd,"/Input_Files/SKU_Master_final.csv"),stringsAsFactors = F) 
sku_mapping = data.frame(sku_mapping %>% group_by(SKU10) %>% dplyr::summarise(PPG = last(PPG)))

ppg_grain = data.frame(unique(promo_file[,c("PPG","PLAN_Cust","Promo_ID")]),row.names = NULL)
promo_data = function(j){
  #j=4
  ppg = ppg_grain$PPG[j]
  cust = ppg_grain$PLAN_Cust[j]
  promo_id = ppg_grain$Promo_ID[j]
  sample = promo_file[promo_file$PLAN_Cust==cust & promo_file$PPG==ppg & promo_file$Promo_ID==promo_id,]
  data_withdate = data.frame()
  for(i in 1:nrow(sample)){
    #i=44
    row1 = sample[i,]
    date <- seq(row1$Promo_ship_start_date,row1$Promo_ship_end_date,by='days')
    data1 <- cbind(row1,date)
    data_withdate <- rbind(data_withdate,data1)
  }
  data_withdate = data.frame(data_withdate %>% group_by(PPG,Promo_ID,PLAN_Cust,date) %>% 
                               dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=mean(INCR_Qty),BASE_Qty=mean(BASE_Qty)))
  data_withdate = merge(data_withdate,week_mapping,by.x = "date",by.y = "Date")
  if(nrow(data_withdate)>0){
    data_withdate$Days_count = 1
    data_withdate1 = data.frame(data_withdate %>% group_by(PPG,Promo_ID,PLAN_Cust,Year,Week_No) %>% 
                                  dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=sum(INCR_Qty),BASE_Qty=sum(BASE_Qty),
                                                   Days_count=sum(Days_count)))
    data_withdate1 = data_withdate1[data_withdate1$Days_count>1,]
    data_withdate1 = data_withdate1[,c("Promo_ID","Year","Week_No")]
    data_withdate = merge(data_withdate,data_withdate1,by = c("Promo_ID","Year","Week_No"))[,names(data_withdate)]
    data_withdate2 = data.frame(data_withdate %>% group_by(PPG,Promo_ID,PLAN_Cust) %>% 
                                  dplyr::summarise(Days_count=sum(Days_count)))
    data_withdate$Days_count = NULL
    data_withdate = merge(data_withdate,data_withdate2,
                          by = c("PPG","Promo_ID","PLAN_Cust"))
    data_withdate$INCR_Qty = data_withdate$INCR_Qty/data_withdate$Days_count
    data_withdate$BASE_Qty = data_withdate$BASE_Qty/data_withdate$Days_count
    data_withdate = data.frame(data_withdate %>% group_by(PPG,Promo_ID,PLAN_Cust,Year,Week_No) %>% 
                                 dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=sum(INCR_Qty),BASE_Qty=sum(BASE_Qty)))
    if(nrow(data_withdate)>13){
      data_withdate = data_withdate[0,]
    }else if(nrow(data_withdate)==2){
      INCR_quantity = sum(data_withdate$INCR_Qty)
      BASE_quantity = sum(data_withdate$BASE_Qty)
      data_withdate$INCR_Qty[1] = INCR_quantity*.8
      data_withdate$INCR_Qty[2] = INCR_quantity*.2
      data_withdate$VSOD[1] = ifelse(data_withdate$INCR_Qty[1]==0,0,data_withdate$INCR_Qty[1]/(INCR_quantity+BASE_quantity))
      data_withdate$VSOD[2] = ifelse(data_withdate$INCR_Qty[2]==0,0,data_withdate$INCR_Qty[2]/(INCR_quantity+BASE_quantity))
    }else if(nrow(data_withdate)==3){
      INCR_quantity = sum(data_withdate$INCR_Qty)
      BASE_quantity = sum(data_withdate$BASE_Qty)
      data_withdate$INCR_Qty[1] = INCR_quantity*.7
      data_withdate$INCR_Qty[2] = INCR_quantity*.2
      data_withdate$INCR_Qty[3] = INCR_quantity*.1
      data_withdate$VSOD[1] = ifelse(data_withdate$INCR_Qty[1]==0,0,data_withdate$INCR_Qty[1]/(INCR_quantity+BASE_quantity))
      data_withdate$VSOD[2] = ifelse(data_withdate$INCR_Qty[2]==0,0,data_withdate$INCR_Qty[2]/(INCR_quantity+BASE_quantity))
      data_withdate$VSOD[3] = ifelse(data_withdate$INCR_Qty[3]==0,0,data_withdate$INCR_Qty[2]/(INCR_quantity+BASE_quantity))}else if(nrow(data_withdate)==0){
      data_withdate = data_withdate[0,]
    }else{
      data_withdate$VSOD = data_withdate$VSOD/nrow(data_withdate)
    }
    return(data_withdate)
  }
}

no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

## Run the two lines - after running all other functions ##
promo_final <- data.frame()
promo_final <- foreach(p=(1:nrow(ppg_grain)),.combine = rbind,
                       .packages=c('dplyr','lubridate','data.table')) %dopar% promo_data(p)
#stopCluster(cl=NULL)
stopCluster(cl)

cust_mapping = fread(paste(wd,"/Input_Files/Customer_Mapping.csv",sep = ""))
promo_prep = merge(promo_final,cust_mapping,by.x="PLAN_Cust",by.y = "PlanToCustomer")[,union(names(promo_final),"DemandCustomer")]
promo_prep$DOD = ifelse(promo_prep$DemandCustomer %in% c("ALL OTHERS - US","INTERNATIONAL"),0,promo_prep$DOD)

promo_prep = merge(promo_prep,sku_mapping,by="PPG")
promo_prep = promo_prep[order(promo_prep$PPG,promo_prep$SKU10,promo_prep$DemandCustomer,
                              promo_prep$PLAN_Cust,promo_prep$Year,promo_prep$Week_No),]

promo_prep = data.frame(promo_prep %>% group_by(PPG,DemandCustomer,SKU10,Promo_ID,Year,Week_No) %>% 
                          dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=sum(INCR_Qty),BASE_Qty=sum(BASE_Qty)))
head(promo_prep)

promo_prep_SKU = data.frame(promo_prep %>% group_by(PPG,DemandCustomer,SKU10,Year,Week_No) %>% 
                              dplyr::summarise(DOD=max(DOD),VSOD=max(VSOD),INCR_Qty=sum(INCR_Qty),BASE_Qty=sum(BASE_Qty)))

fwrite(promo_prep,paste0(wd,"/Output_Files/Promo_data_customer_withPromoID.csv"))
fwrite(promo_prep_SKU,paste0(wd,"/Output_Files/Promo_data_customer.csv"))
user_input = read.csv("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/User_Input_File_USA.csv")
promo_prep_SKU_output = paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"),"/Promo_data_customer.csv")
efs_dir = "/efs/datascience/Reckitt7B8/forecastoutputfiles/"
dir.create(file.path(efs_dir), showWarnings = FALSE)
dir.create(file.path(paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"))))
fwrite(promo_prep_SKU,promo_prep_SKU_output)
efs_dir_path = paste0("/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_",toString(user_input$YEAR),str_pad(toString(user_input$WEEK),2,pad = "0"))
file.copy("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv", efs_dir_path, overwrite = TRUE)
file.copy("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/Customer_Mapping.csv", efs_dir_path, overwrite = TRUE)
file.copy("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/Promo_data.csv", efs_dir_path, overwrite = TRUE)
file.copy("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/SKU_Master_final.csv", efs_dir_path, overwrite = TRUE)
file.copy("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/Nielsen_prep.csv", efs_dir_path, overwrite = TRUE)
file.copy("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/User_Input_File_USA.csv", efs_dir_path, overwrite = TRUE)
