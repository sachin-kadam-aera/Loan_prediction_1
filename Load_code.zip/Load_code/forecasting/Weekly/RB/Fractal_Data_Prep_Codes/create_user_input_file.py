#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sat Sep 15 00:15:52 2018

@author: vikranthole
"""
import pandas as pd
import sys

new_df = pd.DataFrame(columns='Country,Forecast_Model,APO_Destination_location,Item_No2,FORECAST_HORIZON,HOLDOUT_PERIOD,YEAR,WEEK,Forecast_Variable'.split(','))
HOLDOUT_PERIOD,YEAR,WEEK = sys.argv[1],sys.argv[2],sys.argv[3]
#HOLDOUT_PERIOD,YEAR,WEEK =13,2018,18

new_df = new_df.append({'Country':'USA','Forecast_Model':'ALL','APO_Destination_location':'ALL','Item_No2':'ALL','FORECAST_HORIZON':78,'HOLDOUT_PERIOD':HOLDOUT_PERIOD,'YEAR':YEAR,'WEEK':WEEK,'Forecast_Variable':'Primary_Forecast'}, ignore_index=True)
new_df.to_csv('/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Codes/User_config_File/User_Input_File_USA.csv',index = False)
new_df.to_csv('/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/User_Input_File_USA.csv',index = False)
new_df.to_csv('/efs/datascience/Reckitt7B8/data/input/User_Input_File_USA.csv',index = False)
