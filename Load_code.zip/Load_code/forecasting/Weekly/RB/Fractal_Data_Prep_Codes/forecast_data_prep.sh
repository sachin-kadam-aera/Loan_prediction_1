#!/bin/bash
echo 'Connected forecast01.......'

#Univariate RFH
cp /efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_skudmdcust_weekly_aera.csv /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/data/RECKITT_BENCKISER/


#  Multivariate
#Fractal R scripts for Data Preprocessing Regular Run
cp /efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_skudmdcust_weekly_fractal.csv /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Input_Files/ 
cd /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/
R < run_dataprep.R --save

#Fractal to Aera data Format Conversion Regular
cd /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/
python fractal2AeraDataConversion.py /home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes/Output_Files/DF_US_SalesFromFractal.csv /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/data/RECKITT_BENCKISER/rfh_saleshistory_sku10_weekly_multivariate.csv 



