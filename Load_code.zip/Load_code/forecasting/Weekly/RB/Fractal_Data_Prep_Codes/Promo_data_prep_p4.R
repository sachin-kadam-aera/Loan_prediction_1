
rm(list = ls())
if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")

setwd("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
wd = "/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes"
list.files()

sales_file = fread(paste0(wd,"/Output_Files/DF_US_Promo_siebel.csv"))
names(sales_file)
sku_grains = data.frame(unique(sales_file[,c("Brand","SKU10","DemandCustomer")],index = NULL))

user_input = read.csv(paste(wd,"/Input_Files/User_Input_File_USA.csv",sep = ""),stringsAsFactors = FALSE)
start_week = unique(user_input$WEEK)-1
start_year = unique(user_input$YEAR)

sales_file = sales_file[sales_file$Year>2016,]
sales_file$Count = ifelse(sales_file$VSOD>0,1,0)
sales_data1 = sales_file[(sales_file$Year < start_year) |(sales_file$Year == start_year & sales_file$Week_No <= start_week),]
sales_data2 = sales_file[(sales_file$Year > start_year) |(sales_file$Year == start_year & sales_file$Week_No > start_week),]

sales_data_check = data.frame(sales_file %>% group_by(Brand,SKU10,DemandCustomer) %>% dplyr::summarise(VSOD_complete=sum(Count),Sales_sum= sum(Sales)))
sales_data_check1 = data.frame(sales_data1 %>% group_by(Brand,SKU10,DemandCustomer) %>% dplyr::summarise(VSOD_train=sum(Count)))
sales_data_check2 = data.frame(sales_data2 %>% group_by(Brand,SKU10,DemandCustomer) %>% dplyr::summarise(VSOD_fh=sum(Count)))

nrow(sales_data_check[sales_data_check$VSOD_complete>0,])
nrow(sales_data_check1[sales_data_check1$VSOD_train>0,])
nrow(sales_data_check2[sales_data_check2$VSOD_fh>0,])
sku_grains = merge(sales_data_check,sales_data_check1,by= c("Brand","SKU10","DemandCustomer"))
sku_grains = merge(sku_grains,sales_data_check2,by= c("Brand","SKU10","DemandCustomer"))
sku_grains = sku_grains[sku_grains$Sales_sum>0,]
sku_grains$Promo_SKU = ifelse(sku_grains$VSOD_complete>0,1,0)
sku_grains$Fut_Promo = ifelse(sku_grains$VSOD_fh>0,ifelse(sku_grains$VSOD_train>0,0,1),0)
sku_grains$Sales_sum = as.integer(sku_grains$Sales_sum)
sku_grains = sku_grains[order(sku_grains$Brand,sku_grains$DemandCustomer,-sku_grains$Sales_sum),]

fwrite(sku_grains,paste0(wd,"/Output_Files/SKU_Promo_tag.csv"))

