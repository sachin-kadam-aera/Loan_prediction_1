#rm(list=ls())
if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(dplyr)) install.packages("dplyr")
if(!require(readxl)) install.packages("readxl")

wd <- ("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
setwd(paste0(wd))
list.files()

sales_file <- read.csv(paste(wd, "/Output_Files/Sales_UPCSKUPLAN.csv",sep =""),stringsAsFactors = FALSE)
sales_file[is.na(sales_file)] <- "NA"
sales_file$BSG_code <- sales_file$BSG 
sales_file$BSG <- ifelse(sales_file$DemandCustomer=="COSTCO US",sales_file$Brand,sales_file$BSG)
head(sales_file,2)

sku_grain <- data.frame(unique(sales_file[,c("SKU10","PLAN_Cust")]),row.names = NULL)
ZERO_salescount <- function(i,sku_grain){
  #i=944
  sku_grain = sku_grain
  sku = sku_grain$SKU10[i]
  cust = sku_grain$PLAN_Cust[i]
  sample = sales_file[sales_file$SKU10==sku & sales_file$PLAN_Cust==cust,]
  sample <- sample[sample$Year>=2015,]
  sample <- sample[order(sample$Year,sample$Week_No),]
  sample$Sales_N <- sample$Sales
  sales_th <- (mean(sample$Sales[sample$Sales>0]) * 0.4)
  sample$Sales_N <- ifelse(sample$Sales_N <sales_th ,0, sample$Sales_N)
  #end<-max(which(!sample$Sales_N==0))
  sample$rowno = c(1:nrow(sample))   
  end <- sample[sample$Year==ho_year & sample$Week_No==ho_week,"rowno"]
  sample$rowno = NULL
 
  start <- min(which(!sample$Sales_N==0))
  sku_info = sample[1,c("SKU10","PLAN_Cust","Brand","DemandCustomer","BSG","CaseToEach","price_perunit","UPC")]
  #sample$Sales
  if(end-start>1){
    sample1 <- sample[c(start:end),]
    sample1$Count <- ifelse(sample1$Sales_N>0,0,1)
    sample1$contsales <- 0
    for (j in 2:nrow(sample1)){
      sample1$contsales[j] <- ifelse(sample1$Count[j]==1,1+sample1$contsales[j-1],0)
    }
    Start_Week <- sample$Week_No[start]
    Start_Year <- sample$Year[start]
    End_Week <- sample$Week_No[end]
    End_Year <- sample$Year[end]
    Sales_Week <- nrow(sample1)
    ZeroSales_Week <- sum(sample1$Count)
    MAX_continuesZERO <- max(sample1$contsales)
    file <- cbind(sku_info,Start_Year,Start_Week,End_Year,End_Week,Sales_Week,ZeroSales_Week,MAX_continuesZERO)
    return(file)
  }
}

#Close any open cluster
stopCluster(cl=NULL)
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)
  
## Run the two lines - after running all other functions ##
file_prep <- data.frame()
file_prep <- foreach(p=(1:nrow(sku_grain)),.combine = rbind,.export = c('sales_file'),
                      .packages=c('dplyr','doParallel','snow')) %dopar% ZERO_salescount(p,sku_grain)
file_prep <- data.frame(file_prep)  

stopCluster(cl=NULL)
stopCluster(cl)  

#write.csv(file_prep,"SKU_Detail_afterUPC.csv",row.names = FALSE)
### Helper Function ###
dataprep_ZEROsales <- function(sku,cust,sales_data,mapped_SKU){
  # sku = base_sku
  # cust = cust
  # sales_data = sales_bsg
  # mapped_SKU = bsg_data
  sample <- sales_data[sales_data$SKU10==sku & sales_data$PLAN_Cust==cust,]
  sample$Sales <- sample$Sales*sample$CaseToEach
  #head(sample,2)
  sample <- sample[order(sample$Year,sample$Week_No),]
  sample1 <- sample
  sales_mean <- mean(sample1$Sales[sample1$Sales>0])
  sample1$Sales_N <- sample1$Sales
  sales_sum <- sum(sample1$Sales)
  
  sales_th <- sales_mean * .4
  sample1$Sales_N <- ifelse(sample1$Sales_N<sales_th,0,sample1$Sales_N)
  sales_mean <- mean(sample1$Sales_N[sample1$Sales_N>0])
  #sales_th <- sales_mean * .4
  #sample1$Sales_N <- ifelse(sample1$Sales_N<sales_th,0,sample1$Sales_N)
  
  start<-min(which(!sample1$Sales_N==0))
  #end<-max(which(!sample1$Sales_N==0))
  sample1$rowno = c(1:nrow(sample1))   
  end <- sample1[sample1$Year==ho_year & sample1$Week_No==ho_week,"rowno"]
  sample1$rowno = NULL
  
  sample1 <- sample1[c(start:end),]
  sample1$count <- ifelse(sample1$Sales_N==0,1,0)
  saleszero_count <- sum(sample1$count)
  sample2 <- sample1[sample1$Sales_N==0,c("Year","Week_No")]
  sales_mean <- mean(sample1$Sales_N[sample1$Sales_N>0]) 
  
  mapped_SKU <- mapped_SKU[mapped_SKU$SKU10 != sku,]
  if(nrow(mapped_SKU)>0){
    mapped_SKU_final <- data.frame()
    for (j in 1:nrow(mapped_SKU)){
      #j=1
      sku_maped <- mapped_SKU$SKU10[j]
      sample_map <- sales_data[sales_data$SKU10==sku_maped & sales_data$PLAN_Cust==cust,]
      sample_map$Sales <- sample_map$Sales* sample_map$CaseToEach
      sample_map <- sample_map[order(sample_map$Year,sample_map$Week_No),]
      sample_map <- sample_map[c(start:end),]
      sample_map_period <- merge(sample_map,sample2,by=names(sample2))
      sales_sku_map <- sum(sample_map$Sales)
      sales_sku_map_period <- sum(sample_map_period$Sales)
      if(sales_sku_map_period>0){
        sales_sku_map_period_mean <- abs((mean(sample_map_period$Sales[sample_map_period$Sales>0]))/sales_mean)
        check <- ifelse(sales_sku_map_period==0,0,ifelse(sales_sku_map/sales_sku_map_period<1.25,1,0))
        sku_mapped1 <- mapped_SKU[j,]
        sku_mapped1 <- cbind(sku_mapped1,check,sales_sku_map_period_mean)
        mapped_SKU_final <-rbind(mapped_SKU_final,sku_mapped1)
      }
    }
    
    mapped_SKU_final <- mapped_SKU_final[mapped_SKU_final$check==1 & (mapped_SKU_final$sales_sku_map_period_mean <= 1.8 &mapped_SKU_final$sales_sku_map_period_mean >= 0.2) ,]
    
    if(nrow(mapped_SKU_final)>0){
        mapped_sku_final <- mapped_SKU_final[order(mapped_SKU_final$sales_sku_map_period_mean),]
        mapped_sku_list <- mapped_sku_final[,c("PLAN_Cust","SKU10","UPC","CaseToEach","price_perunit","Start_Year","Start_Week")]
        mapped_sku_check <- mapped_sku_list[1,]
        names(mapped_sku_check) <- paste0("Map_",names(mapped_sku_check))
        return(mapped_sku_check)
    }
  }
}

finaldata_ZEROsales <- function(sku,cust,sales_data,sku_map,sku_select){
  # sku = base_sku
  # cust = cust
  # sales_data = sales_bsg
  # sku_map = bsg_data
  # sku_select = mapped_sku
  sample <- sales_data[sales_data$SKU10==sku & sales_data$PLAN_Cust==cust,]
  sample <- sample[order(sample$Year,sample$Week_No),]
  sample1 <- sample
  sales_th <- (mean(sample$Sales[sample$Sales>0]) * 0.4)
  
  sku_sample <- data.frame(sku_map[sku_map$SKU10==sku & sku_map$PLAN_Cust==cust,],row.names=NULL)
  sku_maped <- sku_select$Map_SKU10
  base_uom <- sku_sample$CaseToEach[1]
  map_uom <- sku_select$Map_CaseToEach
  mul_unit <- ifelse(base_uom==0,1,map_uom/base_uom)
  sample_map <- sales_data[sales_data$SKU10==sku_maped & sales_data$PLAN_Cust==cust,]
  sample_map <- sample_map[order(sample_map$Year,sample_map$Week_No),]
  if(nrow(sample_map)>0){
    sample_map$Sales <- sample_map$Sales*mul_unit
    sample_map1 <- sample_map
    sample$Sales <- ifelse(sample$Sales < sales_th,sample$Sales+sample_map$Sales,sample$Sales)
  }
  return(sample)
}

ZERO_salescount <- function(sales_data){
  #sales_data = sales_bsg_update
  sku_grain1 = data.frame(unique(sales_data[,c("SKU10","PLAN_Cust")]), row.names = NULL)
  file_final <- data.frame()
  for (k in 1:nrow(sku_grain1)){
    #k=1
    sku = sku_grain1$SKU10[k]
    cust = sku_grain1$PLAN_Cust[k]
    sample = sales_data[sales_data$SKU10==sku & sales_data$PLAN_Cust==cust,]
    sample <- sample[sample$Year>=2015,]
    sample <- sample[order(sample$Year,sample$Week_No),]
    sample$Sales_N <- sample$Sales
    sales_th <- (mean(sample$Sales[sample$Sales>0]) * 0.4)
    sample$Sales_N <- ifelse(sample$Sales_N <sales_th ,0, sample$Sales_N)
    
    sample$rowno = c(1:nrow(sample))   
    end <- sample[sample$Year==ho_year & sample$Week_No==ho_week,"rowno"]
    sample$rowno = NULL    

    start <- min(which(!sample$Sales_N==0))
    sku_info = sample[1,c("SKU10","PLAN_Cust","Brand","DemandCustomer","BSG","CaseToEach","price_perunit","UPC")]
    #sample$Sales
    if(end-start>1){
      sample1 <- sample[c(start:end),]
      sample1$Count <- ifelse(sample1$Sales_N>0,0,1)
      sample1$contsales <- 0
      for (j in 2:nrow(sample1)){
        sample1$contsales[j] <- ifelse(sample1$Count[j]==1,1+sample1$contsales[j-1],0)
      }
      Start_Week <- sample$Week_No[start]
      Start_Year <- sample$Year[start]
      End_Week <- sample$Week_No[end]
      End_Year <- sample$Year[end]
      Sales_Week <- nrow(sample1)
      ZeroSales_Week <- sum(sample1$Count)
      MAX_continuesZERO <- max(sample1$contsales)
      file <- cbind(sku_info,Start_Year,Start_Week,End_Year,End_Week,Sales_Week,ZeroSales_Week,MAX_continuesZERO)
      file_final <- rbind(file_final,file)
    }
  }
  if(nrow(file_final)>0){
    file_final = file_final[order(file_final$Start_Year,file_final$Start_Week),]
    return(file_final)
  }
}

#### BSG_Mapping Code Start here ####
sku_file <- file_prep
sku_file$Price <- round(sku_file$price_perunit*.5,1)
sku_file <- sku_file[order(sku_file$PLAN_Cust,sku_file$BSG,
                           sku_file$Price,sku_file$Start_Year,
                           sku_file$Start_Week),]
sku_file$BSG_code <- sku_file$BSG 
sku_file$BSG <- ifelse(sku_file$DemandCustomer=="COSTCO",sku_file$Brand,sku_file$BSG)

bsg_grain <- data.frame(unique(sku_file[,c("PLAN_Cust","BSG","Price")]),row.names = NULL)
CZ_map <- function(i,bsg_grain,sku_file,sales_file){
  #i=273
  #bsg_grain[i,]
  bsg = bsg_grain$BSG[i]
  cust = bsg_grain$PLAN_Cust[i]
  Price = bsg_grain$Price[i]
  sales_bsg = sales_file[(sales_file$BSG==bsg & 
                            sales_file$PLAN_Cust==cust & 
                            round(sales_file$price_perunit*.5,1)==Price),]
  
  bsg_data_raw = sku_file[sku_file$PLAN_Cust==cust & sku_file$BSG==bsg & sku_file$Price==Price,]
  bsg_data_raw = bsg_data_raw[order(bsg_data_raw$Start_Year,bsg_data_raw$Start_Week,
                                    (bsg_data_raw$ZeroSales_Week-bsg_data_raw$Sales_Week)),]
  
  cz_SKUmapping = data.frame()
  cz_final_file = data.frame()
  SKU_database = data.frame()
  for (p in 1:nrow(bsg_data_raw)){
    #p=1
    bsg_data = bsg_data_raw[!(bsg_data_raw$SKU10 %in% SKU_database$SKU10),]
    sales_bsg = sales_bsg[!(sales_bsg$SKU10 %in% SKU_database$SKU10),]
    sku_1 = bsg_data[1,c("PLAN_Cust","SKU10","UPC","CaseToEach","price_perunit","Start_Year","Start_Week","Sales_Week","ZeroSales_Week")]
    if(nrow(bsg_data)>0){
      SKU_base = cbind(SKU10=sku_1$SKU10,cust,bsg)
      SKU_database = rbind(SKU_database,SKU_base)
      cz_file = data.frame()
      mapped_sku_database = data.frame()
      base_sku = as.character(sku_1$SKU10)
      nrow_bsg = nrow(bsg_data)
      
      while(nrow_bsg>1){
        if(bsg_data[bsg_data$SKU10==sku_1$SKU10,"MAX_continuesZERO"]>4){
          nrow_bsg = nrow_bsg-1
          ## Getting Rank 1 MApped SKU ##
          mapped_sku = dataprep_ZEROsales(base_sku,cust,sales_bsg,bsg_data)
          if(is.null(mapped_sku)){
            nrow_bsg = 0
            break}
          ## Preparing Sales Data after Mapped SKU Addition to BASE SKU ##
          Sales_data_prep = finaldata_ZEROsales(base_sku,cust,sales_bsg,bsg_data,mapped_sku)
          map_sku_1 = as.character(mapped_sku$Map_SKU10)
          SKU_map = cbind(SKU10=map_sku_1,cust,bsg)
          SKU_database <- rbind(SKU_database,SKU_map)
          sales_bsg_update = sales_bsg[!(sales_bsg$SKU10 %in% c(base_sku,map_sku_1)),]
          sales_bsg_update = rbind(sales_bsg_update,Sales_data_prep)
          ## Updated SKU information on SKUs ## 
          SKU_withCZ = ZERO_salescount(sales_bsg_update)
          if(is.null(SKU_withCZ)){
            nrow_bsg = 0
            break
          }else{
            bsg_data = SKU_withCZ
            sales_bsg = sales_bsg_update}
          
          SKU_base_detail = SKU_withCZ[SKU_withCZ$SKU10==base_sku,c("Sales_Week","ZeroSales_Week")]
          names(SKU_base_detail) = c("Updated_Sales_week","Updated_ZeroSales_Week")
          mapped_sku <- cbind(mapped_sku,SKU_base_detail, row.names = NULL)
          mapped_sku_database <- rbind(mapped_sku_database,mapped_sku)
          cz_file = cbind(sku_1,mapped_sku_database, row.names = NULL)
          }else{
          break}
      }
      if(nrow(cz_file)>0){
        cz_final_file = rbind(cz_final_file,cz_file)
      }
    }
  }
  cz_SKUmapping = rbind(cz_SKUmapping,cz_final_file)
  return(cz_SKUmapping)
}

## Running the MAIN Code ##
CZ_mapping_file_download <- data.frame()
for (n in 1:nrow(bsg_grain)){
  #n=1
#  print(n)
  CZ_mapping_file = data.frame()
  CZ_mapping_file = CZ_map(n,bsg_grain,sku_file,sales_file)
  CZ_mapping_file_download = rbind(CZ_mapping_file_download,CZ_mapping_file)
}

write.csv(CZ_mapping_file_download,paste(wd, "/Output_Files/CZ_mapping_file.csv",sep =""),row.names = FALSE)

