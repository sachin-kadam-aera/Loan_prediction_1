
rm(list = ls())
if(!require(data.table)) install.packages("data.table")
if(!require(lubridate)) install.packages("lubridate")
if(!require(doParallel)) install.packages("doParallel")
if(!require(dplyr)) install.packages("dplyr")

setwd("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
wd = getwd()

sales_promo_data = fread(paste0(wd,"/Output_Files/DF_US_Promo_siebel.csv"),stringsAsFactors = F)
sales_promo_data = data.frame(sales_promo_data)
head(sales_promo_data)
# sales_promo_data = sales_promo_data[sales_promo_data$DemandCustomer=="WALMART US",]
# sales_promo_data = sales_promo_data[sales_promo_data$SKU10 %in% c("19200-00062","19200-00027","19200-00028"),]

user_input = read.csv(paste(wd,"/Input_Files/User_Input_File_USA.csv",sep = ""),stringsAsFactors = FALSE)
start_week = unique(user_input$WEEK)-1
start_year = unique(user_input$YEAR)

sku_mapping = read.csv(paste0(wd,"/Input_Files/PPG_Mapping.csv"),stringsAsFactors = F)
sku_mapping = sku_mapping[,c("SKU10","PPG")]
sales_promo_data = merge(sales_promo_data,sku_mapping,by="SKU10")

sku_grain = data.frame(unique(sales_promo_data[,c("SKU10","DemandCustomer")]))
sku_data_prep = function(i){
  #i=1
  sku = sku_grain$SKU10[i]
  cust = sku_grain$DemandCustomer[i]
  sample = sales_promo_data[sales_promo_data$SKU10==sku & sales_promo_data$DemandCustomer==cust,]
  sample = sample[order(sample$Year,sample$Week_No),]
  sample$Baseline8 = sample$Sales
  for(j in 9:nrow(sample)){
    #j=9
    sample$Baseline8[j] = mean(sample$Sales[(j-8):j])
  }
  sample$incr_sales = sample$Sales-sample$Baseline8
  return(sample)
}

no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

sales_prep <- data.frame()
sales_prep <- foreach(p=(1:nrow(sku_grain)),.combine = rbind,.export = c('sales_promo_data'),
                      .packages=c('dplyr')) %dopar% sku_data_prep(p)
sales_prep$incr_sales = ifelse(sales_prep$incr_sales <0,0,sales_prep$incr_sales)
stopCluster(cl)

#### PPG Desaggragation
ppg_grain = data.frame(unique(sales_promo_data[,c("PPG","DemandCustomer")]))
sku_percentage = function(i){
  #i=1
  ppg = ppg_grain$PPG[i]
  cust = ppg_grain$DemandCustomer[i]
  sample = sales_prep[sales_prep$PPG==ppg & sales_prep$DemandCustomer==cust,]
  sample$incr_sales = ifelse(sample$incr_sales < 0,0,sample$incr_sales)
  sku_list = (unique(sample$SKU10))
  data_prep = data.frame()
  base_sales_ppg = 0 
  incr_sales_ppg = 0
  for (j in 1:length(sku_list)){
    #j=1
    sku=sku_list[j]
    sample1 = sample[sample$SKU10==sku,]
    start = min(which(sample1$Sales!=0))
    sample1 = sample1[(start:nrow(sample1)),]
    sample1 = sample1[((sample1$Year < start_year) | (sample1$Year==start_year & sample1$Week_No<=start_week)),]
    if (nrow(sample1)>=26) {
      sample_baseline = sample1[c((nrow(sample1)-25):nrow(sample1)),]
      base_sales = sum(sample_baseline$Baseline8)
      base_sales_ppg = base_sales_ppg+base_sales
      incr_sales = sum(sample_baseline$incr_sales)
      incr_sales_ppg =incr_sales_ppg+incr_sales
    }else{
      base_sales = sum(sample1$Baseline8)
      base_sales_ppg = base_sales_ppg+base_sales
      incr_sales = sum(sample1$incr_sales)
      incr_sales_ppg =incr_sales_ppg+incr_sales
    }
    data_prep1 = cbind(ppg,cust,sku,base_sales,incr_sales)
    data_prep = rbind(data_prep,data_prep1)
  }
  #base_sales_ppg
  #incr_sales_ppg
  data_prep = cbind(data_prep,base_sales_ppg,incr_sales_ppg)
  data_prep$base_sales = as.numeric(as.character(data_prep$base_sales))
  data_prep$incr_sales = as.numeric(as.character(data_prep$incr_sales))
  data_prep$base_age = ifelse(data_prep$base_sales_ppg==0,0,data_prep$base_sales/data_prep$base_sales_ppg)
  data_prep$incr_age = ifelse(data_prep$incr_sales_ppg==0,0,data_prep$incr_sales/data_prep$incr_sales_ppg)
  return(data_prep)
}

no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

data_prep_final <- data.frame()
data_prep_final <- foreach(p=(1:nrow(ppg_grain)),.combine = rbind,.export = c('sales_prep'),
                      .packages=c('dplyr')) %dopar% sku_percentage(p)
stopCluster(cl)

#str(data_prep_final)
promo_data_percetage = data_prep_final[,c('sku','cust','base_age','incr_age')]
promo_data_percetage$sku = as.character(promo_data_percetage$sku)
promo_data_percetage$cust = as.character(promo_data_percetage$cust)
promo_data_percetage$base_age = as.numeric(as.character(promo_data_percetage$base_age))
promo_data_percetage$incr_age = as.numeric(as.character(promo_data_percetage$incr_age))
str(promo_data_percetage)

promo_data_percetage = data.frame(promo_data_percetage %>% group_by(sku,cust) %>% 
                                    dplyr::summarise(incr_age= mean(incr_age),base_age=mean(base_age)))
sales_prep_final = merge(sales_prep,promo_data_percetage,
                         by.x = c("SKU10",'DemandCustomer'),
                         by.y = c("sku",'cust'))
head(sales_prep_final,2)

sales_prep_final$BASE_Qty_new = sales_prep_final$BASE_Qty*sales_prep_final$base_age
sales_prep_final$INCR_Qty_new = sales_prep_final$INCR_Qty*sales_prep_final$incr_age

sales_prep_final$vsod_act = ifelse(sales_prep_final$Sales==0,0,sales_prep_final$incr_sales/sales_prep_final$Sales)
sales_prep_final$vsod2_disagg = ifelse((sales_prep_final$INCR_Qty_new+sales_prep_final$BASE_Qty_new)==0,0,
                                sales_prep_final$INCR_Qty_new/(sales_prep_final$INCR_Qty_new+sales_prep_final$BASE_Qty_new))
sales_prep_final$vsod_Siebel = ifelse((sales_prep_final$INCR_Qty+sales_prep_final$BASE_Qty)==0,0,
                                sales_prep_final$INCR_Qty/(sales_prep_final$INCR_Qty+sales_prep_final$BASE_Qty))
sales_prep_final$VSOD = ifelse(((sales_prep_final$Year < start_year) | (sales_prep_final$Year==start_year & sales_prep_final$Week_No<=start_week)),
                               sales_prep_final$vsod_act,sales_prep_final$vsod2_disagg)
sales_prep_final$DOD[is.na(sales_prep_final$DOD)] = 0
sales_prep_final$VSOD[is.na(sales_prep_final$VSOD)] = 0

sales_prep_final_sieblecheck = data.frame(sales_prep_final %>% group_by(SKU10,DemandCustomer) %>% dplyr::summarise(V_Sieble = sum(vsod_Siebel)))
sales_prep_final_sieblecheck$Check = ifelse(sales_prep_final_sieblecheck$V_Sieble>0,1,0)
sales_prep_final_sieblecheck = sales_prep_final_sieblecheck[,c("SKU10","DemandCustomer","Check")]
sales_prep_final = merge(sales_prep_final,sales_prep_final_sieblecheck,by=c("SKU10","DemandCustomer"))
sales_prep_final$VSOD = ifelse(sales_prep_final$Check==1,sales_prep_final$VSOD,0)

# sales_prep_final1 = sales_prep_final[sales_prep_final$DemandCustomer %in% c("WALMART US","PUBLIX"),]
# fwrite(sales_prep_final1,paste0(wd,"/4_Output_Files/DF_US_052019_WAL-PUB.csv"))

sales_prep_final = sales_prep_final[,c("Brand","SKU10","DemandCustomer","Year","Quarter","Month_No","Week_No","Sales","W_Nielsen","DOD","VSOD")]
fwrite(sales_prep_final,paste0(wd,"/Output_Files/DF_US_SalesFromFractal.csv"))

# year_week <- data.frame(Year = c(2018,2018,2018),Month_No = c(10,11,12))
# sales_prep_final_check <- merge(sales_prep_final,year_week, by = c("Year","Month_No"))
# sales_prep_final_check <- data.frame(sales_prep_final_check %>% group_by(SKU10,DemandCustomer) %>% dplyr::summarise(Sales=sum(Sales)))
# sales_prep_final_check <- sales_prep_final_check[sales_prep_final_check$Sales>0,c(1,2)]
# head(sales_prep_final_check,2)
# 
# sales_prep_final2 = merge(sales_prep_final,sales_prep_final_check,by = c("SKU10","DemandCustomer"))[,c("Brand","SKU10","DemandCustomer","Year","Quarter","Month_No","Week_No","Sales","W_Nielsen","DOD","VSOD")]
# fwrite(sales_prep_final2,paste0(wd,"/4_Output_Files/DF_US_052019_final_filter.csv"))

