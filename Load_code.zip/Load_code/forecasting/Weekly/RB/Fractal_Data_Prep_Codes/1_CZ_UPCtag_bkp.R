#rm(list=ls())
if(!require(doParallel)) install.packages("doParallel")
if(!require(snow)) install.packages("snow")
if(!require(dplyr)) install.packages("dplyr")
if(!require(readxl)) install.packages("readxl")

wd <- ("/home/fusionops/datascience/forecasting/weekly/RB/Fractal_Data_Prep_Codes")
setwd(paste0(wd))
list.files()

user_input <- read.csv(paste(wd, "/Input_Files/User_Input_File_USA.csv",sep =""))
ho_year<- as.numeric(user_input$YEAR)
ho_week<- as.numeric(user_input$WEEK) -1

sales_file <- read.csv(paste(wd, "/Input_Files/rfh_saleshistory_skudmdcust_weekly_fractal.csv",sep =""),stringsAsFactors = FALSE)
names(sales_file)
sku_g_test <- data.frame(unique(sales_file[,c("SKU10","PLAN_Cust")]))

sales_file[is.na(sales_file)] <- "NA"
head(sales_file,2)
sales_file <- data.frame(sales_file %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) 
                         %>% dplyr::summarise(Sales=sum(Sales)))
Sales_data_Brand_Mapping <- sales_file[order(sales_file$Sales),]
Sales_data_Brand_Mapping <- data.frame(Sales_data_Brand_Mapping 
                                       %>% group_by(SKU10) 
                                       %>% dplyr::summarise(Brand=last(Brand )))
sales_file$Brand <- NULL
sales_file <- merge(sales_file,Sales_data_Brand_Mapping,by="SKU10")
sales_file <- data.frame(sales_file %>% group_by(Brand,SKU10,PLAN_Cust,Year,Week_No) 
                         %>% dplyr::summarise(Sales=sum(Sales)))
sales_file <- sales_file[sales_file$Year >=2015,]

sku_master <- read.csv(paste(wd, "/Input_Files/SKU_Master_final.csv",sep =""),stringsAsFactors = FALSE)
cust_Mapping <- read.csv(paste(wd, "/Input_Files/Customer_Mapping_New.csv",sep =""),stringsAsFactors = FALSE)

names(sku_master)
sku_master <- data.frame(sku_master %>% group_by(SKU10) %>% 
                           summarise(BSG = last(BSG),CaseToEach = last(UOM),
                                     price_perunit = last(Price_unit),UPC = last(UPC),PPG= last(PPG)))
head(sku_master,2)
head(cust_Mapping,2)

Sales_data <- merge(sales_file,cust_Mapping, by.x = "PLAN_Cust", by.y = "PlanToCustomer")
Sales_data <- merge(Sales_data,sku_master,by = "SKU10")

names(Sales_data)
sku_grain <- data.frame(unique(Sales_data[,c("SKU10","PLAN_Cust")]),row.names = NULL)
upc_check <- data.frame(unique(Sales_data[,c("Brand","PLAN_Cust","UPC","SKU10")]),row.names = NULL)

grain = data.frame(unique(Sales_data[,c("Brand","PLAN_Cust","UPC")]),row.names = NULL)

upc_sales_data<-function(i){
  #i=1
  brand = grain$Brand[i]
  upc = grain$UPC[i]
  cust = grain$PLAN_Cust[i]
  sample = Sales_data[Sales_data$Brand == brand & Sales_data$UPC == upc & Sales_data$PLAN_Cust == cust,]
  #names(sample)
  sample$Sales_units = sample$Sales*sample$CaseToEach
  sample = sample[sample$Year>=2015,]
  sample = sample[order(sample$Brand,sample$SKU10,sample$PLAN_Cust,sample$Year,sample$Week_No),]
  sample_upc = data.frame(sample %>% group_by(Brand,UPC,PLAN_Cust,DemandCustomer,Year,Week_No) %>% dplyr::summarise(Sales= sum(Sales_units)),row.names = NULL)

  sku_list = unique(sample$SKU10)
  sku_latest = data.frame()
  for(j in 1:length(sku_list)){
    #j=1
    sku = sku_list[j]
    samplesku = sample[sample$SKU10==sku,]
    samplesku = samplesku[(samplesku$Year <=(ho_year-1) | (samplesku$Week_No <= ho_week & samplesku$Year==ho_year)),]
    samplesku <- samplesku[order(samplesku$Year,samplesku$Week_No),]
    end = max(which(!samplesku$Sales==0))
    end_sales = samplesku[end,]
    end_sales = cbind(end_sales,End_Week = end)
    sku_latest = rbind(sku_latest,end_sales)
  }
  sku_latest <- sku_latest[order(-sku_latest$Sales),]
  sku_latest <- sku_latest[order(-sku_latest$End_Week),]
  
  sku_select <- sku_latest[1,c("SKU10","CaseToEach")]
  sample_upc = cbind(sample_upc,sku_select,row.names = NULL)
  sample_upc$Sales = sample_upc$Sales/sample_upc$CaseToEach
  #names(sample_upc)
  upc_tag = data.frame(cbind(No=i,upc,cust,sku_list,SKU_count=length(sku_list),row.names = NULL))
  
  if(!is.na(sum(sample_upc$Sales))){
    return(list(Frame1=sample_upc,Frame2=upc_tag))
  }
}

custom_combine_function<-function(F1,F2){
  Frame1<-rbind(F1$Frame1,F2$Frame1)
  Frame2<-rbind(F1$Frame2,F2$Frame2) 
  return(list(Frame1=Frame1,Frame2=Frame2))
}

#Close any open cluster
stopCluster(cl=NULL)
no_cores <- detectCores() - 1
cl <- makeCluster(no_cores, type="SOCK")
registerDoParallel(cl)

## Run the two lines - after running all other functions ##
sales_file_upc = list()
sales_file_upc <- foreach(p=(1:nrow(grain)),.combine = custom_combine_function,.export = c('Sales_data'),
                          .packages=c('dplyr','doParallel','snow')) %dopar% upc_sales_data(p)

stopCluster(cl=NULL)
stopCluster(cl)

Sales_file_final <- sales_file_upc$Frame1
UPC_Mapping_CZ <- sales_file_upc$Frame2
names(Sales_file_final)

head(sku_master,2)
SKU_master_bsg <- sku_master[,c("SKU10","BSG","price_perunit")]
Sales_file_final <- merge(Sales_file_final,SKU_master_bsg,by="SKU10")

write.csv(Sales_file_final,paste(wd, "/Output_Files/Sales_UPCSKUPLAN.csv",sep =""),row.names = FALSE)
write.csv(UPC_Mapping_CZ,paste(wd, "/Output_Files/UPC_Mapping_CZ.csv",sep =""),row.names = FALSE)


