open schema reckitt_benckiser;

/*
UPDATE fact_fosalesforecastweekly
SET dd_forecasttype = 'Crostons Method'
WHERE dd_forecasttype like 'Croston%';
*/

DROP TABLE IF EXISTS tmp_fcsttypes;
CREATE TABLE tmp_fcsttypes
(
brand varchar(100) default 'All',
fcsttypes varchar(200)
);


--Auto ARIMA - Box-Cox, GB, Auto ETS Fractal gives 2490/5102
--Out: MAPA_Fractal

--1. Auto ARIMA - Box-Cox
--2. Auto ETS Fractal
--3. Gradient Boosting


/*INSERT INTO tmp_fcsttypes(fcsttypes)
SELECT 'Auto ARIMA - Box-Cox';*/
/*UNION SELECT 'Gradient Boosting'
UNION SELECT 'Auto ETS Fractal';*/

INSERT INTO tmp_fcsttypes(brand,fcsttypes)
SELECT 'EOF','Auto ARIMA_Fractal'
UNION SELECT 'EOF','ARMA';
--UNION SELECT 'EOF','Auto-Regressive';
--UNION SELECT 'EOF','Gradient Boosting';
/*UNION SELECT 'EOF','Auto ARIMA';*/

--No GB for WLT. High -ve bias
INSERT INTO tmp_fcsttypes(brand,fcsttypes)
SELECT 'WLT','Auto ETS Fractal'
--UNION SELECT 'WLT','MAPA_Fractal'
--UNION SELECT 'WLT','Auto ETS'
UNION SELECT 'WLT','Crostons Method'
UNION SELECT 'WLT','Auto ARIMA - Box-Cox'
UNION SELECT 'WLT','Nnet Fractal';

INSERT INTO tmp_fcsttypes(brand,fcsttypes)
SELECT 'BRS','Auto ETS';


/*
UNION
SELECT 'Gradient Boosting'
UNION
SELECT 'MAPA_Fractal'
UNION
SELECT 'Auto ETS';
UNION
SELECT 'Auto ETS Fractal'
*/


DROP TABLE IF EXISTS tmp_rptdate;
CREATE TABLE tmp_rptdate
AS
SELECT '22 JAN 2018' dd_reportingdate_1;


UPDATE fact_fosalesforecastweekly f
SET dd_forecastrank = 100 + dd_forecastrank
FROM fact_fosalesforecastweekly f, tmp_rptdate t
WHERE f.dd_reportingdate = t.dd_reportingdate_1
AND dd_forecastrank < 100;

/* Update rank in Reg using count MAD */
DROP TABLE IF EXISTS tmp_mad_calculation_testperiod_regular;
CREATE TABLE tmp_mad_calculation_testperiod_regular
AS
SELECT DD_REPORTINGDATE,dd_partnumber,dd_forecasttype,
AVG(ct_forecastquantity-ct_salesquantity) ct_bias,
AVG(ABS(ct_forecastquantity-ct_salesquantity)/ct_salesquantity) ct_mad,
rank() over(partition by DD_REPORTINGDATE,dd_partnumber
ORDER BY AVG(ABS(ct_forecastquantity-ct_salesquantity)/(ct_forecastquantity+ct_salesquantity)/2), dd_forecasttype) dd_rank_bymadweighed
FROM fact_fosalesforecastweekly s INNER JOIN dim_jde_item_master sku on sku.dim_jde_item_masterid = s.dim_jde_2nditemnumberid, tmp_rptdate t
WHERE dd_forecastsample = 'Test'  
AND s.dd_reportingdate = t.dd_reportingdate_1
--AND (s.dd_forecasttype IN (SELECT DISTINCT fcsttypes FROM tmp_fcsttypes t2 WHERE brand = 'All')
AND EXISTS ( SELECT 1 FROM tmp_fcsttypes t3 WHERE t3.brand = sku.Sales_Category_Code_4 AND t3.fcsttypes = s.dd_forecasttype)
GROUP BY DD_REPORTINGDATE,dd_partnumber,dd_forecasttype;


UPDATE fact_fosalesforecastweekly f
SET f.dd_forecastrank = t.dd_rank_bymadweighed
FROM fact_fosalesforecastweekly f,tmp_mad_calculation_testperiod_regular t
WHERE f.dd_partnumber = t.dd_partnumber 
AND f.dd_forecasttype = t.dd_forecasttype
AND f.dd_reportingdate = t.dd_reportingdate;



DROP TABLE IF EXISTS tmp_rptdate;
CREATE TABLE tmp_rptdate
AS
SELECT '26 FEB 2018' dd_reportingdate_1;


UPDATE fact_fosalesforecastweekly f
SET dd_forecastrank = 100 + dd_forecastrank
FROM fact_fosalesforecastweekly f, tmp_rptdate t
WHERE f.dd_reportingdate = t.dd_reportingdate_1
AND dd_forecastrank < 100;

/* Update rank in Reg using count MAD */
DROP TABLE IF EXISTS tmp_mad_calculation_testperiod_regular;
CREATE TABLE tmp_mad_calculation_testperiod_regular
AS
SELECT DD_REPORTINGDATE,dd_partnumber,dd_forecasttype,
AVG(ct_forecastquantity-ct_salesquantity) ct_bias,
AVG(ABS(ct_forecastquantity-ct_salesquantity)/ct_salesquantity) ct_mad,
rank() over(partition by DD_REPORTINGDATE,dd_partnumber
ORDER BY AVG(ABS(ct_forecastquantity-ct_salesquantity)/(ct_forecastquantity+ct_salesquantity/2)), dd_forecasttype) dd_rank_bymadweighed
FROM fact_fosalesforecastweekly s INNER JOIN dim_jde_item_master sku on sku.dim_jde_item_masterid = s.dim_jde_2nditemnumberid, tmp_rptdate t
WHERE dd_forecastsample = 'Test'  
AND s.dd_reportingdate = t.dd_reportingdate_1
--AND dd_forecasttype IN (SELECT DISTINCT fcsttypes FROM tmp_fcsttypes)
AND EXISTS ( SELECT 1 FROM tmp_fcsttypes t3 WHERE t3.brand = sku.Sales_Category_Code_4 AND t3.fcsttypes = s.dd_forecasttype)
GROUP BY DD_REPORTINGDATE,dd_partnumber,dd_forecasttype;


UPDATE fact_fosalesforecastweekly f
SET f.dd_forecastrank = t.dd_rank_bymadweighed
FROM fact_fosalesforecastweekly f,tmp_mad_calculation_testperiod_regular t
WHERE f.dd_partnumber = t.dd_partnumber 
AND f.dd_forecasttype = t.dd_forecasttype
AND f.dd_reportingdate = t.dd_reportingdate;




DROP TABLE IF EXISTS tmp_rptdate;
CREATE TABLE tmp_rptdate
AS
SELECT '26 MAR 2018' dd_reportingdate_1;


UPDATE fact_fosalesforecastweekly f
SET dd_forecastrank = 100 + dd_forecastrank
FROM fact_fosalesforecastweekly f, tmp_rptdate t
WHERE f.dd_reportingdate = t.dd_reportingdate_1
AND dd_forecastrank < 100;

/* Update rank in Reg using count MAD */
DROP TABLE IF EXISTS tmp_mad_calculation_testperiod_regular;
CREATE TABLE tmp_mad_calculation_testperiod_regular
AS
SELECT DD_REPORTINGDATE,dd_partnumber,dd_forecasttype,
AVG(ct_forecastquantity-ct_salesquantity) ct_bias,
AVG(ABS(ct_forecastquantity-ct_salesquantity)/ct_salesquantity) ct_mad,
rank() over(partition by DD_REPORTINGDATE,dd_partnumber
ORDER BY AVG(ABS(ct_forecastquantity-ct_salesquantity)/(ct_forecastquantity+ct_salesquantity)/2), dd_forecasttype) dd_rank_bymadweighed
FROM fact_fosalesforecastweekly s INNER JOIN dim_jde_item_master sku on sku.dim_jde_item_masterid = s.dim_jde_2nditemnumberid, tmp_rptdate t
WHERE dd_forecastsample = 'Test'  
AND s.dd_reportingdate = t.dd_reportingdate_1
--AND dd_forecasttype IN (SELECT DISTINCT fcsttypes FROM tmp_fcsttypes)
AND EXISTS ( SELECT 1 FROM tmp_fcsttypes t3 WHERE t3.brand = sku.Sales_Category_Code_4 AND t3.fcsttypes = s.dd_forecasttype)
GROUP BY DD_REPORTINGDATE,dd_partnumber,dd_forecasttype;


UPDATE fact_fosalesforecastweekly f
SET f.dd_forecastrank = t.dd_rank_bymadweighed
FROM fact_fosalesforecastweekly f,tmp_mad_calculation_testperiod_regular t
WHERE f.dd_partnumber = t.dd_partnumber 
AND f.dd_forecasttype = t.dd_forecasttype
AND f.dd_reportingdate = t.dd_reportingdate;
