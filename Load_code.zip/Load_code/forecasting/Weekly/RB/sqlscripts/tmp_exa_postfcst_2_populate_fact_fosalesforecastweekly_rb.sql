
/* Has MAD calculations */
/* Script exa_create_and_populate_6tables.sql (to populate stage tables) should be run before this */


open schema reckitt_benckiser;

/* Validate counts IN 6 tables. All should have non-zero rows */

SELECT COUNT(*)
FROM stage_fosalesforecastweekly_regular;
SELECT COUNT(*)
FROM stage_fosalesforecastweekly_rfh;
SELECT COUNT(*)
FROM stage_fosalesforecastweekly_outlier;
SELECT COUNT(*)
FROM stage_fosalesforecastweekly_ofh;
SELECT COUNT(*)
FROM stage_fosalesforecastweekly_regular_causal;
SELECT COUNT(*)
FROM stage_fosalesforecastweekly_rfh_causal;

DELETE FROM fact_fosalesforecastweekly
WHERE dd_reportingdate in ('25 MAY 2018','26 MAY 2018');

UPDATE stage_fosalesforecastweekly_regular SET dd_reportingdate = '26 MAY 2018';
UPDATE stage_fosalesforecastweekly_rfh SET dd_reportingdate = '26 MAY 2018';
UPDATE stage_fosalesforecastweekly_outlier SET dd_reportingdate = '26 MAY 2018';
UPDATE stage_fosalesforecastweekly_ofh SET dd_reportingdate = '26 MAY 2018';
UPDATE stage_fosalesforecastweekly_regular_causal SET dd_reportingdate = '26 MAY 2018';
UPDATE stage_fosalesforecastweekly_rfh_causal SET dd_reportingdate = '26 MAY 2018';

/* Get 3-grain actuals */
DROP TABLE IF EXISTS tmp_actualsales;
CREATE TABLE tmp_actualsales
(
dd_sku10 varchar(20),
dd_bu varchar(10),
dd_invoicedate_char varchar(20),
dd_invoicedate_date date,
dd_invoicedate_yyyyww varchar(10),
dd_invoicedate_ww varchar(10),
ct_salesquantity int,
dd_demandcustomer varchar(100),
dd_sku12 varchar(20)
);

/* Get actual sales from fact_jde_sales_order_line */
/* Get it as SKU-10,BU,DMDCust Level */

INSERT INTO tmp_actualsales
(dd_sku10,dd_bu,dd_invoicedate_date,ct_salesquantity,dd_demandcustomer)
SELECT itemmaster.BASE_ITEM,bu.Business_Unit,dtinv.datevalue,f_jsol.ct_unitsshipped,dcpasd.CUSTOMERDEMAND
FROM fact_jde_sales_order_line f_jsol INNER JOIN dim_jde_item_master itemmaster ON itemmaster.dim_jde_item_masterid = f_jsol.dim_jde_itemnumbershortid
INNER JOIN dim_jde_businessunitmaster bu ON bu.dim_jde_businessunitmasterid = f_jsol.dim_jde_businessunitmasterid
INNER JOIN dim_date dtinv ON dtinv.dim_dateid = f_jsol.dim_jde_dateinvoiceid
INNER JOIN dim_jde_addressbook dcpasd ON dcpasd.dim_jde_addressbookid = f_jsol.dim_customerparentgroupaddresssoldtoid
INNER JOIN dim_jde_fndlookup sclast ON sclast.dim_jde_fndlookupid = f_jsol.dim_jde_statuscodelastid
WHERE dd_ordertype in ('SX','SO')
AND bu.Business_Unit in ('1072','1086','1087','1088')
AND dtinv.datevalue >= '2014-01-01'
AND f_jsol.dd_invoicenumber > 0 AND itemmaster.BASE_ITEM LIKE '%-%'
AND sclast.User_Defined_Code_KY in ('600','620');


/* Assume 1-1 mapping between SKU-10 and SKU-12. There are 2 exceptions according to tmp_sku10_12_mappingrank which are removed */
UPDATE tmp_actualsales a
SET dd_invoicedate_char = to_char(dd_invoicedate_date,'DD Mon YYYY'),
dd_invoicedate_ww = to_char(dd_invoicedate_date,'WW'),
dd_invoicedate_yyyyww = to_char(dd_invoicedate_date,'YYYYWW'),
a.dd_sku12 = t.sku12
FROM tmp_sku10_12_mappingrank t,tmp_actualsales a
WHERE a.dd_sku10 = t.sku10
AND t.rank1 = 1
AND t.sku10 not in ('19200-89675','51700-97517'); /* Only these 2 have more than 1 active SKUs */

UPDATE stage_fosalesforecastweekly_regular
set dd_reportingdate = to_char(current_date - interval '3' day,'DD MON YYYY');
UPDATE stage_fosalesforecastweekly_rfh
set dd_reportingdate = to_char(current_date - interval '2' day,'DD MON YYYY');
UPDATE stage_fosalesforecastweekly_outlier
set dd_reportingdate = to_char(current_date - interval '1' day,'DD MON YYYY');
UPDATE stage_fosalesforecastweekly_ofh
set dd_reportingdate = to_char(current_date,'DD MON YYYY');

ALTER TABLE stage_fosalesforecastweekly_regular
ADD COLUMN dd_zerosales_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_rfh
ADD COLUMN dd_zerosales_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_outlier
ADD COLUMN dd_zerosales_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_ofh
ADD COLUMN dd_zerosales_changedto_one VARCHAR(10) DEFAULT 'N';

ALTER TABLE stage_fosalesforecastweekly_regular
ADD COLUMN dd_zerofcst_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_rfh
ADD COLUMN dd_zerofcst_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_outlier
ADD COLUMN dd_zerofcst_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_ofh
ADD COLUMN dd_zerofcst_changedto_one VARCHAR(10) DEFAULT 'N';

UPDATE stage_fosalesforecastweekly_regular
SET ct_salesquantity = 1,
dd_zerosales_changedto_one = 'Y'
WHERE ct_salesquantity = 0;

UPDATE stage_fosalesforecastweekly_rfh
SET ct_salesquantity = 1,
dd_zerosales_changedto_one = 'Y'
WHERE ct_salesquantity = 0;

UPDATE stage_fosalesforecastweekly_outlier
SET ct_salesquantity = 1,
dd_zerosales_changedto_one = 'Y'
WHERE ct_salesquantity = 0;

UPDATE stage_fosalesforecastweekly_ofh
SET ct_salesquantity = 1,
dd_zerosales_changedto_one = 'Y'
WHERE ct_salesquantity = 0;

UPDATE stage_fosalesforecastweekly_regular
SET ct_forecastquantity = 1,
dd_zerofcst_changedto_one = 'Y'
WHERE ct_forecastquantity = 0;

UPDATE stage_fosalesforecastweekly_rfh
SET ct_forecastquantity = 1,
dd_zerofcst_changedto_one = 'Y'
WHERE ct_forecastquantity = 0;

UPDATE stage_fosalesforecastweekly_outlier
SET ct_forecastquantity = 1,
dd_zerofcst_changedto_one = 'Y'
WHERE ct_forecastquantity = 0;

UPDATE stage_fosalesforecastweekly_ofh
SET ct_forecastquantity = 1,
dd_zerofcst_changedto_one = 'Y'
WHERE ct_forecastquantity = 0;


/* Update rank in Reg using Weighed MAD */
DROP TABLE IF EXISTS tmp_mad_calculation_testperiod_regular;
CREATE TABLE tmp_mad_calculation_testperiod_regular
AS
SELECT DD_REPORTINGDATE,dd_partnumber,dd_plant,dd_forecasttype,
SUM((ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity)/SUM(ct_forecastquantity) ct_bias,
SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity))/SUM(ct_salesquantity) ct_mad,
rank() over(partition by DD_REPORTINGDATE,dd_partnumber,dd_plant
ORDER BY SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity))/SUM(ct_salesquantity)) dd_rank_bymadweighed
FROM stage_fosalesforecastweekly_regular s
WHERE dd_forecastsample = 'Test' 
/*AND dd_partnumber = '19200-74186' */
GROUP BY DD_REPORTINGDATE,dd_partnumber,dd_plant,dd_forecasttype;

/*
SELECT *
FROM tmp_mad_calculation_testperiod_regular
WHERE dd_forecasttype = 'BSTS Fractal'
ORDER BY dd_plant,dd_forecasttype;

SELECT *
FROM stage_fosalesforecastweekly_regular
WHERE dd_forecasttype = 'BSTS Fractal'
AND dd_partnumber = '19200-74186'
AND dd_plant = 1072
AND dd_forecastsample = 'Test'
ORDER BY dd_forecastdate;
*/

/* Update MAD, Rank and Bias for all rows in regular, using the calculation done in tmp_mad_calculation_testperiod_regular */
UPDATE stage_fosalesforecastweekly_regular f
SET f.dd_forecastrank = t.dd_rank_bymadweighed,
f.ct_mad = t.ct_mad,
f.ct_bias_error = t.ct_bias
FROM stage_fosalesforecastweekly_regular f,tmp_mad_calculation_testperiod_regular t
WHERE f.dd_partnumber = t.dd_partnumber AND f.dd_plant = t.dd_plant
AND f.dd_forecasttype = t.dd_forecasttype;

UPDATE stage_fosalesforecastweekly_regular
SET ct_forecastquantity_regular = CT_FORECASTQUANTITY,
ct_highpi_regular = ct_highpi,
ct_lowpi_regular = ct_lowpi,
ct_mad_holdout_basedonregularfcst = ct_mad,
ct_bias_holdout_basedonregularfcst = ct_bias_error;

/* Update rank in outlier-treated fcst */


DROP TABLE IF EXISTS tmp_mad_calculation_testperiod_outlier;
CREATE TABLE tmp_mad_calculation_testperiod_outlier
AS
SELECT DD_REPORTINGDATE,dd_partnumber,dd_plant,dd_forecasttype,
SUM((ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity)/SUM(ct_forecastquantity) ct_bias,
SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity))/SUM(ct_salesquantity) ct_mad,
rank() over(partition by DD_REPORTINGDATE,dd_partnumber,dd_plant
ORDER BY SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity))/SUM(ct_salesquantity)) dd_rank_bymadweighed
FROM stage_fosalesforecastweekly_outlier s
WHERE dd_forecastsample = 'Test' 
/*AND dd_partnumber = '19200-74186' */
GROUP BY DD_REPORTINGDATE,dd_partnumber,dd_plant,dd_forecasttype;


UPDATE stage_fosalesforecastweekly_outlier f
SET f.dd_forecastrank = t.dd_rank_bymadweighed,
f.ct_mad = t.ct_mad,
f.ct_bias_error = t.ct_bias
FROM stage_fosalesforecastweekly_outlier f,tmp_mad_calculation_testperiod_outlier t
WHERE f.dd_partnumber = t.dd_partnumber AND f.dd_plant = t.dd_plant
AND f.dd_forecasttype = t.dd_forecasttype;

UPDATE stage_fosalesforecastweekly_outlier
SET ct_forecastquantity_outlier = CT_FORECASTQUANTITY,
ct_highpi_outlier = ct_highpi,
ct_lowpi_outlier = ct_lowpi,
ct_mad_holdout_basedonoutlierfcst = ct_mad,
ct_bias_holdout_basedonoutlierfcst = ct_bias_error;

/* Create mapping table for part-plant-r_vs_o */

/* First populate where outlier exists and is better */
DROP TABLE IF EXISTS tmp_bestmethod_r_vs_o;
CREATE TABLE tmp_bestmethod_r_vs_o
AS
SELECT DISTINCT dd_partnumber,dd_plant,'Outlier' dd_bestapproach
FROM stage_fosalesforecastweekly_outlier o
WHERE o.dd_forecastrank = 1
AND EXISTS (
SELECT 1 FROM stage_fosalesforecastweekly_regular r
WHERE r.dd_partnumber = o.dd_partnumber
AND r.dd_plant = o.dd_plant
AND r.dd_forecastrank = 1
AND r.ct_mad > o.ct_mad );

/* Now populate all other part-plants from regular */
INSERT INTO tmp_bestmethod_r_vs_o
SELECT DISTINCT r.dd_partnumber,r.dd_plant,'Regular' dd_bestapproach
FROM stage_fosalesforecastweekly_regular r
WHERE NOT EXISTS ( SELECT 1 FROM ( SELECT DISTINCT dd_partnumber,dd_plant FROM tmp_bestmethod_r_vs_o t)t1
WHERE t1.dd_partnumber = r.dd_partnumber AND t1.dd_plant = r.dd_plant );


/* Combine the forecasts */

DROP TABLE IF EXISTS stage_fosalesforecastweekly_combined;
CREATE TABLE stage_fosalesforecastweekly_combined
AS
SELECT *
FROM stage_fosalesforecastweekly_regular;

UPDATE stage_fosalesforecastweekly_combined comb
SET comb.dd_bestapproach_by_mad_holdout = t.dd_bestapproach
FROM stage_fosalesforecastweekly_combined comb,tmp_bestmethod_r_vs_o t
WHERE comb.dd_partnumber = t.dd_partnumber
AND comb.dd_plant = t.dd_plant;

UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_forecastquantity_regular = r.ct_forecastquantity,
s.ct_highpi_regular = r.ct_highpi,
s.ct_lowpi_regular = r.ct_lowpi,
s.dd_forecastrank_regular = r.dd_forecastrank,
s.ct_mad_holdout_basedonregularfcst = r.ct_mad,
s.ct_bias_holdout_basedonregularfcst = r.ct_bias_error
FROM stage_fosalesforecastweekly_combined s, stage_fosalesforecastweekly_regular r
WHERE s.dd_partnumber = r.dd_partnumber AND s.dd_plant = r.dd_plant
AND r.dd_forecastdate = s.dd_forecastdate
AND r.dd_forecasttype = s.dd_forecasttype;

UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_forecastquantity_rfh = r.ct_forecastquantity,
s.ct_highpi_rfh = r.ct_highpi,
s.ct_lowpi_rfh = r.ct_lowpi,
s.ct_mad_horizon_basedonfullhistforecast = r.ct_mad_horizon_basedonfullhistforecast,
s.ct_bias_horizon_basedonfullhistforecast = r.ct_bias_horizon_basedonfullhistforecast
FROM stage_fosalesforecastweekly_combined s, stage_fosalesforecastweekly_rfh r
WHERE s.dd_partnumber = r.dd_partnumber AND s.dd_plant = r.dd_plant
AND r.dd_forecastdate = s.dd_forecastdate
AND r.dd_forecasttype = s.dd_forecasttype;


UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_forecastquantity_outlier = r.ct_forecastquantity,
s.ct_highpi_outlier = r.ct_highpi,
s.ct_lowpi_outlier = r.ct_lowpi,
s.dd_forecastrank_outlier = r.dd_forecastrank,
s.ct_mad_holdout_basedonoutlierfcst = r.ct_mad,
s.ct_bias_holdout_basedonoutlierfcst = r.ct_bias_holdout_basedonoutlierfcst
FROM stage_fosalesforecastweekly_combined s, stage_fosalesforecastweekly_outlier r
WHERE s.dd_partnumber = r.dd_partnumber AND s.dd_plant = r.dd_plant
AND r.dd_forecastdate = s.dd_forecastdate
AND r.dd_forecasttype = s.dd_forecasttype;

UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_forecastquantity_ofh = r.ct_forecastquantity,
s.ct_highpi_ofh = r.ct_highpi,
s.ct_lowpi_ofh = r.ct_lowpi,
s.ct_mad_horizon_basedonofhforecast = r.ct_mad_horizon_basedonofhforecast,
s.ct_bias_horizon_basedonofhforecast = r.ct_bias_error
FROM stage_fosalesforecastweekly_combined s, stage_fosalesforecastweekly_ofh r
WHERE s.dd_partnumber = r.dd_partnumber AND s.dd_plant = r.dd_plant
AND r.dd_forecastdate = s.dd_forecastdate
AND r.dd_forecasttype = s.dd_forecasttype;


UPDATE stage_fosalesforecastweekly_combined s
SET ct_bestforecastquantiy = ct_forecastquantity_rfh,
ct_forecastquantity = ct_forecastquantity_rfh,
ct_highpi = ct_highpi_rfh,
ct_lowpi = ct_lowpi_rfh,
ct_bestmadholdout = ct_mad_holdout_basedonregularfcst,
ct_bestmadhorizon = ct_mad_horizon_basedonfullhistforecast,
dd_forecastrank_bestapproach = dd_forecastrank_regular
WHERE dd_bestapproach_by_mad_holdout = 'Regular';

UPDATE stage_fosalesforecastweekly_combined s
SET ct_bestforecastquantiy = ct_forecastquantity_ofh,
ct_forecastquantity = ct_forecastquantity_ofh,
dd_forecastrank = dd_forecastrank_outlier,
dd_forecastrank_bestapproach = dd_forecastrank_outlier,
ct_mad = ct_mad_holdout_basedonoutlierfcst,
ct_bias_error = ct_bias_holdout_basedonoutlierfcst,
ct_highpi = ct_highpi_ofh,
ct_lowpi = ct_lowpi_ofh,
ct_bestmadholdout = ct_mad_holdout_basedonoutlierfcst,
ct_bestmadhorizon = ct_mad_horizon_basedonofhforecast
WHERE dd_bestapproach_by_mad_holdout = 'Outlier';

/* Update horizon sales */
UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_salesquantity = rfh.ct_salesquantity
FROM stage_fosalesforecastweekly_combined s,stage_fosalesforecastweekly_rfh rfh
WHERE s.dd_partnumber = rfh.dd_partnumber AND s.dd_plant = rfh.dd_plant
AND rfh.dd_forecastdate = s.dd_forecastdate
AND rfh.dd_forecasttype = s.dd_forecasttype
AND s.ct_salesquantity IS NULL
AND s.dd_forecastsample in ('Horizon','Validation');


UPDATE stage_fosalesforecastweekly_combined f
SET dd_sku10 = substr(dd_partnumber,1,11);

UPDATE stage_fosalesforecastweekly_combined f
SET dd_businessunit = dd_plant;

UPDATE stage_fosalesforecastweekly_combined s
SET s.dd_active_sku12_mappedtosku10 = t.sku12
FROM stage_fosalesforecastweekly_combined s, tmp_sku10_12_mappingrank t
WHERE s.dd_sku10 = t.sku10
AND t.rank1 = 1;

/*
DROP TABLE IF EXISTS tmp_distinct_parts_errormetrics;
CREATE TABLE tmp_distinct_parts_errormetrics
AS
SELECT DISTINCT dd_partnumber,dd_forecasttype,dd_forecastrank,ct_mad_holdout_basedonregularfcst ct_mad_holdout,ct_mad_horizon_basedonfullhistforecast ct_mad_validation,
dd_bestapproach_by_mad_holdout
FROM stage_fosalesforecastweekly_combined WHERE dd_bestapproach_by_mad_holdout = 'Regular'
UNION 
SELECT DISTINCT dd_partnumber,dd_forecasttype,dd_forecastrank_outlier,ct_mad_holdout_basedonoutlierfcst,ct_mad_horizon_basedonofhforecast,
dd_bestapproach_by_mad_holdout
FROM stage_fosalesforecastweekly_combined WHERE dd_bestapproach_by_mad_holdout <> 'Regular';
*/

/*
EXPORT (select * from tmp_distinct_parts_errormetrics order by dd_partnumber,dd_forecastrank)
INTO LOCAL CSV FILE '/Users/lokeshkamani/DSWork/poc_customer/rb/data/rb_combinedforecast.csv.gz'
COLUMN SEPARATOR = ','
WITH COLUMN NAMES 
REPLACE;
*/

/*
UPDATE stage_fosalesforecastweekly_combined f
SET dd_sku10 = substr(dd_partnumber,1,11);

UPDATE stage_fosalesforecastweekly_combined f
SET dd_businessunit = substr(dd_partnumber,13,4);

UPDATE stage_fosalesforecastweekly_combined f
SET dd_customercode = substr(dd_partnumber,18,10);
*/


/*
select *
FROM tmp_sku10_12_mappingrank
WHERE sku10 = '62338-74734';

select distinct dd_sku10,dd_active_sku12_mappedtosku10
FROM stage_fosalesforecastweekly_combined
WHERE dd_sku10 = '62338-74734';

*/

DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(upper(dd_reportingdate),'DD MON YYYY') dd_reportingdate,
dd_reportingdate dd_reportingdate_char
from stage_fosalesforecastweekly_combined;


/* Create a de-normalized table containing data from Sales Order */

drop table if exists tmp_saleshistory_grain_reqmonths;
drop table if exists tmp_saleshistory_grain_reqmonths_2;

drop table if exists fact_fosalesforecastweekly_temp;
create table fact_fosalesforecastweekly_temp as
select * from fact_fosalesforecastweekly WHERE 1=2;


insert into fact_fosalesforecastweekly_temp
(
fact_fosalesforecastweeklyid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mad,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
--dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_active_sku12_mappedtosku10,
DD_BESTAPPROACH_BY_MAD_HOLDOUT,
DD_FORECAST_QUANTITY,
DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_business_unit,dd_customerno

)
select  (select ifnull(max(fact_fosalesforecastweeklyid), 0) from fact_fosalesforecastweekly m)
+ row_number() over(order by dd_partnumber,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecastid,
1 dim_partid,
1 dim_plantid,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
upper(sf.dd_reportingdate),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mad * 100,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
--case when sf.dd_forecastdate is null then '190000'
--else sf.dd_forecastdate END 
--dd_forecastdatevalue,
ct_bias_error * 100,
ct_bias_error_rank,
sf.dd_partnumber dd_partnumber,
dd_active_sku12_mappedtosku10,
sf.DD_BESTAPPROACH_BY_MAD_HOLDOUT,
sf.DD_FORECAST_QUANTITY,
sf.DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_businessunit,dd_customercode
from stage_fosalesforecastweekly_combined sf;



UPDATE fact_fosalesforecastweekly_temp f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
fact_fosalesforecastweekly_temp f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE fact_fosalesforecastweekly_temp f
SET f.dim_dateidforecast = d.dim_dateid
from (select Calendarweekyr,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by Calendarweekyr)d,
fact_fosalesforecastweekly_temp f
WHERE to_char(f.dd_forecastdate) = to_char(concat(left(d.Calendarweekyr,4),right(d.Calendarweekyr,2))) 
AND f.dim_dateidforecast <> d.dim_dateid;

DELETE FROM fact_fosalesforecastweekly f
WHERE EXISTS 
(SELECT 1 FROM tmp_maxrptdate t
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = t.dd_reportingdate );

insert into fact_fosalesforecastweekly
(
FACT_FOSALESFORECASTWEEKLYID,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mad,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plant,
DD_Forecast_approach,
DD_FORECAST_QUANTITY,
DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_business_unit,dd_customerno,dd_active_sku12_mappedtosku10,
DD_BESTAPPROACH_BY_MAD_HOLDOUT,
dim_customerparentgroupaddresssoldtoid
)
select
FACT_FOSALESFORECASTWEEKLYID,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mad,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plant,
DD_Forecast_approach,
DD_FORECAST_QUANTITY,
DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_business_unit,dd_customerno,dd_active_sku12_mappedtosku10,
DD_BESTAPPROACH_BY_MAD_HOLDOUT,
dim_customerparentgroupaddresssoldtoid
from fact_fosalesforecastweekly_temp;


/*
UPDATE fact_fosalesforecastweekly
set dd_forecastgrain = 'SKU10-BU'
WHERE dd_reportingdate = '23 APR 2018';

UPDATE fact_fosalesforecastweekly
set dd_forecastgrain = 'SKU10-BU-CustCode'
WHERE dd_reportingdate = '01 APR 2018';


UPDATE fact_fosalesforecastweekly
set dd_forecastgrain = 'SKU10-BU'
WHERE dd_reportingdate = '23 APR 2018';

DELETE FROM fact_fosalesforecastweekly
WHERE dd_reportingdate in ('03 APR 2018','04 APR 2018');
*/


/* 02340-87637_1086_11599041 has 3 methods with forecast rank = 0 */
--SELECT *
/*
SELECT DISTINCT dd_forecasttype,dd_forecastrank
FROM stage_fosalesforecastweekly_combined
WHERE dd_partnumber = '02340-87637_1086_11599041'
AND dd_forecasttype = 'LarsLasso- Cross Validation';

SELECT DISTINCT dd_forecasttype,dd_forecastrank
FROM stage_fosalesforecastweekly_regular
WHERE dd_partnumber = '02340-87637_1086_11599041'
AND dd_forecasttype = 'LarsLasso- Cross Validation';

*/

/*
SELECT DISTINCT dd_forecasttype,dd_forecastrank
FROM stage_fosalesforecastweekly_outlier
WHERE dd_partnumber = '02340-87637_1086_11599041'
AND dd_forecasttype = 'LarsLasso- Cross Validation';*/   /* This gave 0 rows */

/*
SELECT COUNT(*) FROM fact_fosalesforecastweekly
WHERE dd_reportingdate = '23 APR 2018'
AND dd_forecastrank = 0;

SELECT COUNT(DISTINCT dd_partnumber)
FROM stage_fosalesforecastweekly_combined
WHERE dd_forecastrank IS NULL;
*/

UPDATE fact_fosalesforecastweekly
SET DD_BESTAPPROACH_BY_MAD_HOLDOUT = 'Standard Fcst'
WHERE DD_BESTAPPROACH_BY_MAD_HOLDOUT LIKE 'Standard%';

UPDATE fact_fosalesforecastweekly
SET DD_BESTAPPROACH_BY_MAD_HOLDOUT = 'Outlier-treated Fcst'
WHERE DD_BESTAPPROACH_BY_MAD_HOLDOUT LIKE 'Outlier%';

UPDATE fact_fosalesforecastweekly f
SET DIM_JDE_2NDITEMNUMBERID = d.DIM_JDE_ITEM_MASTERID
FROM fact_fosalesforecastweekly f,dim_jde_item_master d
WHERE f.dd_active_sku12_mappedtosku10 = d.ITEM_NUMBER_2
AND (f.DIM_JDE_2NDITEMNUMBERID = 1 or f.DIM_JDE_2NDITEMNUMBERID is null);

UPDATE fact_fosalesforecastweekly f
SET f.dd_segment = t.segment,
f.dd_brand = t.brand,
f.dd_spc = t.spc,
f.dd_bsgbrandsegment = t.bsgbrandsegment
FROM fact_fosalesforecastweekly f,tmp_brandsegspcskumapping1 t
WHERE f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 = t.itemcode;

UPDATE fact_fosalesforecastweekly f
SET f.dd_sku12 = f.DD_ACTIVE_SKU12_MAPPEDTOSKU10
WHERE (f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 is not null and f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 <> 'Not Set')
AND (f.dd_sku12 IS NULL OR f.dd_sku12 = 'Not Set');


/* Update customer fcst */
/*
UPDATE fact_fosalesforecastweekly f
SET f.CT_FORECASTCUSTOMER = t.ct_forecastquantity_rb
FROM fact_fosalesforecastweekly f,tmp_custfcst t
WHERE f.dd_sku10 = t.dd_sku10
AND f.dd_business_unit = t.dd_plant
AND f.dd_forecastdate = t.dd_yyyyww;
*/

UPDATE fact_fosalesforecastweekly f
SET DD_FORECASTGRAIN = 'SKU10-BU'
FROM fact_fosalesforecastweekly f,tmp_maxrptdate t
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = t.dd_reportingdate;


UPDATE fact_fosalesforecastweekly f
SET dd_madrank = dd_forecastrank
FROM fact_fosalesforecastweekly f,tmp_maxrptdate t
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = t.dd_reportingdate;

/* Thas sku10 has some problem - 0 or null ranks */
DELETE FROM fact_fosalesforecastweekly
WHERE dd_sku10 = '62338-97279'
AND (dd_forecastrank is null or dd_forecastrank = 0);

DELETE FROM fact_fosalesforecastweekly
WHERE (dd_forecastrank is null or dd_forecastrank = 0);



/*
DROP TABLE IF EXISTS tmp_mad_calculation_horizon;
CREATE TABLE tmp_mad_calculation_horizon
AS
SELECT DD_REPORTINGDATE,dd_sku10,dd_business_unit,dd_demandcustomer,dd_forecasttype,
SUM((ct_forecastquantity-ct_salesquantity)*ct_salesquantity/case when ct_forecastquantity = 0 then 1 else ct_forecastquantity end)/case when SUM(ct_forecastquantity) = 0 then 1 else SUM(ct_forecastquantity) END ct_bias,
SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/case when ct_forecastquantity = 0 then 1 else ct_forecastquantity end))/case when SUM(ct_salesquantity) = 0 then 1 else SUM(ct_forecastquantity) END ct_mad,
rank() over(partition by DD_REPORTINGDATE,dd_sku10,dd_business_unit,dd_demandcustomer
ORDER BY SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/case when ct_forecastquantity = 0 then 1 else ct_forecastquantity end))/case when SUM(ct_salesquantity) = 0 then 1 else SUM(ct_salesquantity) END) dd_rank_bymadweighed
FROM fact_fosalesforecastweekly s, tmp_maxrptdate t1
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = t1.dd_reportingdate
AND dd_forecastsample = 'Validation'
--AND DD_REPORTINGDATE = '23 APR 2018'
GROUP BY DD_REPORTINGDATE,dd_sku10,dd_business_unit,dd_demandcustomer,dd_forecasttype;

UPDATE fact_fosalesforecastweekly f
SET f.CT_MAD_HORIZON = t.CT_MAD * 100
FROM fact_fosalesforecastweekly f,tmp_mad_calculation_horizon t
WHERE f.DD_REPORTINGDATE = t.DD_REPORTINGDATE
AND f.dd_sku10 = t.dd_sku10 AND f.dd_business_unit = t.dd_business_unit 
AND f.dd_demandcustomer = t.dd_demandcustomer
AND f.dd_forecasttype = t.dd_forecasttype;

select *
from tmp_mad_calculation_horizon
limit 5;
*/





DROP TABLE IF EXISTS tmp_week_to_startdatemapping;
CREATE TABLE tmp_week_to_startdatemapping
(
YYYYWW int,
START_DATE varchar(20)
);

IMPORT INTO tmp_week_to_startdatemapping
FROM LOCAL CSV FILE '../noncausal/data/week_to_start_date_mapping_corr.csv'
COLUMN SEPARATOR = ','
SKIP = 1;

UPDATE fact_fosalesforecastweekly f
SET f.dd_startdate = to_date(t.start_date,'YYYY-MM-DD')
FROM fact_fosalesforecastweekly f,tmp_week_to_startdatemapping t,tmp_maxrptdate mrpt
WHERE f.DD_FORECASTDATE = t.YYYYWW
AND TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate;


DROP TABLE IF EXISTS tmp_weeklysales_bycust;
CREATE TABLE tmp_weeklysales_bycust
AS
SELECT b.dd_sku10,b.dd_bu,b.dd_demandcustomer,b.dd_invoicedate_ww,
sum(ct_salesquantity) ct_salesquantity_weekly_byskubucust,
sum(t.weeklysales) ct_salesquantity_weekly_byskubu,
cast(0 as decimal(18,4)) ct_fraction_weekly
FROM tmp_actualsales b,
(SELECT dd_sku10,dd_bu,dd_invoicedate_ww,
sum(ct_salesquantity) weeklysales
FROM tmp_actualsales
GROUP BY dd_sku10,dd_bu,dd_invoicedate_ww) t
WHERE t.dd_sku10 = b.dd_sku10 and t.dd_bu = b.dd_bu
AND t.dd_invoicedate_ww = b.dd_invoicedate_ww
GROUP BY b.dd_sku10,b.dd_bu,b.dd_demandcustomer,b.dd_invoicedate_ww;

UPDATE tmp_weeklysales_bycust
SET ct_fraction_weekly = ct_salesquantity_weekly_byskubucust/ct_salesquantity_weekly_byskubu
WHERE ct_salesquantity_weekly_byskubu > 0;


DROP TABLE IF EXISTS tmp_fact_fosalesforecastweekly_withcust;
CREATE TABLE tmp_fact_fosalesforecastweekly_withcust
AS
SELECT f.*,
t.dd_demandcustomer dd_dmdcust,
f.ct_forecastquantity * t.ct_fraction_weekly ct_forecastquantity_bydemandcust
FROM fact_fosalesforecastweekly f, tmp_weeklysales_bycust t,tmp_maxrptdate mrpt
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate
AND f.dd_forecastrank = 1
AND f.dd_sku10 = t.dd_sku10
AND f.dd_business_unit = t.dd_bu
AND substr(f.dd_forecastdate,5,2) = t.dd_invoicedate_ww;

UPDATE tmp_fact_fosalesforecastweekly_withcust
SET ct_forecastquantity = ct_forecastquantity_bydemandcust,
dd_demandcustomer = dd_dmdcust,
dd_reportingdate = TO_CHAR(TO_DATE(upper(dd_reportingdate),'DD MON YYYY') + INTERVAL '1' DAY,'DD MON YYYY');

ALTER TABLE tmp_fact_fosalesforecastweekly_withcust
DROP COLUMN dd_dmdcust;
ALTER TABLE tmp_fact_fosalesforecastweekly_withcust
DROP COLUMN ct_forecastquantity_bydemandcust;

INSERT INTO fact_fosalesforecastweekly
SELECT *
FROM tmp_fact_fosalesforecastweekly_withcust;


/* Populate forecast data for grains that were missed */
/* Get previous 13-week avg */
DROP TABLE IF EXISTS tmp_existinggrains_fcst;
CREATE TABLE tmp_existinggrains_fcst
AS
SELECT DISTINCT f.dd_sku10,f.DD_ACTIVE_SKU12_MAPPEDTOSKU10,f.dd_business_unit,
f.dd_demandcustomer
FROM fact_fosalesforecastweekly f,tmp_maxrptdate mrpt
WHERE dd_forecastrank = 1 AND dd_forecastdate = 201801
and TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate + INTERVAL '1' DAY;

DROP TABLE IF EXISTS tmp_13weekavg1;
CREATE TABLE tmp_13weekavg1
AS
SELECT dd_sku10,dd_sku12,dd_bu,dd_demandcustomer,
'13-week avg' dd_forecasttype,
1 dd_forecastrank,
to_char((mrpt.dd_reportingdate + interval '1' day),'DD MON YYYY') dd_reportingdate,
--t.dd_forecastdate,
sum(ct_salesquantity) ct_forecastquantity_13weekavg
FROM tmp_actualsales t,tmp_maxrptdate mrpt
--,(SELECT DISTINCT dd_forecastdate FROM stage_fosalesforecastweekly_regular) t
WHERE dd_invoicedate_yyyyww >= '201808'
AND dd_invoicedate_yyyyww <= '201820'
AND NOT EXISTS
(SELECT 1 FROM tmp_existinggrains_fcst f
WHERE f.dd_sku10 = t.dd_sku10 and f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 = t.dd_sku12
AND f.dd_business_unit = t.dd_bu and f.dd_demandcustomer = t.dd_demandcustomer)
GROUP BY dd_sku10,dd_sku12,dd_bu,dd_demandcustomer,to_char((mrpt.dd_reportingdate + interval '1' day),'DD MON YYYY');--,t.dd_forecastdate;

UPDATE tmp_13weekavg1
SET ct_forecastquantity_13weekavg = ct_forecastquantity_13weekavg/13;

DROP TABLE IF EXISTS tmp_13weekavg;
CREATE TABLE tmp_13weekavg
AS
SELECT t.*,t1.dd_forecastdate
FROM  tmp_13weekavg1 t,(SELECT DISTINCT dd_forecastdate FROM stage_fosalesforecastweekly_regular) t1;

/*
DELETE FROM fact_fosalesforecastweekly
WHERE dd_forecasttype = '13-week avg';
*/

INSERT INTO fact_fosalesforecastweekly
(fact_fosalesforecastweeklyid,
DD_SKU10,DD_ACTIVE_SKU12_MAPPEDTOSKU10,
DD_BUSINESS_UNIT,DD_DEMANDCUSTOMER,
dd_forecasttype,dd_forecastrank,
dd_reportingdate,dd_forecastdate,
ct_forecastquantity)
SELECT
(SELECT MAX(ifnull(fact_fosalesforecastweeklyid,0)) FROM fact_fosalesforecastweekly)
+ row_number() over(order by ''),
dd_sku10,dd_sku12,
dd_bu,dd_demandcustomer,
dd_forecasttype,dd_forecastrank,
dd_reportingdate,dd_forecastdate,
ct_forecastquantity_13weekavg
FROM tmp_13weekavg;


UPDATE fact_fosalesforecastweekly f
SET f.dd_startdate = to_date(t.start_date,'YYYY-MM-DD')
FROM fact_fosalesforecastweekly f,tmp_week_to_startdatemapping t,tmp_maxrptdate mrpt
WHERE f.DD_FORECASTDATE = t.YYYYWW
AND TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate + interval '1' day;

select distinct dd_reportingdate,dd_forecasttype from fact_fosalesforecastweekly f
order by to_date(dd_reportingdate,'DD MON YYYY');

update fact_fosalesforecastweekly
SET DD_TYPE = '6';

update fact_fosalesforecastweekly
SET DD_DUR = '7D';

update fact_fosalesforecastweekly
SET DD_MODEL = 'IMPORT';

