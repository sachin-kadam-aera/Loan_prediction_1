
/* Has MAD calculations */


open schema reckitt_benckiser;


DROP TABLE IF EXISTS stage_fosalesforecastweekly_combined;
CREATE TABLE stage_fosalesforecastweekly_combined (
DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
dd_partnumber       VARCHAR(150)  NOT NULL ,
dd_plant           VARCHAR(40) ,
CT_SALESQUANTITY    DECIMAL(36,6),
CT_FORECASTQUANTITY DECIMAL(36,6),
CT_LOWPI            DECIMAL(36,6),
CT_HIGHPI           DECIMAL(36,6),
CT_mad             DECIMAL(36,6),
DD_LASTDATE         VARCHAR(50)  ,
DD_HOLDOUTDATE      VARCHAR(50)  ,
DD_FORECASTSAMPLE   VARCHAR(50)  ,
DD_FORECASTTYPE     VARCHAR(50)  ,
DD_FORECASTRANK     DECIMAL(18,0),
DD_FORECASTMODE     VARCHAR(50)  ,
DD_COMPANYCODE      VARCHAR(50)  ,
CT_BIAS_ERROR_RANK  DECIMAL(36,6),
CT_BIAS_ERROR       DECIMAL(36,6),
DD_FORECASTEDFLAG VARCHAR(3) DEFAULT 'Yes',
DD_FLAG_MIN_HISTORY VARCHAR(3) DEFAULT 'No',
DD_FLAG_HOLDOUT VARCHAR(3) DEFAULT 'No',
DD_Forecast_approach VARCHAR(50) DEFAULT 'OutlierTreatedWithFullHist',
DD_FORECAST_QUANTITY   VARCHAR(50) DEFAULT 'Ordered Quantity',
DD_FORECASTGRAIN  VARCHAR(50) DEFAULT 'SKU-BusinessUnit',
ct_forecastquantity_regular decimal(18,4),
ct_forecastquantity_rfh decimal(18,4),
ct_forecastquantity_outlier decimal(18,4),
ct_forecastquantity_ofh decimal(18,4),
ct_highpi_regular decimal(18,4),
ct_highpi_rfh decimal(18,4),
ct_highpi_outlier decimal(18,4),
ct_highpi_ofh decimal(18,4),
ct_lowpi_regular decimal(18,4),
ct_lowpi_rfh decimal(18,4),
ct_lowpi_outlier decimal(18,4),
ct_lowpi_ofh decimal(18,4),
ct_mad_holdout_basedonregularfcst decimal(18,4),
ct_mad_horizon_basedonfullhistforecast decimal(18,4),
ct_mad_holdout_basedonoutlierfcst decimal(18,4),
ct_mad_horizon_basedonofhforecast decimal(18,4),
ct_bias_holdout_basedonregularfcst decimal(18,4),
ct_bias_horizon_basedonfullhistforecast decimal(18,4),
ct_bias_holdout_basedonoutlierfcst decimal(18,4),
ct_bias_horizon_basedonofhforecast decimal(18,4),
dd_bestapproach_by_mad_holdout varchar(100) default 'Regular',
ct_bestforecastquantiy decimal(18,4),
ct_bestmadholdout decimal(18,4),
ct_bestmadhorizon decimal(18,4),
ct_bestbiasholdout decimal(18,4),
ct_bestbiashorizon decimal(18,4),
dd_forecastrank_regular int,
dd_forecastrank_outlier int,
dd_forecastrank_bestapproach int,
dd_sku10 varchar(11),
dd_sku12 varchar(20) default 'Not Set',
dd_businessunit varchar(10) default 'Not Set',
dd_customercode varchar(30) default 'Not Set',
dd_active_sku12_mappedtosku10 varchar(20) default 'Not Set'
);

DROP TABLE IF EXISTS stage_fosalesforecastweekly_regular;
CREATE TABLE stage_fosalesforecastweekly_regular 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;

DROP TABLE IF EXISTS stage_fosalesforecastweekly_rfh;
CREATE TABLE stage_fosalesforecastweekly_rfh 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;


DROP TABLE IF EXISTS stage_fosalesforecastweekly_outlier;
CREATE TABLE stage_fosalesforecastweekly_outlier 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;

DROP TABLE IF EXISTS stage_fosalesforecastweekly_ofh;
CREATE TABLE stage_fosalesforecastweekly_ofh 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;

DROP TABLE IF EXISTS stage_fosalesforecastweekly_regular_causal;
CREATE TABLE stage_fosalesforecastweekly_regular_causal 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;

DROP TABLE IF EXISTS stage_fosalesforecastweekly_RFH_causal;
CREATE TABLE stage_fosalesforecastweekly_RFH_causal
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;


/* Import the FCST output file into stage table */
IMPORT INTO stage_fosalesforecastweekly_regular
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE './Rb_Regular.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

IMPORT INTO stage_fosalesforecastweekly_rfh
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE './Rb_RFH.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

IMPORT INTO stage_fosalesforecastweekly_outlier
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE './Rb_outlier.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

IMPORT INTO stage_fosalesforecastweekly_ofh
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE './Rb_OFH.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

IMPORT INTO stage_fosalesforecastweekly_regular_causal
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE './Rb_Regular_Causal.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;


IMPORT INTO stage_fosalesforecastweekly_rfh_causal
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE './Rb_RFH_Causal.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;
