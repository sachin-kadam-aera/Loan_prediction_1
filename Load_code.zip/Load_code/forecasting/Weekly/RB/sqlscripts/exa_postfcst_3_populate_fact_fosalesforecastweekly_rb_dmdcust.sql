OPEN SCHEMA RECKITT_BENCKISER;

/* Get 3-grain actuals */
DROP TABLE IF EXISTS tmp_actualsales;
CREATE TABLE tmp_actualsales
(
dd_sku10 varchar(20),
dd_bu varchar(10),
dd_invoicedate_char varchar(20),
dd_invoicedate_date date,
dd_invoicedate_yyyyww varchar(10),
dd_invoicedate_ww varchar(10),
ct_salesquantity int,
dd_demandcustomer varchar(100),
dd_sku12 varchar(20)
);

/* Get actual sales from fact_jde_sales_order_line */
/* Get it as SKU-10,BU,DMDCust Level */

INSERT INTO tmp_actualsales
(dd_sku10,dd_bu,dd_invoicedate_date,ct_salesquantity,dd_demandcustomer)
SELECT itemmaster.BASE_ITEM,bu.Business_Unit,dtinv.datevalue,f_jsol.ct_unitsshipped,dcpasd.CUSTOMERDEMAND
FROM fact_jde_sales_order_line f_jsol INNER JOIN dim_jde_item_master itemmaster ON itemmaster.dim_jde_item_masterid = f_jsol.dim_jde_itemnumbershortid
INNER JOIN dim_jde_businessunitmaster bu ON bu.dim_jde_businessunitmasterid = f_jsol.dim_jde_businessunitmasterid
INNER JOIN dim_date dtinv ON dtinv.dim_dateid = f_jsol.dim_jde_dateinvoiceid
INNER JOIN dim_jde_addressbook dcpasd ON dcpasd.dim_jde_addressbookid = f_jsol.dim_customerparentgroupaddresssoldtoid
INNER JOIN dim_jde_fndlookup sclast ON sclast.dim_jde_fndlookupid = f_jsol.dim_jde_statuscodelastid
WHERE dd_ordertype in ('SX','SO')
AND bu.Business_Unit in ('1072','1086','1087','1088')
AND dtinv.datevalue >= '2014-01-01'
AND f_jsol.dd_invoicenumber > 0 AND itemmaster.BASE_ITEM LIKE '%-%'
AND sclast.User_Defined_Code_KY in ('600','620');

/* Assume 1-1 mapping between SKU-10 and SKU-12. There are 2 exceptions according to tmp_sku10_12_mappingrank which are removed */
UPDATE tmp_actualsales a
SET dd_invoicedate_char = to_char(dd_invoicedate_date,'DD Mon YYYY'),
dd_invoicedate_ww = to_char(dd_invoicedate_date,'WW'),
dd_invoicedate_yyyyww = to_char(dd_invoicedate_date,'YYYYWW'),
a.dd_sku12 = t.sku12
FROM tmp_sku10_12_mappingrank t,tmp_actualsales a
WHERE a.dd_sku10 = t.sku10
AND t.rank1 = 1
AND t.sku10 not in ('19200-89675','51700-97517'); /* Only these 2 have more than 1 active SKUs */


drop table if exists tmp_max_rptdate;
CREATE TABLE tmp_max_rptdate
AS
SELECT MAX(to_date(dd_reportingdate,'DD MON YYYY')) dd_reportingdate_date,
MAX(to_date(dd_reportingdate,'DD MON YYYY')) dd_reportingdate,
to_char(MAX(to_date(dd_reportingdate,'DD MON YYYY')),'DD MON YYYY') dd_reportingdate_char
FROM fact_fosalesforecastweekly;

/* Alternatively, insert a reporting date explicitly*/
/*
DELETE FROM tmp_max_rptdate;
INSERT INTO tmp_max_rptdate (dd_reportingdate_date,dd_reportingdate,dd_reportingdate_char)
SELECT '2018-06-09','2018-06-09','09 JUN 2018';
*/

DROP TABLE IF EXISTS tmp_weeklysales_skulc;
CREATE TABLE tmp_weeklysales_skulc
AS
SELECT dd_sku10,dd_bu,dd_invoicedate_ww,
sum(ct_salesquantity) weeklysales
FROM tmp_actualsales
GROUP BY dd_sku10,dd_bu,dd_invoicedate_ww;

DROP TABLE IF EXISTS tmp_weeklysales_bycust;
CREATE TABLE tmp_weeklysales_bycust
AS
SELECT b.dd_sku10,b.dd_bu,b.dd_demandcustomer,b.dd_invoicedate_ww,
sum(ct_salesquantity) ct_salesquantity_weekly_byskubucust,
t.weeklysales ct_salesquantity_weekly_byskubu,
cast(0 as decimal(18,4)) ct_fraction_weekly
FROM tmp_actualsales b,
tmp_weeklysales_skulc t
WHERE t.dd_sku10 = b.dd_sku10 and t.dd_bu = b.dd_bu
AND t.dd_invoicedate_ww = b.dd_invoicedate_ww
GROUP BY b.dd_sku10,b.dd_bu,b.dd_demandcustomer,b.dd_invoicedate_ww,t.weeklysales;

UPDATE tmp_weeklysales_bycust
SET ct_fraction_weekly = ct_salesquantity_weekly_byskubucust/ct_salesquantity_weekly_byskubu
WHERE ct_salesquantity_weekly_byskubu > 0;


DROP TABLE IF EXISTS tmp_fact_fosalesforecastweekly_withcust;
CREATE TABLE tmp_fact_fosalesforecastweekly_withcust
AS
SELECT f.*,
t.dd_demandcustomer dd_dmdcust,
f.ct_forecastquantity * t.ct_fraction_weekly ct_forecastquantity_bydemandcust
FROM fact_fosalesforecastweekly f, tmp_weeklysales_bycust t,tmp_maxrptdate mrpt
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate + INTERVAL '1' DAY
AND f.dd_forecastrank = 1
AND f.dd_sku10 = t.dd_sku10
AND f.dd_business_unit = t.dd_bu
AND substr(f.dd_forecastdate,5,2) = t.dd_invoicedate_ww;

UPDATE tmp_fact_fosalesforecastweekly_withcust
SET ct_forecastquantity = ct_forecastquantity_bydemandcust,
dd_demandcustomer = dd_dmdcust,
dd_reportingdate = TO_CHAR(TO_DATE(upper(dd_reportingdate),'DD MON YYYY') + INTERVAL '1' DAY,'DD MON YYYY');

ALTER TABLE tmp_fact_fosalesforecastweekly_withcust
DROP COLUMN dd_dmdcust;
ALTER TABLE tmp_fact_fosalesforecastweekly_withcust
DROP COLUMN ct_forecastquantity_bydemandcust;

INSERT INTO fact_fosalesforecastweekly
SELECT *
FROM tmp_fact_fosalesforecastweekly_withcust;



DELETE FROM fact_fosalesforecastweekly  f
WHERE EXISTS ( SELECT 1 FROM tmp_max_rptdate t WHERE t.dd_reportingdate = to_date(f.dd_reportingdate,'DD MON YYYY'));

INSERT INTO fact_fosalesforecastweekly
SELECT *
FROM tmp_fact_fosalesforecastweekly_withcust;


UPDATE fact_fosalesforecastweekly
SET dd_latestreporting = 'N';

UPDATE fact_fosalesforecastweekly
SET dd_latestreporting = 'Y'
WHERE to_date(dd_reportingdate,'DD MON YYYY') = (SELECT MAX(to_date(dd_reportingdate,'DD MON YYYY')) FROM fact_fosalesforecastweekly);
