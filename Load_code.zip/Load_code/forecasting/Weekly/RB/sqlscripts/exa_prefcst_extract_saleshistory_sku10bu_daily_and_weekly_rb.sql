OPEN SCHEMA RECKITT_BENCKISER;

DROP TABLE IF EXISTS tmp_saleshistory;
CREATE TABLE tmp_saleshistory
(
sku varchar(200),
businessunit varchar(10),
dd_dummy varchar(3),
date_char varchar(50),
DATEVALUE date,
ct_salesquantity decimal(18,4),
dd_grain varchar(250)
);



/* Existing extract file extracted from report, after removing first 4-5 rows and TOTAL row at bottom */

DROP TABLE IF EXISTS tmp_saleshistory_skubuplantocust;
CREATE TABLE tmp_saleshistory_skubuplantocust
(
dd_sku10 varchar(20),
dd_bu varchar(10),
dd_invoicedate_char varchar(20),
dd_invoicedate_date date,
dd_invoicedate_yyyyww varchar(10),
yyyyww_fcst varchar(10),   /* Different week logic for forecasting scripts */
dd_invoicedate_ww varchar(10),
ct_salesquantity int,
dd_demandcustomer varchar(100),
dd_customerplanto varchar(50),
dd_sku12 varchar(20)
);

INSERT INTO tmp_saleshistory_skubuplantocust
(dd_sku10,dd_bu,dd_invoicedate_date,ct_salesquantity,dd_demandcustomer,dd_customerplanto,dd_sku12)
SELECT itemmaster.BASE_ITEM,bu.Business_Unit,dtinv.datevalue,SUM(f_jsol.ct_unitsshipped) ct_unitsshipped,dcpasd.CUSTOMERDEMAND, 
dcpasd.Address_Number dd_customerplanto,
itemmaster.Item_Number_2 dd_sku12
FROM fact_jde_sales_order_line f_jsol INNER JOIN dim_jde_item_master itemmaster ON itemmaster.dim_jde_item_masterid = f_jsol.dim_jde_itemnumbershortid
INNER JOIN dim_jde_businessunitmaster bu ON bu.dim_jde_businessunitmasterid = f_jsol.dim_jde_businessunitmasterid
INNER JOIN dim_date dtinv ON dtinv.dim_dateid = f_jsol.dim_jde_dateinvoiceid
INNER JOIN dim_jde_addressbook dcpasd ON dcpasd.dim_jde_addressbookid = f_jsol.dim_customerparentgroupaddresssoldtoid
INNER JOIN dim_jde_fndlookup sclast ON sclast.dim_jde_fndlookupid = f_jsol.dim_jde_statuscodelastid
WHERE f_jsol.dd_ordertype in ('SX','SO')
AND bu.Business_Unit in ('1072','1086','1087','1088')
AND dtinv.datevalue >= '2014-01-01' AND dtinv.datevalue <= current_date
AND f_jsol.dd_invoicenumber > 0 AND itemmaster.BASE_ITEM LIKE '%-%'
AND sclast.User_Defined_Code_KY in ('600','620')
GROUP BY itemmaster.BASE_ITEM,bu.Business_Unit,dtinv.datevalue,dcpasd.CUSTOMERDEMAND, 
dcpasd.Address_Number,
itemmaster.Item_Number_2;


/* Create table for baseitem,plantocust,qty. Used for weight calculation for promo */
DROP TABLE IF EXISTS tmp_sku_plantocust_weights;
CREATE TABLE tmp_sku_plantocust_weights
AS
SELECT dd_sku10 ,dd_customerplanto ,sum(ct_salesquantity) ct_salesquantity
FROM tmp_saleshistory_skubuplantocust
WHERE dd_invoicedate_date <= current_date
GROUP BY dd_sku10,dd_customerplanto ORDER BY dd_sku10, dd_customerplanto;

EXPORT (select dd_sku10 'Base Item',dd_customerplanto 'Address Number',ct_salesquantity 'SUM Quantity Shipped / Invoiced'
FROM tmp_sku_plantocust_weights)
INTO LOCAL CSV FILE '../noncausal/data/low_level_grain_data.csv'
COLUMN SEPARATOR = ',' REPLACE;

UPDATE tmp_saleshistory_skubuplantocust
SET dd_invoicedate_char = to_char(dd_invoicedate_date,'DD MON YYYY'),
dd_invoicedate_ww = to_char(dd_invoicedate_date,'WW'),
dd_invoicedate_yyyyww = to_char(dd_invoicedate_date,'YYYYWW');



DROP TABLE IF EXISTS tmp_saleshistory_skubu;
CREATE TABLE tmp_saleshistory_skubu
AS
SELECT dd_sku10,dd_bu,dd_invoicedate_char,dd_invoicedate_date,sum(ct_salesquantity) ct_salesquantity,
cast(null as varchar(10)) yyyyww_fcst
FROM tmp_saleshistory_skubuplantocust
GROUP BY dd_sku10,dd_bu,dd_invoicedate_char,dd_invoicedate_date;

/* Ignore grains that have less than 12 months of training data */
/* Ignore grains that have no sales in last 3 months */
DROP TABLE IF EXISTS tmp_maxdate;
CREATE TABLE tmp_maxdate
AS
SELECT dd_sku10,dd_bu,max(dd_invoicedate_date) max_datevalue,min(dd_invoicedate_date) min_datevalue
FROM tmp_saleshistory_skubu
GROUP BY dd_sku10,dd_bu
HAVING max(dd_invoicedate_date) >= current_date - interval '3' month
AND min(dd_invoicedate_date) <= current_date  - interval '15' month;
/*HAVING max(dd_invoicedate_date) >= to_date('24 DEC 2017','DD MON YYYY') - interval '3' month
AND min(dd_invoicedate_date) <= to_date('24 DEC 2017','DD MON YYYY')  - interval '15' month;
*/


DELETE FROM tmp_saleshistory_skubu t
WHERE NOT EXISTS ( SELECT 1 FROM tmp_maxdate t1
WHERE t.dd_sku10 = t1.dd_sku10 AND t.dd_bu = t1.dd_bu);

DELETE FROM tmp_saleshistory_skubuplantocust t
WHERE NOT EXISTS ( SELECT 1 FROM tmp_maxdate t1
WHERE t.dd_sku10 = t1.dd_sku10 AND t.dd_bu = t1.dd_bu);

EXPORT (select dd_sku10 BASE_ITEM,dd_bu BUSINESS_UNIT,to_char(dd_invoicedate_date,'YYYY-MM-DD') DATEVALUE,ct_salesquantity QTY_ORDERED 
from tmp_saleshistory_skubu order by dd_sku10, dd_bu, dd_invoicedate_date)
INTO LOCAL CSV FILE '../noncausal/data/saleshistory_sku10bu_daily.csv.gz'
COLUMN SEPARATOR = ',' REPLACE
WITH COLUMN NAMES;

/* Convert to weekly */
DROP TABLE IF EXISTS tmp_week_to_datemapping;
CREATE TABLE tmp_week_to_datemapping
(
date_char varchar(50),
date_date date,
ww varchar(2),
YYYYWW int
);

IMPORT INTO tmp_week_to_datemapping(date_char,ww,YYYYWW)
FROM LOCAL CSV FILE '../noncausal/data/daily_to_week_conversion.csv'
COLUMN SEPARATOR = ','
SKIP = 1;

UPDATE tmp_week_to_datemapping
SET date_date = TO_DATE(date_char,'YYYY-MM-DD');


UPDATE tmp_saleshistory_skubu w
SET w.yyyyww_fcst = t.YYYYWW
FROM tmp_saleshistory_skubu w,tmp_week_to_datemapping t
WHERE w.dd_invoicedate_date = t.date_date; 

/* Imputation */
/* Create table with 0's */
DROP TABLE IF EXISTS tmp_impute_zeros;
CREATE TABLE tmp_impute_zeros
AS
SELECT DISTINCT t.dd_sku10,dd_bu,to_char(w.YYYYWW) yyyyww_fcst,0 ct_salesquantity
FROM (SELECT dd_sku10,dd_bu,min(dd_invoicedate_date) min_dd_invoicedate_date FROM tmp_saleshistory_skubu GROUP BY dd_sku10,dd_bu) t, tmp_week_to_datemapping w
WHERE to_date(to_char(w.YYYYWW),'YYYYWW') >= t.min_dd_invoicedate_date
AND to_date(to_char(w.YYYYWW),'YYYYWW') <= current_date + interval '6' month;


INSERT INTO tmp_saleshistory_skubu 
(dd_sku10,dd_bu,yyyyww_fcst,ct_salesquantity)
SELECT z.*
FROM tmp_impute_zeros z
WHERE NOT EXISTS ( SELECT 1 FROM tmp_saleshistory_skubu t1 WHERE t1.dd_sku10 = z.dd_sku10 AND t1.dd_bu = z.dd_bu AND t1.yyyyww_fcst = z.yyyyww_fcst);

/* Weekly data at SKU-BU level */
EXPORT (select dd_sku10 BASE_ITEM,dd_bu BUSINESS_UNIT,'abc' dd_company,yyyyww_fcst,sum(ct_salesquantity) QTY_ORDERED
FROM tmp_saleshistory_skubu 
WHERE to_date(yyyyww_fcst,'YYYYWW') <= current_date		/* For regular file, restrict to previous week start dt. To be used for outlier file. Additional 0's from RFH will impact outliers */
GROUP BY dd_sku10,dd_bu,yyyyww_fcst ORDER BY dd_sku10, dd_bu, yyyyww_fcst)
INTO LOCAL CSV FILE '../noncausal/data/r_saleshistory_sku10bu_weekly.csv'
COLUMN SEPARATOR = ',' REPLACE;
--WITH COLUMN NAMES;


EXPORT (select dd_sku10 BASE_ITEM,dd_bu BUSINESS_UNIT,'abc' dd_company,yyyyww_fcst,sum(ct_salesquantity) QTY_ORDERED
FROM tmp_saleshistory_skubu
WHERE to_date(yyyyww_fcst,'YYYYWW') <= current_date + interval '4' month   /* RFH. 4 MONTHS INTO THE FUTURE */
GROUP BY dd_sku10,dd_bu,yyyyww_fcst ORDER BY dd_sku10, dd_bu, yyyyww_fcst)
INTO LOCAL CSV FILE '../noncausal/data/rfh_saleshistory_sku10bu_weekly.csv'
COLUMN SEPARATOR = ',' REPLACE;
