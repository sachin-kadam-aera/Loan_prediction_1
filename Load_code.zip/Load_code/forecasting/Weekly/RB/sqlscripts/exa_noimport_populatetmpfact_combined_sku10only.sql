
/* Has MAD calculations */
/* Script exa_create_and_populate_6tables.sql (to populate stage tables) should be run before this */


open schema reckitt_benckiser;

DROP TABLE IF EXISTS tmp_fact_fosalesforecastweekly_backpopulate;
CREATE TABLE tmp_fact_fosalesforecastweekly_backpopulate
AS
SELECT *
FROM fact_fosalesforecastweekly
WHERE 1=2;

/* Validate counts IN 6 tables. All should have non-zero rows */

SELECT COUNT(*)
FROM stage_fosalesforecastweekly_regular;
SELECT COUNT(*)
FROM stage_fosalesforecastweekly_rfh;

/* Get 3-grain actuals */
DROP TABLE IF EXISTS tmp_actualsales;
CREATE TABLE tmp_actualsales
(
dd_sku10 varchar(20),
dd_bu varchar(10),
dd_invoicedate_char varchar(20),
dd_invoicedate_date date,
dd_invoicedate_yyyyww varchar(10),
dd_invoicedate_ww varchar(10),
ct_salesquantity int,
dd_demandcustomer varchar(100),
dd_sku12 varchar(20)
);

/* Get actual sales from fact_jde_sales_order_line */
/* Get it as SKU-10,BU,DMDCust Level */

INSERT INTO tmp_actualsales
(dd_sku10,dd_bu,dd_invoicedate_date,ct_salesquantity,dd_demandcustomer)
SELECT itemmaster.BASE_ITEM,bu.Business_Unit,dtinv.datevalue,f_jsol.ct_unitsshipped,dcpasd.CUSTOMERDEMAND
FROM fact_jde_sales_order_line f_jsol INNER JOIN dim_jde_item_master itemmaster ON itemmaster.dim_jde_item_masterid = f_jsol.dim_jde_itemnumbershortid
INNER JOIN dim_jde_businessunitmaster bu ON bu.dim_jde_businessunitmasterid = f_jsol.dim_jde_businessunitmasterid
INNER JOIN dim_date dtinv ON dtinv.dim_dateid = f_jsol.dim_jde_dateinvoiceid
INNER JOIN dim_jde_addressbook dcpasd ON dcpasd.dim_jde_addressbookid = f_jsol.dim_customerparentgroupaddresssoldtoid
INNER JOIN dim_jde_fndlookup sclast ON sclast.dim_jde_fndlookupid = f_jsol.dim_jde_statuscodelastid
WHERE dd_ordertype in ('SX','SO')
AND bu.Business_Unit in ('1072','1086','1087','1088','1071','1073')
AND dtinv.datevalue >= '2014-01-01'
AND f_jsol.dd_invoicenumber > 0 AND itemmaster.BASE_ITEM LIKE '%-%'
AND sclast.User_Defined_Code_KY in ('600','620');


/* Assume 1-1 mapping between SKU-10 and SKU-12. There are 2 exceptions according to tmp_sku10_12_mappingrank which are removed */
UPDATE tmp_actualsales a
SET dd_invoicedate_char = to_char(dd_invoicedate_date,'DD Mon YYYY'),
dd_invoicedate_ww = to_char(dd_invoicedate_date,'WW'),
dd_invoicedate_yyyyww = to_char(dd_invoicedate_date,'YYYYWW'),
a.dd_sku12 = t.sku12
FROM tmp_sku10_12_mappingrank t,tmp_actualsales a
WHERE a.dd_sku10 = t.sku10
AND t.rank1 = 1
AND t.sku10 not in ('19200-89675','51700-97517'); /* Only these 2 have more than 1 active SKUs */

UPDATE stage_fosalesforecastweekly_regular
set dd_reportingdate = '28 JUL 2018';
UPDATE stage_fosalesforecastweekly_rfh
set dd_reportingdate = '28 JUL 2018';

/* Delete from RFH those methods that are not present in reg */
DELETE FROM stage_fosalesforecastweekly_rfh rfh
WHERE NOT EXISTS (select 1 from 
(SELECT DISTINCT dd_partnumber,dd_plant,dd_forecasttype FROM stage_fosalesforecastweekly_regular) r 
WHERE rfh.dd_partnumber = r.dd_partnumber  
AND rfh.dd_plant = r.dd_plant
AND r.dd_forecasttype = rfh.dd_forecasttype);



ALTER TABLE stage_fosalesforecastweekly_regular
ADD COLUMN dd_zerosales_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_rfh
ADD COLUMN dd_zerosales_changedto_one VARCHAR(10) DEFAULT 'N';

ALTER TABLE stage_fosalesforecastweekly_regular
ADD COLUMN dd_zerofcst_changedto_one VARCHAR(10) DEFAULT 'N';
ALTER TABLE stage_fosalesforecastweekly_rfh
ADD COLUMN dd_zerofcst_changedto_one VARCHAR(10) DEFAULT 'N';



UPDATE stage_fosalesforecastweekly_regular
SET ct_salesquantity = 1,
dd_zerosales_changedto_one = 'Y'
WHERE ct_salesquantity = 0;

UPDATE stage_fosalesforecastweekly_rfh
SET ct_salesquantity = 1,
dd_zerosales_changedto_one = 'Y'
WHERE ct_salesquantity = 0;


UPDATE stage_fosalesforecastweekly_regular
SET ct_forecastquantity = 1,
dd_zerofcst_changedto_one = 'Y'
WHERE ct_forecastquantity = 0;

UPDATE stage_fosalesforecastweekly_rfh
SET ct_forecastquantity = 1,
dd_zerofcst_changedto_one = 'Y'
WHERE ct_forecastquantity = 0;


/* Temporarily remove holt winters due to null forecast qty */

/*
DELETE FROM stage_fosalesforecastweekly_regular
WHERE dd_forecasttype like '%Box%';
DELETE FROM stage_fosalesforecastweekly_rfh
WHERE dd_forecasttype like '%Box%';
*/



/* Update rank in Reg using Weighed MAD */
DROP TABLE IF EXISTS tmp_mad_calculation_testperiod_regular;
CREATE TABLE tmp_mad_calculation_testperiod_regular
AS
SELECT DD_REPORTINGDATE,dd_partnumber,dd_plant,dd_forecasttype,
SUM((ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity)/SUM(ct_salesquantity) ct_bias,
SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity))/SUM(ct_salesquantity) ct_mad,
rank() over(partition by DD_REPORTINGDATE,dd_partnumber,dd_plant
ORDER BY SUM((ABS(ct_forecastquantity-ct_salesquantity)*ct_salesquantity/ct_forecastquantity))/SUM(ct_salesquantity), dd_forecasttype) dd_rank_bymadweighed
FROM stage_fosalesforecastweekly_regular s
WHERE dd_forecastsample = 'Test' 
GROUP BY DD_REPORTINGDATE,dd_partnumber,dd_plant,dd_forecasttype;

/*
select *
from tmp_mad_calculation_testperiod_regular
order by dd_partnumber,dd_plant,dd_rank_bymadweighed
limit 200;
*/

/* Update MAD, Rank and Bias for all rows in regular, using the calculation done in tmp_mad_calculation_testperiod_regular */
UPDATE stage_fosalesforecastweekly_regular f
SET f.dd_forecastrank = t.dd_rank_bymadweighed,
f.ct_mad = t.ct_mad,
f.ct_bias_error = t.ct_bias
FROM stage_fosalesforecastweekly_regular f,tmp_mad_calculation_testperiod_regular t
WHERE f.dd_partnumber = t.dd_partnumber AND f.dd_plant = t.dd_plant
AND f.dd_forecasttype = t.dd_forecasttype;

UPDATE stage_fosalesforecastweekly_regular
SET ct_forecastquantity_regular = CT_FORECASTQUANTITY,
ct_highpi_regular = ct_highpi,
ct_lowpi_regular = ct_lowpi,
ct_mad_holdout_basedonregularfcst = ct_mad,
ct_bias_holdout_basedonregularfcst = ct_bias_error;



/* Combine the forecasts */

DROP TABLE IF EXISTS stage_fosalesforecastweekly_combined;
CREATE TABLE stage_fosalesforecastweekly_combined
AS
SELECT *
FROM stage_fosalesforecastweekly_regular;

UPDATE stage_fosalesforecastweekly_combined comb
SET comb.dd_bestapproach_by_mad_holdout = 'Regular';


UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_forecastquantity_regular = r.ct_forecastquantity,
s.ct_highpi_regular = r.ct_highpi,
s.ct_lowpi_regular = r.ct_lowpi,
s.dd_forecastrank_regular = r.dd_forecastrank,
s.ct_mad_holdout_basedonregularfcst = r.ct_mad,
s.ct_bias_holdout_basedonregularfcst = r.ct_bias_error
FROM stage_fosalesforecastweekly_combined s, stage_fosalesforecastweekly_regular r
WHERE s.dd_partnumber = r.dd_partnumber AND s.dd_plant = r.dd_plant
AND r.dd_forecastdate = s.dd_forecastdate
AND r.dd_forecasttype = s.dd_forecasttype;

UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_forecastquantity_rfh = r.ct_forecastquantity,
s.ct_highpi_rfh = r.ct_highpi,
s.ct_lowpi_rfh = r.ct_lowpi,
s.ct_mad_horizon_basedonfullhistforecast = r.ct_mad_horizon_basedonfullhistforecast,
s.ct_bias_horizon_basedonfullhistforecast = r.ct_bias_horizon_basedonfullhistforecast
FROM stage_fosalesforecastweekly_combined s, stage_fosalesforecastweekly_rfh r
WHERE s.dd_partnumber = r.dd_partnumber AND s.dd_plant = r.dd_plant
AND r.dd_forecastdate = s.dd_forecastdate
AND r.dd_forecasttype = s.dd_forecasttype;


UPDATE stage_fosalesforecastweekly_combined s
SET ct_bestforecastquantiy = ct_forecastquantity_rfh,
ct_forecastquantity = ct_forecastquantity_rfh,
ct_highpi = ct_highpi_rfh,
ct_lowpi = ct_lowpi_rfh,
ct_bestmadholdout = ct_mad_holdout_basedonregularfcst,
ct_bestmadhorizon = ct_mad_horizon_basedonfullhistforecast,
dd_forecastrank_bestapproach = dd_forecastrank_regular
WHERE dd_bestapproach_by_mad_holdout = 'Regular';


/* Update horizon sales */
UPDATE stage_fosalesforecastweekly_combined s
SET s.ct_salesquantity = rfh.ct_salesquantity
FROM stage_fosalesforecastweekly_combined s,stage_fosalesforecastweekly_rfh rfh
WHERE s.dd_partnumber = rfh.dd_partnumber AND s.dd_plant = rfh.dd_plant
AND rfh.dd_forecastdate = s.dd_forecastdate
AND rfh.dd_forecasttype = s.dd_forecasttype
AND s.ct_salesquantity IS NULL
AND s.dd_forecastsample in ('Horizon','Validation');


UPDATE stage_fosalesforecastweekly_combined f
SET dd_sku10 = substr(dd_partnumber,1,11);

UPDATE stage_fosalesforecastweekly_combined f
SET dd_businessunit = dd_plant;

UPDATE stage_fosalesforecastweekly_combined s
SET s.dd_active_sku12_mappedtosku10 = t.sku12
FROM stage_fosalesforecastweekly_combined s, tmp_sku10_12_mappingrank t
WHERE s.dd_sku10 = t.sku10
AND t.rank1 = 1;

UPDATE stage_fosalesforecastweekly_combined
SET dd_businessunit = 'US';

UPDATE stage_fosalesforecastweekly_combined
SET dd_customercode = 'ALL CHANNELS';



DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(upper(dd_reportingdate),'DD MON YYYY') dd_reportingdate,
dd_reportingdate dd_reportingdate_char
from stage_fosalesforecastweekly_combined;


/* Create a de-normalized table containing data from Sales Order */

drop table if exists tmp_saleshistory_grain_reqmonths;
drop table if exists tmp_saleshistory_grain_reqmonths_2;

drop table if exists fact_fosalesforecastweekly_temp;
create table fact_fosalesforecastweekly_temp as
select * from tmp_fact_fosalesforecastweekly_backpopulate WHERE 1=2;


insert into fact_fosalesforecastweekly_temp
(
fact_fosalesforecastweeklyid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mad,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
--dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_active_sku12_mappedtosku10,
DD_BESTAPPROACH_BY_MAD_HOLDOUT,
DD_FORECAST_QUANTITY,
DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_business_unit,dd_customerno

)
select  (select ifnull(max(fact_fosalesforecastweeklyid), 0) from tmp_fact_fosalesforecastweekly_backpopulate m)
+ row_number() over(order by dd_partnumber,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecastid,
1 dim_partid,
1 dim_plantid,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
upper(sf.dd_reportingdate),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mad * 100,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
--case when sf.dd_forecastdate is null then '190000'
--else sf.dd_forecastdate END 
--dd_forecastdatevalue,
ct_bias_error * 100,
ct_bias_error_rank,
sf.dd_partnumber dd_partnumber,
dd_active_sku12_mappedtosku10,
sf.DD_BESTAPPROACH_BY_MAD_HOLDOUT,
sf.DD_FORECAST_QUANTITY,
sf.DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_businessunit,dd_customercode
from stage_fosalesforecastweekly_combined sf;



UPDATE fact_fosalesforecastweekly_temp f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
fact_fosalesforecastweekly_temp f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE fact_fosalesforecastweekly_temp f
SET f.dim_dateidforecast = d.dim_dateid
from (select Calendarweekyr,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by Calendarweekyr)d,
fact_fosalesforecastweekly_temp f
WHERE to_char(f.dd_forecastdate) = to_char(concat(left(d.Calendarweekyr,4),right(d.Calendarweekyr,2))) 
AND f.dim_dateidforecast <> d.dim_dateid;

DELETE FROM tmp_fact_fosalesforecastweekly_backpopulate f
WHERE EXISTS 
(SELECT 1 FROM tmp_maxrptdate t
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = t.dd_reportingdate );

insert into tmp_fact_fosalesforecastweekly_backpopulate
(
FACT_FOSALESFORECASTWEEKLYID,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mad,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plant,
DD_Forecast_approach,
DD_FORECAST_QUANTITY,
DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_business_unit,dd_customerno,dd_active_sku12_mappedtosku10,
DD_BESTAPPROACH_BY_MAD_HOLDOUT,
dim_customerparentgroupaddresssoldtoid
)
select
FACT_FOSALESFORECASTWEEKLYID,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mad,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plant,
DD_Forecast_approach,
DD_FORECAST_QUANTITY,
DD_FORECASTGRAIN,
ct_forecastquantity_regular,
ct_forecastquantity_rfh,
dd_sku10,dd_business_unit,dd_customerno,dd_active_sku12_mappedtosku10,
DD_BESTAPPROACH_BY_MAD_HOLDOUT,
dim_customerparentgroupaddresssoldtoid
from fact_fosalesforecastweekly_temp;

UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET DIM_JDE_2NDITEMNUMBERID = d.DIM_JDE_ITEM_MASTERID
FROM tmp_fact_fosalesforecastweekly_backpopulate f,dim_jde_item_master d
WHERE f.dd_active_sku12_mappedtosku10 = d.ITEM_NUMBER_2
AND (f.DIM_JDE_2NDITEMNUMBERID = 1 or f.DIM_JDE_2NDITEMNUMBERID is null);

UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET f.dd_segment = t.segment,
f.dd_brand = t.brand,
f.dd_spc = t.spc,
f.dd_bsgbrandsegment = t.bsgbrandsegment
FROM tmp_fact_fosalesforecastweekly_backpopulate f,tmp_brandsegspcskumapping1 t
WHERE f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 = t.itemcode;

UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET f.dd_sku12 = f.DD_ACTIVE_SKU12_MAPPEDTOSKU10
WHERE (f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 is not null and f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 <> 'Not Set')
AND (f.dd_sku12 IS NULL OR f.dd_sku12 = 'Not Set');


/* Update customer fcst */
/*
UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET f.CT_FORECASTCUSTOMER = t.ct_forecastquantity_rb
FROM tmp_fact_fosalesforecastweekly_backpopulate f,tmp_custfcst t
WHERE f.dd_sku10 = t.dd_sku10
AND f.dd_business_unit = t.dd_plant
AND f.dd_forecastdate = t.dd_yyyyww;
*/

UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET DD_FORECASTGRAIN = 'SKU10'
FROM tmp_fact_fosalesforecastweekly_backpopulate f,tmp_maxrptdate t
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = t.dd_reportingdate;


UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET dd_madrank = dd_forecastrank
FROM tmp_fact_fosalesforecastweekly_backpopulate f,tmp_maxrptdate t
WHERE TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = t.dd_reportingdate;

/* Thas sku10 has some problem - 0 or null ranks */
DELETE FROM tmp_fact_fosalesforecastweekly_backpopulate
WHERE dd_sku10 = '62338-97279'
AND (dd_forecastrank is null or dd_forecastrank = 0);

DELETE FROM tmp_fact_fosalesforecastweekly_backpopulate
WHERE (dd_forecastrank is null or dd_forecastrank = 0);


DROP TABLE IF EXISTS tmp_week_to_startdatemapping_1;
CREATE TABLE tmp_week_to_startdatemapping_1
AS
SELECT t.YYYYWW, t.START_DATE,row_number() over(order by to_date(t.START_DATE)) dd_daterank
FROM dim_week_to_startdatemapping t;

DROP TABLE IF EXISTS tmp_week_to_startdatemapping_2;
CREATE TABLE tmp_week_to_startdatemapping_2
AS
SELECT t1.*,to_date(t1.START_DATE) START_DATE_DATEFMT,
to_date(t2.START_DATE) - interval '1' day END_DATE_DATEFMT
FROM tmp_week_to_startdatemapping_1 t1, tmp_week_to_startdatemapping_1 t2
WHERE t2.dd_daterank = t1.dd_daterank + 1;

/*
select *
from tmp_week_to_startdatemapping_2
where yyyyww = 201824
order by dd_daterank limit 10;



select *
from tmp_actualsales limit 10;
*/


UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET f.dd_startdate = to_date(t.start_date,'YYYY-MM-DD')
FROM tmp_fact_fosalesforecastweekly_backpopulate f,tmp_week_to_startdatemapping t,tmp_maxrptdate mrpt
WHERE f.DD_FORECASTDATE = t.YYYYWW
AND TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate;

/* Populate forecast data for grains that were missed */
/* Get previous 13-week avg */
DROP TABLE IF EXISTS tmp_existinggrains_fcst;
CREATE TABLE tmp_existinggrains_fcst
AS
SELECT DISTINCT f.dd_sku10,f.DD_ACTIVE_SKU12_MAPPEDTOSKU10,f.dd_business_unit,
ifnull(f.dd_demandcustomer,'Not Set') dd_demandcustomer
FROM tmp_fact_fosalesforecastweekly_backpopulate f,tmp_maxrptdate mrpt
WHERE dd_forecastrank = 1 AND dd_forecastdate = 201801
and TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate;

DROP TABLE IF EXISTS tmp_13weekavg1;
CREATE TABLE tmp_13weekavg1
AS
SELECT dd_sku10,dd_sku12,'Not Set' dd_bu,'Not Set' dd_demandcustomer,
'13-week avg' dd_forecasttype,
1 dd_forecastrank,
to_char((mrpt.dd_reportingdate),'DD MON YYYY') dd_reportingdate,
--t.dd_forecastdate,
sum(ct_salesquantity) ct_forecastquantity_13weekavg
FROM tmp_actualsales t,tmp_maxrptdate mrpt
--,(SELECT DISTINCT dd_forecastdate FROM stage_fosalesforecastweekly_regular) t
WHERE dd_invoicedate_yyyyww >= '201818'
AND dd_invoicedate_yyyyww <= '201830'
AND NOT EXISTS
(SELECT 1 FROM tmp_existinggrains_fcst f
WHERE f.dd_sku10 = t.dd_sku10 and f.DD_ACTIVE_SKU12_MAPPEDTOSKU10 = t.dd_sku12)
GROUP BY dd_sku10,dd_sku12,to_char((mrpt.dd_reportingdate),'DD MON YYYY');
--,t.dd_forecastdate;



UPDATE tmp_13weekavg1
SET ct_forecastquantity_13weekavg = ct_forecastquantity_13weekavg/13;

DROP TABLE IF EXISTS tmp_13weekavg;
CREATE TABLE tmp_13weekavg
AS
SELECT t.*,t1.dd_forecastdate
FROM  tmp_13weekavg1 t,(SELECT DISTINCT dd_forecastdate FROM stage_fosalesforecastweekly_regular) t1;


INSERT INTO tmp_fact_fosalesforecastweekly_backpopulate
(fact_fosalesforecastweeklyid,
DD_SKU10,DD_ACTIVE_SKU12_MAPPEDTOSKU10,
DD_BUSINESS_UNIT,DD_DEMANDCUSTOMER,
dd_forecasttype,dd_forecastrank,
dd_reportingdate,dd_forecastdate,
ct_forecastquantity)
SELECT
(SELECT MAX(ifnull(fact_fosalesforecastweeklyid,0)) FROM tmp_fact_fosalesforecastweekly_backpopulate)
+ row_number() over(order by ''),
dd_sku10,dd_sku12,
dd_bu,dd_demandcustomer,
dd_forecasttype,dd_forecastrank,
dd_reportingdate,dd_forecastdate,
ct_forecastquantity_13weekavg
FROM tmp_13weekavg;


UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET f.dd_startdate = to_date(t.start_date,'YYYY-MM-DD')
FROM tmp_fact_fosalesforecastweekly_backpopulate f,tmp_week_to_startdatemapping t,tmp_maxrptdate mrpt
WHERE f.DD_FORECASTDATE = t.YYYYWW
AND TO_DATE(upper(f.dd_reportingdate),'DD MON YYYY') = mrpt.dd_reportingdate;

/*
select distinct dd_reportingdate,dd_forecasttype from tmp_fact_fosalesforecastweekly_backpopulate f
order by to_date(dd_reportingdate,'DD MON YYYY');
*/

update tmp_fact_fosalesforecastweekly_backpopulate
SET DD_TYPE = '6';

update tmp_fact_fosalesforecastweekly_backpopulate
SET DD_DUR = '7D';

update tmp_fact_fosalesforecastweekly_backpopulate
SET DD_MODEL = 'IMPORT';

UPDATE tmp_fact_fosalesforecastweekly_backpopulate
SET dd_latestreporting = 'N';

UPDATE tmp_fact_fosalesforecastweekly_backpopulate
SET dd_latestreporting = 'Y'
WHERE to_date(dd_reportingdate,'DD MON YYYY') = (SELECT dd_reportingdate FROM tmp_maxrptdate);


DROP TABLE IF EXISTS tmp_next13weeksflag;
CREATE TABLE tmp_next13weeksflag
AS
SELECT dd_reportingdate,dd_forecastdate,rank() over(partition by dd_reportingdate order by dd_forecastdate) dd_weekrank
FROM (SELECT distinct dd_reportingdate,dd_forecastdate
FROM tmp_fact_fosalesforecastweekly_backpopulate
WHERE dd_latestreporting = 'Y'
AND dd_forecastsample = 'Horizon');


UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET f.dd_flag_weeknumberfromlastdate = t.dd_weekrank
FROM tmp_fact_fosalesforecastweekly_backpopulate  f, tmp_next13weeksflag t
WHERE f.dd_forecastdate = t.dd_forecastdate
AND f.dd_reportingdate = t.dd_reportingdate;




/* Update actuals for SKU-level forecast */
UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET f.ct_salesquantity = s.ct_salesquantity_weekly
FROM tmp_fact_fosalesforecastweekly_backpopulate f,
(SELECT dd_sku10,t.yyyyww, sum(ct_salesquantity) ct_salesquantity_weekly
FROM tmp_actualsales s, tmp_week_to_startdatemapping_2 t
WHERE s.dd_invoicedate_date >= t.start_date_datefmt
AND s.dd_invoicedate_date <= t.end_date_datefmt
GROUP BY  dd_sku10,t.yyyyww) s
WHERE f.dd_sku10 = s.dd_sku10 --AND f.dd_business_unit = 'Not Set' AND f.dd_customerno = 'Not Set'
AND DD_FORECASTGRAIN = 'SKU10'
AND f.dd_forecastdate = s.yyyyww
AND dd_forecastdate >= to_number(to_char(current_date,'YYYYWW')) - 1;   /* Update actual sales from previous week */
--AND dd_latestreporting = 'Y'
--AND dd_forecastsample IN ('Horizon','Test')
--AND (f.ct_salesquantity IS NULL OR f.ct_salesquantity = 0);
--AND dd_reportingdate = '28 JUL 2018';


/*
SELECT *
FROM tmp_actualsales
WHERE dd_sku10 = '19200-80309'
AND dd_invoicedate_date >= '2018-06-10';

SELECT dd_sku10,t.yyyyww, sum(ct_salesquantity) ct_salesquantity_weekly
FROM tmp_actualsales s, tmp_week_to_startdatemapping_2 t
WHERE s.dd_invoicedate_date >= t.start_date_datefmt
AND s.dd_invoicedate_date <= t.end_date_datefmt
AND s.dd_sku10 = '19200-80309'
AND s.dd_invoicedate_date >= '2018-06-10'
GROUP BY  dd_sku10,t.yyyyww

SELECT *
FROM tmp_fact_fosalesforecastweekly_backpopulate
WHERE dd_reportingdate = '10 JUN 2018'
AND dd_sku10 = '19200-80309'
AND dd_forecastdate = 201825;

*/

/*
select *
from tmp_fact_fosalesforecastweekly_backpopulate
where dd_sku10 = '62338-83768'
AND dd_latestreporting = 'Y'
AND dd_forecastdate = '201824';
*/

UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET DD_FORECASTGRAIN = 'SKU10'
WHERE dd_reportingdate = '28 JUL 2018';

UPDATE tmp_fact_fosalesforecastweekly_backpopulate f
SET dd_customerno = 'ALL CHANNELS',
dd_business_unit = 'US',
DD_DEMANDCUSTOMER = 'ALL CHANNELS'
WHERE DD_FORECASTGRAIN = 'SKU10';


UPDATE tmp_fact_fosalesforecastweekly_backpopulate
SET dd_startdate = '2018-12-31'
WHERE dd_startdate IS NULL 
AND dd_forecastdate = 201853;



DROP TABLE IF EXISTS tmp_skusabsentfromfact;
CREATE TABLE tmp_skusabsentfromfact
AS
SELECT DISTINCT dd_sku10
FROM fact_fosalesforecastweekly
WHERE dd_reportingdate = '28 JUL 2018';

UPDATE tmp_fact_fosalesforecastweekly_backpopulate
SET AMT_UNITPRICE = 0
WHERE AMT_UNITPRICE is null;

INSERT INTO fact_fosalesforecastweekly
SELECT t.*
FROM tmp_fact_fosalesforecastweekly_backpopulate t
WHERE NOT EXISTS 
(SELECT 1 FROM tmp_skusabsentfromfact t1 where t.dd_sku10 = t1.dd_sku10);

/*
SELECT to_date(dd_reportingdate,'DD MON YYYY') rptdate,
dd_brand,
count(distinct dd_sku10) skucount
FROM fact_fosalesforecastweekly
GROUP BY to_date(dd_reportingdate,'DD MON YYYY'),dd_brand
ORDER BY to_date(dd_reportingdate,'DD MON YYYY'),dd_brand;
*/
