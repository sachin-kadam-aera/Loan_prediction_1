#!/opt/anaconda2/bin/pythoni
# -*- coding: utf-8 -*-
"""
Created by Anshuman Lall/ Shravan Shetty
Reads sales data from text file and generate forecast in a text file
"""


import os
import forecast_config
import pandas as pd
import sys
from time import time, localtime, strftime
import datetime
import calendar
from read_data import read_data
from generate_forecast import get_forecast
from generate_forecast_mult import get_forecast_mult
from generate_forecast_mult_v2 import get_forecast_mult_v2
from generate_forecast_mult_box_cox import get_forecast_mult_box_cox
from generate_forecast_hw import get_forecast_hw
from generate_forecast_hw_mult import get_forecast_hw_mult
from generate_forecast_arima import generate_auto_arima
from generate_auto_regressive_arima import get_forecast_auto_regressive
from generate_forecast_processed_arima import generate_processed_auto_arima
from forecast_rankings import forecast_rankings
from generate_forecast_ETS import generate_auto_ets
from generate_forecast_croston import generate_auto_croston
from generate_forecast_gradientBoosting import get_forecast_gradientBoosting
from generate_forecast_randomforest import get_forecast_randomForest
from generate_auto_regressive_arma_MAPE import get_forecast_ARMA_MAPE
from generate_auto_regressive_arima_ma import get_forecast_auto_regressive_ma
from generate_forecast_nnet_AR import generate_nnet_AR
from generate_forecast_LassoCV import get_forecast_LassoCV
from generate_forecast_RidgeCV import get_forecast_RidgeCV
from generate_forecast_LarsLassoCV import get_forecast_LarsLassoCV
from generate_forecast_RidgeKernel import get_forecast_RidgeKernel
import numpy as np
from QueueProcessor import MultiProcessQueue
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from collections import Counter
###############.................................Fractal scripts..................................##############
from generate_forecast_arima_fractal import generate_auto_arima_fractal
from generate_forecast_ETS_fractal import generate_auto_ets_fractal
from generate_forecast_USTLETS_Fractal import generate_USTLETS
from generate_forecast_STLARIMA_fractal import generate_STLARIMA_fractal
from generate_forecast_MAPA_fractal import generate_MAPA_fractal
from generate_forecast_nnet_fractal import generate_nnet_fractal
from generate_forecast_bsts_fractal import generate_bsts_fractal
from generate_forecast_BI_BSTS_Fractal import generate_BI_BSTS
from generate_forecast_BI_ARIMAX_Fractal import generate_BI_Arimax
from generate_forecast_BI_XGBOOST import generate_BI_xgboost
"""
from generate_forecast_arima_fractal import generate_auto_arima_fractal
from generate_forecast_ETS_fractal import generate_auto_ets_fractal
from generate_forecast_USTLETS_Fractal import generate_USTLETS
from generate_forecast_STLARIMA_fractal import generate_STLARIMA_fractal
from generate_forecast_MAPA_fractal import generate_MAPA_fractal
from generate_forecast_nnet_fractal import generate_nnet_fractal
from generate_forecast_bsts_fractal import generate_bsts_fractal
# from generate_forecast_XGBoost import get_forecast_XGBoost
"""
def create_dir_not_exist(directory_path):
    """
    Checks if a directory_path exists, if not creates it
    :param directory_path:
    :return: None
    """
    import os
    if not os.path.isdir(directory_path):
        print "Creating new directory at location {0}".format(os.curdir + "/" + directory_path)
        os.mkdir(directory_path)


def arg_parameters(argv, def_argk):
    """
    Updates command line argument to the forecast configurations. Need forecast.ini keys as method parameter and system arguments.
    argv: Command line argument supplied by user
    def_argk : Keys related to Forecast.ini
    return Updated forecast_configuration with system arguments
    """
    import getopt
    cmd = map(lambda x: x + "=", def_argk)
    default_cmd = " ".join(["python main.py"] +
                           map(lambda x: "--{0} <{0}>".format(x), def_argk))
    try:
        opts, args = getopt.getopt(argv, "h", cmd)
    except getopt.GetoptError:
        print default_cmd
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            sys.exit()
        elif (opt.strip('-') + "=") in cmd:
            forecast_config.setConfig(opt.strip('-'), arg.strip())
    return forecast_config.getConfig()


t0 = time()
today = datetime.date.today()
# Update forecast configuration parameter
conf_run_script = arg_parameters(
    sys.argv[1:], forecast_config.getConfig('RunScript').keys())
print "Forecast Configurations are: ", ' '.join(["{0}={1}".format(k, v) for k, v in conf_run_script.items()])

run_type = conf_run_script['run_type']
company = conf_run_script['company']
ReportingYYYYMMDD = (int(today.year) * 100 +
                     int(today.month)) * 100 + int(today.day)

print "Company is {0} and Run Type is {1}".format(company, run_type)

create_dir_not_exist('result')
create_dir_not_exist('result/' + company)
time_frequency = forecast_config.getConfig('RunScript')['time_frequency']


last_date_2 = int(conf_run_script['last_date_fh'])  # last date is not inclusive
# holdout date is not inclusive
holdout_date_2 = int(conf_run_script['holdout_date_fh'])
input_file_oh = 'data/' + company + "/" + conf_run_script['input_file_oh']


# Format output file so that it can take any file
output_file = conf_run_script['output_file']
output_file = list(output_file.rpartition('.'))
# if user didn't give fileformat,  last index will contain the filename.
if output_file[1] != '.':
    output_file[0] = output_file[2]

input_file = 'data/' + company + "/" + conf_run_script['input_file']


output_timestamp = strftime('%Y_%m_%d__%H_%M', localtime())
output_file = "result/{1}/{0}_{1}_{2}.csv".format(
    output_file[0], company, output_timestamp)
tmp_output_file = "result/{0}/Intermediate_result_{0}_{1}.csv".format(
    company, output_timestamp)
create_dir_not_exist('logs')

log_file = 'logs/log' + output_timestamp + '.txt'
logfile = open(log_file, 'w+')
logfile.write('The program started at %s ' % datetime.datetime.now())

if run_type == '0':
    logfile.write('in pre-compute mode\n')
elif run_type == '1':
    logfile.write('in on-demand mode\n')
    
logfile.write('Reading sales records from %s \n' % input_file)
# Dates are not inclusive
last_date_1 = int(conf_run_script['last_date'])  # last date is not inclusive
# holdout date is not inclusive
holdout_date_1 = int(conf_run_script['holdout_date'])
logfile.write('Last Date\t\t %d \n' % last_date_1)
logfile.write('Holdout Date\t %d \n' % holdout_date_1)

horizon_in_months = int(conf_run_script["horizon_period"])


# IMPORT HISTORICAL SALES DATA
# Expected fields: ['UIN','Comop','CompanyCode','YYYYMM','Sales']
data = read_data(input_file)  # Month field gets added here
data_oh = read_data(input_file_oh)  # Month field gets added here


# Starting generate Forecasts
"""
forecast_algo = [generate_auto_arima, generate_processed_auto_arima,
                 generate_auto_ets, generate_auto_croston,
                  generate_nnet_AR,
                 get_forecast_mult, get_forecast,
                  get_forecast_hw, get_forecast_hw_mult,
                 get_forecast_mult_v2, get_forecast_mult_box_cox, get_forecast_auto_regressive,
                 get_forecast_auto_regressive_ma, get_forecast_RidgeCV, get_forecast_randomForest,
                 get_forecast_gradientBoosting,
                 get_forecast_RidgeKernel,
                 get_forecast_LassoCV, get_forecast_LarsLassoCV ,generate_bsts_fractal,generate_nnet_AR,generate_nnet_fractal,generate_MAPA_fractal,generate_auto_arima,generate_auto_arima_fractal,generate_auto_ets_fractal,generate_auto_ets,generate_USTLETS,generate_STLARIMA_fractal]
"""
"""
forecast_algo = [generate_auto_arima, generate_processed_auto_arima,
                 generate_auto_ets, generate_auto_croston,
                  generate_nnet_AR,
                 get_forecast_mult, get_forecast,
                 get_forecast_mult_v2, get_forecast_mult_box_cox, get_forecast_auto_regressive,
                 get_forecast_auto_regressive_ma, get_forecast_RidgeCV, get_forecast_randomForest,
                 get_forecast_gradientBoosting,
                 get_forecast_RidgeKernel,
                 get_forecast_LassoCV, get_forecast_LarsLassoCV]
"""
forecast_algo = [get_forecast_randomForest]#[generate_BI_Arimax]#,generate_BI_xgboost]
def my_task(args):
    data1 = args[0]
    last_date = args[1]
    holdout_date = args[2]
    data1 = data1[data1.YYYYMM < last_date]  # As Last date is not inclusive
    data1 = data1.sort_values(['YYYYMM'],ascending=[1])
    data1 = data1.drop('grain', axis=1).reset_index(
        drop=True)  # This is very important step
    # Write to the queue
    store = pd.DataFrame([])
    for func in forecast_algo:
        store = store.append(func(
            *(data1, data1.UIN[0], data1.Comop[0], last_date, holdout_date, horizon_in_months)))
    return store


def forecast_run(last_date,holdout_date,data,tag):
    t1 = time()
    print tag
    CC_map = data[['UIN', 'CompanyCode']].drop_duplicates()
    CC_map.columns = ['dim_partid', 'dd_companycode']
    data = data.drop('CompanyCode', 1)
    
    logfile.write(
        '\nModule 1: Read data completed successfully in %7.2f seconds \n' % (time() - t1))
    
    data["grain"] = data['Comop'].astype(str) + "--" + data['UIN'].astype(str)
    total_grain = data.grain.unique().size
    
    logfile.write('Total Grains \t\t%d \n' % (total_grain))
    logfile.write('\nModule 2: Generate Forecasts starting..\n')
      
    
    _start = time()
    mpq = MultiProcessQueue(int(conf_run_script['num_process']))
    data_mpq = 0
    for grain in data.grain.unique():
        data1 = data[data.grain == grain]
        if len(data1[data1.YYYYMM < holdout_date]) >= int(conf_run_script['min_training_period']):
            data_mpq += 1
            list_enque =  [data1,last_date,holdout_date]
	    mpq.enqueue(my_task, list_enque)
    
    store = []
    if data_mpq > 0:
        # Running Multiprocessing Queues
        print "Forecasting {0} products".format(data_mpq)
        mpq.execute()
        for i in range(data_mpq):
            store += [mpq.dequeue()]
    else:
        import sys
        print "Nothing to forecast"
        sys.exit(1)
    # Tell child processes to stop
    store = pd.concat(store)
    print "Sending  numbers to Queue() took %s seconds" % ((time() - _start))
    
    if store.empty:
        print "There is an insufficient data for running the forecast. Please add  more data or change min_training_period in forecast.ini"
        sys.exit(-1)
    store = store.reset_index()
    store = store.drop('index', 1)
    
    store.to_csv(tmp_output_file, index=False)
    # Completed: Run forecasting
    
    logfile.write('Total Part/Plant combination explored %d \n' % i)
    # logfile.write('Total Part/Plant combination forecasted %d \n' % (len(store[['UIN', 'Comop']].drop_duplicates())))
    # logfile.write('Total Parts forecasted %d \n' % (len(store[['UIN']].drop_duplicates())))
    logfile.write(
        'Module 2: Generate Forecasts complete in %7.2f seconds\n' % (time() - t1))
    logfile.write('Total Plants forecasted %d \n' %
                  (len(store[['Comop']].drop_duplicates())))
    logfile.write(
        'Module 2: Generate Forecasts complete in %7.2f seconds\n' % (time() - t1))
    
    logfile.write('\nModule 3: Generate Forecast Rankings..\n')
    t1 = time()
    # Forecast Ranking
    store = forecast_rankings(store)
    
    logfile.write('Module 3: Forecast ranking completed\n')
    
    # Add additional information ie Year, Forecast Sample
    store['Year'] = store.YYYYMM.apply(lambda x: int(x / 100))
    # store['Forecast_Sample'] = store.YYYYMM.apply(lambda x: 'Test' if x > holdout_date else 'Train')
    store['Forecast_Sample'] = store.YYYYMM.apply(
        lambda x: 'Horizon' if x >= last_date else 'Test' if x >= holdout_date else 'Train')
    
    # Rename Columns for Output
    col_mapping = {'Comop': 'dd_level2', 'Forecast': 'ct_forecastquantity', 'Forecast_Type': 'dd_forecasttype',
                   'High90PI': 'ct_high90pi', 'High95PI': 'ct_high95pi', 'Low90PI': 'ct_low90pi', 'Low95PI': 'ct_low95pi',
                   'MAPE': 'ct_mape', 'Month': 'dd_month', 'Sales': 'ct_salesquantity', 'UIN': 'dim_partid',
                   'YYYYMM': 'dd_yearmonth',
                   'Forecast_Rank': 'dd_forecastrank', 'Year': 'dd_year', 'Forecast_Sample': 'dd_forecastsample',
                   'Bias_Error': 'dd_bias_error', 'Bias_Error_Rank': 'dd_bias_error_rank'}
    # When extra variables are used in input data, but not need to be used in
    # output
    store = store[col_mapping.keys()]
    store.columns = [col_mapping[col] for col in store.columns]
    
    # Add Last day of the month-year to the forecastdate using calendar library
    try:
        store['dd_forecastdate'] = store.dd_yearmonth.apply(     
            lambda x: x * 100 + calendar.monthrange(x / 100, x % 100)[1])    
    except:
        store['dd_forecastdate'] = store['dd_yearmonth']
        
    if time_frequency=='Weekly':
            store['dd_forecastdate'] = store.dd_yearmonth
            # Format the Dates in a proper format
            store['dd_reportingdate'] = datetime.datetime.strptime(str(ReportingYYYYMMDD), '%Y%m%d').strftime('%d %b %Y')
            store['dd_holdoutdate'] = str(holdout_date)
            store['dd_lastdate'] = str(last_date)
    
    elif time_frequency=='Monthly':
            store['dd_forecastdate'] = store.dd_yearmonth.apply(lambda x: x * 100 + calendar.monthrange(x / 100, x % 100)[1])
            # Format the Dates in a proper format
            store['dd_reportingdate'] = datetime.datetime.strptime(str(ReportingYYYYMMDD), '%Y%m%d').strftime('%d %b %Y')
            store['dd_holdoutdate'] = datetime.datetime.strptime(str(holdout_date * 100 + 1), '%Y%m%d').strftime('%d %b %Y')
            store['dd_lastdate'] = datetime.datetime.strptime(str(last_date * 100 + 1), '%Y%m%d').strftime('%d %b %Y')
    
    store = store.drop('dd_yearmonth', 1)
    
    
    if run_type == '1':
        store['dd_forecastmode'] = 'on-demand'
    elif run_type == '0':
        store['dd_forecastmode'] = 'pre-computed'
    
    store = pd.merge(store, CC_map, how='left', on=['dim_partid'])
    # Intermediate result
    store.to_csv(tmp_output_file, index=False)
    
    # Reorder Columns for output and Finalize the Confidence interval
    prediction_interval = '90'
    # filters data according to the required prediction intervals
    store = store.iloc[:,
                       ~store.columns.str.contains('ct.*[0-9][0-9]pi') | store.columns.str.contains('.*' + prediction_interval + 'pi')]
    
    # Renames and Generalizing PIs to Low and High values
    for pattern, mapper in [('low' + prediction_interval, 'ct_lowpi'), ('high' + prediction_interval, 'ct_highpi')]:
        store.columns = store.columns.to_series().map(
            lambda col: mapper if pattern in col else col)
    
    store = store[['dd_reportingdate', 'dd_forecastdate',
                   'dim_partid', 'dd_level2', 'ct_salesquantity', 'ct_forecastquantity', 'ct_lowpi', 'ct_highpi', 'ct_mape',
                   'dd_lastdate', 'dd_holdoutdate',
                   'dd_forecastsample', 'dd_forecasttype', 'dd_forecastrank', 'dd_forecastmode', 'dd_companycode',
                   'dd_bias_error_rank', 'dd_bias_error']]
    
    # Forecast Capping with more than million using following logic:
    # Forecast = meanHistoricSales + 3*Std_devHistoricSales
    # HighPI = Forecast + 3 *Std_devHistoricSales
    capping = float(conf_run_script['demand_capping'])
    # Create capping columns
    store["capping"] = False
    if store[store.ct_forecastquantity > capping].shape[0] > 1:
        store.loc[store.ct_forecastquantity > capping, "capping"] = True
        # Get the grain
        store["grain"] = store['dim_partid'].astype(
            str) + "--" + store['dd_level2'].astype(str)
        cap_grain = store[store.capping]['grain'].drop_duplicates()
    
        # filter data by grain and historic data
        cap_avg_sales = store[(store.grain.isin(cap_grain))]
        cap_avg_sales = cap_avg_sales.query(
            'dd_forecastsample=="Train" or dd_forecastsample=="Test"')
    
        # Group by to get avg sales and std_dev for each grains
        cap_avg_sales = cap_avg_sales.groupby(
            'grain')['ct_salesquantity'].agg([np.std])
        for store_grain in cap_grain:
            tmp_index = store.query(
                "capping == True and grain == '{0}'".format(store_grain)).index
            store.loc[tmp_index, "ct_forecastquantity"] = capping
            store.loc[tmp_index, "ct_highpi"] = capping + \
                3 * cap_avg_sales.ix[store_grain, "std"]
            store.loc[tmp_index, "ct_lowpi"] = capping - \
                3 * cap_avg_sales.ix[store_grain, "std"]
        store = store.drop('grain', axis=1)
    
    # Capping High PI to maximum value of 3*Forecast quantity
    store.ct_highpi = store.apply(lambda row: min(
        row.ct_highpi, 3 * row.ct_forecastquantity), axis=1)
    
    output_file_final = "result/{1}/{0}_{1}_{2}_{3}.csv".format(
    output_file[0], company,tag,output_timestamp)

    store.to_csv(tmp_output_file, index=False)
    store.drop('capping', axis=1).to_csv(output_file_final, index=False)

    t = time() - t0
    logfile.write('Wrote forecasts to %s \n' % output_file_final)
    logfile.write(
        'The program completed successfully and took %7.2f seconds\n' % t)
    df_out  = store.drop('capping', axis=1)
    return df_out;

#### Running All 4 forecasts  -Reg, Reg + full history, Outlier Handled, Outlier handled + Full history ...
#Reg_out = forecast_run(last_date_1,holdout_date_1,data,"Regular")
Reg_fh_out = forecast_run(last_date_2,holdout_date_2,data,"RegularFullHistory")
#Outlier_out =  forecast_run(last_date_1,holdout_date_1,data_oh,"OutlierHandled")
#Outlier_fh_out = forecast_run(last_date_2,holdout_date_2,data_oh,"OutlierHandledFullHistory")

#####...........................................................................Forecast Analysis ..............................................................# 
#### Merging Holdout and horizon mapes for regular outputs
Reg_out = Reg_out[Reg_out['dd_forecastrank']==1] 
Reg_final = Reg_out[['dim_partid','dd_level2','dd_forecasttype','ct_mape']].drop_duplicates().reset_index(drop=True)
Reg_final.columns = ['dim_partid','dd_level2','dd_forecasttype','ct_mape_Holdout']
Reg_forecast_final = Reg_final.merge(Reg_fh_out,on=['dim_partid','dd_level2','dd_forecasttype'])
Reg_forecast_final = Reg_forecast_final[['dim_partid','dd_level2','dd_forecasttype','ct_mape_Holdout','ct_mape']].drop_duplicates().reset_index(drop=True)
Reg_forecast_final.columns = ['dim_partid','dd_level2','dd_forecasttype','ct_mape_Holdout','ct_mape_horizon']
Reg_forecast_final['Outlier_Flag'] = "Regular"

#### Merging Holdout and horizon mapes for Outlier outputs
Outlier_out = Outlier_out[Outlier_out['dd_forecastrank']==1]
Outlier_final = Outlier_out[['dim_partid','dd_level2','dd_forecasttype','ct_mape']].drop_duplicates().reset_index(drop=True)
Outlier_final.columns = ['dim_partid','dd_level2','dd_forecasttype','ct_mape_Holdout']
Outlier_forecast_final = Outlier_final.merge(Reg_fh_out,on=['dim_partid','dd_level2','dd_forecasttype'])
Outlier_forecast_final = Outlier_forecast_final[['dim_partid','dd_level2','dd_forecasttype','ct_mape_Holdout','ct_mape']].drop_duplicates().reset_index(drop=True)
Outlier_forecast_final.columns = ['dim_partid','dd_level2','dd_forecasttype_oh','ct_mape_Holdout_oh','ct_mape_horizon_oh']
Outlier_forecast_final['Outlier_Flag_oh'] = "Outlier"

Forecast_final = Reg_forecast_final.merge(Outlier_forecast_final,on=['dim_partid','dd_level2'])
Forecast_final['Holdout_MAPE'] = np.where((Forecast_final['ct_mape_Holdout'] > Forecast_final['ct_mape_Holdout_oh']), Forecast_final['ct_mape_Holdout_oh'],Forecast_final['ct_mape_Holdout']) 
Forecast_final['Horizon_MAPE'] = np.where((Forecast_final['ct_mape_Holdout'] > Forecast_final['ct_mape_Holdout_oh']), Forecast_final['ct_mape_horizon_oh'],Forecast_final['ct_mape_horizon'])
Forecast_final['Flag'] =np.where((Forecast_final['ct_mape_Holdout'] > Forecast_final['ct_mape_Holdout_oh']), Forecast_final['Outlier_Flag_oh'],Forecast_final['Outlier_Flag'])
Forecast_final['Forecast_type'] =np.where((Forecast_final['ct_mape_Holdout'] > Forecast_final['ct_mape_Holdout_oh']), Forecast_final['dd_forecasttype_oh'],Forecast_final['dd_forecasttype'])


Forecast_final = Forecast_final[['dim_partid','dd_level2','Forecast_type','Holdout_MAPE','Horizon_MAPE','Flag']].drop_duplicates().reset_index(drop=True)

#writer = pd.ExcelWriter('All_Parts_MAPEs.xlsx', engine='xlsxwriter')

# Convert the dataframe to an XlsxWriter Excel object.
#Forecast_final.to_excel(writer, sheet_name='Sheet1')
Forecast_final.to_csv("ForecastResult_Summary.csv")

# Close the Pandas Excel writer and output the Excel file.
#writer.save()

#logfile.close()

######################################################################################################################################
def getmode(inplist):
    '''with list of items as input, returns mode
    '''
    dictofcounts = {}
    listofcounts = []
    for i in inplist:
        countofi = inplist.count(i) # count items for each item in list
        listofcounts.append(countofi) # add counts to list
        dictofcounts[i]=countofi # add counts and item in dict to get later
    maxcount = max(listofcounts) # get max count of items
    if maxcount ==1:
    	#modelist = min(inplist)
        modelist = [] # if more than one mode, add to list to print out
        for key, item in dictofcounts.iteritems():
            if item ==maxcount: # get item from original list with most counts
                modelist.append(str(key))
        #print "There is no mode for this dataset, values occur only once"
        return modelist[0]
    else:
        modelist = [] # if more than one mode, add to list to print out
        for key, item in dictofcounts.iteritems():
            if item ==maxcount: # get item from original list with most counts
                modelist.append(str(key))
       # print "The mode(s) are:",' and '.join(modelist)
        return modelist 

######################################################################################################################################
######.................................Forecasting Rank 1 Methods Histograms.......................................................###
word_list = list(Forecast_final['Forecast_type'])
counts = Counter(word_list)
labels, values = zip(*counts.items())

# sort your values in descending order
indSort = np.argsort(values)[::-1]

# rearrange your data
labels = np.array(labels)[indSort]
values = np.array(values)[indSort]
indexes = np.arange(len(labels))

labels_1 = labels[indexes]
 

bar_width = 0.3
fig = plt.figure()
ax = plt.subplot(111)
ax.barh(indexes,values, color='green')
plt.yticks(indexes, labels)



# set individual bar lables using above list
total = sum(values)

values_perc = np.divide(np.array(values)*100 , total)

ax.tick_params(labelsize = 6)
ax.invert_yaxis()
ax.set_title('Forecasting Methods - Histogram')
ax.set_xlabel('Count of grains')
plt.tight_layout()
fig = ax.get_figure()
fig.savefig('Fcst_Methods_histogram.png')


######################################################################################################################################
######.......................................................MAPE Histograms.......................................................###

homape_hist_data = Forecast_final[Forecast_final.Holdout_MAPE < 100]
s = list(homape_hist_data['Holdout_MAPE'])

hrmape_hist_data = Forecast_final[Forecast_final.Horizon_MAPE < 100]
q = list(hrmape_hist_data['Horizon_MAPE'])

bins = range(0,100,2)

fig = plt.figure()
#fig.suptitle('MAPE Histogram', fontsize=14, fontweight='bold')
ax = plt.subplot(211)
ax.hist(s,  bins=50 , rwidth=0.5, facecolor='orange' )
ax.set_xticklabels(bins,rotation='vertical')
ax.tick_params(labelsize = 6)
ax.set_xticks(bins)
#ax.set_xlabel('MAPE')
ax.set_ylabel('Count of grains')
ax.set_title('Holdout MAPE Histogram')

ax = plt.subplot(212)
ax.hist(q,  bins=50 , rwidth=0.5, facecolor='orange' )
ax.set_xticklabels(bins,rotation='vertical')
ax.tick_params(labelsize = 6)
ax.set_xticks(bins)
ax.set_xlabel('MAPE Bins')
ax.set_ylabel('Count of grains')
ax.set_title('Horizon MAPE Histogram')
plt.tight_layout()



fig = ax.get_figure()


fig.savefig('MAPE_histogram.png')


######################################################################################################################################
######.................................................Writing Summary Table.......................................................###

a = len(Forecast_final['dim_partid'].unique())
b = len(Forecast_final['dd_level2'].unique())
c = Forecast_final.shape[0]


s = list(Forecast_final['Holdout_MAPE'])
s2 =  [ '%.0f' % elem for elem in s ]
d = min(getmode(s2))


mape_1 = Forecast_final[Forecast_final.Holdout_MAPE <= int(d)]
e = mape_1.shape[0]


f = e *100 / c

s = list(Forecast_final['Horizon_MAPE'])
s2 =  [ '%.0f' % elem for elem in s ]
g = min(getmode(s2))


mape_2 = Forecast_final[Forecast_final.Horizon_MAPE <= int(g)]
h = mape_2.shape[0]

i = float(h*100 /c)


mape_3 = Forecast_final[Forecast_final.Holdout_MAPE <= 20]
j = mape_3.shape[0]

k = float(j*100 /c)

mape_4 = Forecast_final[Forecast_final.Holdout_MAPE <= 100]
l = mape_4.shape[0]

m = float(l*100 /c)

mape_5 = Forecast_final[Forecast_final.Horizon_MAPE <= 20]
n = mape_5.shape[0]

o = float(n*100 /c)

mape_6 = Forecast_final[Forecast_final.Horizon_MAPE <= 100]
p = mape_6.shape[0]

q = float(p*100 /c)


Df_1 = {'col1': ["# Parts","# Plants",'# unique Grains','Holdout Mode Mape',
'# Parts having Holdout MAPE under Mode', '% Parts having Holdout MAPE under Mode', 'Horizon Mode Mape','# Parts having Horizon MAPE under Mode', 
'% Parts having Horizon MAPE under Mode','# Parts having Holdout MAPE under 20', '% Parts having Holdout MAPE under 20','# Parts having Holdout MAPE under 100', '% Parts having Holdout MAPE under 100'
,'# Parts having Horizon MAPE under 20', '% Parts having Horizon MAPE under 20','# Parts having Horizon MAPE under 100', '% Parts having Horizon MAPE under 100'], 
'col2': [a,b,c,d,e, f,g,h,i,j,k,l,m,n,o,p,q]}

df = pd.DataFrame(data=Df_1)

df.columns = ['Description', 'Value']


print df

df.to_csv("ForecastAnalysis_Summary.csv")
# Create a Pandas Excel writer using XlsxWriter as the engine.
#writer = pd.ExcelWriter('Summary_Output.xlsx', engine='xlsxwriter')

# Convert the dataframe to an XlsxWriter Excel object.
#df.to_excel(writer, sheet_name='Sheet1')

# Close the Pandas Excel writer and output the Excel file.
#writer.save()


