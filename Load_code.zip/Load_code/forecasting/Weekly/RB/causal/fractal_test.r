library(bsts)
library(xgboost)
library(dplyr)
library(forecast)
format_negatives<-function(x){
  try(x[x<0]<-0,silent=TRUE)
  return(x)
}
generate_BI_ARIMAX <- function(Train_Sales,data,data1,Test_Sales,holdout_months,horizon_in_months,time_period){
  data$Sales = as.numeric(Train_Sales$Sales)
  
  drop<-c("Month")
  a<-data
  a<-a[!names(a) %in% drop]
  
  #if(nrow(a)==0){next}
  #if (length(a)==sum(is.na(a))) {next}
  
  #a[min(which(!is.na(a))):max(which(!is.na(a))),]
  #if(length(a)<8) {next}
  names(a)
  num = nrow(data)
  
  start =  (nrow(data) -  nrow(data[data$Sales!= 0,])) + 1
  end = nrow(data); train_period = start:end;forecast_period =  1:holdout_months
  #print(start)
  #print(end)
  #print(head(a))
  #test_period = (end+1):(end+13);
  b = a[start:end,]
  #print(colnames(b))
  min.model=lm(b[,"Sales"]~ 1, data = b)
  tmp_var = names(b)[!names(b) %in% c("Month","Sales")]
  #features_da<-features_da[!features_da %in% c("Month","Sales")]
#formula = paste("Sales ~ ", paste0(features_da,collapse = "+" ))
  biggest<-paste("Sales ~ ", paste0(tmp_var,collapse = "+" ))
  step_arimax<-step(min.model,direction = "forward",scope = biggest)
  
  
  vardf<-data.frame(var=names(step_arimax$coefficients),beta=as.numeric(step_arimax$coefficients))
  imp_var_arimax <- na.omit(vardf)
  if(nrow(imp_var_arimax)<2){
    imp_var_arimax$var<-c("E1")
  }
  imp_var_arimax<-imp_var_arimax[!imp_var_arimax$var %in% c("(Intercept)"),]
  imp_var_arimax<-imp_var_arimax[!imp_var_arimax%in% c("QuarterQ3","QuarterQ4","QuarterQ2")]
  
  
  t <- data.frame(Important_Variables=imp_var_arimax$var,Beta=abs(imp_var_arimax$beta))
  imp_var_arimax <- as.character(imp_var_arimax$var)
  
  y <- decompose(ts(a[train_period,"Sales"],frequency = 13),type = "additive",filter = NULL)
  #plot(y)
  
  trend  <- y$trend
  season <- y$seasonal
  err    <- y$random
  
  train  <- trend[min(which(!is.na(trend))):max(which(!is.na(trend)))]
  #test   <- as.numeric(ts(a[test_period,"Sales"]))
  train1 <- err[min(which(!is.na(err))):max(which(!is.na(err)))]
  #test1  <- ts(a[test_period,"Sales"])
  
  z <- snaive(season,h=(length(forecast_period)+13))$mean
  x <- as.numeric(z)
  #end
  model1 <- lm(Sales~.,data = a)
  modelcoef <- na.omit(model1$coefficients)
  #print(a)
  print(start:(start+length(train)-1))
  print(imp_var_arimax)
  print(a[start:(start+length(train)-1),c(imp_var_arimax)])
 if(length(modelcoef)>1){
    fit.arima.imp_new <- auto.arima(log1p(train),xreg=ts(a[start:(start+length(train)-1),
                                                           c(imp_var_arimax)],frequency=13),stepwise = FALSE)
    forecast_arima.imp_new <- forecast(fit.arima.imp_new, h=(length(forecast_period)+13),
                                       xreg=a[c(train_period[(length(train_period)-1):(length(train_period))],
                                                forecast_period),c(imp_var_arimax)])$mean
  }else{
    fit.arima.imp_new <- auto.arima(log1p(train),stepwise = FALSE)
    forecast_arima.imp_new <- forecast(fit.arima.imp_new, h=(length(forecast_period)+13))$mean
  }
  forecast_arima.imp_new <- expm1(as.numeric(forecast_arima.imp_new))
  
  if(length(modelcoef)>1){
   print(a[start:(start+length(train)-1),c(imp_var_arimax)])
    error <- nnetar(train1,xreg =ts(a[start:(start+length(train)-1),c(imp_var_arimax)],
                                    frequency = 13),start.p = 1,start.q = 1)
    errforecast <- forecast(error,h=(length(forecast_period)+13),
                            xreg=a[c(train_period[(length(train_period)-1):(length(train_period))],
                                     forecast_period),c(imp_var_arimax)])$mean
  }else{
    error <- nnetar(train1,start.p = 1,start.q = 1)
    errforecast <- forecast(error,h=(length(forecast_period)+13))$mean
  }
  errforecast <- as.numeric(errforecast)
  
  pred_arimax <- forecast_arima.imp_new + errforecast + x
  pred_arimax <- format_negatives(pred_arimax)
  
  fitted <- expm1(fit.arima.imp_new$fitted)
  
  forecast_values= c(fitted,pred_arimax)
  # Prepare output
  
  
  a1 = rep(NA,(num+holdout_months+horizon_in_months))
  length(a1)
  a1$Forecast<- forecast_values
  
  a1 = as.data.frame(a1)
  a1['Low95PI']=NA
  a1['High95PI']=NA
  a1['Low90PI']=NA
  a1['High90PI']=NA
  #print(a2)
  return (a1)
}
generate_xgboost_fractal <- function(Train_Sales,data,data1,Test_Sales,holdout_months,horizon_in_months,time_period) {
data1 = data1[nrow(data)+1:nrow(Test_Sales),]
Test_Sales = Test_Sales[nrow(data)+1:nrow(Test_Sales),]

#print(data1)
#print(Test_Sales)
#print(length(Train_Sales))
#print(length(Test_Sales))
#print(length(data))
#:wq
print(length(data1))

drop<-c("Month")
a<-data
a<-a[!names(a) %in% drop]

#print(nrow(Train_Sales))
#print(nrow(Test_Sales))
#print(nrow(data))
#print(nrow(data1))
#model data
time_period = as.integer(time_period)
data$Sales = as.numeric(Train_Sales$Sales)
data1$Sales = as.numeric(Test_Sales)
sample_xgboost<-data1
num = nrow(data)

start =  (nrow(data) -  nrow(data[data$Sales!= 0,])) + 1
end = nrow(data); train_period = start:end; test_period = (end+1):(end+13);forecast_period =  (end+1):num
#print(start)
#print(end)
#Specify features here
features_da<-names(sample_xgboost)[c(1:ncol(sample_xgboost))]
features_da<-features_da[!features_da %in% c("Month","Sales")]
data_xgboost_complete<-sample_xgboost
wltst_da=train_period[(length(train_period)-5):length(train_period)]
data_xgboost_train <- data # sample_xgboost[dplyr::setdiff(train_period,wltst_da),]
#print("Train test split  DONE---------------------")
#Specify the target variable name
target_da<-'Sales'
data_xgboost_complete[,features_da] <- as.numeric(data_xgboost_complete[,features_da])
#Specify the cross - validation matrix to build ensembles
dval_da <- xgb.DMatrix(data=data.matrix(data_xgboost_complete[wltst_da,features_da]),
                       label=data.matrix(data_xgboost_complete[wltst_da,target_da]),missing=NA)

watchlist_da <- list(dval=dval_da)

#List the flexible parameters for model to tune
# eta<-c(0.3,0.1,0.5)
# max_depth<-c(5,7)
# subsample<-c(1,0.7)
# colsample_bytree<-c(0.4,0.7,1)
eta<-c(0.3)
max_depth<-c(7)
subsample<-c(0.7)
colsample_bytree<-c(1.0)
data_xgboost_train[,features_da] <- as.numeric(data_xgboost_train[,features_da])
#features_da<-features_da[!features_da %in% c("Month","Sales")]
formula = paste("Sales ~ ", paste0(features_da,collapse = "+" ))
model1 <- lm(formula,data = data_xgboost_train)



modelcoef <- na.omit(model1$coefficients)
#print("-----STarting the model-----")

if(length(modelcoef)>1){
  set.seed(2017)
  clf_qty_da2 <-     xgb.train(params=list(objective="reg:linear", booster = "gbtree", eta=eta,max_depth=max_depth, 
                                        subsample=subsample, colsample_bytree=colsample_bytree) ,
                            data = xgb.DMatrix(data=data.matrix(data_xgboost_train[,features_da]),label=data.matrix(data_xgboost_train[,target_da]),missing = NA),
                            nrounds = 400,
                            verbose = 0,
                            print_every_n = 5,
                            # early_stopping_rounds = 30,
                            eval_metric='rmse',
                            watchlist = watchlist_da,
                            maximize = FALSE )
  #View(data1[,features_da])
  pred_qty_da<-predict(clf_qty_da2,xgb.DMatrix(data.matrix(data1[,features_da]),missing=NA))
  fit_qty_da<-predict(clf_qty_da2,xgb.DMatrix(data.matrix(data[,features_da]),missing=NA))
  pred_qty_da = as.data.frame(format_negatives(pred_qty_da))
  fit_qty_da = as.data.frame(format_negatives(fit_qty_da))
  colnames(fit_qty_da)<- c('Forecast')
  colnames(pred_qty_da)<- c('Forecast')
  a1 = rbind(fit_qty_da,pred_qty_da)}else{
  a1 = data.frame(c(data_xgboost_train$Sales,rep(0,time_period)))
  colnames(a1) <- c("Forecast")
}}

 

generate_BI_BSTS1 <- function(Train_Sales,data,data1,Test_Sales,holdout_months,horizon_in_months,time_period){

  # data = data[order(data$YYYYMM),]
  # data1 = data[data$YYYYMM >= 201740,]
  # data1$Sales_log = log1p(data1$Sales)
  # data = data[data$YYYYMM < 201740,]

  data1 = data1[nrow(data)+1:nrow(Test_Sales),]
  Test_Sales = Test_Sales[nrow(data)+1:nrow(Test_Sales),]

  #print(data1)
  #print(Test_Sales)
  #print(length(Train_Sales))
  #print(length(Test_Sales))
  #print(length(data))
  #:wq
  print(length(data1))


 #print(nrow(Train_Sales))
  print(nrow(Test_Sales))
  #print(nrow(data))
  print(nrow(data1))
  #model data
  time_period = as.integer(time_period)
  data$Sales = Train_Sales
  data1$Sales = Test_Sales
  data$Sales=ts(data$Sales,frequency = 13)
  data$Sales_log<-ts(log1p(data$Sales),frequency = 13)

  imp_variables<-names(data[,c(1:ncol(data))])
  imp_variables<-imp_variables[!imp_variables %in% c("Sales","Sales_log","Month")]
  Formula<-as.formula(paste("Sales~",paste(imp_variables,sep = "",collapse = "+")))

  Formula_log<-as.formula(paste("Sales_log~",paste(imp_variables,sep = "",collapse = "+")))


  ss1<- AddSeasonal(list(),data$Sales, nseasons = 13)
  ss1<-AddSemilocalLinearTrend(ss1,data$Sales)
  ss1<-AddSeasonal(ss1,data$Sales,nseasons =13 ,season.duration = 4)

  ss2<- AddSeasonal(list(),data$Sales_log, nseasons = 13)
  ss2<-AddSemilocalLinearTrend(ss2,data$Sales_log)
  ss2<-AddSeasonal(ss2,data$Sales_log,nseasons =13 ,season.duration = 4)

  fit <- bsts(Formula, state.specification = ss1, data = data, niter = 1000, ping=0, seed=2016)
  fit_log <- bsts(Formula_log, state.specification = ss2, data = data, niter = 1000, ping=0, seed=2016)

  #fit <- bsts(x, state.specification = ss1, niter = 1000, ping=0, seed=2016)
  burn1 = 500
  forecast <-predict.bsts(fit, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast_log <-predict.bsts(fit_log, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast <-predict.bsts(fit, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast_log <-predict.bsts(fit_log, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))

  #training fit

  fitted <- (-colMeans(fit$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales))
  fitted <- data.frame(as.numeric(fitted))
  mean <- data.frame(as.numeric(forecast$mean))

  #  burn1 = 100
  fitted_log <- (-colMeans(fit_log$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales_log))
  fitted_log <- data.frame(as.numeric(expm1(fitted_log)))
  mean_log <- data.frame(as.numeric(expm1(forecast_log$mean)))


  colnames(fitted)<- c('Forecast_bstsx')
  colnames(mean)<- c('Forecast_bstsx')

  colnames(fitted_log)<- c('Forecast_bstsx')
  colnames(mean_log)<- c('Forecast_bstsx')

  # Prepare output

  a1 = rbind(fitted,mean)
  a2 = rbind(fitted_log,mean_log)

  a1$Forecast_bstsx = format_negatives(a1$Forecast_bstsx)
  a2$Forecast_bstsx = format_negatives(a2$Forecast_bstsx)

  actual = data1$Sales[1:13]; pred = mean$Forecast_bstsx[1:13] ; pred_log = mean_log$Forecast_bstsx[1:13]
  ind  = which(actual != 0 );  actual_1 = actual[ind]; pred1 = pred[ind] ; pred2 = pred_log[ind]

  mape_ex1<-mean(abs((pred1-actual_1)/actual_1))
  mape_ex2<-mean(abs((pred2-actual_1)/actual_1))


  if(mape_ex1<= mape_ex2){final_out = a1 }
  else {final_out = a2}


  #print(a2)
  return (final_out)
}
BSTS_BI <- function(Train_Sales,data,data1,Test_Sales,holdout_months,horizon_in_months,time_period){

  # data = data[order(data$YYYYMM),]
  # data1 = data[data$YYYYMM >= 201740,]
  # data1$Sales_log = log1p(data1$Sales)
  # data = data[data$YYYYMM < 201740,]
  #print(nrow(Train_Sales))
  #print(nrow(Test_Sales))
  #print(nrow(data))
  #print(nrow(data1))
 #print(data1)
  #print(Test_Sales) 
 data1 = data1[nrow(data)+1:nrow(Test_Sales),]
  Test_Sales = Test_Sales[nrow(data)+1:nrow(Test_Sales),]
 
  #print(data1)
  #print(Test_Sales)
  #print(length(Train_Sales))
  #print(length(Test_Sales))
  #print(length(data))
  #:wq
  print(length(data1))
 

 #print(nrow(Train_Sales))
  print(nrow(Test_Sales))
  #print(nrow(data))
  print(nrow(data1))
  #model data
  time_period = as.integer(time_period)
  data$Sales = Train_Sales
  data1$Sales = Test_Sales
  data$Sales=ts(data$Sales,frequency = 13)
  data$Sales_log<-ts(log1p(data$Sales),frequency = 13)

  imp_variables<-names(data[,c(1:ncol(data))])
  imp_variables<-imp_variables[!imp_variables %in% c("Sales","Sales_log","Month")]
  Formula<-as.formula(paste("Sales~",paste(imp_variables,sep = "",collapse = "+")))

  Formula_log<-as.formula(paste("Sales_log~",paste(imp_variables,sep = "",collapse = "+")))


  ss1<- AddSeasonal(list(),data$Sales, nseasons = 13)
  ss1<-AddSemilocalLinearTrend(ss1,data$Sales)
  ss1<-AddSeasonal(ss1,data$Sales,nseasons =13 ,season.duration = 4)

  ss2<- AddSeasonal(list(),data$Sales_log, nseasons = 13)
  ss2<-AddSemilocalLinearTrend(ss2,data$Sales_log)
  ss2<-AddSeasonal(ss2,data$Sales_log,nseasons =13 ,season.duration = 4)

  fit <- bsts(Formula, state.specification = ss1, data = data, niter = 1000, ping=0, seed=2016)
  fit_log <- bsts(Formula_log, state.specification = ss2, data = data, niter = 1000, ping=0, seed=2016)

  #fit <- bsts(x, state.specification = ss1, niter = 1000, ping=0, seed=2016)
  burn1 = 500
  forecast <-predict.bsts(fit, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast_log <-predict.bsts(fit_log, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast <-predict.bsts(fit, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast_log <-predict.bsts(fit_log, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))

  #training fit

  fitted <- (-colMeans(fit$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales))
  fitted <- data.frame(as.numeric(fitted))
  mean <- data.frame(as.numeric(forecast$mean))

  #  burn1 = 100
  fitted_log <- (-colMeans(fit_log$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales_log))
  fitted_log <- data.frame(as.numeric(expm1(fitted_log)))
  mean_log <- data.frame(as.numeric(expm1(forecast_log$mean)))


  colnames(fitted)<- c('Forecast_bstsx')
  colnames(mean)<- c('Forecast_bstsx')

  colnames(fitted_log)<- c('Forecast_bstsx')
  colnames(mean_log)<- c('Forecast_bstsx')

  # Prepare output

  a1 = rbind(fitted,mean)
  a2 = rbind(fitted_log,mean_log)

  a1$Forecast_bstsx = format_negatives(a1$Forecast_bstsx)
  a2$Forecast_bstsx = format_negatives(a2$Forecast_bstsx)

  actual = data1$Sales[1:13]; pred = mean$Forecast_bstsx[1:13] ; pred_log = mean_log$Forecast_bstsx[1:13]
  ind  = which(actual != 0 );  actual_1 = actual[ind]; pred1 = pred[ind] ; pred2 = pred_log[ind]

  mape_ex1<-mean(abs((pred1-actual_1)/actual_1))
  mape_ex2<-mean(abs((pred2-actual_1)/actual_1))


  if(mape_ex1<= mape_ex2){final_out = a1 }
  else {final_out = a2}


  #print(a2)
  return (final_out)
}
X =  read.csv(file="X.csv", header=TRUE, sep=",")
Xtest =  read.csv(file="xtest.csv", header=TRUE, sep=",")
Y =  read.csv(file="Y.csv", header=TRUE, sep=",")
Ytest =  read.csv(file="Ytest.csv", header=TRUE, sep=",")
#print(sales)
output = generate_BI_ARIMAX(Y,X,Xtest,Ytest,13,13,52)
print(output)
