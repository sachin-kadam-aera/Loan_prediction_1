import pandas as pd
import numpy as np


def forecast_error(data1,Ytest,Y_pred1,holdout_date,last_date):
    """
    Generates a dataframe with holdout records and Metrics like SE, APE, and Error

    :param data1: Complete data
    :param Ytest: Actual Test data
    :param Y_pred1: Forecast data
    :param holdout_date:
    :param last_date:
    :return:
    """
    Y_compare = pd.DataFrame(data1.YYYYMM).join(Ytest)
    Y_compare = Y_compare.reset_index().drop('index',1)
    Y_compare = pd.DataFrame(Y_compare).join(Y_pred1)
    Y_compare['Error']=(Y_compare.Forecast - Y_compare.Sales)*100/ Y_compare.Sales  # Error
    Y_compare['SE']=Y_compare['Error'] ** 2  # Squared Errors
    Y_compare['APE']=abs(Y_compare.Forecast - Y_compare.Sales)*100/ Y_compare.Sales  # Absolute Percentage Error
    Y_compare = Y_compare[Y_compare.YYYYMM >= holdout_date]
    Y_compare = Y_compare[Y_compare.YYYYMM < last_date]
    Y_compare.loc[Y_compare["APE"] >100000, "APE"] = 100000
    Y_compare['Bias_Error']= 100*(sum(Y_compare.Forecast)-sum(Y_compare.Sales))/(1+sum(Y_compare.Sales))
    Y_compare.loc[Y_compare["Bias_Error"] >1000000, "Bias_Error"] = 1000000
    return Y_compare


def get_confidence_interval(data, holdout_date):
    """
     Calculate Prediction interval for the given data according to the RMSE value
    :param data: Complete data with Forecast results
    :return: CI results
    """
    data['SE']= (data.Forecast - data.Sales) ** 2  # Squared Errors
    RMSE = np.sqrt(data.SE.mean())

    # 95% PI
    data['Low95PI'] = data.Forecast - RMSE * 1.96
    data['High95PI'] = data.Forecast + RMSE * 1.96
    # 90% PI
    data['Low90PI'] = data.Forecast - RMSE * 1.645
    data['High90PI'] = data.Forecast + RMSE * 1.645

    # Data less than holdout date is NaN
    data.loc[data.YYYYMM < holdout_date, ["Low95PI", "High95PI", "Low90PI", "High90PI"]] = np.NAN
    data.loc[data["Low95PI"] < 0, "Low95PI"] = 0
    data.loc[data["High95PI"] < 0, 'High95PI'] = 0
    data.loc[data["Low90PI"] < 0, "Low90PI"] = 0
    data.loc[data["High90PI"] < 0, 'High90PI'] = 0
    
    data.loc[data["Low95PI"] >100000, "Low95PI"] = 100000
    data.loc[data["High95PI"]>100000, 'High95PI'] = 100000
    data.loc[data["Low90PI"]>100000, "Low90PI"] = 100000
    data.loc[data["High90PI"]>100000, 'High90PI'] = 100000
    data = data.drop('SE', axis=1)
    return data
