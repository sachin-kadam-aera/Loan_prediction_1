#!/bin/sh

cp forecast_1rb.ini forecast.ini
python ./main.py 1>rb1c.log 2>rb1c.err 
echo 'PART1 DONE'
gzip result/RECKITT_BENDKISER/*csv 
cp forecast_2rb.ini forecast.ini
python ./main.py 1>rb2c.log 2>rb2c.err
echo 'PART2 DONE'
gzip result/RECKITT_BENDKISER/*csv 
cp forecast_3rb.ini forecast.ini
python ./main.py 1>rb3c.log 2>rb3c.err
echo 'PART3 DONE'
gzip result/RECKITT_BENDKISER/*csv 
cp forecast_4rb.ini forecast.ini
python ./main.py 1>rb4c.log 2>rb4c.err
echo 'PART4 DONE'
gzip result/RECKITT_BENDKISER/*csv 
cp forecast_5rb.ini forecast.ini
python ./main.py 1>rb5c.log 2>rb5c.err
echo 'PART5 DONE'
