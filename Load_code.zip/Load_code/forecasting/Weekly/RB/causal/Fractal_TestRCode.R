library(forecast)
library(MAPA)
library(bsts)
SampleData = read.csv("sample_data.csv")
print(dim(SampleData))

generate_forecast_mapa <- function(data,holdout_months,horizon_in_months,time_period) {
  #prepare preprocessing
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data,frequency = 13)
  
  #model data
  fit <- mapaest(x,model="ZZA")
  forecast <- mapafor(x,fit,h=holdout_months+horizon_in_months+1,comb = "w.mean",outplot = 0,95)
  
  #training fit
  fitted <- data.frame(as.numeric(forecast$infor))
  colnames(fitted)<- c('Forecast')
  #Forecast values
  mean <- data.frame(as.numeric(forecast$outfor))
  colnames(mean) <- c("Forecast")
  
  
  # Prepare output
  a1 = as.data.frame(rbind(fitted,mean))
  a1['Low90PI']=NA
  a1['High90PI']=NA
  a1['Low95PI']=NA
  a1['High95PI']=NA
  
  return (a1)
}

generate_USTLARIMA_Fractal <-function(data,holdout_months,horizon_in_months,time_period){
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = time_period)

  #model data
  fit <- stlf(x,method='arima',h=holdout_months+horizon_in_months+1)

  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  fitted <- data.frame((as.numeric(forecast$fitted)))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- data.frame(forecast)

  colnames(forecast_fit) <- c("Forecast","Low85PI","High85PI","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  forecast_90 <- forecast_90[,1]
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA

  #Forecast values
  forecast_fit['Low90PI']=NA
  forecast_fit['High90PI']=NA

  #Prepare output
  a1 = rbind(fitted[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")],forecast_fit[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")])
  return (a1)


}
generate_NNAR <-function(data,holdout_months,horizon_in_months,time_period){
  num = nrow(data)
  time_period = as.integer(time_period)
  x=data$Sales

  #model data
#akl<-forecast(nnetar(sample_nn, repeats=26,scale.inputs=TRUE),h=length(forecast_period))
  #pred_nn<-as.numeric(akl$mean)
  #fit <-nnetar(x,repeats=26,scale.inputs=TRUE)
  forecast <- forecast(nnetar(x, repeats=26,scale.inputs=TRUE),h=holdout_months+horizon_in_months+1,95)
  #forecast <- forecast(fit,h=(holdout_months+horizon_in_months+1),95)

  #training fit
  fitted <- data.frame((as.numeric(forecast$mean)))
  print 
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- data.frame(forecast)

  colnames(forecast_fit) <- c("Forecast","Low85PI","High85PI","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  forecast_90 <- forecast_90[,1]
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA

  #Forecast values
  forecast_fit['Low90PI']=NA
  forecast_fit['High90PI']=NA

  #Prepare output
  a1 = rbind(fitted[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")],forecast_fit[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")])
  return (a1)


}
generate_forecast_nnet_fractal<-function(data,holdout_months,horizon_in_months,time_period){

  #model data
  set.seed(30)
   time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = time_period)
  fit <- nnetar(x,repeats=26,scale.inputs=TRUE)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  mean <- data.frame(as.numeric(forecast$mean))
  colnames(fitted)<- c('Forecast')
  colnames(mean)<- c('Forecast')
  # Prepare output

  a1 = rbind(fitted,mean)
  return (a1)
}
generate_forecast_bsts_fractal<-function(data,holdout_months,horizon_in_months,time_period){
    
    #model data
    time_period = as.integer(time_period)
    x=ts(data = data$Sales,frequency = time_period)
    
    ss4 <- AddSeasonal(list(),x, nseasons = time_period)
    ss4 <- AddSeasonal(ss4,x, nseasons = time_period,season.duration = 4)
    ss4<-AddSemilocalLinearTrend(ss4,x)
    fit <-bsts(x, state.specification = ss4, niter = 2000, ping=0, seed=2016)
    burn1 = 500
    forecast <-predict.bsts(fit,horizon =holdout_months+horizon_in_months+1, burn=burn1, 95)
  
    #training fit
    
    fitted <- (-colMeans(fit$one.step.prediction.errors[-(1:burn1),])+as.numeric(x))
    fitted <- data.frame(as.numeric(fitted))
    mean <- data.frame(as.numeric(forecast$mean))
    colnames(fitted)<- c('Forecast')
    colnames(mean)<- c('Forecast')
    # Prepare output
    
    a1 = rbind(fitted,mean)
    return (a1)
  }



output = generate_forecast_bsts_fractal(SampleData,13,13,53)
#output = generate_forecast_ETS_fractal(SampleData,13,13,53) 
print(output)
