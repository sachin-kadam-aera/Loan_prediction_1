#!/bin/sh

for i in forecast_?rb.ini
do sed 's/holdout_date:201739/holdout_date:201752/' $i|sed 's/last_date:201752/last_date:201813/' |sed 's/output_file: causal/output_file: fh_causal/' > ${i}.fh
done


