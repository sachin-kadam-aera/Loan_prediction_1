library(forecast)
library(bsts)
format_negatives<-function(x){
  try(x[x<0]<-0,silent=TRUE)
  return(x)
}
auto_arima_fractal <- function(data,holdout_months,horizon_in_months,time_period) {

#prepare preprocessing
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = 52)
  print(x)
  #model data
  fit <- auto.arima(x,seasonal=TRUE,start.p=1)
  print(summary(fit)) 
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)
  
  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  mean <- data.frame(forecast$mean)
  
  colnames(mean) <- c("Forecast")
  mean['Low95PI']=NA
  mean['High95PI']=NA
  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  mean['Low90PI']=forecast_90['Lo 90']
  mean['High90PI']=forecast_90['Hi 90']
  
  # Prepare output
  a1 = rbind(fitted,mean)
  return (a1)
}

generate_BI_BSTS <- function(data,holdout_months,horizon_in_months,time_period){

   #data = data[order(data$weekyear,)]
   data1 = data[data$weekyear >= 201740,]
   data1$Sales_log = log1p(data1$Sales)
   data = data[data$weekyear < 201740,]

  #model data
  #time_period = as.integer(time_period)
  #data$Sales = Train_Sales
  #data1$Sales = Test_Sales
  data$Sales=ts(data$Sales,frequency = 13)
  data$Sales_log<-ts(log1p(data$Sales),frequency = 13)

  imp_variables<-names(data[,c(1:ncol(data))])
  imp_variables<-imp_variables[!imp_variables %in% c("dim_partid","dd_level2","comop","weekyear","Sales","Sales_log")]
  Formula<-as.formula(paste("Sales~",paste(imp_variables,sep = "",collapse = "+")))

  Formula_log<-as.formula(paste("Sales_log~",paste(imp_variables,sep = "",collapse = "+")))


  ss1<- AddSeasonal(list(),data$Sales, nseasons = 13)
  ss1<-AddSemilocalLinearTrend(ss1,data$Sales)
  ss1<-AddSeasonal(ss1,data$Sales,nseasons =13,season.duration = 4)

  ss2<- AddSeasonal(list(),data$Sales_log, nseasons = 13)
  ss2<-AddSemilocalLinearTrend(ss2,data$Sales_log)
  ss2<-AddSeasonal(ss2,data$Sales_log,nseasons =13 ,season.duration = 4)
                                                                                                                     
  #ss2<-AddSemilocalLinearTrend(ss2,data$Sales_log)
  #ss2<-AddSeasonal(ss2,data$Sales_log,nseasons =13 ,season.duration = 4)

  fit <- bsts(Formula, state.specification = ss1, data = data, niter = 1000, ping=0, seed=2016)
  fit_log <- bsts(Formula_log, state.specification = ss2, data = data, niter = 1000, ping=0, seed=2016)

  #fit <- bsts(x, state.specification = ss1, niter = 1000, ping=0, seed=2016)
  burn1 = 500
  forecast <-predict.bsts(fit, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast_log <-predict.bsts(fit_log, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))

  #training fit

  fitted <- (-colMeans(fit$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales))
  fitted <- data.frame(as.numeric(fitted))
  mean <- data.frame(as.numeric(forecast$mean))

  #  burn1 = 100
  fitted_log <- (-colMeans(fit_log$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales_log))
  fitted_log <- data.frame(as.numeric(expm1(fitted_log)))
  mean_log <- data.frame(as.numeric(expm1(forecast_log$mean)))


  colnames(fitted)<- c('Forecast_bstsx')
  colnames(mean)<- c('Forecast_bstsx')

  colnames(fitted_log)<- c('Forecast_bstsx')
  colnames(mean_log)<- c('Forecast_bstsx')

  # Prepare output

  a1 = rbind(fitted,mean)
  a2 = rbind(fitted_log,mean_log)

  a1$Forecast_bstsx = format_negatives(a1$Forecast_bstsx)
  a2$Forecast_bstsx = format_negatives(a2$Forecast_bstsx)

  actual = data1$Sales[1:13]; pred = mean$Forecast_bstsx[1:13] ; pred_log = mean_log$Forecast_bstsx[1:13]
  ind  = which(actual != 0 );  actual_1 = actual[ind]; pred1 = pred[ind] ; pred2 = pred_log[ind]

  mape_ex1<-mean(abs((pred1-actual_1)/actual_1))
  mape_ex2<-mean(abs((pred2-actual_1)/actual_1))


  if(mape_ex1<= mape_ex2){final_out = a1 }
  else {final_out = a2}
  return (final_out)
                                                                                                                                                                             
  #training fit

  fitted <- (-colMeans(fit$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales))
  fitted <- data.frame(as.numeric(fitted))
  mean <- data.frame(as.numeric(forecast$mean))

  #  burn1 = 100
  fitted_log <- (-colMeans(fit_log$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales_log))
  fitted_log <- data.frame(as.numeric(expm1(fitted_log)))
  mean_log <- data.frame(as.numeric(expm1(forecast_log$mean)))


  colnames(fitted)<- c('Forecast_bstsx')
  colnames(mean)<- c('Forecast_bstsx')

  colnames(fitted_log)<- c('Forecast_bstsx')
  colnames(mean_log)<- c('Forecast_bstsx')

  # Prepare output

  a1 = rbind(fitted,mean)
  a2 = rbind(fitted_log,mean_log)

  a1$Forecast_bstsx = format_negatives(a1$Forecast_bstsx)
  a2$Forecast_bstsx = format_negatives(a2$Forecast_bstsx)

  actual = data1$Sales[1:13]; pred = mean$Forecast_bstsx[1:13] ; pred_log = mean_log$Forecast_bstsx[1:13]
  ind  = which(actual != 0 );  actual_1 = actual[ind]; pred1 = pred[ind] ; pred2 = pred_log[ind]

  mape_ex1<-mean(abs((pred1-actual_1)/actual_1))
  mape_ex2<-mean(abs((pred2-actual_1)/actual_1))


  if(mape_ex1<= mape_ex2){final_out = a1 }
  else {final_out = a2}


  #print(a2)
  return (final_out)
}
sales =  read.csv(file="onepart_bivariate.csv", header=TRUE, sep=",")
output = generate_BI_BSTS(sales,13,13,52)
print(output)
