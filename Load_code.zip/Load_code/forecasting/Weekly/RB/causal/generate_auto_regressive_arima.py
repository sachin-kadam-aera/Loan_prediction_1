# -*- coding: utf-8 -*-
"""
Created by Shravan Shetty
Generates non seasonal AR model. Calculates best AR value depending on the AIC
value of the model.
"""

import pandas as pd
import statsmodels.api as sm
import numpy as np
from numpy import linalg
from split_forecast_input import split_forecast_input
from forecast_error import forecast_error, get_confidence_interval
import  forecast_config
import datetime
# Update forecast configuration parameter
conf_read_input = forecast_config.getConfig('RunScript')
time_frequency = forecast_config.getConfig('RunScript')['time_frequency']

def get_forecast_auto_regressive(data1, UIN, Comop, last_date, holdout_date, horizon_in_months):
    if len(data1[data1.YYYYMM < holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']):  # this ensures min. 2 year of data for forecasting
        print UIN, "insufficient historical data"
        return
    # horizon_in_months = 24
    # Prepare Training and Test dataset
    data2, X, Y, Xtest, Ytest = split_forecast_input(data1, UIN, Comop, holdout_date, last_date, horizon_in_months)
    if time_frequency == "Monthly":
        date_format='%Y%m'
    elif time_frequency == "Weekly":
        date_format='%Y%W'
    else:
        date_format='%Y%m'
    data3=data2[:len(Y)]
    data3['YYYYMM']=data3['YYYYMM'].astype(str)
    data3['date']=data3.apply(lambda x: datetime.datetime.strptime(x['YYYYMM'] + '-1',"%Y%W-%w"), axis=1)
    Y.index = data3.date
    #Y.index = pd.to_datetime(data2.YYYYMM[:len(Y)], format=date_format,  dayfirst='True')
   # Y.index = pd.to_datetime(data2.YYYYMM[:len(Y)], format=date_format)    
    ## Optimzed Auto regressor for AR models

    Y['Sales'] = Y['Sales'].astype(np.float)
    # Model building: Finding the best AR
    try:
        AR_mod20 = sm.tsa.ARMA(Y, (1, 0)).fit(disp=False)
        minModel = AR_mod20

        for i in range(2, 4):
            AR_mod20 = sm.tsa.ARMA(Y, (i, 0)).fit(disp=False)
            if AR_mod20.aic < minModel.aic:
                minModel = AR_mod20
        # Forecasting
        data3=data2.copy(deep=True)
        data3['YYYYMM']=data3['YYYYMM'].astype(str)
        data3['date']=data3.apply(lambda x: datetime.datetime.strptime(x['YYYYMM'] + '-1',"%Y%W-%w"), axis=1)
        Ytest.index = data3.date
        #Ytest.index = pd.to_datetime(data2.YYYYMM, format=date_format)
        Y_pred1 = minModel.fittedvalues.append(pd.DataFrame(minModel.forecast(len(Ytest) - len(Y))[0]))
        Y_pred1.index = Ytest.index = range(0, len(Ytest))
        Y_pred1.columns = ['Forecast']
        Y_pred1.Forecast = Y_pred1.Forecast.apply(lambda x: max(1, x))

        ## Get the forecast error (APE)
        Y_compare = forecast_error(data2, Ytest, Y_pred1, holdout_date, last_date)

        # Printing MAPE to confirm correct results during development
        print "AR-AIC: UIN =", UIN, "Comop=", Comop, "MAPE =", Y_compare.APE.mean(), "Bias= ", \
        Y_compare.Bias_Error.iloc[1]

        # Return full dataset with
        # Columns for Forecast, MAPE and Forecast_Type
        Y_return = pd.DataFrame(data2).join(Y_pred1)
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['MAPE'] = Y_compare.APE.mean()  # This is a single number
        Y_return['Forecast_Type'] = 'Auto-Regressive'
    except ValueError as e:
        print UIN, "ValueError in AR Step", e
        return
    except linalg.LinAlgError:
        print UIN, "SVD Error: Did not Converge in AR step"
        return
    except Exception as e:
        print "Exception in AR step:  ", e
        return
    return Y_return
