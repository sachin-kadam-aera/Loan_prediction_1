sleep 7200
cp forecast.ini.bkp.201819_201831 forecast.ini
nohup ./main.py 1>fhrb.log 2>fhrb.err
