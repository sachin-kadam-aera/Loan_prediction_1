#!/bin/sh
set -x

if [ $# -eq 3 ]
then
lastdt_yyyyww=$1
hodate=$2
rptdate=$3
else
echo "The 3 required parameters were not passed"
echo "Pass lastdt_yyyyww, hodate and rptdate as parameters e.g
201827 201819 '11 JUL 2018' "

read lastdt_yyyyww hodate rptdate
fi

echo "Passed params are $lastdt_yyyyww,$hodate,$rptdate"

#Check if fractal forecast output files exist 
efs_fcstoutputdirectory="/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_$lastdt_yyyyww"
fractal_regfile=${efs_fcstoutputdirectory}/frac_r.csv
fractal_rfhfile=${efs_fcstoutputdirectory}/frac_rfh.csv

if [ ! -f ${efs_fcstoutputdirectory}/Fractal_Output_9Methods.csv ]
then
echo "${efs_fcstoutputdirectory}/Fractal_Output_9Methods.csv does not exist. Please copy it from fcst07 and rerun this script"
exit 2
fi

if [ ! -f ${efs_fcstoutputdirectory}/Fractal_Output_XGBoost.csv ]
then
echo "${efs_fcstoutputdirectory}/Fractal_Output_XGBoost.csv does not exist. Please copy it from fcst06 and rerun this script"
exit 2
fi

#Combine the 9 meth and xgb files
cp ${efs_fcstoutputdirectory}/Fractal_Output_9Methods.csv ${efs_fcstoutputdirectory}/Fractal_Output_10Methods.csv
sed -n '2,$p' ${efs_fcstoutputdirectory}/Fractal_Output_XGBoost.csv >> ${efs_fcstoutputdirectory}/Fractal_Output_10Methods.csv

#Generate reg and rfh files
/home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/fcstlib/convertfractoaera.py ${efs_fcstoutputdirectory}/Fractal_Output_10Methods.csv $hodate $lastdt_yyyyww "$rptdate"

mv frac_r.csv $fractal_regfile
mv frac_rfh.csv $fractal_rfhfile

gzip $fractal_regfile $fractal_rfhfile

echo "Created ${fractal_regfile}.gz
and
${fractal_rfhfile}.gz"

mkdir ${efs_fcstoutputdirectory}/archive
mv ${efs_fcstoutputdirectory}/Fractal_Output*csv ${efs_fcstoutputdirectory}/archive
