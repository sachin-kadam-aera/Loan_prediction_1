import pandas as pd
import numpy as np
import datetime as dt


def impute_data(data0, last_date):
    imputed_data=pd.DataFrame()
    grain_list=data0.grain.unique()
    for grain in grain_list:
        data=data0[data0['grain']==grain]
        data1=data.copy(deep=True)
        start_date=data1['DATEVALUE'].min()
        data1.set_index('DATEVALUE', inplace=True)
        all_days = pd.date_range(start_date, last_date, freq='D')
        data2=data1.reindex(all_days)
        data2['DATEVALUE']=data2.index
        data2['grain']=grain
        if imputed_data.empty:
            imputed_data=data2
        else:
            imputed_data=imputed_data.append(data2)

    shape=imputed_data.shape[0]+1
    index_array=np.arange(1,shape)  
    imputed_data.set_index(index_array, inplace=True)
    imputed_data.replace(np.nan,0, inplace=True)

    return imputed_data


def week_agg(data0):  
    daily_Data=data0 
    single_date=[0, 1, 2, 3, 4, 5, 6,7, 8, 9]
    ###GETTING WEEK AND CONVERTING 1 DIGHT WEEK TO 2, EX: WEEK NUMBER = 1 TO WEEK NUMBER = 01 ######
    daily_Data['week']=daily_Data.apply(lambda x: ('0'+str(x['DATEVALUE'].isocalendar()[1])) if (x['DATEVALUE'].isocalendar()[1] in(single_date)) else str(x['DATEVALUE'].isocalendar()[1]) ,axis=1)
    ##### GETTING YEAR. USING SAME FUNCTION SO year and week won't unmatch ######
    daily_Data['YYYYWW']=daily_Data.apply(lambda x: (str(x['DATEVALUE'].isocalendar()[0])+str(x['week'])) ,axis=1)
    daily_Data1=daily_Data[['grain', 'YYYYWW', 'QTY_ORDERED']]
    daily_Data2=daily_Data1.groupby(['grain', 'YYYYWW']).agg({'QTY_ORDERED':['sum']}).reset_index()
    daily_Data2.columns=daily_Data2.columns.droplevel(1)
    d1=daily_Data2.copy(deep=True)
    d1['Week']=d1['YYYYWW'].astype(str).str[4:]
    return d1


####DAILY DATA FROM STAGING##########
daily_Data=pd.read_csv('rb_historysku10-bu2_dailydata.csv')
daily_Data['DATEVALUE'] = pd.to_datetime(daily_Data['DATEVALUE'])
daily_Data['grain']=daily_Data['BASE_ITEM'].astype(str)+'--'+daily_Data['BUSINESS_UNIT'].astype(str)
daily_Data.drop(['BASE_ITEM','BUSINESS_UNIT'], axis=1, inplace=True)

####IMPUTING DATA#####
#####ADDING MISSING WEEKS WITH 0 SALES, NOTHING ELSE TO IMPUTE#####
imputed_data1=impute_data(daily_Data,'2018-09-30')

###### AGGREGATING DATA AT WEEK LEVEL######
final_input_data=week_agg(imputed_data1)

####FORMATTING DATA FOR FINAL INPUT######
final_input_data['SKU']=final_input_data['grain'].astype(str).str[:11]
final_input_data['BU']=final_input_data['grain'].astype(str).str[13:]
final_input_data['comop']='abc'
#final_input_data.drop(['grain'], inplace=True)
final_input_data1=final_input_data[['SKU', 'BU', 'comop', 'YYYYWW', 'QTY_ORDERED']]

final_input_data1.to_csv('saleshistory_weekly.csv.fh', index=False, header=False)
