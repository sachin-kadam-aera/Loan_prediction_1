#!/bin/sh
set -x
aerafcstdirectory="/home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/result/RECKITT_BENCKISER"


#set -x
#Last Date needs to be passed as a parameter. It should be of 6 char with form yyyyww
lastdt_yyyyww=`/efs/datascience/Reckitt7B8/scripts/postprocessingscripts/check_lastdtparam.sh $1`
if [ $? -ne 0 ]
then
exit 1
fi
echo $lastdt_yyyyww

#If directory does not exist, create it and give permissions so that other users can also write to it(e.g from 06 and 07 servers)
if [ ! -d /efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_$lastdt_yyyyww ]
then
mkdir /efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_$lastdt_yyyyww
chmod 777 /efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_$lastdt_yyyyww
fi

efs_fcstoutputdirectory="/efs/datascience/Reckitt7B8/forecastoutputfiles/fcst_$lastdt_yyyyww"
aera_regfile=${efs_fcstoutputdirectory}/reg_aera.csv
aera_rfhfile=${efs_fcstoutputdirectory}/rfh_aera.csv

for i in ${aerafcstdirectory}/*${lastdt_yyyyww}*gz
do
gunzip $i
done

#Single reg file
cp ${aerafcstdirectory}/*r_univariate*${lastdt_yyyyww}*csv $aera_regfile
sed -n '2,$p' ${aerafcstdirectory}/*r_multivariate*${lastdt_yyyyww}*csv >> $aera_regfile

#Single rfh file
cp ${aerafcstdirectory}/*rfh_univariate*${lastdt_yyyyww}*csv $aera_rfhfile
sed -n '2,$p' ${aerafcstdirectory}/*rfh_multivariate*${lastdt_yyyyww}*csv >> $aera_rfhfile

gzip $aera_regfile $aera_rfhfile

echo "Created ${aera_regfile}.gz
and
${aera_rfhfile}.gz"

for i in ${aerafcstdirectory}/*${lastdt_yyyyww}*csv
do
gzip $i
done
