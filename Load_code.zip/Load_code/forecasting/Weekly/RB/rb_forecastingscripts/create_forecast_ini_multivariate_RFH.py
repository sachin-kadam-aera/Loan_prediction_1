#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon Aug 13 16:54:28 2018

@author: priyankahole
"""


import pandas as pd
import sys

para = pd.read_csv('/home/fusionops/datascience/forecasting/weekly/RB//Fractal_Codes/Codes_USA/Week_Mapping.csv')
HOLDOUT_PERIOD,YEAR,WEEK = sys.argv[1],sys.argv[2],sys.argv[3]
ho_para = para[para['Week_No'].isin((para[(para['Year']==int(YEAR)) & (para['Week']==int(WEEK))]['Week_No'] + int(HOLDOUT_PERIOD)))]

last_date = str(ho_para.iloc[0]['Year']) + str(ho_para.iloc[0]['Week']).zfill(2)
holdout_date = str(YEAR)+str(WEEK).zfill(2)
month = str(YEAR)+str(WEEK).zfill(2)+str(HOLDOUT_PERIOD)

filename1 = "rfh_saleshistory_sku10_weekly_multivariate.csv" #"rfh_saleshistory_sku10_weekly.csv"#sys.argv[1]
data = pd.read_csv("/home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/data/RECKITT_BENCKISER/"+filename1+month,header=None)
col = list(data.columns)
col.sort()
col_name = []
for i in range(len(col)-5):
    col_name.append('a'+str(i))

print last_date
path1 = "/home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/"
path = "/efs/datascience/Reckitt7B8/scripts/"
last_date = str(last_date)
filename = path+filename1
print filename
holdout_date = str(holdout_date)
print last_date
print holdout_date




#import datetime
#dt = datetime.datetime.now().strftime ("%d%b%y")

f = open(path1+"forecast.ini","w")

f.write("[RunScript]")
f.write("\n")
f.write("run_type:1")
f.write("\n")
f.write("company:RECKITT_BENCKISER")
f.write("\n")
f.write("input_file:"+filename1+month)
print "input_file:"+filename1+month
f.write("\n")
f.write("output_file:rb_forecast_result_rfh_multivariate_"+month+".csv")
print "output_file:rb_forecast_result_rfh_multivariate.csv"+month
f.write("\n")
f.write("holdout_date:"+holdout_date)#%holdout_date
f.write("\n")
f.write("last_date:"+last_date)#%last_date
f.write("\n")
f.write("demand_capping:1000000000")
f.write("\n")
f.write("num_process:30")
f.write("\n")
f.write("input_columns:UIN,Comop,CompanyCode,YYYYMM,Sales,"+",".join(col_name))
#print "input_columns:UIN,Comop,CompanyCode,YYYYMM,Sales,"+",".join(col_name)
f.write("\n")
f.write("separator:,")
f.write("\n")
f.write("min_training_period:26")
f.write("\n")
f.write("horizon_period:78")
f.write("\n")
f.write("time_frequency:Weekly")
f.write("\n")
#f.write("batch_size:1000")
#f.write("\n")
f.write("minimum_quantity:1")
f.write("\n")
f.write("efs_dir:"+holdout_date)
f.write("\n")
f.close()
