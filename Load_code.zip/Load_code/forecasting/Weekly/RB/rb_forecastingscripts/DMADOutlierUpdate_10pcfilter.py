# -*- coding: utf-8 -*-
"""
2reated on Mon Apr 10 17:09:35 2017

@author: vikranthole
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from pylab import *
import sys


def doubleMADsfromMedian(y,thresh=4):
    #uses L1 distance instead of L2 distance, and has support for asymmetric distributions
    # warning: this function does not check for NAs
    # nor does it address issues when
    # more than 50% of your data have identical values
    m = np.median(y)
    abs_dev = np.abs(y - m)
    left_mad = np.median(abs_dev[y <= m])
    right_mad = np.median(abs_dev[y >= m])
    y_mad = left_mad * np.ones(len(y))
    y_mad[y > m] = right_mad
    modified_z_score = 0.6745 * abs_dev / y_mad
    modified_z_score[y == m] = 0
    return modified_z_score > thresh



def outlierHandling(data):

    mean = str(round(data.Sales.mean(),0))
    try:
        #print data
        data['Actual'] = data.Sales
        outlier_data = data[doubleMADsfromMedian(data.Sales)]
        data.Sales[data.Sales.isin(outlier_data.Sales)]  = mean
        data['Difference'] = data['Actual'].astype(np.float) - data['Sales'].astype(np.float)
        data['Difference'] = data['Difference'].apply(lambda x: 1 if x!=0 else 0)
        total = data['Difference'].count()
        outlier_count = data['Difference'].sum()
        #print total,outlier_count
        if outlier_count/float(total) > 0.1:
            data['Sales'] = data['Actual']
        data = data.drop('Actual', 1)
        data = data.drop('Difference', 1)
    except:
        pass
    #print data
    return data

def  outlier(inputdata):

    inputdata.YYYYMM = inputdata.YYYYMM.astype('int')
    inputdata.Sales = inputdata.Sales.astype('int')

    outlier_handle_data = inputdata.groupby(['UIN','Comop']).apply(outlierHandling)
    complete_data = [outlier_handle_data]
    df = pd.concat(complete_data, ignore_index=True)
   # print df['YYYYMM'].unique()
    df['YYYYMM'] = df['YYYYMM'].apply(lambda x: int(x))
    df['Sales'] = df['Sales'].apply(lambda x: float(x))
    return df

input_path = sys.argv[1]

def outlier_count(originaldata,outlierdata):
    #originaldata.to_csv('OriginalSalesHistory.csv',index =False)
    combine_data = pd.merge(originaldata, outlierdata, left_on=['UIN', 'Comop',u'CompanyCode',u'YYYYMM'], \
                right_on=['UIN', 'Comop',u'CompanyCode',u'YYYYMM'], how='inner')
    combine_data.columns = ['UIN', 'Comop',u'CompanyCode',u'YYYYMM', u'Sales_regular', u'Sales_dmad']
    combine_data['Diffrence'] = combine_data[u'Sales_dmad'] - combine_data[u'Sales_regular']

    combine_data['Diffrence'] = combine_data['Diffrence'].apply(lambda x: 0 if x==0 else 1)

    sales_summ = combine_data.groupby(['UIN', 'Comop']).agg({'Diffrence':np.sum})
    sales_summ = sales_summ.reset_index()

    dmad_imputed_data = sales_summ[sales_summ.Diffrence > 0]

    dmad_imputed_data.head()
    dmad_imputed_data = dmad_imputed_data[['UIN', 'Comop']]
    original = pd.merge(dmad_imputed_data, originaldata, left_on=['UIN', 'Comop'], \
            right_on=['UIN', 'Comop'], how='inner')
    dmad = pd.merge(dmad_imputed_data, outlierdata, left_on=['UIN', 'Comop'], \
            right_on=['UIN', 'Comop'], how='inner')
    original.to_csv(input_path[:-4]+'_orginal_sales_with_outlierparts_10percent_filter.csv',index = False,header=False)
    dmad.to_csv(input_path[:-4]+'_dmad_sales_history_with_outlierparts_10percent_filter.csv',index = False,header=False)




data = pd.read_csv(input_path, sep=',', low_memory=False, header=None, \
                       names=['UIN', 'Comop',u'CompanyCode',u'YYYYMM','Sales'],dtype={'UIN': np.str, 'CompanyCode': np.str,'Comop':np.str,u'YYYYMM':int})
data.Sales = data.Sales.apply(lambda x: max(0, x))

final_data = []
data['grain'] = data['UIN'] + data['Comop']
grain_list = list(data.grain.unique())
grain_list = [x for x in grain_list if str(x) != 'nan']
for grain in grain_list:
  #  print grain
    data1 = data[data.grain == grain]
    data1 = data1.drop('grain', 1)
    data1 = outlier(data1)
    final_data.append(data1)

data = data.drop('grain', 1)
comp = pd.concat(final_data)
comp.head()
#outlier_count(originaldata,outlierdata)
outlier_count(data,comp)
