import pandas as pd
import sys
import os


HOLDOUT_PERIOD,YEAR,WEEK = sys.argv[1],sys.argv[2],sys.argv[3]
month = str(YEAR)+str(WEEK).zfill(2)+str(HOLDOUT_PERIOD)

print '/efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_skudmdcust_weekly_aera.csv'+month
os.system('cp /efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_skudmdcust_weekly_aera.csv'+month +' /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/data/RECKITT_BENCKISER/')
os.system('cp /efs/datascience/Reckitt7B8/data/input/rfh_saleshistory_sku10_weekly_multivariate.csv'+month +' /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts/data/RECKITT_BENCKISER/')



