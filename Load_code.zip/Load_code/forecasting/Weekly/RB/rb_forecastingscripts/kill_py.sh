#!/bin/sh

for i in `ps -ef|grep main.py|grep python|awk '{print $2}'`; do kill -9 $i; done
