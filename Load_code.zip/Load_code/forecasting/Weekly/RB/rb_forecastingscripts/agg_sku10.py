#!/bin.python

df=pd.read_csv('rfh_saleshistory_sku10bu_weekly.csv',header=None)
df1=df.groupby([0,2,3]).sum()
df1.to_csv('rfh_saleshistory_sku10bu_weekly_aggbysku.csv.csv')
