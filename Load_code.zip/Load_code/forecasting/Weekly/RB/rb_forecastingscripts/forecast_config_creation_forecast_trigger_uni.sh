#!/bin/bash
echo 'Connected forecast01.......'
# Path data
#//home/fusionops/RB/datascience/forecasting/weekly/RB/rb_forecastingscripts/data/RECKITT_BENCKISER/
# file name should be rfh_saleshistory_sku10_weekly_v1.csv

# after preprocessing output file name
# file name should be rfh_saleshistory_sku10_weekly_v1.csv

#create ini file for Regular univariate
cd /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts 
python create_forecast_ini_univariate_R.py $1 $2 $3

#Triggered Regular forecast univariate
cd /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts
python ./main_doesnothave_hw_rf_multivariate.py 1> rb_1.log 2>rb_1.err 
echo 'Regular Forecast Completed.... Univariate'

#create ini file for RFH univariate
cd /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts
python create_forecast_ini_univariate_RFH.py $1 $2 $3

#Triggered RFH forecast univariate
cd /home/fusionops/datascience/forecasting/weekly/RB/rb_forecastingscripts
python ./main_doesnothave_hw_rf_multivariate.py 1> rb_2.log 2>rb_2.err 
echo 'Regular Full History Forecast Completed....Univariate'



cd /efs/datascience/Reckitt7B8/data/
chmod 777 output

