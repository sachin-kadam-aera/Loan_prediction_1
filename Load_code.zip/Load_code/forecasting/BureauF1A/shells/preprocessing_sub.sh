#!/bin/bash
echo 'Connecting forecast01 ...'
webservice_path=$1
token=$2
outlier=$3

echo Preprocessing R scripts ...

export PATH=/opt/anaconda2/bin/:$PATH
cd /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/
Rscript --vanilla ./src/customer_submissions_multivariate.R $webservice_path $token $outlier
echo preprocessing R scripts shell script finished ..
