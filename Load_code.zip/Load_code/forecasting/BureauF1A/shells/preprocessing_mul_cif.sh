#!/bin/bash
echo 'Connecting forecast01 ...'
webservice_path=$1
token=$2

echo Preprocessing R scripts ...

export PATH=/opt/anaconda2/bin/:$PATH
cd /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/
Rscript --vanilla ./src/customer_inspections_multivariate.R $webservice_path $token
echo preprocessing R scripts shell script finished ..
