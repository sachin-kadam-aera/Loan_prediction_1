#!/bin/bash
echo 'Connecting forecast01 ...'

forecast_start_date=$1


export PATH=/opt/anaconda3/bin/:$PATH


echo Preprocessing combined xgb and rf scripts started ...

cd /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/
python ./src/combined_xgb_rf.py $forecast_start_date 

echo Preprocessing combined xgb and rf scripts started ...


