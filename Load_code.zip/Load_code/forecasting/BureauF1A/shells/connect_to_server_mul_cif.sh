#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on...

webservice_path=$1
token=$2
HOST=$3

echo "token: "$token
echo "webservice_path: "$webservice_path
echo "HOST: "$HOST
echo "This script call Forecast01 UAT-IRL script"

echo "This script call Forecast01 UAT-IRL script"
status=$(ssh -o BatchMode=yes -o ConnectTimeout=5 fusionops@$HOST echo ok 2>&1)
if [[ $status == ok ]]; then
        echo SSH passed to target server, moving on... Forecast01 after Preprocessing -
        ssh -o StrictHostKeyChecking=no fusionops@$HOST "/efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/shells/preprocessing_mul_cif.sh $webservice_path $token"

elif [[ $status == "Permission denied"* ]] ; then
    echo I am unable to communicate to target host PPPPPPPPPPPPPPPPPPPP
fi
