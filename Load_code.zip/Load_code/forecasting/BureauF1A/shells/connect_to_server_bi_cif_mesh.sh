#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on...

webservice_path=$1
token=$2
HOST=$3

echo "token: "$token
echo "webservice_path: "$webservice_path
echo "HOST: "$HOST
echo "This script call Forecast01 UAT-IRL script"

echo "This script call Forecast01 UAT-IRL script"
# status=$(ssh -o BatchMode=yes -o ConnectTimeout=5 fusionops@$HOST echo ok 2>&1)
# if [[ $status == ok ]]; then
#         echo SSH passed to target server, moving on... Forecast01 after Preprocessing -
#         ssh -o StrictHostKeyChecking=no fusionops@$HOST "/efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/shells/preprocessing_bi_cif.sh $webservice_path $token"
# 
# elif [[ $status == "Permission denied"* ]] ; then
#     echo I am unable to communicate to target host PPPPPPPPPPPPPPPPPPPP
# fi

success_response="Server is running"
status_message="success"

response=$(curl -s $HOST | cut -d '"' -f 2)
echo "Responce:"$response

if [[ "$response" == "$success_response" ]];
	then
		echo "Running Script..."
		status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/shells/preprocessing_bi_cif.sh '$webservice_path' '$token' "}')
	echo 'status o/p-'$status
	if [[ "$status" == "$status_message" ]];
		then
		echo "Successfully executed the script"
	else
		echo "Unable to execute the script"
	fi
else
	echo "Unable to connect to server"
fi
