#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on...

HOST=$1
forecast_start_date=$2

echo "HOST: "$HOST
echo "forecast_start_date:"$forecast_start_date

echo "This script call Forecast01 UAT-IRL script"

response=$(curl -s $HOST | cut -d '"' -f 2)
echo "Responce:"$response


if [[ "$response" == "Server is running" ]];
	then
		echo "Running Submission R Script..."
		status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/shells/combined_xgb_rf.sh '$forecast_start_date' "}')
echo 'script o/p-'$status
else

echo 'Unable to run the script'
fi
