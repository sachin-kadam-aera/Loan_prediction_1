#!/bin/bash
echo 'Connecting forecast01 ...'
webservice_path=$1
token=$2
normalise_submission_flag=$3
normalise_inspection_flag=$4

echo Preprocessing R scripts ...

export PATH=/opt/anaconda2/bin/:$PATH
cd /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/
Rscript --vanilla ./src/combine.R $webservice_path $token $normalise_submission_flag $normalise_inspection_flag
echo preprocessing R scripts shell script finished ..
