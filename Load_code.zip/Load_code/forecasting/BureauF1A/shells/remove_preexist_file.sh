#!/bin/bash
set -o errexit

USER1=$(whoami)

rm -f /efs/datascience/BureauF1A/output/combined_xgb_rf_input.csv
echo 'already exits file is remove'
