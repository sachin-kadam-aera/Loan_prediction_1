#!/bin/bash
set -o errexit

USER1=$(whoami)
echo SSH passed to target server, moving on...

webservice_path=$1
token=$2
HOST=$3

echo "token: "$token
echo "webservice_path: "$webservice_path
echo "HOST: "$HOST
echo "This script call Forecast01 UAT-IRL script"

echo "This script call Forecast01 UAT-IRL script"


if [[ "$response" == "$success_response" ]];
	then
		echo "Running Script..."
		status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/shells/preprocessing_sea_inspection.sh '$webservice_path' '$token' "}' | jq -r '.status' )
	if [[ "$status" == "$status_message" ]];
		then
		echo "Successfully executed the script"
	else
		echo "Unable to execute the script"
	fi
else
	echo "Unable to connect to server"
fi