#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on...

webservice_path=$1
token=$2
HOST=$3
forecast_start_date=$4

echo "token: "$token
echo "webservice_path: "$webservice_path
echo "HOST: "$HOST

echo "This script call Forecast01 UAT-IRL script"

response=$(curl -s $HOST | cut -d '"' -f 2)
echo "Responce:"$response


if [[ "$response" == "Server is running" ]];
	then
		echo "Running Submission R Script..."
		status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/shells/run_stepwise_submission.sh '$webservice_path' '$token' '$forecast_start_date' "}')
echo 'script o/p-'$status
fi


