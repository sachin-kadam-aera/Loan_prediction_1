#!/bin/bash
echo 'Connecting forecast01 ...'
webservice_path=$1
token=$2
forecast_start_date=$3

echo Preprocessing R scripts ...

export PATH=/opt/anaconda3/bin/:$PATH

cd /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/
Rscript --vanilla ./src/submissions_input_china.R $webservice_path $token
echo preprocessing R scripts shell script finished ..

echo Preprocessing R scripts finished ...
