/*

create table fact_bv_preprocessed_data
(
fact_bv_preprocessed_dataid decimal(36,0),
dd_Product_Line varchar(100),	
DD_Operating_Office varchar(100),	
dd_SBU varchar(100),
dd_month_start_date date,
dd_Month_Label varchar(15),
dd_date_year varchar(4),
ct_Volume decimal(36,4),
dd_Month_Working_Days varchar(2),
dd_Number_of_Holidays varchar(2),
ct_sin_month decimal(18,4),
ct_cos_month decimal(18,4),
ct_T5 decimal(18,4),
ct_T6 decimal(18,4),
ct_T7 decimal(18,4),
ct_T8 decimal(18,4),
ct_T9 decimal(18,4),
ct_T10 decimal(18,4),
ct_T11 decimal(18,4),
ct_T12 decimal(18,4),
ct_diff5 decimal(18,4),	
ct_diff6 decimal(18,4),
ct_diff7 decimal(18,4),
ct_diff8 decimal(18,4),
ct_diff9 decimal(18,4),
ct_diff10 decimal(18,4),
ct_diff11 decimal(18,4),
ct_avg3m decimal(18,4),
ct_avg6m decimal(18,4),
ct_SFDC decimal(18,4),
ct_EDI decimal(18,4),
ct_Quotations decimal(18,4),
 dd_latestreporting_flag varchar(1),
dd_snapshotdate varchar(15)
)

*/
drop table if exists  tmp_bv_preprocessed_data;
create table tmp_bv_preprocessed_data
(
dd_Product_Line varchar(100),	
DD_Operating_Office varchar(100),	
dd_SBU varchar(100),
dd_month_start_date date,
dd_Month_Label varchar(15),
dd_date_year varchar(4),
ct_Volume decimal(36,4),
dd_Month_Working_Days varchar(2),
dd_Number_of_Holidays varchar(2),
ct_sin_month decimal(18,4),
ct_cos_month decimal(18,4),
ct_T5 decimal(18,4),
ct_T6 decimal(18,4),
ct_T7 decimal(18,4),
ct_T8 decimal(18,4),
ct_T9 decimal(18,4),
ct_T10 decimal(18,4),
ct_T11 decimal(18,4),
ct_T12 decimal(18,4),
ct_diff5 decimal(18,4),	
ct_diff6 decimal(18,4),
ct_diff7 decimal(18,4),
ct_diff8 decimal(18,4),
ct_diff9 decimal(18,4),
ct_diff10 decimal(18,4),
ct_diff11 decimal(18,4),
ct_avg3m decimal(18,4),
ct_avg6m decimal(18,4),
ct_SFDC decimal(18,4),
ct_EDI decimal(18,4),
ct_Quotations decimal(18,4)
);

/* import outlier treated sales data into tmp table */
import into tmp_bv_preprocessed_data
(
dd_Product_Line,	
DD_Operating_Office,	
dd_SBU,
dd_month_start_date,
dd_Month_Label,
dd_date_year,
ct_Volume,
dd_Month_Working_Days,
dd_Number_of_Holidays,
ct_sin_month,
ct_cos_month,
ct_T5,
ct_T6,
ct_T7,
ct_T8,
ct_T9,
ct_T10,
ct_T11,
ct_T12,
ct_diff5,	
ct_diff6,
ct_diff7,
ct_diff8,
ct_diff9,
ct_diff10,
ct_diff11,
ct_avg3m,
ct_avg6m,
ct_SFDC,
ct_EDI,
ct_Quotations
)
from local CSV file '/efs/datascience/BureauF1A/output/bv_input_monthly.csv' 
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

DELETE FROM fact_bv_preprocessed_data f
WHERE EXISTS (SELECT 1 FROM stg_currentrunparam_mul_isf curr
WHERE curr.dd_reportingdate = f.dd_snapshotdate);


update fact_bv_preprocessed_data
set dd_latestreporting_flag = 'N' ;

/* Insert latest data from tmp to fact table with laster reporting flag */
insert into fact_bv_preprocessed_data
(
fact_bv_preprocessed_dataid,
dd_Product_Line,	
DD_Operating_Office,	
dd_SBU,
dd_month_start_date,
dd_Month_Label,
dd_date_year,
ct_Volume,
dd_Month_Working_Days,
dd_Number_of_Holidays,
ct_sin_month,
ct_cos_month,
ct_T5,
ct_T6,
ct_T7,
ct_T8,
ct_T9,
ct_T10,
ct_T11,
ct_T12,
ct_diff5,	
ct_diff6,
ct_diff7,
ct_diff8,
ct_diff9,
ct_diff10,
ct_diff11,
ct_avg3m,
ct_avg6m,
ct_SFDC,
ct_EDI,
ct_Quotations,
 dd_latestreporting_flag,
dd_snapshotdate
)
select 
(
select 
ifnull(max(fact_bv_preprocessed_dataID), 0) 
from fact_bv_preprocessed_data m) + row_number() 
over(order by '') as fact_bv_preprocessed_dataID,
dd_Product_Line,	
DD_Operating_Office,	
dd_SBU,
dd_month_start_date,
dd_Month_Label,
dd_date_year,
ct_Volume,
dd_Month_Working_Days,
dd_Number_of_Holidays,
round(ct_sin_month,2),
round(ct_cos_month,2),
ct_T5,
ct_T6,
ct_T7,
ct_T8,
ct_T9,
ct_T10,
ct_T11,
ct_T12,
round(ct_diff5,2),
round(ct_diff6,2),
round(ct_diff7,2),
round(ct_diff8,2),
round(ct_diff9,2),
round(ct_diff10,2),
round(ct_diff11,2),
ct_avg3m,
ct_avg6m,
ct_SFDC,
ct_EDI,
ct_Quotations,
'Y', curr.dd_reportingdate
from tmp_bv_preprocessed_data, stg_currentrunparam_mul_isf curr;


