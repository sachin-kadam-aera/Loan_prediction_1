DROP TABLE IF EXISTS tmp_submission_stepwise_input;
CREATE TABLE tmp_submission_stepwise_input
(
grain VARCHAR(100),
cos_dir_actual_xgb  VARCHAR(100),
cos_dir_actual_rf VARCHAR(100),
cos_slope_actual_xgb VARCHAR(100),
cos_slope_actual_rf VARCHAR(100),
choice VARCHAR(100),
defaulted_choice VARCHAR(100)
);

import into tmp_submission_stepwise_input
(             
grain,
cos_dir_actual_xgb,
cos_dir_actual_rf ,
cos_slope_actual_xgb,
cos_slope_actual_rf,
choice,
defaulted_choice
)
from local CSV FILE '/efs/datascience/BureauF1A/output/combined_xgb_rf_result.csv' 
ENCODING = 'UTF-8' ROW SEPARATOR = 'LF'  COLUMN SEPARATOR = ',' COLUMN DELIMITER = '"' SKIP = 1 REJECT LIMIT 0;
