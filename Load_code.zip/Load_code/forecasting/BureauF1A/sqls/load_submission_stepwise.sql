
DROP TABLE IF EXISTS tmp_submission_stepwise_input;
CREATE TABLE tmp_submission_stepwise_input
(         
DD_productline VARCHAR(100),
DD_Operating_Office VARCHAR(100),
DD_month_start_date VARCHAR(18),
CT_SUBMISSION decimal(18,4),
DD_Territory VARCHAR(100),
DD_Region VARCHAR(100),
CT_Month_Working_Days  decimal(3,0),
DD_MONTH_LABEL  VARCHAR(20),
CT_Number_of_holiday decimal(3,0)
);



CREATE TABLE IF not exists fact_submission_stepwise_input
(   
 fact_submission_stepwise_inputID  decimal(36,0),
DD_productline VARCHAR(100),
DD_Operating_Office VARCHAR(100),
DD_month_start_date VARCHAR(18),
CT_SUBMISSION decimal(18,4),
DD_Territory VARCHAR(100),
DD_Region VARCHAR(100),
CT_Month_Working_Days  decimal(3,0),
DD_MONTH_LABEL  VARCHAR(20),
CT_Number_of_holiday decimal(3,0),
dd_latestreporting_flag varchar(3),
dd_snapshotdate varchar(12)
);



import into tmp_submission_stepwise_input
(             
DD_productline,
DD_Operating_Office,
DD_month_start_date,
CT_SUBMISSION,
DD_Territory,
DD_Region,
CT_Month_Working_Days,
DD_MONTH_LABEL,
CT_Number_of_holiday
)
from local CSV FILE '/efs/datascience/BureauF1A/output/submissions_input_stepwise.csv' 
ENCODING = 'UTF-8' ROW SEPARATOR = 'LF'  COLUMN SEPARATOR = ',' COLUMN DELIMITER = '"' SKIP = 1 REJECT LIMIT 0;


DELETE FROM fact_submission_stepwise_input f
WHERE EXISTS (SELECT 1 FROM stg_currentrunparam_mul_isf curr
WHERE curr.dd_reportingdate = f.dd_snapshotdate);

update fact_submission_stepwise_input
set dd_latestreporting_flag = 'N' ;

insert into fact_submission_stepwise_input  (
fact_submission_stepwise_inputID,
DD_productline,
DD_Operating_Office,
DD_month_start_date,
CT_SUBMISSION,
DD_Territory,
DD_Region,
CT_Month_Working_Days,
DD_MONTH_LABEL,
CT_Number_of_holiday,
dd_latestreporting_flag ,
dd_snapshotdate
)
select
(
select ifnull(max(fact_submission_stepwise_inputID), 0)  from fact_submission_stepwise_input m) + row_number()  
over(order by '')  as fact_submission_stepwise_inputID,
 						
DD_productline,
DD_Operating_Office,
DD_month_start_date,
CT_SUBMISSION,
DD_Territory,
DD_Region,
CT_Month_Working_Days,
DD_MONTH_LABEL,
CT_Number_of_holiday,
'Y',
curr.dd_reportingdate
from tmp_submission_stepwise_input, stg_currentrunparam_mul_isf curr;

