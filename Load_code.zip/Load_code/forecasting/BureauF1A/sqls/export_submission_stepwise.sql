
EXPORT (select * from  tmp_stepwise_submission)
INTO LOCAL CSV FILE '/efs/datascience/BureauF1A/output/combined_xgb_rf_input.csv'  
COLUMN SEPARATOR = ',' with column names ;

