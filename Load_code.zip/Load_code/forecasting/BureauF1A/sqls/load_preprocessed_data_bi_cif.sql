
DROP TABLE IF EXISTS TMP_bv_bivariate_ci;

CREATE TABLE TMP_bv_bivariate_ci
(
DD_Customer_Name VARCHAR(100) ,
DD_Operating_Office VARCHAR(100) ,
DD_SBU VARCHAR(100) ,
DD_month_start_date VARCHAR(10) ,
DD_Month_Label VARCHAR(10) ,
DD_date_year VARCHAR(10) ,
CT_Volume DECIMAL(36,8) ,
CT_Month_Working_Days DECIMAL(36,8) ,
CT_Number_of_Holidays DECIMAL(36,8) ,
CT_sin_month DECIMAL(36,8) ,
CT_cos_month DECIMAL(36,8)
) ;

 CREATE TABLE IF NOT EXISTS fact_bv_bivariate_ci(
fact_bv_bivariate_ciID DECIMAL(36,0) ,
DD_Customer_Name VARCHAR( 100) ,
DD_Operating_Office VARCHAR( 100) ,
DD_SBU VARCHAR( 100) ,
DD_month_start_date VARCHAR( 10) ,
DD_Month_Label VARCHAR( 10) ,
DD_date_year VARCHAR( 10) ,
CT_Volume DECIMAL(36,8) ,
CT_Month_Working_Days DECIMAL(36,8) ,
CT_Number_of_Holidays DECIMAL(36,8) ,
CT_sin_month DECIMAL(36,8) ,
CT_cos_month DECIMAL(36,8),
dd_latestreporting_flag varchar(1),
dd_snapshotdate varchar(15)
);

import into TMP_bv_bivariate_ci
(
DD_Customer_Name ,
DD_Operating_office ,
DD_SBU ,
DD_month_start_date ,
DD_Month_Label ,
DD_date_year ,
CT_Volume ,
CT_Month_Working_Days ,
CT_Number_of_Holidays ,
CT_sin_month ,CT_cos_month
)
from local CSV FILE '/efs/datascience/BureauF1A/output/customer_level_inspection_bivariate_input.csv'
ENCODING = 'UTF-8' ROW SEPARATOR = 'LF'  COLUMN SEPARATOR = ',' COLUMN DELIMITER = '"' SKIP = 1 REJECT LIMIT 0;

/*
select * from TMP_bv_bivariate_ci limit 10
*/
DELETE FROM fact_bv_bivariate_ci f
WHERE EXISTS (SELECT 1 FROM stg_currentrunparam_bi_ci curr
WHERE curr.dd_reportingdate = f.dd_snapshotdate);

update fact_bv_bivariate_ci
set dd_latestreporting_flag = 'N' ;


insert into fact_bv_bivariate_ci (
fact_bv_bivariate_ciID,
 DD_Customer_Name ,
DD_Operating_office ,
DD_SBU ,
DD_month_start_date ,
DD_Month_Label ,
DD_date_year ,
CT_Volume ,
CT_Month_Working_Days ,
CT_Number_of_Holidays ,
CT_sin_month ,
CT_cos_month,
dd_latestreporting_flag,
dd_snapshotdate
)
 select (
 select ifnull(max( fact_bv_bivariate_ciID), 0)  from fact_bv_bivariate_ci m) + row_number()
over(order by '')  as fact_bv_bivariate_ciID,
DD_Customer_Name ,
DD_Operating_office ,
DD_SBU ,
DD_month_start_date ,
DD_Month_Label ,
DD_date_year ,
CT_Volume ,
round(CT_Month_Working_Days,0) ,
round(CT_Number_of_Holidays,0) ,
round(CT_sin_month,4),
round(CT_cos_month,4),
'Y',
curr.dd_reportingdate
from TMP_bv_bivariate_ci , stg_currentrunparam_bi_ci curr;


