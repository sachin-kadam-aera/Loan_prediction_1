#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on..

config_file=$1
yml_file_path=$2 
py_path=$3
input_csv_file=$4
last_date=$5
horizon_start_date=$6
horizon_date=$7
HOST=$8


echo "config_file "$config_file
echo "py_path:"$py_path
echo "yml_file_path: "$yml_file_path
echo "input_csv_file "$input_csv_file
echo "last_date:"$last_date
echo "horizon_start_date: "$horizon_start_date
echo "horizon_date: "$horizon_date
echo "HOST: "$HOST


echo "This script call Forecast01 (UAT-IRL) shell script"

response=$(curl -s $HOST | cut -d '"' -f 2)
echo "Responce:"$response

if [[ "$response" == "Server is running" ]];
	then
		echo "Running Submission R Script..."
		status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_checks/run_forecast_checks.sh '$config_file' '$yml_file_path' '$py_path' '$input_csv_file' '$last_date' '$horizon_start_date' '$horizon_date' "}')
echo 'script o/p-'$status
fi



