#!/bin/bash

set -o errexit
USER1=$(whoami)

forecastcheck_input_file=$1
forecastcheck_output_file=$2

echo "output file path :"$forecastcheck_input_file
echo "Input file path:"$forecastcheck_output_file

cd /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_checks/ 

rm -f $forecastcheck_input_file
rm -f $forecastcheck_output_file
rm -f *.txt

