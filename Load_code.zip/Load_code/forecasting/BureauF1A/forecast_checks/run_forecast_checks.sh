#!/bin/bash

set -o errexit
USER1=$(whoami)

config_file=$1
yml_file_path=$2 
py_path=$3 # file with path
input_csv_file=$4
last_date=$5
horizon_start_date=$6
horizon_date=$7

echo "config_file "$config_file
echo "py_path:"$py_path
echo "yml_file_path: "$yml_file_path
echo "input_csv_file "$input_csv_file
echo "last_date:"$last_date
echo "horizon_start_date: "$horizon_start_date
echo "horizon_date: "$horizon_date

var_name=$(grep -A0 'name:' $yml_file_path | tail -n1);
var_name=${var_name//*name: /};
echo "$var_name"

virtual_env_path=/home/fusionops/.conda/envs/$var_name
echo "Current virtual env path -> " $virtual_env_path

if [ -d $virtual_env_path ]; then
   echo "Virtual Env. already exists -> " $virtual_env_path
   echo "Activating the env.."
   export PATH=/opt/anaconda3/bin/:$PATH
   source /opt/anaconda3/etc/profile.d/conda.sh
   conda activate $var_name

else
   echo "Creating a new virtual env..."
   export PATH=/opt/anaconda3/bin/:$PATH
   conda env create -f  $yml_file_path
   source /opt/anaconda3/etc/profile.d/conda.sh
   conda activate $var_name
fi

cd /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_checks
python $py_path $config_file $input_csv_file $last_date $horizon_start_date $horizon_date
echo "Shell script processing completed."
