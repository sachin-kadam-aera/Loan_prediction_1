import matplotlib.pyplot as plt
import pandas as pd 
import numpy as np
import os
from PIL import Image
import datetime
from scipy import stats
import math  # for using atan function
import sys
import configparser
import warnings
warnings.simplefilter("ignore")

# Helper Functions 

# Write something to a file 
def write_to_file(str_):
    fname = './out.txt'
    with open(fname, 'a') as h_file:
        h_file.write(str_+'\n')
        
# Get the current date-time stamp ( for creating unique file names)
def get_current_time_stamp():
    time_now = datetime.datetime.now()
    date_time_now = time_now.strftime('%Y' + "_" + '%m' + '_' + '%d' + '_' + '%H' + '_' + '%M' + '_' + '%S')
    return date_time_now

# Write into a log file         
def write_to_log(str_):
    fname = './log_'+ tstamp +'.txt'
    with open(fname, 'a') as h_file:
        h_file.write(str_+'\n') 
        
# Write into the error-log file               
def log_error(str_):
    fname = './errorlog_'+ tstamp +'.txt'
    with open(fname, 'a') as h_file:
        h_file.write(str_+'\n')   

# Fit a line to x and y coordinates               
def get_trendline(x,y):
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    return p        

def remove_sp_chars(str_):
    return str_.replace("\\","").replace("/","").replace(" ","_")

def write_to_report(str_):
    fname = input_file_path[:-4] + "_results.csv"
    with open(fname, 'a') as h_file:
        h_file.write(str_+'\n')
        
def write_report_header(HEADER_):
    write_to_report(HEADER_)
        
def remove_comma(str_):
    return str_.replace(",","")

#create a file name ( jpg extension for charts) based on some string tuple arguments
def get_filename(str_tup,ext_='.jpg') :
    str_= "~".join(str_tup)
    str_ = remove_comma(str_)
    return str_.replace("\\","").replace("/","").replace(" ","-")+ ext_

# create a chart of the pyplot (matplotlib) type
def create_chart():
        plt_ax = plt.axis('off');
        plt_1  = plt.plot(df_actual[vol_col_historical]);
        plt_2 = plt.plot(df_forecast[vol_col_forecast]);
        plt_sav = plt.savefig(img_folder_path + "/" +  img_fname , dpi = 100,format = 'jpeg');
        plt.clf();
        
# get the slope - given a dataframe of points        
def get_slope(df):
    x_seq = np.arange(len(df))
    slope, intercept, r_value, p_value, std_err = stats.linregress(x_seq, df)
    deg = math.atan(slope) * (180.0/math.pi)
    return slope,deg

# get slope & angle of t12 and f12 values 
def get_slope_12(df_act,df_fcast):
    x1_seq = np.arange(12)
    x2_seq = x1_seq+12
    slope1, intercept1, r_value1, p_value1, std_err1 = stats.linregress(x1_seq, df_act)
    slope2, intercept2, r_value2, p_value2, std_err2 = stats.linregress(x2_seq, df_fcast)
    deg1 = math.atan(slope1) * (180.0/math.pi)
    deg2 = math.atan(slope2) * (180.0/math.pi)
    return slope1,slope2,deg1, deg2 

def create_hyperlink(str_):
    return '=HYPERLINK("%s")' % (str_)

# check if folder exists - if not, create it from the config folder name 
def create_dir(list_dir) : 
    for DIR_ in list_dir :
        if not os.path.exists(DIR_):
            os.makedirs(DIR_)
            
#--------------------------------- 
#	Read from Config file
#-----------------------------------

# Read from the config.ini file into variables
config_name=sys.argv[1]
print(config_name)
config_obj = configparser.ConfigParser()
config_file=config_obj.read(config_name)
thresholds = config_obj["thresholds"]
charts = config_obj["charts"]

# ------- setting variables from the config file
img_folder_path  = "./img_graph_forecast"
input_file_path = sys.argv[2]
flagged_report_folder = "./flagged_records"

filter_1_col = "DD_GRAIN1"
filter_2_col = "DD_GRAIN3"
filter_3_col = "DD_GRAIN2"

algo_name_col = "DD_FORECASTALGORITHM" 
rank_col = "DD_FORECASTRANK"
vol_col_forecast  = "CT_FORECASTQUANTITY"
vol_col_historical = "CT_SALESQUANTITY"
date_column = "DD_ACTUALDATEVALUE"

#dates ( convert into int - these come as strings)
actuals_end_date = int(sys.argv[3])
horizon_start_date = int(sys.argv[4])
horizon_end_date = int(sys.argv[5])


#thresholds
min_records_actuals  = int(thresholds["min_records_actuals"])
lift_in_mean  = float(thresholds["lift_in_mean"]) 
almost_zero_degree = float(thresholds["almost_zero_degree"])

# charts 
create_visualisation_charts = charts["create_visualisation_charts"]

# show in report
# shiow_vars = display["checks_to_display"]
# ---------------------------------------------------
#       Historical  & Forecast Charts - All grains 
# ---------------------------------------------------
#Todo : Create this dynamically ( pull from config file)
REPORT_HEADER = 'ELEMENT1,ELEMENT2,ELEMENT3,ALGO,ALGO_RANK,CHART_PATH'\
                ',TOT_RECORDS_COUNT,ACTUALS_COUNT,FORECAST_COUNT,COUNT_T12,COUNT_F12'\
                ',SLOPE_T12,ANGLE_T12,SLOPE_F12,ANGLE_F12,SLOPE_FC,ANGLE_FC,NA_T12,NA_F12'\
                ',SD_T12,SD_F12,MEAN_T12,MEAN_F12,COV_T12,COV_F12,VIX_T12,VIX_F12'\
                ',CHK_1,CHK_2,CHK_3,CHK_4,CHK_5,CHK_6,CHK_7,CHK_8,CHK_9,CHK_10'\
                ',CHK_11,CHK_12,CHK_13,CHK_14,JOBID, JOBNAME, REPORTING_DATE'

df_report  = pd.read_csv(input_file_path)
tstamp = get_current_time_stamp()
actuals_start_date=int(min(df_report['DD_ACTUALDATEVALUE']))
print("actuals_start_date->", actuals_start_date)

# Create directories if they donot exist 
create_dir([img_folder_path,flagged_report_folder])

#Todo - dynamically subset based on the number of valid filteres ( eg :for 2 filters , 3 filters - same line )
# get all the unique combinations of the 3 filters into a list 
df_filtered = df_report.drop_duplicates(subset = [filter_1_col, filter_2_col,filter_3_col,algo_name_col],keep ='first')
list_filtered  = df_filtered[[filter_1_col, filter_2_col,filter_3_col,algo_name_col]].values.tolist() 
write_report_header(REPORT_HEADER)


for element_1, element_2,element_3,element_4  in list_filtered: 
    
    # print(element_1, element_2,element_3,element_4)
    # split the data into actuals and forecasts
    df_graph = df_report[ ( df_report[filter_1_col]== element_1 ) & (df_report[filter_2_col] == element_2) & (df_report[filter_3_col] == element_3) & (df_report[algo_name_col] == element_4) ]
    df_actual = df_graph[(df_graph[date_column] >= actuals_start_date) & (df_graph[date_column] <= actuals_end_date) ]
    df_forecast = df_graph[(df_graph[date_column] >= horizon_start_date ) &  (df_graph[date_column] <= horizon_end_date)]
    df_actual_12 = df_actual.tail(12) # last 12 records of the actual/historical dataset
    df_forecast_12 =  df_forecast.head(12) #first 12 records of the forecast dataset

    #should have a minmum record count and atleast 1 value for forecast 
    all_conditions_ok = True if ((len(df_actual[vol_col_historical]) > min_records_actuals )  & ( len(df_forecast[vol_col_forecast])> 1) ) else False 
    #All the initial minimum checks 
    all_conditions_ok = True if (
                                    ( len(df_actual[vol_col_historical]) > min_records_actuals )   \
                                  & ( len(df_forecast[vol_col_forecast])> 1 )\
                                  & ( len(df_forecast_12) > 1) \
                                  #& (is_not_empty_df(df_graph))
                                ) else False 

    algo_rank = int(df_graph[rank_col].mean())
    img_fname = get_filename(( element_1, element_2,element_3 +'~R' + str(algo_rank) + '~' + element_4  ))
	
    if all_conditions_ok:
# ----------------------------------------  
#       Part 1 - Chart / Visualization of Actuals / Forecasts     
# ----------------------------------------     

        if create_visualisation_charts.lower() == 'yes' :
            create_chart() 
# ----------------------------------------  
#        Part 2 - report generation  
# ---------------------------------------- 

# ------------------------------
#  Build the attributes - add your measures here
# ------------------------------
        count_records_all_data = len(df_graph)
        count_records_actual = len(df_actual)
        count_records_forecast = len(df_forecast)

        count_actual_12 = len(df_actual_12)
        count_forecast_12 = len(df_forecast_12)
        count_forecast_12_non_null = len(df_forecast_12[vol_col_forecast])
        count_actual_12_non_null = len(df_actual_12[vol_col_historical])
        chart_path  = img_folder_path + "/" +  img_fname 
        
        chart_path = create_hyperlink(chart_path) if create_visualisation_charts.lower() == 'yes' else 'Not selected'
        
        str_log_1 = f"{remove_comma(element_1)}, {remove_comma(element_2)},{remove_comma(element_3)}, {element_4},{algo_rank},{chart_path},{count_records_all_data}, {count_records_actual},{count_records_forecast},{count_actual_12},{count_forecast_12}"
        # get slope of T12 , F12 , F-longterm
        s_t12, s_f12, deg_t12, deg_f12 = get_slope_12(df_actual_12[vol_col_historical],df_forecast_12[vol_col_forecast])
        s_fc, deg_fc = get_slope(df_forecast[vol_col_forecast])

        str_log_2 = f"{s_t12}, {deg_t12}, {s_f12},{deg_f12},{s_fc}, {deg_fc}"
        str_log_2 = str_log_2.replace("nan", '')
        
        # Todo 
        #Get slope of the entire historical data , slope of entire forecast data and compare 
        #s_actual, s_forecast, deg3, deg4 = get_slopes(df_actual[vol_col_historical],df_forecast[vol_col_forecast])
        #print("s_actual, s_forecast, deg3, deg4 = " + s_actual, s_forecast, deg3, deg4)

        # Are there null values ?
        str_log_3 = f"{df_actual_12[vol_col_historical].isna().sum()},{df_forecast_12[vol_col_forecast].isna().sum()}"
        str_log_3 = str_log_3.replace("nan", '')

        #Capture Other statistical measures
        sd_t12 = df_actual_12[vol_col_historical].std()
        sd_f12 = df_forecast_12[vol_col_forecast].std()
        mean_t12 = df_actual_12[vol_col_historical].mean()
        mean_f12 = df_forecast_12[vol_col_forecast].mean()
        coffvar_t12 =  sd_t12/mean_t12 if mean_t12 != 0 else ''
        coffvar_f12 =  sd_f12/mean_f12 if mean_f12 != 0 else ''

        # volatility as log-returns
        sd_logret_t12= np.log(df_actual_12[vol_col_historical]/df_actual_12[vol_col_historical].shift()).std()
        sd_logret_f12=np.log(df_forecast_12[vol_col_forecast]/df_forecast_12[vol_col_forecast].shift()).std()

        #str_log_4 = f"%s,%s,%s,%s,%s,%s,%s,%s" %(sd_t12,sd_f12,mean_t12,mean_f12,coffvar_t12,coffvar_f12,sd_logret_t12,sd_logret_f12 )
        str_log_4 = f"{sd_t12},{sd_f12},{mean_t12},{mean_f12},{coffvar_t12},{coffvar_f12},{sd_logret_t12},{sd_logret_f12}"
        str_log_4 = str_log_4.replace("nan", '')

    # ------------------------------
    #  Checks / Flags  - Add your checks here
    # ------------------------------

        # Check 1 - slope direction different t12 v/s f12
        chk1 = True if ((s_t12>0 and  s_f12<0 ) or (s_t12<0 and s_f12>0 )) else False 

        # Check 2 - slope direction different between t12 v/s long term forecast
        chk2 = True if ((s_t12>0 and  s_fc<0 ) or (s_t12<0 and s_fc>0 ))   else False 

        #Check 3 - direction for t12 is different from both f12 and long-term forecast
        chk3 = True if (chk1 and chk2) else False 

        # Check  4 - Mean of f12 is 50% (set in var 'LIFT_IN_MEAN') greater than mean (t12)  
        if mean_t12 != 0 :
            chk4 = True if ((mean_f12  - mean_t12 ) / mean_t12) > lift_in_mean else False  
        else : chk4 = 'NA'

        # Check 5 - non-zero flat-forecast
        chk5 = True if ( (mean_f12 > 0) and (sd_f12 == 0) ) else False  

        # Check 6 - volatility <> 0 and f_12 angle < 10 degrees
        chk6  = True  if  ( (sd_f12 != 0 ) and  (deg_t12 < almost_zero_degree) ) else False 

        # zero value flat forecast  
        chk7 = True if ( (mean_f12 == 0) and (sd_f12 == 0) ) else False  
                
        # check 8  - Rank 1 - and flat forecast 
        chk8  = True if ( (algo_rank == 1) and (chk5 or chk7) ) else False
            
        # check 9  -  All flat forecast ( zero + non-zero )
        chk9  = True if ( (algo_rank == 1) and (chk5 or chk7) ) else False
        
        #check 10 - Any of the values greater than 2*s.d of its own distribution 
        chk10  = True if ( any ( df_forecast_12[vol_col_forecast] > (mean_f12 + 2*sd_f12) ) ) else False
        
        #check 11 - Any of the values lessser than 2*s.d of its own distribution
        chk11  = True if ( any ( df_forecast_12[vol_col_forecast] < mean_f12 - 2*sd_f12) ) else False
        
        #check 12 - Any of the values lessser 2*s.d of its own distribution ( outliers )
        chk12  = True if ( (chk10) or (chk11) ) else False
        
        #check 13 - Any of the values are both outside upper and lower range( 2*s.d) 
        chk13  = True if ( chk10 and chk11 ) else False
        
        #check 14 - f12 is monotonic
        chk14 = True if df_forecast_12[vol_col_forecast].is_monotonic else False 
        
        # Check  - Is the mean of the forecast within 2 sd of the values in actual 
        # Check - max value of forecast more than 50% of mean & ( greater than )
        # Check  - If mean f12 is between 0 and 1 and the mean of actual is way higher 
        # Check  - there is seasonality in actual , but not in forecast 
        # Check  - Are there more forecast values beyond the horizon end_date ? 

        #str_log_checks = f"%s,%s,%s,%s,%s,%s" %(chk1,chk2,chk3,chk4,chk5,chk6)
        str_log_checks = f"{chk1},{chk2},{chk3},{chk4},{chk5},{chk6},{chk7},{chk8},{chk9},{chk10},{chk11},{chk12},{chk13},{chk14}"
        jobname, jobid, reporting_date = df_report['DD_PROCESS_NAME'][0], df_report['DD_JOBID'][0], df_report['DD_REPORTINGDATE'][0]
        job_info_checks = f"{jobname},{jobid},{reporting_date}"
        k = ",".join((str_log_1,str(str_log_2),str_log_3,str_log_4,str_log_checks,job_info_checks))
        
    # ----------------------------------------  
    #        Write the report  
    # ----------------------------------------
        write_to_report(k)
    
    # fail on getting into creating the reports/charts (all_conditions_ok = False )
    # Log the errors where all_conditions are not met 
    else : 
        if (len(df_actual[vol_col_historical]) < min_records_actuals) :
            log_error('E1:Failed Threshold - Min records in Actuals < 12 ' + img_fname  )
        elif (len(df_forecast[vol_col_forecast])<= 1) : 
            log_error('E2:Failed Threshold - Forecast value count < 2' + img_fname  )
        elif (len(df_forecast_12) <2 ) :
            log_error('E3:Failed Threshold - F12 value count < 2' + img_fname  )
