library(tidyr)
library(lubridate)
library(dplyr)
library(ggplot2)
library(forecastML)

# source files
source("./src/read_reports.R")

# Configurations
args <- commandArgs(trailingOnly = TRUE)
env.url <- args[1] #"https://insightqd.aeratechnology.com/ispring/client/v2/reports/"
token <- args[2] #"7f19ef36937891c23df05850223353c9"
page.size <- 10000

api.holidays <- "holiday_calendar"
api.working.days <- "monthly_working_days"
api.operating.office.mapping <- "bv_submission_univariate"
api.customer.submission <- "Master_Client_Forecast_Submissions_Customer"

normalize <- TRUE

submissions <- read_reports(env.url = env.url,
                            api.name = api.customer.submission,
                            token = token,
                            page.size = page.size)


## For running manually
#submissions <- read.csv("./raw_data/Master_Client_Submissions_Aug21.csv", skip = 3) 
#submissions[,"Grain"] <- apply(submissions %>% select(Master.Client.Forecast, Product.Line), 1,  paste0, collapse = "-")

#top50customers <- read.csv("./top50/top50 master client forecast submissions.csv")
#top50customers[,"Grain"] <- apply(top50customers %>% select(Master_Client_Forecast, Product_line), 1,  paste0, collapse = "-")

#submissions_top50 <- submissions %>% filter(Grain %in% unique(top50customers$Grain))
## END



# submissions <- submissions %>%
#   select(operating_office = Operating.Office,
#          product_line = Product.Line,
#          submissions.submitting_for = Master.Client.Forecast, 
#          report_date.year_month = Year.Month,
#          count_of_submission = Count.of.Submission)

submissions <- submissions %>%
  select(operating_office,
         product_line,
         submissions.submitting_for = master_client_forecast,
         report_date.year_month = year_month,
         count_of_submission)

operating.office.mapping <- read_reports(env.url = env.url,
                                           api.name = api.operating.office.mapping,
                                           token = token,
                                           page.size = page.size) %>%
  select(Operating.Office = operating_office, Territory = territory, Region = region) %>%
  distinct()

holidays.calendar <- read_reports(env.url = env.url,
                                  api.name = api.holidays,
                                  token = token,
                                  page.size = page.size)

working.days.monthly <- read_reports(env.url = env.url,
                                     api.name = api.working.days,
                                     token = token,
                                     page.size = page.size)


clean.submissions.dat <- submissions %>%
  mutate(Date = as.Date(paste0(report_date.year_month,'01'), format = "%Y%m%d"),
         Lab.Location = as.character(operating_office)) %>%
  mutate(Month.Start.Date = floor_date(Date, unit = "month")) %>%
  select(Lab.Location, Product.Line=product_line, Customer = submissions.submitting_for, Month.Start.Date, Count.of.Submission = count_of_submission) %>%
  group_by(Product.Line, Lab.Location, Customer, Month.Start.Date) %>%
  summarise(Count.of.Submission = sum(Count.of.Submission, na.rm = T), .groups = 'drop')

new.rows <- clean.submissions.dat %>%
  select(Lab.Location, Product.Line, Customer) %>%
  distinct() %>%
  mutate(Month.Start.Date = max(working.days.monthly$month_start_date),
         Count.of.Submission = 0)

clean.submissions.dat <- rbind(clean.submissions.dat, new.rows)

clean.submissions.dat <- clean.submissions.dat %>%
  forecastML::fill_gaps(date_col = 4,
                        frequency = '1 month',
                        groups = c("Product.Line", "Lab.Location", "Customer"))

clean.working.days.monthly <- working.days.monthly %>%
  mutate(Month.Start.Date = as.Date(month_start_date, format = "%Y-%m-%d"),
         Month.Label = month(Month.Start.Date,label = TRUE, abbr = FALSE)) %>%
  select(Month.Start.Date, Month.Working.Days = month_working_days, Territory = territory, Month.Label)

clean.holidays.calendar <- holidays.calendar %>%
  mutate(date = as.Date(holiday_date, format = "%Y-%m-%d"),
         is.holiday = 1,
         Month.Start.Date = floor_date(date, unit = 'month')) %>%
  select(Territory = territory, date, day = holiday_day, Month.Start.Date, is.holiday) %>%
  distinct() %>%
  group_by(Territory, Month.Start.Date) %>%
  summarise(No.of.Holidays = sum(is.holiday, na.rm = T), .groups = 'drop')

submissions.subset <- clean.submissions.dat %>%
  mutate(Operating.Office = as.character(Lab.Location)) %>%
  select(Product.Line,
         Operating.Office,
         Customer,
         Month.Start.Date,
         Submissions = Count.of.Submission) 

submissions.subset[is.na(submissions.subset$Submissions), "Submissions"] <- 0

if(normalize){
  submissions.subset <- submissions.subset %>%
    arrange(Product.Line, Operating.Office, Customer, Month.Start.Date) %>%
    group_by(Product.Line, Operating.Office, Customer) %>%
    mutate(lag.12 = lag(Submissions, 12)) %>% 
    mutate(flag.2020 = ifelse(year(Month.Start.Date) == 2020, 1, 0)) %>%
    replace_na(list(lag.12 = 0)) %>%
    mutate(Normalized.Submissions = (Submissions + flag.2020 * lag.12)/(1 + flag.2020)) %>% 
    select(Product.Line, Operating.Office, Month.Start.Date, Submissions = Normalized.Submissions)
}

submissions.with.holidays <- submissions.subset %>%
  inner_join(operating.office.mapping, by = "Operating.Office")  %>% 
  left_join(clean.working.days.monthly, by = c("Territory", "Month.Start.Date")) %>% 
  left_join(clean.holidays.calendar, by = c("Territory", "Month.Start.Date"))

submissions.with.holidays[is.na(submissions.with.holidays$No.of.Holidays), "No.of.Holidays"] <- 0

submissions.at.operating.office <- submissions.with.holidays

submissions.at.operating.office.input <- submissions.at.operating.office %>%
  select(Customer, Product.Line, Operating.Office, Month.Start.Date, Month.Label, Month.Working.Days, No.of.Holidays, Submissions) %>%
  group_by(Customer,Product.Line, Operating.Office, Month.Label, Month.Start.Date) %>%
  summarise(Month.Working.Days = mean(Month.Working.Days, na.rm = T),
            number.of.holidays = sum(No.of.Holidays, na.rm = T),
            Total.Submissions = sum(Submissions, na.rm = T),
            .groups = 'drop') %>%
  arrange(Customer,Product.Line, Operating.Office, Month.Start.Date, Month.Label) %>%
  group_by(Customer,Product.Line, Operating.Office) %>%
  mutate(`sin_month` = sin(2*pi/(12)*month(Month.Start.Date)),
         `cos_month` = cos(2*pi/(12)*month(Month.Start.Date)),
         `T-1` = lag(Total.Submissions, 1),
         `T-2` = lag(Total.Submissions, 2),
         `T-3` = lag(Total.Submissions, 3),
         `T-4` = lag(Total.Submissions, 4),
         `T-5` = lag(Total.Submissions, 5),
         `T-6` = lag(Total.Submissions, 6),
         `T-7` = lag(Total.Submissions, 7),
         `T-8` = lag(Total.Submissions, 8),
         `T-9` = lag(Total.Submissions, 9),
         `T-10` = lag(Total.Submissions, 10),
         `T-11` = lag(Total.Submissions, 11),
         `T-12` = lag(Total.Submissions, 12),
         diff1 = `T-1` - `T-2`,
         diff2 = `T-2` - `T-3`,
         diff3 = `T-3` - `T-4`,
         diff4 = `T-4` - `T-5`,
         diff5 = `T-5` - `T-6`,
         diff6 = `T-6` - `T-7`,
         diff7 = `T-7` - `T-8`,
         diff8 = `T-8` - `T-9`,
         diff9 = `T-9` - `T-10`,
         diff10 = `T-10` - `T-11`,
         diff11 = `T-11` - `T-12`,
         avg3m = (`T-5` + `T-6` + `T-7`)/3,
         avg6m = (`T-5` + `T-6` + `T-7` + `T-8` + `T-9` + `T-10`)/6) %>%
  mutate(SBU = "CUSTOMER",
         date_year = year(Month.Start.Date)) %>%
  select(`Customer` = Customer,
         `Product Line` = Product.Line,
         `Operating Office` = Operating.Office,
         SBU,
         month_start_date = Month.Start.Date,
         `Month Label` = Month.Label,
         date_year,
         Volume = Total.Submissions,
         `Month Working Days` = Month.Working.Days,
         `Number of Holidays` = number.of.holidays,
         everything())

submissions.at.operating.office.input <- submissions.at.operating.office.input %>%
  group_by(`Customer`, `Product Line`, `Operating Office`) %>%
  #dplyr::slice(13:n()) %>%
  ungroup() %>%
  as.data.frame()
#submissions.at.operating.office.input[is.na(submissions.at.operating.office.input)] <- ""
#write.csv(submissions.at.operating.office.input, "./processed_input/customer_submissions_OO_Master_Client_Forecasting.csv", row.names = F)

submissions.at.all <- submissions.with.holidays %>% filter(!(Operating.Office %in% c("KOWLOON BAY", "TAIWAN"))) %>% mutate(Operating.Office="ALLOTHERCUSTOMERS")

submissions.at.all.input<- submissions.at.all %>%
  select(Customer, Product.Line, Operating.Office, Month.Start.Date, Month.Label, Month.Working.Days, No.of.Holidays, Submissions) %>%
  group_by(Customer,Product.Line, Operating.Office, Month.Label, Month.Start.Date) %>%
  summarise(Month.Working.Days = mean(Month.Working.Days, na.rm = T),
            number.of.holidays = sum(No.of.Holidays, na.rm = T),
            Total.Submissions = sum(Submissions, na.rm = T),
            .groups = 'drop') %>%
  arrange(Customer,Product.Line, Operating.Office, Month.Start.Date, Month.Label) %>%
  group_by(Customer,Product.Line, Operating.Office) %>%
  mutate(`sin_month` = sin(2*pi/(12)*month(Month.Start.Date)),
         `cos_month` = cos(2*pi/(12)*month(Month.Start.Date)),
         `T-1` = lag(Total.Submissions, 1),
         `T-2` = lag(Total.Submissions, 2),
         `T-3` = lag(Total.Submissions, 3),
         `T-4` = lag(Total.Submissions, 4),
         `T-5` = lag(Total.Submissions, 5),
         `T-6` = lag(Total.Submissions, 6),
         `T-7` = lag(Total.Submissions, 7),
         `T-8` = lag(Total.Submissions, 8),
         `T-9` = lag(Total.Submissions, 9),
         `T-10` = lag(Total.Submissions, 10),
         `T-11` = lag(Total.Submissions, 11),
         `T-12` = lag(Total.Submissions, 12),
         diff1 = `T-1` - `T-2`,
         diff2 = `T-2` - `T-3`,
         diff3 = `T-3` - `T-4`,
         diff4 = `T-4` - `T-5`,
         diff5 = `T-5` - `T-6`,
         diff6 = `T-6` - `T-7`,
         diff7 = `T-7` - `T-8`,
         diff8 = `T-8` - `T-9`,
         diff9 = `T-9` - `T-10`,
         diff10 = `T-10` - `T-11`,
         diff11 = `T-11` - `T-12`,
         avg3m = (`T-5` + `T-6` + `T-7`)/3,
         avg6m = (`T-5` + `T-6` + `T-7` + `T-8` + `T-9` + `T-10`)/6) %>%
  mutate(SBU = "CUSTOMER",
         date_year = year(Month.Start.Date)) %>%
  select(`Customer` = Customer,
         `Product Line` = Product.Line,
         `Operating Office` = Operating.Office,
         SBU,
         month_start_date = Month.Start.Date,
         `Month Label` = Month.Label,
         date_year,
         Volume = Total.Submissions,
         `Month Working Days` = Month.Working.Days,
         `Number of Holidays` = number.of.holidays,
         everything())

submissions.at.all.input <- submissions.at.all.input %>%
  group_by(`Customer`, `Product Line`, `Operating Office`) %>%
  #dplyr::slice(13:n()) %>%
  ungroup() %>%
  as.data.frame()

submissions.for.cortex <- rbind(submissions.at.operating.office.input, submissions.at.all.input)

submissions.for.cortex[is.na(submissions.for.cortex)] <- ""
write.csv(submissions.for.cortex, "/efs/datascience/BureauF1A/output/customer_level_submission.csv", row.names = FALSE)
