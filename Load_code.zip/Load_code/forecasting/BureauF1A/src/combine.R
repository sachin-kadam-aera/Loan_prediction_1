args <- commandArgs(trailingOnly = TRUE)
env.url <- args[1] #"https://insightqd.aeratechnology.com/ispring/client/v2/reports/"
token <- args[2] #"c1e8337a2423330ce144d3194fa9e14d"
normalise.submission <- args[3] #"True/False as boolean"
normalise.inspection <- args[4] #"True/False as boolean"
page.size <- 10000

api.submissions <- "bv_submission_univariate"
api.inspections <- "BV_inspection_by_office"
api.holidays <- "holiday_calendar"
api.working.days <- "monthly_working_days"

source("./src/read_reports.R")
source("./src/submissions.R")
source("./src/inspections.R")

monthly.input <- rbind(submissions.monthly.input, inspections.monthly.input)
monthly.input[is.na(monthly.input$SFDC), "SFDC"] <- 0
monthly.input[is.na(monthly.input$EDI), "EDI"] <- 0
monthly.input[is.na(monthly.input$Quotations), "Quotations"] <- 0

monthly.input <- monthly.input %>% arrange(`Product Line`, `Operating Office`, SBU, month_start_date)
write.csv(monthly.input, "/efs/datascience/BureauF1A/output/bv_input_monthly.csv", row.names = F)


