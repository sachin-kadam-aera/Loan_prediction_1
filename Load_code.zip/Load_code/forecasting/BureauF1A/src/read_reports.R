library(httr)
library(jsonlite) 

fetch_records <-  function(env.url,
                           api.name,
                           token,
                           row.start,
                           page.size){
  
  url <- paste0(env.url, api.name)
  params <- list(rowStart = row.start,
                 pageSize = page.size,
                 format = 'json')
  
  response <- GET(url = url,
                  query = params,
                  add_headers("Authorization" = token,
                              "Host" = 'app-uatirl01.aeratechnology.com'))
  
  if(response$status_code == 200){
    json.response <- fromJSON(content(response, "text"))
    dat <- as.data.frame(json.response$data)
    return(dat) 
  }else{
    return(NULL)
  }
}

read_reports <- function(env.url,
                         api.name,
                         token,
                         page.size){
  data.chunks <- NULL
  for(i in 0:10000){
    row.start <- (i * page.size)
    
    chunk <- fetch_records(env.url, api.name, token, row.start, page.size)
    
    if((!is.null(chunk)) & (is.data.frame(chunk))){
      if(is.null(data.chunks)){
        data.chunks <- chunk
      }else{
        if(nrow(chunk) == 0|is.null(chunk)){
          return(data.chunks)
        }
        data.chunks <- rbind(data.chunks, chunk)
      }
    }else{
      cat("NO data Fetched")
    }
  }
}

# inspections <- read_reports(env.url = "https://insightqd.aeratechnology.com/ispring/client/v2/reports/",
#                   api.name = "BV_inspection_by_office",
#                   token = "52507777bebf668843b90d1082bfc3fe",
#                   page.size = 10000)
