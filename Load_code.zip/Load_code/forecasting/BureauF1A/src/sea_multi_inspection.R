library(tidyr)
library(lubridate)
library(dplyr)
library(ggplot2)
library(forecastML)


source("./src/read_reports.R")
# Configurations
args <- commandArgs(trailingOnly = TRUE)

env.url <- args[1] # "https://insightqd.aeratechnology.com/ispring/client/v2/reports/"
token <- args[2] # "1ddafb673c7b0b46a41a9ca5a60cea1d"
page.size <- 10000
api.inspections <- "BV_inspection_by_office_sea"
api.holidays <- "holiday_calendar"
api.working.days <- "monthly_working_days"


inspections <- read_reports(env.url = env.url,
                            api.name = api.inspections,
                            token = token,
                            page.size = page.size)

inspections$operating_office <- as.character(ifelse(inspections$operating_office == "NOIDA", "I-INDIA", inspections$operating_office))
inspections$operating_office <- as.character(ifelse(inspections$operating_office == "DHAKA", "I-BANGLADESH", inspections$operating_office))

operating.office.mapping <- inspections %>%
  select(Operating.Office = operating_office, Territory = territory, Region = region) %>%
  distinct()

holidays.calendar <- read_reports(env.url = env.url,
                                  api.name = api.holidays,
                                  token = token,
                                  page.size = page.size)

working.days.monthly <- read_reports(env.url = env.url,
                                     api.name = api.working.days,
                                     token = token,
                                     page.size = page.size)

clean.inspection.dat <- inspections %>%
  select(Product.Line = product_line, SBU = sbu, Operating.Office = operating_office, Year.Month = year_month, Sum.Of.Mandays=sum_of_mandays) %>%
  mutate(Date = as.Date(paste(substr(as.character(inspections$year_month), 1, 4), substr(as.character(inspections$year_month), 5, 6), "01", sep = '-'), format = "%Y-%m-%d"),
         Product.Line = as.character(Product.Line)) %>%
  filter(Year.Month != 101) %>%
  mutate(Week.Start.Date = floor_date(Date, unit="week"),
         Month.Start.Date = floor_date(Date, unit = "month")) %>%
  select(Product.Line,
         Operating.Office,
         Date, Week.Start.Date,
         Month.Start.Date,
         Sum.Of.Mandays) %>%
  mutate(Operating.Office = ifelse(Operating.Office == "NOIDA", "I-INDIA", Operating.Office)) %>%
  group_by(Product.Line, Operating.Office, Month.Start.Date) %>%
  summarise(Sum.Of.Mandays = sum(Sum.Of.Mandays), .groups = 'drop')


new.rows <- clean.inspection.dat %>%
  select(Operating.Office, Product.Line) %>%
  distinct() %>%
  mutate(Month.Start.Date = max(working.days.monthly$month_start_date),
         Sum.Of.Mandays = 0)

clean.inspection.dat <- rbind(clean.inspection.dat, new.rows)

clean.inspection.dat <- clean.inspection.dat %>%
  forecastML::fill_gaps(date_col = 3,
                        frequency = '1 month',
                        groups = c("Product.Line", "Operating.Office"))

clean.working.days.monthly <- working.days.monthly %>%
  mutate(Month.Start.Date = as.Date(month_start_date, format = "%Y-%m-%d"),
         Month.Label = lubridate::month(Month.Start.Date, label = TRUE, abbr = FALSE)) %>%
  select(Month.Start.Date, Month.Working.Days = month_working_days, Territory = territory, Month.Label)

clean.holidays.calendar <- holidays.calendar %>%
  mutate(date = as.Date(holiday_date, format = "%Y-%m-%d"),
         is.holiday = 1,
         Month.Start.Date = floor_date(date, unit = 'month')) %>%
  select(Territory = territory, date, day = holiday_day, Month.Start.Date, is.holiday) %>%
  distinct() %>%
  group_by(Territory, Month.Start.Date) %>%
  summarise(No.of.Holidays = sum(is.holiday, na.rm = T), .groups = 'drop')

inspections.subset <- clean.inspection.dat %>%
  mutate(Operating.Office = as.character(Operating.Office)) %>%
  select(Product.Line,
         Operating.Office,
         Month.Start.Date,
         Mandays = Sum.Of.Mandays) 

inspections.subset[is.na(inspections.subset$Mandays), "Mandays"] <- 0

normalize <- T
if(normalize){
    cat("Performing Normalization")
  inspections.subset <- inspections.subset %>%
      arrange(Product.Line, Operating.Office, Month.Start.Date) %>%
      group_by(Product.Line, Operating.Office) %>%
      mutate(lag.12 = lag(Mandays, 12),
             lag.24 = lag(Mandays, 24)) %>%
      mutate(flag.normalize = ifelse(((Operating.Office %in% c('I-VIETNAM')) &
                                        (month(Month.Start.Date) %in% c(6, 7, 8, 9, 10, 11, 12)) &
                                        (year(Month.Start.Date) == 2021)) |((Operating.Office %in% c('I-INDIA')) &
                                                                 (month(Month.Start.Date) %in% c(4, 5, 6)) &
                                                                 (year(Month.Start.Date) == 2020)) | ((Operating.Office %in% c('I-INDIA')) &
                                                                                                        (month(Month.Start.Date) %in% c(4, 5, 6)) &
                                                                                                        (year(Month.Start.Date) == 2021)) | ((Operating.Office %in% c('I-BANGLADESH')) &
                                                                                                                                               (month(Month.Start.Date) %in% c(4)) &
                                                                                                                                               (year(Month.Start.Date) == 2020)) | ((Operating.Office %in% c('I-BANGLADESH')) &
                                                                                                                                                                                      (month(Month.Start.Date) %in% c(4)) &
                                                                                                                                                                                      (year(Month.Start.Date) == 2021)), 1, 0)) %>%
      replace_na(list(lag.12 = 0, lag.24 = 0)) %>%
      mutate(Normalized.Mandays = ifelse(Operating.Office %in% c('I-VIETNAM'), Mandays * abs(flag.normalize-1) + (0.20 * Mandays + 0.80 * lag.12) * flag.normalize,
                                         ifelse(Operating.Office %in% c('I-INDIA', 'I-BANGLADESH'), Mandays * abs(flag.normalize-1) + (0.20 * Mandays + 0.80 * ifelse(year(Month.Start.Date) == 2020, lag.12, lag.24)) * flag.normalize, Mandays))) %>%
      select(Product.Line, Operating.Office, Month.Start.Date, Mandays = Normalized.Mandays)
}

inspections.with.holidays <- inspections.subset %>%
  inner_join(operating.office.mapping, by = "Operating.Office")  %>% 
  left_join(clean.working.days.monthly, by = c("Territory", "Month.Start.Date")) %>% 
  left_join(clean.holidays.calendar, by = c("Territory", "Month.Start.Date"))

inspections.with.holidays[is.na(inspections.with.holidays$No.of.Holidays), "No.of.Holidays"] <- 0

inspections.monthly.input <- inspections.with.holidays %>%
  select(Product.Line, Operating.Office, Month.Start.Date, Month.Label, Month.Working.Days, No.of.Holidays, Mandays) %>%
  group_by(Product.Line, Operating.Office, Month.Label, Month.Start.Date) %>%
  summarise(Month.Working.Days = mean(Month.Working.Days, na.rm = T),
            number.of.holidays = mean(No.of.Holidays, na.rm = T),
            Total.mandays = sum(Mandays, na.rm = T),
            .groups = 'drop') %>%
  arrange(Product.Line, Operating.Office, Month.Start.Date, Month.Label) %>%
  group_by(Product.Line, Operating.Office) %>%
  mutate(`sin_month` = sin(2*pi/(12)*month(Month.Start.Date)), 
         `cos_month` = cos(2*pi/(12)*month(Month.Start.Date)),
         `quarter` = lubridate::quarter(Month.Start.Date),
         `T-5` = lag(Total.mandays, 5),
         `T-6` = lag(Total.mandays, 6),
         `T-7` = lag(Total.mandays, 7),
         `T-8` = lag(Total.mandays, 8),
         `T-9` = lag(Total.mandays, 9),
         `T-10` = lag(Total.mandays, 10),
         `T-11` = lag(Total.mandays, 11),
         `T-12` = lag(Total.mandays, 12),
         diff5 = `T-5` - `T-6`,
         diff6 = `T-6` - `T-7`,
         diff7 = `T-7` - `T-8`,
         diff8 = `T-8` - `T-9`,
         diff9 = `T-9` - `T-10`,
         diff10 = `T-10` - `T-11`,
         diff11 = `T-11` - `T-12`,
         avg3m = (`T-5` + `T-6` + `T-7`)/3,
         avg6m = (`T-5` + `T-6` + `T-7` + `T-8` + `T-9` + `T-10`)/6) %>%
  mutate(SBU = "INSPECTION",
         date_year = year(Month.Start.Date)) %>%
  select(`Product Line` = Product.Line,
         `Operating Office` = Operating.Office,
         SBU,
         month_start_date = Month.Start.Date,
         `Month Label` = Month.Label,
         date_year,
         Volume = Total.mandays,
         `Month Working Days` = Month.Working.Days,
         `Number of Holidays` = number.of.holidays,
         everything())

inspections.monthly.input <- inspections.monthly.input %>%
  as.data.frame()

inspections.monthly.input[is.na(inspections.monthly.input)] <- ''
write.csv(inspections.monthly.input, '/efs/datascience/BureauF1A/output/inspections_monthly_input_vietnam__60_40_Bangladesh_India_80_20_mar22_v2.csv', row.names = F)
