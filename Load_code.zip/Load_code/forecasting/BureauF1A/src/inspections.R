library(tidyr)
library(lubridate)
library(dplyr)
library(ggplot2)
library(forecastML)



inspections <- read_reports(env.url = env.url,
                            api.name = api.inspections,
                            token = token,
                            page.size = page.size)

operating.office.mapping <- inspections %>%
  select(Operating.Office = operating_office, Territory = territory, Region = region) %>%
  distinct()

holidays.calendar <- read_reports(env.url = env.url,
                                  api.name = api.holidays,
                                  token = token,
                                  page.size = page.size)

working.days.monthly <- read_reports(env.url = env.url,
                                     api.name = api.working.days,
                                     token = token,
                                     page.size = page.size)

clean.inspection.dat <- inspections %>%
  select(Product.Line = product_line, SBU = sbu, Operating.Office = operating_office, Year.Month = year_month, Sum.Of.Mandays=sum_of_mandays) %>%
  # separate(Operating.Office,
  #          c(NA, "Operating.Office"),
  #          sep = "-") %>%
  mutate(Date = as.Date(paste(substr(as.character(inspections$year_month), 1, 4), substr(as.character(inspections$year_month), 5, 6), "01", sep = '-'), format = "%Y-%m-%d"),
         Product.Line = as.character(Product.Line)) %>%
  filter(Year.Month != 101) %>%
  mutate(Week.Start.Date = floor_date(Date, unit="week"),
         Month.Start.Date = floor_date(Date, unit = "month")) %>%
  select(Product.Line,
         Operating.Office,
         Date, Week.Start.Date,
         Month.Start.Date,
         Sum.Of.Mandays) %>%
  group_by(Product.Line, Operating.Office, Month.Start.Date) %>%
  summarise(Sum.Of.Mandays = sum(Sum.Of.Mandays), .groups = 'drop')


new.rows <- clean.inspection.dat %>%
  select(Operating.Office, Product.Line) %>%
  distinct() %>%
  mutate(Month.Start.Date = max(working.days.monthly$month_start_date),
         Sum.Of.Mandays = 0)

clean.inspection.dat <- rbind(clean.inspection.dat, new.rows)

clean.inspection.dat <- clean.inspection.dat %>%
  forecastML::fill_gaps(date_col = 3,
                        frequency = '1 month',
                        groups = c("Product.Line", "Operating.Office"))

clean.working.days.monthly <- working.days.monthly %>%
  mutate(Month.Start.Date = as.Date(month_start_date, format = "%Y-%m-%d"),
         Month.Label = month(Month.Start.Date,label = TRUE, abbr = FALSE)) %>%
  select(Month.Start.Date, Month.Working.Days = month_working_days, Territory = territory, Month.Label)

clean.holidays.calendar <- holidays.calendar %>%
  mutate(date = as.Date(holiday_date, format = "%Y-%m-%d"),
         is.holiday = 1,
         Month.Start.Date = floor_date(date, unit = 'month')) %>%
  select(Territory = territory, date, day = holiday_day, Month.Start.Date, is.holiday) %>%
  distinct() %>%
  group_by(Territory, Month.Start.Date) %>%
  summarise(No.of.Holidays = sum(is.holiday, na.rm = T), .groups = 'drop')

inspections.subset <- clean.inspection.dat %>%
  mutate(Operating.Office = as.character(Operating.Office)) %>%
  select(Product.Line,
         Operating.Office,
         Month.Start.Date,
         Mandays = Sum.Of.Mandays) 

inspections.subset[is.na(inspections.subset$Mandays), "Mandays"] <- 0

if(normalise.inspection == 'true'){
  inspections.subset <- inspections.subset %>%
    arrange(Product.Line, Operating.Office, Month.Start.Date) %>%
    group_by(Product.Line, Operating.Office) %>%
    mutate(lag.12 = lag(Mandays, 12)) %>%
    mutate(flag.2020 = ifelse(year(Month.Start.Date) == 2020, 1, 0)) %>%
    replace_na(list(lag.12 = 0)) %>%
    mutate(Normalized.Mandays = (Mandays + flag.2020 * lag.12)/(1 + flag.2020)) %>%
    select(Product.Line, Operating.Office, Month.Start.Date, Mandays = Normalized.Mandays)
}

inspections.with.holidays <- inspections.subset %>%
  inner_join(operating.office.mapping, by = "Operating.Office")  %>% 
  left_join(clean.working.days.monthly, by = c("Territory", "Month.Start.Date")) %>% 
  left_join(clean.holidays.calendar, by = c("Territory", "Month.Start.Date"))

inspections.with.holidays[is.na(inspections.with.holidays$No.of.Holidays), "No.of.Holidays"] <- 0

# inspections.with.holidays[is.na(inspections.with.holidays$Month.Label), "Month.Label"] <- month(inspections.with.holidays[is.na(inspections.with.holidays$Month.Label), "Month.Start.Date"],
#                                                                                                 abbr = FALSE,
#                                                                                                 label = TRUE)
# inspections.with.holidays <- inspections.with.holidays %>% filter(complete.cases(.))

inspections.monthly.input <- inspections.with.holidays %>%
  select(Product.Line, Operating.Office, Month.Start.Date, Month.Label, Month.Working.Days, No.of.Holidays, Mandays) %>%
  group_by(Product.Line, Operating.Office, Month.Label, Month.Start.Date) %>%
  summarise(Month.Working.Days = mean(Month.Working.Days, na.rm = T),
            number.of.holidays = sum(No.of.Holidays, na.rm = T),
            Total.mandays = sum(Mandays, na.rm = T),
            .groups = 'drop') %>%
  arrange(Product.Line, Operating.Office, Month.Start.Date, Month.Label) %>%
  group_by(Product.Line, Operating.Office) %>%
  mutate(`sin_month` = sin(2*pi/(12)*month(Month.Start.Date)), 
         `cos_month` = cos(2*pi/(12)*month(Month.Start.Date)),
         #`T-3` = lag(Total.mandays, 3),# No use
         #`T-4` = lag(Total.mandays, 4),# No use
         `T-5` = lag(Total.mandays, 5),
         `T-6` = lag(Total.mandays, 6),
         `T-7` = lag(Total.mandays, 7),
         `T-8` = lag(Total.mandays, 8),
         `T-9` = lag(Total.mandays, 9),
         `T-10` = lag(Total.mandays, 10),
         `T-11` = lag(Total.mandays, 11),
         `T-12` = lag(Total.mandays, 12),
         #diff1 = `T-1` - `T-2`,# No use
         #diff2 = `T-2` - `T-3`,# No use
         #diff3 = `T-3` - `T-4`,# No use
         #diff4 = `T-4` - `T-5`,# No use
         diff5 = `T-5` - `T-6`,
         diff6 = `T-6` - `T-7`,
         diff7 = `T-7` - `T-8`,
         diff8 = `T-8` - `T-9`,
         diff9 = `T-9` - `T-10`,
         diff10 = `T-10` - `T-11`,
         diff11 = `T-11` - `T-12`,
         avg3m = (`T-5` + `T-6` + `T-7`)/3,
         avg6m = (`T-5` + `T-6` + `T-7` + `T-8` + `T-9` + `T-10`)/6,
         SFDC = NA,
         EDI = NA,
         Quotations = NA) %>%
  mutate(SBU = "INSPECTION",
         date_year = year(Month.Start.Date)) %>%
  select(`Product Line` = Product.Line,
         `Operating Office` = Operating.Office,
         SBU,
         month_start_date = Month.Start.Date,
         `Month Label` = Month.Label,
         date_year,
         Volume = Total.mandays,
         `Month Working Days` = Month.Working.Days,
         `Number of Holidays` = number.of.holidays,
         everything())

inspections.monthly.input <- inspections.monthly.input %>%
  group_by(`Product Line`, `Operating Office`) %>%
  dplyr::slice(13:n()) %>%
  ungroup() %>%
  as.data.frame()

