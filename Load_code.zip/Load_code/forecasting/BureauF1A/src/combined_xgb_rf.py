import pandas as pd
import numpy as np
import os
import sys

from sklearn.metrics.pairwise import cosine_similarity
from PIL import Image
import datetime
from scipy import stats
import math  # for using atan function
import configparser
import warnings
warnings.simplefilter("ignore")



# ----------------------------------------------------------
# 			Helper Functions
# ----------------------------------------------------------

def convert_format(x):

    return x[0:4] + x[4:]


def write_to_report(str_):
    fname = '/efs/datascience/BureauF1A/output/combined_xgb_rf_op.csv'
    with open(fname, 'a') as h_file:
        h_file.write(str_ + '\n')


def get_slope(df):
    x_seq = np.arange(len(df))
    slope, intercept, r_value, p_value, std_err = stats.linregress(x_seq, df)
    # deg = math.atan(slope) * (180.0/math.pi)
    return slope


def get_direction_sig(df, num_points):
    sig = []
    # for k in range(0,len(df)-(num_points-1)):
    for k in range(0, len(df) - (num_points - 1)):
        df_temp = df[k:k + num_points]
        sl_ = 0 if get_slope(df_temp) < 0 else 1
        sig.append(sl_)
    return sig


def get_slope_sig(df, num_points):
    num_points = 2
    sig = []
    for k in range(0, len(df) - (num_points - 1)):
        df_temp = df[k:k + num_points]
        # sl_ = int(get_slope(df_temp))
        sl_ = get_slope(df_temp)
        sig.append(sl_)
    return sig


# ----------------------------------------------------------
# 			Variables
# ----------------------------------------------------------

# Note - Change these every monthly run
# variables

df = pd.read_csv('/efs/datascience/BureauF1A/output/combined_xgb_rf_input.csv')
forecast_start_date = int(sys.argv[1]) # 202204
num_points = 2  # number of points to consider to plot the regression line eg:2 means taking two consecutive months


print(df.head())

df['uniq_grain'] = df['DD_GRAIN1'] + "_"+ df['DD_GRAIN2']
# df['uniq_grain'] = df['Grain']

# df['yr_month'] = df['DD_ACTUALDATEVALUE'].apply(lambda x: convert_format(x))
df['yr_month'] = df['DD_ACTUALDATEVALUE'].astype('int')

# ---------------------------------------------------------

HEADER = "grain,cos_dir_actual_xgb,cos_dir_actual_rf,cos_slope_actual_xgb,cos_slope_actual_rf,choice,defaulted_choice"
# write_to_report(HEADER)


print(df.head())
df_ = pd.DataFrame()
for grain_comb in df.uniq_grain.unique():
    print(grain_comb)
    df_qt = df[df['uniq_grain'] == grain_comb]
    df_qt.sort_values(by='yr_month', inplace=True)

    # create actual (reference) , forecast(RF) and forecast(xgb)
    t_ = df_qt[df_qt['yr_month'] < forecast_start_date][df_qt.DD_FORECASTALGORITHM == 'STEPWISE_RANDOMFOREST']  # training period
    f_xgb = df_qt[df_qt['yr_month'] >= forecast_start_date][df_qt.DD_FORECASTALGORITHM == 'STEPWISE_XGBOOST']  # Forecast period
    f_rf = df_qt[df_qt['yr_month'] >= forecast_start_date][df_qt.DD_FORECASTALGORITHM == 'STEPWISE_RANDOMFOREST']  # Forecast period

    # compare direction vector
    vec_dir_actuals = get_direction_sig(t_.tail(12)['CT_SALESQUANTITY'], num_points)
    vec_dir_xgb = get_direction_sig(f_xgb.head(12)['CT_FORECASTQUANTITY'], num_points)
    vec_dir_rf = get_direction_sig(f_rf.head(12)['CT_FORECASTQUANTITY'], num_points)
    print(vec_dir_actuals)
    print(vec_dir_xgb)
    print(vec_dir_rf)
    cos_dir_act_xgb, cos_dir_act_rf = cosine_similarity([vec_dir_actuals], [vec_dir_xgb]), cosine_similarity(
        [vec_dir_actuals], [vec_dir_rf])
    # print(len(vec_dir_actuals),len(vec_dir_xgb),len(vec_dir_rf))

    # compare slope vector
    vec_slope_actuals = get_slope_sig(t_.tail(12)['CT_SALESQUANTITY'], num_points)
    vec_slope_xgb = get_slope_sig(f_xgb.head(12)['CT_FORECASTQUANTITY'], num_points)
    vec_slope_rf = get_slope_sig(f_rf.head(12)['CT_FORECASTQUANTITY'], num_points)
    cos_slope_act_xgb, cos_slope_act_rf = cosine_similarity([vec_slope_actuals], [vec_slope_xgb]), cosine_similarity(
        [vec_slope_actuals], [vec_slope_rf])

    if ((cos_dir_act_xgb >= cos_dir_act_rf) & (cos_slope_act_xgb >= cos_slope_act_rf)):
        choice = 'STEPWISE_XGBOOST'
    elif ((cos_dir_act_xgb <= cos_dir_act_rf) & (cos_slope_act_xgb <= cos_slope_act_rf)):
        choice = 'STEPWISE_RANDOMFOREST'
    else:
        choice = 'default'

    if choice == 'default':
        if (cos_dir_act_xgb >= cos_dir_act_rf):
            choice_defaulted = 'STEPWISE_XGBOOST'
        else:
            choice_defaulted = 'STEPWISE_RANDOMFOREST'
    else:
        choice_defaulted = choice
        str_ = f"{grain_comb},{float(cos_dir_act_xgb)},{float(cos_dir_act_rf)},{float(cos_slope_act_xgb)},{float(cos_slope_act_rf)},{choice},{choice_defaulted}"
        df_ = df_.append(pd.DataFrame(str_.split(',')).T)
#     write_to_report(str_)

df_.columns = [x for x in HEADER.split(',')]

df_.to_csv("/efs/datascience/BureauF1A/output/combined_xgb_rf_result.csv", index = False)
