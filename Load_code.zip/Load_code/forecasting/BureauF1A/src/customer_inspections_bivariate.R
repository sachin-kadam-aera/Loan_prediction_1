library(tidyr)
library(lubridate)
library(dplyr)
library(ggplot2)
library(forecastML)

# source files
source("./src/read_reports.R")

# Configurations
args <- commandArgs(trailingOnly = TRUE)
env.url <- args[1] #"https://insightqd.aeratechnology.com/ispring/client/v2/reports/"
token <- args[2] #"7f19ef36937891c23df05850223353c9"
page.size <- 10000

api.customer.inspection <- "InspectionsatCustomer"
api.holidays <- "holiday_calendar"
api.working.days <- "monthly_working_days"

top_50_customers <- read.csv("/efs/datascience/testing/top50customers.csv") # To be converted to a report.

inspections <- read_reports(env.url = env.url,
                            api.name = api.customer.inspection,
                            token = token,
                            page.size = page.size)

customers <- top_50_customers$Top_50_Customers

operating.office.mapping <- inspections %>%
  select(Operating.Office = operating_office, Territory = territory, Region = region) %>%
  distinct()

holidays.calendar <- read_reports(env.url = env.url,
                                  api.name = api.holidays,
                                  token = token,
                                  page.size = page.size)

working.days.monthly <- read_reports(env.url = env.url,
                                     api.name = api.working.days,
                                     token = token,
                                     page.size = page.size)

clean.inspection.dat <- inspections %>%
  select(Client.Name = client_name, Operating.Office = operating_office, Year.Month = year_month, Sum.Of.Mandays=sum_of_mandays) %>%
  mutate(Date = as.Date(paste(substr(as.character(inspections$year_month), 1, 4), substr(as.character(inspections$year_month), 5, 6), "01", sep = '-'), format = "%Y-%m-%d"),
         Client.Name = as.character(Client.Name)) %>%
  filter(Year.Month != 101) %>%
  mutate(Week.Start.Date = floor_date(Date, unit="week"),
         Month.Start.Date = floor_date(Date, unit = "month")) %>%
  select(Client.Name,
         Operating.Office,
         Date, Week.Start.Date,
         Month.Start.Date,
         Sum.Of.Mandays) %>%
  group_by(Client.Name, Operating.Office, Month.Start.Date) %>%
  summarise(Sum.Of.Mandays = sum(Sum.Of.Mandays), .groups = 'drop')

new.rows <- clean.inspection.dat %>%
  select(Operating.Office, Client.Name) %>%
  distinct() %>%
  mutate(Month.Start.Date = max(working.days.monthly$month_start_date),
         Sum.Of.Mandays = 0)

clean.inspection.dat <- rbind(clean.inspection.dat, new.rows)

clean.inspection.dat <- clean.inspection.dat %>%
  forecastML::fill_gaps(date_col = 3,
                        frequency = '1 month',
                        groups = c("Client.Name", "Operating.Office"))

clean.working.days.monthly <- working.days.monthly %>%
  mutate(Month.Start.Date = as.Date(month_start_date, format = "%Y-%m-%d"),
         Month.Label = month(Month.Start.Date,label = TRUE, abbr = FALSE)) %>%
  select(Month.Start.Date, Month.Working.Days = month_working_days, Territory = territory, Month.Label)

clean.holidays.calendar <- holidays.calendar %>%
  mutate(date = as.Date(holiday_date, format = "%Y-%m-%d"),
         is.holiday = 1,
         Month.Start.Date = floor_date(date, unit = 'month')) %>%
  select(Territory = territory, date, day = holiday_day, Month.Start.Date, is.holiday) %>%
  distinct() %>%
  group_by(Territory, Month.Start.Date) %>%
  summarise(No.of.Holidays = sum(is.holiday, na.rm = T), .groups = 'drop')

inspections.subset <- clean.inspection.dat %>%
  mutate(Operating.Office = as.character(Operating.Office)) %>%
  select(Client.Name,
         Operating.Office,
         Month.Start.Date,
         Mandays = Sum.Of.Mandays)

inspections.subset[is.na(inspections.subset$Mandays), "Mandays"] <- 0

inspections.with.holidays <- inspections.subset %>%
  inner_join(operating.office.mapping, by = "Operating.Office")  %>%
  left_join(clean.working.days.monthly, by = c("Territory", "Month.Start.Date")) %>%
  left_join(clean.holidays.calendar, by = c("Territory", "Month.Start.Date"))

inspections.with.holidays[is.na(inspections.with.holidays$No.of.Holidays), "No.of.Holidays"] <- 0

inspections.at.operating.office <- inspections.with.holidays %>% filter(Client.Name %in% customers)

inspections.at.operating.office.input <- inspections.at.operating.office %>%
  select(Client.Name, Operating.Office, Month.Start.Date, Month.Label, Month.Working.Days, No.of.Holidays, Mandays) %>%
  group_by(Client.Name, Operating.Office, Month.Label, Month.Start.Date) %>%
  summarise(Month.Working.Days = mean(Month.Working.Days, na.rm = T),
            number.of.holidays = sum(No.of.Holidays, na.rm = T),
            Total.mandays = sum(Mandays, na.rm = T),
            .groups = 'drop') %>%
  arrange(Client.Name, Operating.Office, Month.Start.Date, Month.Label) %>%
  group_by(Client.Name, Operating.Office) %>%
  mutate(`sin_month` = sin(2*pi/(12)*month(Month.Start.Date)),
         `cos_month` = cos(2*pi/(12)*month(Month.Start.Date))) %>%
  mutate(SBU = "CUSTOMER",
         date_year = year(Month.Start.Date)) %>%
  select(`Customer Name` = Client.Name,
         `Operating Office` = Operating.Office,
         SBU,
         month_start_date = Month.Start.Date,
         `Month Label` = Month.Label,
         date_year,
         Volume = Total.mandays,
         `Month Working Days` = Month.Working.Days,
         `Number of Holidays` = number.of.holidays,
         everything())

inspections.at.operating.office.input <- inspections.at.operating.office.input %>%
  group_by(`Customer Name`, `Operating Office`) %>%
  ungroup() %>%
  as.data.frame()


inspections.at.all <- inspections.with.holidays %>% filter(Client.Name %in% customers) %>% filter(!Operating.Office %in% c("KOWLOON BAY", "TAIWAN")) %>%
mutate(Operating.Office="ALLOTHERCUSTOMERS") 

inspections.at.all.input<- inspections.at.all %>%
  select(Client.Name, Operating.Office, Month.Start.Date, Month.Label, Month.Working.Days, No.of.Holidays, Mandays) %>%
  group_by(Client.Name, Operating.Office, Month.Label, Month.Start.Date) %>%
  summarise(Month.Working.Days = mean(Month.Working.Days, na.rm = T),
            number.of.holidays = mean(No.of.Holidays, na.rm = T),
            Total.mandays = sum(Mandays, na.rm = T),
            .groups = 'drop') %>%
  arrange(Client.Name, Operating.Office, Month.Start.Date, Month.Label) %>%
  group_by(Client.Name, Operating.Office) %>%
  mutate(`sin_month` = sin(2*pi/(12)*month(Month.Start.Date)),
         `cos_month` = cos(2*pi/(12)*month(Month.Start.Date))) %>%
  mutate(SBU = "CUSTOMER",
         date_year = year(Month.Start.Date)) %>%
  select(`Customer Name` = Client.Name,
         `Operating Office` = Operating.Office,
         SBU,
         month_start_date = Month.Start.Date,
         `Month Label` = Month.Label,
         date_year,
         Volume = Total.mandays,
         `Month Working Days` = Month.Working.Days,
         `Number of Holidays` = number.of.holidays,
         everything())

inspections.at.all.input <- inspections.at.all.input %>%
  group_by(`Customer Name`, `Operating Office`) %>%
  ungroup() %>%
  as.data.frame()


inspections.for.cortex <- rbind(inspections.at.operating.office.input,inspections.at.all.input)

write.csv(inspections.for.cortex, paste0("/efs/datascience/BureauF1A/output/customer_level_inspection_bivariate_input.csv"), row.names = FALSE)


