library(tidyr)
library(lubridate)
library(dplyr)
library(forecastML)

source("./src/read_reports.R")

args <- commandArgs(trailingOnly = TRUE)
env.url <- args[1] 
token <- args[2]
page.size <- 10000
normalize <- TRUE

api.submissions <- "bv_submission_univariate"
api.holidays <- "holiday_calendar"
api.working.days <- "monthly_working_days"

submissions <- read_reports(env.url = env.url,
                            api.name = api.submissions,
                            token = token,
                            page.size = page.size)

operating.office.mapping <- submissions %>%
  select(Operating.Office = operating_office, Territory = territory, Region = region) %>%
  distinct()

holidays.calendar <- read_reports(env.url = env.url,
                                  api.name = api.holidays,
                                  token = token,
                                  page.size = page.size)

working.days.monthly <- read_reports(env.url = env.url,
                                     api.name = api.working.days,
                                     token = token,
                                     page.size = page.size)


clean.submissions.dat <- submissions %>%
  filter(year_month != 101) %>%
  mutate(Date = as.Date(date, format = "%d %b %Y"),
         Lab.Location = as.character(operating_office)) %>%
  mutate(Week.Start.Date = floor_date(Date, unit="week"),
         Month.Start.Date = floor_date(Date, unit = "month")) %>%
  select(Lab.Location, Product.Line=product_line, Month.Start.Date, Count.of.Submission = count_of_submission) %>%
  group_by(Product.Line, Lab.Location, Month.Start.Date) %>%
  summarise(Count.of.Submission = sum(Count.of.Submission, na.rm = T), .groups = 'drop')

new.rows <- clean.submissions.dat %>%
  select(Lab.Location, Product.Line) %>%
  distinct() %>%
  mutate(Month.Start.Date = max(working.days.monthly$month_start_date),
         Count.of.Submission = 0)

clean.submissions.dat <- rbind(clean.submissions.dat, new.rows)

clean.submissions.dat <- clean.submissions.dat %>%
  forecastML::fill_gaps(date_col = 3,
                        frequency = '1 month',
                        groups = c("Product.Line", "Lab.Location"))

clean.working.days.monthly <- working.days.monthly %>%
  mutate(Month.Start.Date = as.Date(month_start_date, format = "%Y-%m-%d"),
         Month.Label = month(Month.Start.Date,label = TRUE, abbr = FALSE)) %>%
  select(Month.Start.Date, Month.Working.Days = month_working_days, Territory = territory, Month.Label)

clean.holidays.calendar <- holidays.calendar %>%
  mutate(date = as.Date(holiday_date, format = "%Y-%m-%d"),
         is.holiday = 1,
         Month.Start.Date = floor_date(date, unit = 'month')) %>%
  select(Territory = territory, date, day = holiday_day, Month.Start.Date, is.holiday) %>%
  distinct() %>%
  group_by(Territory, Month.Start.Date) %>%
  summarise(No.of.Holidays = sum(is.holiday, na.rm = T), .groups = 'drop')

submissions.subset <- clean.submissions.dat %>%
  mutate(Lab.Location = as.character(Lab.Location)) %>%
  select(Product.Line,
         Operating.Office = Lab.Location,
         Month.Start.Date,
         Submissions = Count.of.Submission) 

submissions.subset[is.na(submissions.subset$Submissions), "Submissions"] <- 0

# Normalize 2020
if(normalize){
  cat("Performing 2020 Normalization")
  submissions.subset <- submissions.subset %>%
    arrange(Product.Line, Operating.Office, Month.Start.Date) %>%
    group_by(Product.Line, Operating.Office) %>%
    mutate(lag.12 = lag(Submissions, 12)) %>%
    mutate(flag.2020 = ifelse(year(Month.Start.Date) == 2020, 1, 0)) %>%
    replace_na(list(lag.12 = 0)) %>%
    mutate(Normalized.Submissions = (Submissions + flag.2020 * lag.12)/(1 + flag.2020)) %>%
    select(Product.Line, Operating.Office, Month.Start.Date, Submissions = Normalized.Submissions)
}

submissions.with.holidays <- submissions.subset %>%
  inner_join(operating.office.mapping, by = "Operating.Office")  %>% 
  left_join(clean.working.days.monthly, by = c("Territory", "Month.Start.Date")) %>% 
  left_join(clean.holidays.calendar, by = c("Territory", "Month.Start.Date"))

submissions.with.holidays[is.na(submissions.with.holidays$No.of.Holidays), "No.of.Holidays"] <- 0

input.dat <- submissions.with.holidays %>%
  ungroup()

# Garbage collection
rm(submissions.with.holidays, 
   submissions.subset, 
   clean.holidays.calendar,
   clean.working.days.monthly, 
   clean.submissions.dat,
   working.days.monthly,
   new.rows,
   holidays.calendar,
   operating.office.mapping,
   submissions)
gc()

write.csv(input.dat, "/efs/datascience/BureauF1A/output/submissions_input_stepwise.csv", row.names = F)