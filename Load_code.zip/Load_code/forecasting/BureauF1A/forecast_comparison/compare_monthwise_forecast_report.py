# Checks to compare forecast outputs for current month and the previous month
# modified 28 Oct 2021
# This file : Forked from monthly_comparison_v4_B ( for conversion to .py for automation)

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import os
from PIL import Image
import datetime
import sys
from scipy import stats
import math  # for using atan function

from sklearn.metrics.pairwise import cosine_similarity

import warnings
warnings.simplefilter("ignore")


# ---------------------------------------------------------------
#   			Helper functions
# ---------------------------------------------------------------


# Helper Functions

# Write something to a file
def write_to_file(str_):
    fname = './out.txt'
    with open(fname, 'a') as h_file:
        h_file.write(str_+'\n')

# Get the current date-time stamp ( for creating unique file names)
def get_current_time_stamp():
    time_now = datetime.datetime.now()
    date_time_now = time_now.strftime('%Y' + "_" + '%m' + '_' + '%d' + '_' + '%H' + '_' + '%M' + '_' + '%S')
    return date_time_now

# Write into a log file
def write_to_log(str_):
    fname = './log_'+ tstamp +'.txt'
    with open(fname, 'a') as h_file:
        h_file.write(str_+'\n')

# Write into the error-log file
def log_error(str_):
    fname = './errorlog_'+ tstamp +'.txt'
    with open(fname, 'a') as h_file:
        h_file.write(str_+'\n')

# Fit a line to x and y coordinates
def get_trendline(x,y):
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    return p

def get_file_name(str_) :
    l_str = str_.split('/')
    return l_str[len(l_str)-1].split('.')[0].upper()

def remove_sp_chars(str_):
    return str_.replace("\\","").replace("/","").replace(" ","_").replace(",","")

# def write_to_report(str_):
# 	fname = f"../reports/report_monthly_comparison_{report_fname}_{tstamp}.csv"
# 	with open(fname, 'a') as h_file:
#     	h_file.write(str_+'\n')
#
def remove_comma(str_):
    return str_.replace(",","")

#create a file name ( jpg extension for charts) based on some string tuple arguments
def get_filename(str_tup,ext_='.jpg') :
    str_= "~".join(str_tup)
    str_ = remove_comma(str_)
    return str_.replace("\\","").replace("/","").replace(" ","-")+ ext_

# def create_chart():
#         #
#         #plt_ax = plt.axis('off');
#         plt_1  = plt.plot(m1_df_forecast[forecast_vol_column]);
#         plt_2 = plt.plot(m2_df_forecast[forecast_vol_column]);
#         #plt_sav = plt.savefig(img_folder_path + "/" +  img_fname , dpi = 100,format = 'jpeg');
#         plt_sav = plt.savefig(f'../reports/charts/{img_fname}' , dpi = 100,format = 'jpeg');
#         plt.clf();


def get_slope(df):
    x_seq = np.arange(len(df))
    slope, intercept, r_value, p_value, std_err = stats.linregress(x_seq, df)
    #deg = math.atan(slope) * (180.0/math.pi)
    return slope


def get_direction_sig(df,num_points) :
    sig = []
    #for k in range(0,len(df)-(num_points-1)):
    for k in range(0,len(df)-(num_points-1)):
        df_temp = df[k:k+num_points]
        sl_ = 0 if get_slope(df_temp) < 0 else 1
        sig.append(sl_)
    return sig


# get slope & angle of t12 and f12 values
def get_slope_12(df_act,df_fcast):
    x1_seq = np.arange(12)
    x2_seq = x1_seq+12
    slope1, intercept1, r_value1, p_value1, std_err1 = stats.linregress(x1_seq, df_act)
    slope2, intercept2, r_value2, p_value2, std_err2 = stats.linregress(x2_seq, df_fcast)
    deg1 = math.atan(slope1) * (180.0/math.pi)
    deg2 = math.atan(slope2) * (180.0/math.pi)
    return slope1,slope2,deg1, deg2

def create_hyperlink(str_):
    return '=HYPERLINK("%s")' % (str_)

# check if folder exists - if not, create it from the config folder name
def create_dir(list_dir) :
    for DIR_ in list_dir :
        if not os.path.exists(DIR_):
            os.makedirs(DIR_)

# Check if volumne and percentage deviation are greater than threshold
def check_deviation(a,b) :
    #print(a,CHANGE_VOL_PERCENTAGE,b,CHANGE_VOL_ABS)
    if (a > CHANGE_VOL_PERCENTAGE) and (b > CHANGE_VOL_ABS) :
        return True
    else : return False


# this function return null if value = nan
def remove_nan(val_) :
    if np.isnan(val_) :
        return ''



# ---------------------------------------------------------------
#   			Helper functions
# ---------------------------------------------------------------

# Change this as command line args
m2_df_report  = pd.read_csv(sys.argv[2])  # last month file
m1_df_report  = pd.read_csv(sys.argv[1])  # current month file


# ---------------------------------------------------------------
#   			Declarations
# ---------------------------------------------------------------

process_name = m2_df_report.DD_PROCESS_NAME.iloc[0]
month1_jobID = m1_df_report.DD_JOBID.iloc[0]
month2_jobID = m2_df_report.DD_JOBID.iloc[0]
report_fname = remove_sp_chars(process_name).upper() # Check with umesh - output file name to be picked from process name

filter_1_col = 'DD_GRAIN1'
filter_2_col = 'DD_GRAIN2'
filter_3_col = 'DD_GRAIN3'

forecast_date_column = 'DD_ACTUALDATEVALUE'
forecast_vol_column = 'CT_FORECASTQUANTITY'
actual_vol_column = 'CT_SALESQUANTITY'

horizon_start_date = int(sys.argv[3]) # 202110
horizon_end_date = int(sys.argv[4]) #202209

#  Thresholds
INCREASE_EVAL_METRIC = 50   # this is the % increase in eval metric ( error ) of this month as compared to last month
CHANGE_VOL_PERCENTAGE = 15
CHANGE_VOL_ABS = 50
COSINE_SIM_DIRECTION_THRESHOLD = 0.7


# ---------------------------------------------------------------
#   			Declarations
# ---------------------------------------------------------------

tstamp = get_current_time_stamp()

# Dataframe  to write the final output
column_names = "ELEMENT1,ELEMENT2,ELEMENT3,M1_TOP_ALGO,M2_TOP_ALGO,M1_TOP_ALGO_EVAL,M2_TOP_ALGO_EVAL,MAX_VOL_DEV,MAX_PERC_DEV,MONTHS_DEVIATING,MAX_VOL_ACTUAL_12M,AVG_VOL_ACTUAL_12M,CHANGE_ALGO,CHANGE_TO_FALLBACK,EVAL_METRIC_INCREASE,ALGO_CHANGE_AND_EVAL_CHANGE,VOL_AND_PERC_DEVIATED,TREND_DIFFERENT, COS_SIM_TREND"
print(column_names)
columns = column_names.split(",")
df_out = pd.DataFrame (columns=columns )
m1_df_report = m1_df_report[m1_df_report["DD_FORECASTRANK"] == 1]
m2_df_report = m2_df_report[m2_df_report["DD_FORECASTRANK"] == 1]

m1_df_filtered = m1_df_report.drop_duplicates(subset = [filter_1_col, filter_2_col,filter_3_col],keep ='first')
m1_list_filtered  = m1_df_filtered[[filter_1_col, filter_2_col,filter_3_col]].values.tolist()
m2_df_filtered = m2_df_report.drop_duplicates(subset = [filter_1_col, filter_2_col,filter_3_col],keep ='first')
m2_list_filtered  = m2_df_filtered[[filter_1_col, filter_2_col,filter_3_col]].values.tolist()
l_common_grains = [k for k in m1_list_filtered if k in m2_list_filtered ]  #common grains for both months


for element_1, element_2,element_3  in l_common_grains:

    m1_df_grain = m1_df_report[ ( m1_df_report[filter_1_col]== element_1 ) & (m1_df_report[filter_2_col] == element_2) & (m1_df_report[filter_3_col] == element_3)]
    m2_df_grain = m2_df_report[ ( m2_df_report[filter_1_col]== element_1 ) & (m2_df_report[filter_2_col] == element_2) & (m2_df_report[filter_3_col] == element_3)]

    # Filter for top ranked algo
    m1_df_top_ranked = m1_df_grain [m1_df_grain['DD_FORECASTRANK']==1]
    m2_df_top_ranked = m2_df_grain [m2_df_grain['DD_FORECASTRANK']==1]

    # Get the top ranked algo name
    m1_top_algo = m1_df_top_ranked['DD_FORECASTALGORITHM'].iloc[0]
    m2_top_algo = m2_df_top_ranked['DD_FORECASTALGORITHM'].iloc[0]

    # Get the top ranked algo metric
    m1_top_algo_metric = m1_df_top_ranked['CT_RANKINGMETRICVALUE'].iloc[0]
    m2_top_algo_metric = m2_df_top_ranked['CT_RANKINGMETRICVALUE'].iloc[0]

    # ------------------- ACTUAL VOLUMES (AVG, MAX) FROM THE LATEST MONTH (M2) ------------------------

    m2_df_actual_12 = m2_df_top_ranked[m2_df_top_ranked[forecast_date_column] < horizon_start_date].sort_values(by=forecast_date_column).tail(12)
    max_actual_vol_12 = m2_df_actual_12[actual_vol_column].max()
    avg_actual_vol_12 = m2_df_actual_12[actual_vol_column].mean()

    # ------------------- FORECAST COMPARISON  NUMBERS ------------------------
    # get the forecast subsetted with the dates to forecast ( avoid random ordering )

    m1_df_top_ranked = m1_df_top_ranked.sort_values(by = forecast_date_column)
    m2_df_top_ranked = m2_df_top_ranked.sort_values(by = forecast_date_column)

    # Sort the top ranked dfs based on the date_column
    m1_df_forecast = m1_df_top_ranked[(m1_df_top_ranked[forecast_date_column] >= horizon_start_date ) &  (m1_df_top_ranked[forecast_date_column] <= horizon_end_date)]
    m2_df_forecast = m2_df_top_ranked[(m2_df_top_ranked[forecast_date_column] >= horizon_start_date ) &  (m2_df_top_ranked[forecast_date_column] <= horizon_end_date)]

    m1_df_forecast = m1_df_forecast.sort_values(by=forecast_date_column).reset_index()
    m2_df_forecast = m2_df_forecast.sort_values(by=forecast_date_column).reset_index()

    #m1_df_forecast[forecast_vol_column],m2_df_forecast[forecast_vol_column]
    df_fc_comp = pd.merge(m1_df_forecast[[forecast_date_column,forecast_vol_column]], m2_df_forecast[[forecast_date_column,forecast_vol_column]], on=forecast_date_column, how='outer')

    # rename to make it simpler names - nothing more
    df_fc_comp  =  df_fc_comp.rename(columns={'DD_ACTUALDATEVALUE':'fc_date','CT_FORECASTQUANTITY_x':'m1_vol' ,'CT_FORECASTQUANTITY_y':'m2_vol'})
    df_fc_comp['vol_diff_abs'] =abs(df_fc_comp['m2_vol'] - df_fc_comp['m1_vol'] )
    df_fc_comp['vol_diff_perctg'] = abs((df_fc_comp['m2_vol'] - df_fc_comp['m1_vol'] )*100 / df_fc_comp['m1_vol'] )

    df_fc_comp['CHK'] = df_fc_comp.apply(lambda x : check_deviation(abs(x['vol_diff_perctg']), abs(x['vol_diff_abs']) ),axis = 1 )

    max_vol_dev =  df_fc_comp.vol_diff_abs.max()
    #vol_dev_low =  df_fc_comp.vol_diff_abs.min()
    max_perc_dev = df_fc_comp.vol_diff_perctg.max()

    #max_perc_dev =  max(abs(perc_dev_low),abs(perc_dev_high) )
    #max_vol_dev =  max(abs(vol_dev_low),abs(vol_dev_high) )

    # number of months where the deviations are above the threshold
    months_deviating = len(df_fc_comp[df_fc_comp['CHK'] == True] )

    #write the grain to combine it later
    df_fc_comp['grain'] =  '{remove_sp_chars(element_1)}-{remove_sp_chars(element_2)}-{remove_sp_chars(element_3)}'


    # ----------- month-to-month trend check ( cosine similarity)
    num_points = 2
    a= get_direction_sig(m1_df_forecast[forecast_vol_column],num_points)
    b= get_direction_sig(m2_df_forecast[forecast_vol_column],num_points)

    # --------------------- The checks -------------------

    # CHK_1 = True if the top algorithm has changed
    CHK_1 = True if m1_top_algo != m2_top_algo else False

    # CHK_2  = True if the algo has change from any non-fallback to FALL BACK
    CHK_2 = True if (CHK_1 and( m1_top_algo != 'FALL_BACK_NAIVE')  and( m2_top_algo == 'FALL_BACK_NAIVE')) else False

    # CHK_3 = True if the eval metric ( of top algo) has increased more than the threshold
    if not np.isnan(m2_top_algo_metric) :
        # this condition to take care of nan values for metric or grains where rank 1 = fallback
        CHK_3 = True if ((m2_top_algo_metric - m1_top_algo_metric)*100/(m1_top_algo_metric) )> INCREASE_EVAL_METRIC else False
    else :
        CHK_3 = 'CND'  # 'could not detemine' becasue nan

    # CHK _4 = True if the top algorithm has changed and the evaluation metric has gone past the threshold
    # What it means : The eval metric most probably changed because the algorithm has changed.
    CHK_4 = True if ( (str(CHK_3)=='True') & (str(CHK_1)=='True') ) else False

    CHK_5  = True if (months_deviating > 0) else False

    cos_sim_trend = (cosine_similarity([a],[b])).flatten()[0]
    CHK_6  =  True if (cos_sim_trend < COSINE_SIM_DIRECTION_THRESHOLD) else False

    #append the new row to the output dataframe
    data_values = [remove_comma(element_1), remove_comma(element_2),remove_comma(element_3),\
       m1_top_algo,m2_top_algo,m1_top_algo_metric,m2_top_algo_metric, \
       max_vol_dev,max_perc_dev,months_deviating, \
       max_actual_vol_12,avg_actual_vol_12, \
       CHK_1,CHK_2,CHK_3,CHK_4,CHK_5,CHK_6,cos_sim_trend]
    new_row = pd.Series(data_values,index=df_out.columns )
    df_out = df_out.append(new_row, ignore_index=True)

    str_ = "{remove_comma(element_1)}, {remove_comma(element_2)},{remove_comma(element_3)},{m1_top_algo},{m2_top_algo},{m1_top_algo_metric},{m2_top_algo_metric},{max_vol_dev},{max_perc_dev},{months_deviating},{max_actual_vol_12},{avg_actual_vol_12},{CHK_1},{CHK_2},{CHK_3},{CHK_4},{CHK_5},{CHK_6},{cos_sim_trend}"

df_out = df_out.replace([np.inf, -np.inf], np.nan)  # Replcae inf value with nan
# remove the na values -
df_out= df_out.fillna('')  # remove the nan/na values for db load failure fix  -

# Append 3 columns - month1jobID, month2jobID, Process Name - to be loaded to db
df_out['LAST_MONTH_JOBID'] = month2_jobID
df_out['CURRENT_MONTH_JOBID'] = month1_jobID
df_out['DD_PROCESS_NAME'] = process_name
process_name=process_name.replace(" ","_")
output_path = os.path.dirname(sys.argv[1])
print("Output file ->", output_path + "/" + month1_jobID + "_" +month2_jobID + '.csv.gz')
df_out.to_csv(output_path +'/' + month1_jobID + "_" +month2_jobID + 'fcst_comp_results.csv.gz',index=False)
