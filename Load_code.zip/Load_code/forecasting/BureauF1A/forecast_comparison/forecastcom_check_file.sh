#!/bin/bash

set -o errexit
USER1=$(whoami)

forecastcom_input_file1=$1
forecastcom_input_file2=$2
forecastcom_output_file=$3

echo "Input file path1 :"$forecastcom_input_file1
echo "Input file path2 :"$forecastcom_input_file2
echo "Output file path:"$forecastcom_output_file

cd /efs/datascience/BureauF1A/output/forecast_comparison/

rm -f $forecastcom_input_file1
rm -f $forecastcom_input_file2
rm -f $forecastcom_output_file
