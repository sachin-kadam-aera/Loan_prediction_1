#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on..


yml_file_path=$1
py_path=$2
input_csv_file1=$3
input_csv_file2=$4
horizon_start_date=$5
horizon_date=$6
HOST=$7


echo "py_path:"$py_path
echo "yml_file_path: "$yml_file_path
echo "input_csv_file1 "$input_csv_file1
echo "input_csv_file2 "$input_csv_file2
echo "horizon_start_date: "$horizon_start_date
echo "horizon_date: "$horizon_date
echo "HOST: "$HOST


echo "This script call Forecast01 (UAT-IRL) shell script"



response=$(curl -s $HOST | cut -d '"' -f 2)
echo "Responce:"$response


if [[ "$response" == "Server is running" ]];
	then
		echo "Running Submission R Script..."
		status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_comparison/run_forecast_comparison.sh '$yml_file_path' '$py_path' '$input_csv_file1' '$input_csv_file2' '$horizon_start_date' '$horizon_date' "}')
echo 'script o/p-'$status
fi





