#!/bin/bash

set -o errexit
USER1=$(whoami)

tvar_replace_name=$1
input_csv_file=$2

echo "tmp external name :"$tvar_replace_name
echo "input csv file :"$input_csv_file

if [ -f /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_comparison/load_forecastcompare_$tvar_replace_name.sql ]
then
mv /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_comparison/load_forecastcompare_$tvar_replace_name.sql /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_comparison/load_forecastcompare_$tvar_replace_name.sql.previousversion
fi

sed "s/var_ext/$tvar_replace_name/g" /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_comparison/template_load_forecast_compare.sql |sed "s|var_file_path|$input_csv_file|g" >> /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_comparison/load_forecastcompare_$tvar_replace_name.sql

chmod 777 /efs/datascience/aera-datascience/deploy/forecasting/BureauF1A/forecast_comparison/load_forecastcompare_$tvar_replace_name.sql


