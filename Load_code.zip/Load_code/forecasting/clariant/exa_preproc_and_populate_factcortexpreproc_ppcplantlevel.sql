

/* 1. Add data from the latest month - which is stored in stg_orderdataraw */
/* Ensure there's no duplication. Only insert data for rows that are not present in fact_orderdataraw_allmonths */
DROP TABLE IF EXISTS tmp_distinctmonthsalreadypresent;
CREATE TABLE tmp_distinctmonthsalreadypresent
AS
SELECT DISTINCT to_char(to_date(substr(CUSTOMERREQUESTEDMATERIALAVAILABILITYDATE,1,10),'YYYY-MM-DD'),'YYYYMM') dd_crmadate_yyyymm 
FROM fact_orderdataraw_allmonths;

INSERT INTO fact_orderdataraw_allmonths 
SELECT s.*
FROM stg_orderdataraw s
WHERE NOT EXISTS ( SELECT 1 FROM tmp_distinctmonthsalreadypresent t
WHERE to_char(to_date(substr(s.CUSTOMERREQUESTEDMATERIALAVAILABILITYDATE,1,10),'YYYY-MM-DD'),'YYYYMM') = t.dd_crmadate_yyyymm );

/* 2. Cleanup: Remove ZPRS records. Update ppc to mapped ppc(dd_ppc_final) from dim_ppcmapping table */
DELETE FROM fact_orderdataraw_allmonths
WHERE ItemCategory = 'ZPRS';

UPDATE fact_orderdataraw_allmonths t
SET t.PPC = m.dd_ppc_final
FROM fact_orderdataraw_allmonths t,dim_ppcmapping m
WHERE t.ppc = m.dd_ppc
AND t.PPC <> m.dd_ppc_final;

/* 3. Aggregate at ppc-plant-month level */

DROP TABLE IF EXISTS tmp_salesorder_ppcplant;
CREATE TABLE tmp_salesorder_ppcplant
AS
SELECT
CAST('PPC-DeliveryPlant' AS VARCHAR(100)) dd_graindefinition,
PPC || '-' || DELIVERYPLANT dd_forecastgrain,
ppc dd_ppc,
deliveryplant dd_deliveryplant,
to_date(substr(CUSTOMERREQUESTEDMATERIALAVAILABILITYDATE,1,10),'YYYY-MM-DD') dd_crmadate,
SUM(ORDERQUANTITYINBASEUNIT) ct_orderqty
FROM fact_orderdataraw_allmonths
GROUP BY 1,2,3,4,5;

DROP TABLE IF EXISTS tmp_salesorder_ppcplant_monthly;
CREATE TABLE tmp_salesorder_ppcplant_monthly
AS
SELECT dd_graindefinition,dd_forecastgrain,dd_ppc,dd_deliveryplant,
year(dd_crmadate)||lpad(month(dd_crmadate),2,'0') dd_yyyymm,
TO_DATE(year(dd_crmadate)||lpad(month(dd_crmadate),2,'0')||'01','YYYYMMDD') dd_crmadate_monthly,
sum(ct_orderqty) ct_orderqty
FROM tmp_salesorder_ppcplant
GROUP BY 1,2,3,4,5,6; 

/* 4. Imputation: Fill missing months with 0s. Start from first month with non-zero orderqty */

DROP TABLE IF EXISTS tmp_daterange;
CREATE TABLE tmp_daterange
AS
SELECT DISTINCT dd_crmadate_monthly
FROM tmp_salesorder_ppcplant_monthly;

DROP TABLE IF EXISTS tmp_min_nonzerodate;
CREATE TABLE tmp_min_nonzerodate
AS
SELECT dd_graindefinition,dd_forecastgrain,dd_ppc,dd_deliveryplant,
t.dd_snapshotdate dd_crmadate_monthly_max,
MIN(dd_crmadate_monthly) dd_crmadate_monthly_min
FROM tmp_salesorder_ppcplant_monthly, dim_currentsnapshotdate t
WHERE ct_orderqty > 0
GROUP BY dd_graindefinition,dd_forecastgrain,dd_ppc,dd_deliveryplant, t.dd_snapshotdate;

DROP TABLE IF EXISTS tmp_alldates_allgrains;
CREATE TABLE tmp_alldates_allgrains
AS
SELECT t1.*,d.dd_crmadate_monthly
FROM tmp_min_nonzerodate t1, tmp_daterange d
WHERE d.dd_crmadate_monthly >= t1.dd_crmadate_monthly_min
AND d.dd_crmadate_monthly <= t1.dd_crmadate_monthly_max;

DELETE FROM tmp_alldates_allgrains a
WHERE EXISTS ( SELECT 1 FROM tmp_salesorder_ppcplant_monthly s
WHERE s.dd_forecastgrain = a.dd_forecastgrain
AND s.dd_crmadate_monthly = a.dd_crmadate_monthly);


DROP TABLE IF EXISTS tmp_salesorder_ppcplant_monthly_imputed;
CREATE TABLE tmp_salesorder_ppcplant_monthly_imputed
AS
SELECT s.dd_graindefinition, s.dd_forecastgrain, s.dd_ppc, s.dd_deliveryplant, s.dd_yyyymm, dd_crmadate_monthly,
s.ct_orderqty,
CAST(0 AS DECIMAL(10,2)) ct_orderqty_modifiedoutliertreated,
CAST('NoError' AS VARCHAR(20)) dd_exceptionflag,
CAST('E0' AS VARCHAR(20)) dd_exceptioncode,
CAST('None' as VARCHAR(100)) dd_exceptiondescritpion,
CAST('None' AS VARCHAR(10)) dd_outlierflag
FROM tmp_salesorder_ppcplant_monthly s 
UNION
SELECT a.dd_graindefinition, a.dd_forecastgrain, a.dd_ppc, a.dd_deliveryplant,
year(dd_crmadate_monthly)||lpad(month(dd_crmadate_monthly),2,'0') dd_yyyymm,
a.dd_crmadate_monthly,
0 ct_orderqty,
CAST(0 AS DECIMAL(10,2)) ct_orderqty_modifiedoutliertreated,
CAST('NoError' AS VARCHAR(20)) dd_exceptionflag,
CAST('E0' AS VARCHAR(20)) dd_exceptioncode,
CAST('None' as VARCHAR(100)) dd_exceptiondescritpion,
CAST('None' AS VARCHAR(10)) dd_outlierflag
FROM tmp_alldates_allgrains a;

/* 5. Statistics on Imputed Data */
/* Calculate some statistics for each grain */
/* Use only on the 18 months. Reasons: Very old data may be very different from current data. Data after snapshot date cannot be used as it will mean look-ahead */

DROP TABLE IF EXISTS tmp_salesorder_ppcplant_monthly_imputed_anl;
CREATE TABLE tmp_salesorder_ppcplant_monthly_imputed_anl
AS
SELECT dd_forecastgrain,dd_exceptionflag,dd_exceptiondescritpion,dd_exceptioncode,
sum(ct_orderqty) qty_sum,
ROUND(avg(ct_orderqty),1) qty_avg,
median(ct_orderqty) qty_med,
min(ct_orderqty) qty_min,
max(ct_orderqty) qty_max,
max(ct_orderqty) - min(ct_orderqty) qty_range,
ROUND((max(ct_orderqty) - min(ct_orderqty))/(CASE WHEN ROUND(avg(ct_orderqty),1) = 0 THEN 1 ELSE ROUND(avg(ct_orderqty),1) END),2) qty_rangebymean,
ROUND(stddev(ct_orderqty),1) qty_sd,
ROUND(ROUND(stddev(ct_orderqty),1)/(CASE WHEN ROUND(avg(ct_orderqty),1) = 0 THEN 1 ELSE ROUND(avg(ct_orderqty),1) END),2) qty_cov,
count(*) cnt_months,
SUM(CASE WHEN ct_orderqty > 0 THEN 1 ELSE 0 END) cnt_nonzero,
SUM(CASE WHEN ct_orderqty > 0 THEN 1 ELSE 0 END)/count(*) ratio_nonzero,
min(dd_crmadate_monthly) mindate,
max(dd_crmadate_monthly) maxdate,
rank() over(order by sum(ct_orderqty) desc) dd_rank_vol,
rank() over(order by count(*) desc) dd_rank_count,
rank() over(order by 
ROUND(ROUND(stddev(ct_orderqty),1)/(CASE WHEN ROUND(avg(ct_orderqty),1) = 0 THEN 1 ELSE ROUND(avg(ct_orderqty),1) END),2) desc) dd_rank_cov
FROM tmp_salesorder_ppcplant_monthly_imputed, dim_currentsnapshotdate t
WHERE dd_crmadate_monthly > t.dd_snapshotdate - INTERVAL '18' MONTH   
AND dd_crmadate_monthly <= t.dd_snapshotdate 
GROUP BY dd_forecastgrain,dd_exceptionflag,dd_exceptiondescritpion,dd_exceptioncode;

UPDATE tmp_salesorder_ppcplant_monthly_imputed_anl
SET qty_avg = 0.1
WHERE qty_avg = 0;

UPDATE tmp_salesorder_ppcplant_monthly_imputed_anl
SET qty_med = 0.1
WHERE qty_med = 0;

/* 6. Exception classification */
DROP TABLE IF EXISTS tmp_last6mzero;
CREATE TABLE tmp_last6mzero
AS
SELECT dd_forecastgrain,sum(ct_orderqty) ct_orderqty
FROM tmp_salesorder_ppcplant_monthly_imputed, dim_currentsnapshotdate t
WHERE dd_crmadate_monthly > t.dd_snapshotdate - INTERVAL '4' MONTH
AND dd_crmadate_monthly <= t.dd_snapshotdate
GROUP BY dd_forecastgrain
HAVING sum(ct_orderqty) <= 0;

UPDATE tmp_salesorder_ppcplant_monthly_imputed_anl a
SET dd_exceptionflag = 'Error',
dd_exceptiondescritpion = 'Last 4m are zero. Forecast these as zero',
dd_exceptioncode = 'E1'
FROM tmp_salesorder_ppcplant_monthly_imputed_anl a, tmp_last6mzero t
WHERE a.dd_exceptionflag = 'NoError'
AND a.dd_forecastgrain = t.dd_forecastgrain;

/* Very low median --> Median <= 1 */
UPDATE tmp_salesorder_ppcplant_monthly_imputed_anl a
SET dd_exceptionflag = 'Error',
dd_exceptiondescritpion = 'Median is 0 - Intermittent or outdated grain. Forecast by 6MA',
dd_exceptioncode = 'E2'
WHERE dd_exceptionflag = 'NoError'
AND qty_med <= 1;

/* Intermittent: More than 20% 0s */
UPDATE tmp_salesorder_ppcplant_monthly_imputed_anl a
SET dd_exceptionflag = 'Error',
dd_exceptiondescritpion = 'Intermittent More than 20% zeros. Forecast by 6MA or Crostons',
dd_exceptioncode = 'E3'
WHERE dd_exceptionflag = 'NoError'
AND ratio_nonzero <= 0.8;

/* Training Data Points */
UPDATE tmp_salesorder_ppcplant_monthly_imputed_anl a
SET dd_exceptionflag = 'Error',
dd_exceptiondescritpion = 'Short History - less than 12 months training data. Forecast by 6MA or ARIMA or SES',
dd_exceptioncode = 'E4'
WHERE dd_exceptionflag = 'NoError'
AND cnt_months < 18;


/* Update the exception flags in timeseries data */
UPDATE tmp_salesorder_ppcplant_monthly_imputed i
SET i.dd_exceptionflag = a.dd_exceptionflag,
i.dd_exceptiondescritpion = a.dd_exceptiondescritpion,
i.dd_exceptioncode = a.dd_exceptioncode
FROM tmp_salesorder_ppcplant_monthly_imputed i,tmp_salesorder_ppcplant_monthly_imputed_anl a
WHERE i.dd_forecastgrain = a.dd_forecastgrain;

UPDATE tmp_salesorder_ppcplant_monthly_imputed i
SET i.dd_exceptionflag = 'Error',
i.dd_exceptiondescritpion = 'No History in last 18 months. Forecast 0 for these',
i.dd_exceptioncode = 'E5'
FROM tmp_salesorder_ppcplant_monthly_imputed i
WHERE NOT EXISTS ( SELECT 1 FROM tmp_salesorder_ppcplant_monthly_imputed_anl a
WHERE i.dd_forecastgrain = a.dd_forecastgrain);

/* 7. Outlier treatment */

DROP TABLE IF EXISTS tmp_salesorder_ppcplant_monthly_imputed_anl_outliers;
CREATE TABLE tmp_salesorder_ppcplant_monthly_imputed_anl_outliers
AS
SELECT t.*, qty_avg/qty_med ratio_avgtomed
FROM tmp_salesorder_ppcplant_monthly_imputed_anl t
WHERE (qty_avg/qty_med < 0.5 OR qty_avg/qty_med > 1.5)
AND dd_exceptionflag = 'NoError';

/* Find median from last 6 months for each data point. Rolling Window */
DROP TABLE IF EXISTS tmp_salesorder_ppcplant_monthly_imputed_runningstat;
CREATE TABLE tmp_salesorder_ppcplant_monthly_imputed_runningstat
AS
SELECT i1.*, median(i2.ct_orderqty) ct_orderqty_median6m,
avg(i2.ct_orderqty) ct_orderqty_avg6m,
ABS(i1.ct_orderqty - median(i2.ct_orderqty)) ct_absdeviation,
CAST(0 AS DECIMAL(10,2)) ct_mad
FROM tmp_salesorder_ppcplant_monthly_imputed i1 INNER JOIN
tmp_salesorder_ppcplant_monthly_imputed i2
ON i1.dd_forecastgrain = i2.dd_forecastgrain
WHERE i1.dd_crmadate_monthly > i2.dd_crmadate_monthly 
AND i1.dd_crmadate_monthly <= i2.dd_crmadate_monthly + INTERVAL '6' MONTH
GROUP BY i1.*;

DROP TABLE IF EXISTS tmp_grainwisemad;
CREATE TABLE tmp_grainwisemad
AS
SELECT t.dd_forecastgrain, median(ct_absdeviation) ct_mad
FROM tmp_salesorder_ppcplant_monthly_imputed_runningstat t
GROUP BY t.dd_forecastgrain;

UPDATE tmp_salesorder_ppcplant_monthly_imputed_runningstat t
SET t.ct_mad = m.ct_mad
FROM tmp_salesorder_ppcplant_monthly_imputed_runningstat t, tmp_grainwisemad m
WHERE t.dd_forecastgrain = m.dd_forecastgrain;


UPDATE tmp_salesorder_ppcplant_monthly_imputed_runningstat t
SET t.dd_outlierflag = 'Yes-2MAD',
t.ct_orderqty_modifiedoutliertreated = t.ct_orderqty_median6M
WHERE ct_absdeviation > 2 * ct_mad;

UPDATE tmp_salesorder_ppcplant_monthly_imputed_runningstat t
SET t.ct_orderqty_modifiedoutliertreated = t.ct_orderqty
WHERE dd_outlierflag = 'None';

/* Update main preproc table */
UPDATE tmp_salesorder_ppcplant_monthly_imputed i
SET i.ct_orderqty_modifiedoutliertreated = i.ct_orderqty;

UPDATE tmp_salesorder_ppcplant_monthly_imputed i
SET i.ct_orderqty_modifiedoutliertreated = t.ct_orderqty_modifiedoutliertreated,
i.dd_outlierflag = t.dd_outlierflag
FROM tmp_salesorder_ppcplant_monthly_imputed i, tmp_salesorder_ppcplant_monthly_imputed_runningstat t
WHERE i.dd_forecastgrain = t.dd_forecastgrain 
AND i.dd_crmadate_monthly = t.dd_crmadate_monthly;

/* 8. Populate fact_cortexpreproc_ppcplantlevel. Maintain only the current snapshot */
/* Archive to be maintained in fact_cortexpreproc_ppcplantlevel_archive */
DROP TABLE IF EXISTS fact_cortexpreproc_ppcplantlevel;
CREATE TABLE fact_cortexpreproc_ppcplantlevel
AS
SELECT 
rank() over(order by '') fact_cortexpreproc_ppcplantlevelid,
t1.dd_snapshotdate,
t.*
FROM tmp_salesorder_ppcplant_monthly_imputed t, dim_currentsnapshotdate t1;

DELETE FROM fact_cortexpreproc_ppcplantlevel_archive a
WHERE EXISTS ( SELECT 1 FROM dim_currentsnapshotdate s
WHERE s.dd_snapshotdate = a.dd_snapshotdate);

UPDATE fact_cortexpreproc_ppcplantlevel_archive
SET dd_currentsnapshotflag = 'N';

INSERT INTO fact_cortexpreproc_ppcplantlevel_archive
AS
SELECT f.*, 'Y' dd_currentsnapshotflag
FROM fact_cortexpreproc_ppcplantlevel f;


