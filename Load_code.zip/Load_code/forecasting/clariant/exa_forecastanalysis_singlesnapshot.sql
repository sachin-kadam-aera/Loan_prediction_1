open schema clariant;

DROP TABLE IF EXISTS tmp_grain_exception;
CREATE TABLE tmp_grain_exception
AS
SELECT DISTINCT dd_forecastgrain dd_grain1, dd_exceptioncode
FROM tmp_salesorder_ppcplant_monthly_imputed ; --fact_cortexpreproc_ppcplantlevel;

select f.dd_grain1, --f.dd_forecastdate, 
e.dd_exceptioncode, sum(f.ct_forecastquantity) fcst
FROM tmp_forecastouput_singlejob f, tmp_grain_exception e
WHERE f.dd_grain1 = e.dd_grain1
AND f.dd_forecastrank = 1
AND f.dd_forecastdate >= '2018-12-31'
AND f.dd_forecastdate <= '2019-12-31'
AND e.dd_exceptioncode in ('E1') --,'E2')
GROUP BY f.dd_grain1, e.dd_exceptioncode
ORDER BY sum(f.ct_forecastquantity) desc, f.dd_grain1, e.dd_exceptioncode;


SELECT dd_forecastgrain, dd_yyyymm, ct_orderqty, ct_orderqty_modifiedoutliertreated, dd_exceptioncode, DD_EXCEPTIONDESCRITPION
FROM tmp_salesorder_ppcplant_monthly_imputed --fact_cortexpreproc_ppcplantlevel
WHERE dd_forecastgrain = '16418726007-INB3'
ORDER BY dd_yyyymm;

SELECT *
FROM tmp_fcst_6ma
WHERE dd_forecastgrain = '30848030033-9AR1';

SELECT *
FROM tmp_forecastouput_singlejob
WHERE dd_forecastrank = 1
AND dd_grain1 = '30848030033-9AR1';

