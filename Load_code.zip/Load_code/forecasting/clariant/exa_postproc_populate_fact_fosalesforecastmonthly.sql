

/* Get 6MA for rankingmode and final forecast */
/* Should have all the grains */
DROP TABLE IF EXISTS tmp_fcst_6ma;
CREATE TABLE tmp_fcst_6ma
AS
SELECT DISTINCT t1.dd_forecastgrain,
CAST('6MA' AS VARCHAR(30)) dd_forecasttype,
CAST(0 AS DECIMAL(10,2)) ct_rankingmode_forecastquantity,
CAST(0 AS DECIMAL(10,2)) ct_fcst_6ma_withoutoutlier_ranking,
CAST(0 AS DECIMAL(10,2)) ct_forecastquantity,
CAST(0 AS DECIMAL(10,2)) ct_fcst_6ma_withoutoutlier_final
FROM fact_cortexpreproc_ppcplantlevel t1
WHERE EXISTS ( SELECT 1 FROM dim_currentsnapshotdate s where t1.dd_snapshotdate = s.dd_snapshotdate);

/* Ranking table for 6MA. Uses training period data for calculating 6MA */
DROP TABLE IF EXISTS tmp_fcst_6ma_ranking;
CREATE TABLE tmp_fcst_6ma_ranking
AS
SELECT t1.dd_forecastgrain, 
avg(t1.ct_orderqty_modifiedoutliertreated) ct_fcst_6ma_ranking,
avg(t1.ct_orderqty) ct_fcst_6ma_withoutoutlier_ranking
FROM fact_cortexpreproc_ppcplantlevel t1, dim_currentsnapshotdate t
WHERE dd_crmadate_monthly > t.dd_snapshotdate - INTERVAL '12' MONTH
AND dd_crmadate_monthly <= t.dd_snapshotdate - INTERVAL '6' MONTH
GROUP BY t1.dd_forecastgrain;

/* Final fcst for 6MA. Uses last 6 months from snapshot date */
DROP TABLE IF EXISTS tmp_fcst_6ma_final;
CREATE TABLE tmp_fcst_6ma_final
AS
SELECT t1.dd_forecastgrain, 
avg(t1.ct_orderqty_modifiedoutliertreated) ct_fcst_6ma_final,
avg(t1.ct_orderqty) ct_fcst_6ma_withoutoutlier_final
FROM fact_cortexpreproc_ppcplantlevel t1, dim_currentsnapshotdate t
WHERE dd_crmadate_monthly > t.dd_snapshotdate - INTERVAL '6' MONTH
AND dd_crmadate_monthly <= t.dd_snapshotdate 
GROUP BY t1.dd_forecastgrain;

UPDATE tmp_fcst_6ma t
SET t.ct_rankingmode_forecastquantity = t1.ct_fcst_6ma_ranking,
t.ct_fcst_6ma_withoutoutlier_ranking = t1.ct_fcst_6ma_withoutoutlier_ranking
FROM tmp_fcst_6ma t, tmp_fcst_6ma_ranking t1
WHERE t.dd_forecastgrain = t1.dd_forecastgrain;

UPDATE tmp_fcst_6ma t
SET t.ct_forecastquantity = t1.ct_fcst_6ma_final,
t.ct_fcst_6ma_withoutoutlier_final = t1.ct_fcst_6ma_withoutoutlier_final
FROM tmp_fcst_6ma t, tmp_fcst_6ma_final t1
WHERE t.dd_forecastgrain = t1.dd_forecastgrain;

/* Pick up only the data for current job from dim_currentcortexjob. dim_currentcortexjob will be populate at runtime or manually by user */
DROP TABLE IF EXISTS tmp_forecastouput_singlejob;
CREATE TABLE tmp_forecastouput_singlejob
AS
SELECT c.dd_jobid, 
t.dd_snapshotdate, 
c.dd_grain2 dd_grain1, 
substr(c.dd_grain2,1,11) dd_ppc,
substr(c.dd_grain2,13,4) dd_deliveryplant,
c.dd_forecastalgorithm dd_forecasttype,
c.dd_forecastrank,
c.dd_forecastdate,
c.dd_actualdatevalue dd_yyyymm,
c.ct_salesquantity,
c.ct_rankingmode_forecastquantity,
c.ct_forecastquantity,
d.dd_holdout_date dd_endoftrainingperiod,
d.dd_last_date dd_endofholdoutperiod,
d.dd_horizon_date dd_endofhorizonperiod,
CASE WHEN c.dd_actualdatevalue <= d.dd_holdout_date THEN 'Training' 
WHEN c.dd_actualdatevalue <= d.dd_last_date THEN 'Test' 
WHEN c.dd_actualdatevalue > d.dd_holdout_date THEN 'Horizon'
END dd_forecastsample,
CAST(0 AS INT) dd_forecastlagfromsnapshotdate,
CAST(0 AS DECIMAL(10,2)) ct_absoluteerror_rankingmode,
CAST(0 AS DECIMAL(10,2)) ct_biaserror_rankingmode
FROM FACT_FORECASTOUTPUT_CORTEX_DATA c, dim_currentsnapshotdate  t, dim_jobmetadata_cortex_data d, dim_currentcortexjob cj
WHERE c.dd_jobid = cj.dd_cortexjobid
AND c.dd_jobid = d.dd_jobid
AND c.dd_forecastalgorithm IN ('FALL_BACK_NAIVE','FittestARIMA','CROSTONS_MA','TBATS','SIMPLE_EXPO_SMOOTHING');

/* For exception grains, use only the specified methods */
DROP TABLE IF EXISTS tmp_grain_exception;
CREATE TABLE tmp_grain_exception
AS
SELECT DISTINCT dd_forecastgrain dd_grain1, dd_exceptioncode
FROM fact_cortexpreproc_ppcplantlevel;


DELETE FROM tmp_forecastouput_singlejob t
WHERE EXISTS ( SELECT 1 FROM tmp_grain_exception e
WHERE t.dd_grain1 = e.dd_grain1
AND e.dd_exceptioncode IN ('E3'))
AND dd_forecasttype NOT IN ('FALL_BACK_NAIVE','CROSTONS_MA');

/* Populate lag column dd_forecastlagfromsnapshotdate */
DROP TABLE IF EXISTS tmp_rank_horizonperiods;
CREATE TABLE tmp_rank_horizonperiods
AS
SELECT dd_forecastdate,
rank() over(order by dd_forecastdate) dd_forecastlagfromsnapshotdate
FROM 
(SELECT DISTINCT dd_forecastdate FROM tmp_forecastouput_singlejob WHERE dd_forecastsample = 'Horizon');

UPDATE tmp_forecastouput_singlejob f
SET f.dd_forecastlagfromsnapshotdate = t.dd_forecastlagfromsnapshotdate
FROM tmp_forecastouput_singlejob f, tmp_rank_horizonperiods t
WHERE f.dd_forecastdate = t.dd_forecastdate;

/* Generate naive for all periods */
DROP TABLE IF EXISTS tmp_distinctdates_fcst;
CREATE TABLE tmp_distinctdates_fcst
AS
SELECT DISTINCT dd_jobid, 
dd_snapshotdate,
dd_forecastdate,
dd_yyyymm,
dd_endoftrainingperiod,
dd_endofholdoutperiod,
dd_endofhorizonperiod,
dd_forecastsample,
dd_forecastlagfromsnapshotdate
FROM tmp_forecastouput_singlejob;

DROP TABLE IF EXISTS tmp_6MAforecasts_naive;
CREATE TABLE tmp_6MAforecasts_naive
AS
SELECT c.dd_jobid, 
c.dd_snapshotdate, 
naive.dd_forecastgrain dd_grain1, 
substr(naive.dd_forecastgrain,1,11) dd_ppc,
substr(naive.dd_forecastgrain,13,4) dd_deliveryplant,
'FALL_BACK_NAIVE' dd_forecasttype,
-1 dd_forecastrank,
c.dd_forecastdate,
c.dd_yyyymm dd_yyyymm,
CAST(0 AS DECIMAL(10,2)) ct_salesquantity,
naive.ct_rankingmode_forecastquantity,
naive.ct_forecastquantity,
c.dd_endoftrainingperiod,
c.dd_endofholdoutperiod,
c.dd_endofhorizonperiod,
c.dd_forecastsample,
dd_forecastlagfromsnapshotdate,
CAST(0 AS DECIMAL(10,2)) ct_absoluteerror_rankingmode,
CAST(0 AS DECIMAL(10,2)) ct_biaserror_rankingmode
FROM tmp_distinctdates_fcst c, tmp_fcst_6ma naive;

UPDATE tmp_6MAforecasts_naive t
SET t.ct_salesquantity = s.ct_orderqty_modifiedoutliertreated
FROM tmp_6MAforecasts_naive t, fact_cortexpreproc_ppcplantlevel s
WHERE t.dd_grain1 = s.dd_forecastgrain
AND t.dd_yyyymm = s.dd_yyyymm;

DELETE FROM tmp_forecastouput_singlejob
WHERE dd_forecasttype = 'FALL_BACK_NAIVE';

INSERT INTO tmp_forecastouput_singlejob
SELECT *
FROM tmp_6MAforecasts_naive;

/* Holdout calculations, ranking */
DROP TABLE IF EXISTS tmp_holdoutdata;
CREATE TABLE tmp_holdoutdata
AS
SELECT dd_grain1, dd_forecasttype, dd_yyyymm, 
CAST(0 AS DECIMAL(10,2)) ct_salesquantity,
ct_rankingmode_forecastquantity,
ct_forecastquantity
FROM tmp_forecastouput_singlejob
WHERE dd_forecastsample = 'Test';

UPDATE tmp_holdoutdata t
SET t.ct_salesquantity = s.ct_orderqty_modifiedoutliertreated
FROM tmp_holdoutdata t, fact_cortexpreproc_ppcplantlevel s
WHERE t.dd_grain1 = s.dd_forecastgrain
AND t.dd_yyyymm = s.dd_yyyymm;

/* Holdout Metrics are based on outlier treated sales */
DROP TABLE IF EXISTS tmp_holdoutmetrics;
CREATE TABLE tmp_holdoutmetrics
AS
SELECT dd_grain1, dd_forecasttype, 
sum(abs(ct_rankingmode_forecastquantity - ct_salesquantity)) ct_mae,
rank() over(partition by dd_grain1 order by sum(abs(ct_rankingmode_forecastquantity - ct_salesquantity)),dd_forecasttype) dd_forecastrankmae
FROM tmp_holdoutdata
GROUP BY dd_grain1, dd_forecasttype;

UPDATE tmp_forecastouput_singlejob f
SET f.dd_forecastrank = t.dd_forecastrankmae
FROM tmp_forecastouput_singlejob f, tmp_holdoutmetrics t
WHERE f.dd_grain1 = t.dd_grain1
AND f.dd_forecasttype = t.dd_forecasttype;

UPDATE tmp_forecastouput_singlejob f
SET f.ct_forecastquantity = 0
FROM tmp_forecastouput_singlejob f, tmp_grain_exception e
WHERE f.dd_grain1 = e.dd_grain1
AND e.dd_exceptioncode in ('E1')
AND f.dd_forecastsample = 'Horizon';

UPDATE tmp_forecastouput_singlejob f
SET ct_absoluteerror_rankingmode = abs(ct_rankingmode_forecastquantity - ct_salesquantity),
ct_biaserror_rankingmode = ct_rankingmode_forecastquantity - ct_salesquantity;


/* If the snapshot already exists, then delete it */
DELETE FROM fact_fosalesforecastmonthly f
WHERE EXISTS ( SELECT 1 FROM dim_currentsnapshotdate s
WHERE f.dd_snapshotdate = s.dd_snapshotdate);

/* Update all previous snapshots to N */
UPDATE fact_fosalesforecastmonthly
SET dd_latestsnapshotflag = 'N';


/* Only current snapshot will have flag Y */
INSERT INTO fact_fosalesforecastmonthly
(
	FACT_FOSALESFORECASTMONTHLYID, 
	DD_JOBID, 
	DD_SNAPSHOTDATE, 
	DD_GRAIN1, 
	DD_PPC, 
	DD_DELIVERYPLANT, 
	DD_FORECASTTYPE, 
	DD_FORECASTRANK, 
	DD_FORECASTDATE, 
	DD_YYYYMM, 
	CT_SALESQUANTITY, 
	CT_RANKINGMODE_FORECASTQUANTITY, 
	CT_FORECASTQUANTITY, 
	DD_ENDOFTRAININGPERIOD, 
	DD_ENDOFHOLDOUTPERIOD, 
	DD_ENDOFHORIZONPERIOD, 
	DD_FORECASTSAMPLE, 
	DD_FORECASTLAGFROMSNAPSHOTDATE, 
	DD_LATESTSNAPSHOTFLAG, 
	CT_ABSOLUTEERROR_RANKINGMODE, 
	CT_BIASERROR_RANKINGMODE
)
SELECT 
	rank() over(order by '') FACT_FOSALESFORECASTMONTHLYID, 
	DD_JOBID, 
	DD_SNAPSHOTDATE, 
	DD_GRAIN1, 
	DD_PPC, 
	DD_DELIVERYPLANT, 
	DD_FORECASTTYPE, 
	DD_FORECASTRANK, 
	DD_FORECASTDATE, 
	DD_YYYYMM, 
	CT_SALESQUANTITY, 
	CT_RANKINGMODE_FORECASTQUANTITY, 
	CT_FORECASTQUANTITY, 
	DD_ENDOFTRAININGPERIOD, 
	DD_ENDOFHOLDOUTPERIOD, 
	DD_ENDOFHORIZONPERIOD, 
	DD_FORECASTSAMPLE, 
	DD_FORECASTLAGFROMSNAPSHOTDATE, 
	CAST('Y' as varchar(10)) DD_LATESTSNAPSHOTFLAG, 
	CT_ABSOLUTEERROR_RANKINGMODE, 
	CT_BIASERROR_RANKINGMODE
FROM tmp_forecastouput_singlejob t;


UPDATE fact_fosalesforecastmonthly
SET fact_fosalesforecastmonthlyid = rownum;
