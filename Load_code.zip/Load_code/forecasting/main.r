library(forecast)
# library(seasonal)
# Sys.setenv(X13_PATH = "/Users/sshetty/Downloads/x13assrc_V1.1_B19")
library(zoo)
library(MASS)
library(tsintermittent)
data_transform <- function(data,pow){
  if(pow == 'log'){
    return(log(1+data))
  }
  else if (pow=='exp'){
    return (exp(data)-1)
  }
  return(data^pow)
}

# #Test dataset
# data = read.csv('/Users/sshetty/git/release/datascience/forecasting/data/R_test/NAmerica_EMD.csv')
# holdout_months=3
# horizon_in_months=26
#start_date=20140131
# end_date='20171130'
# time_unit='M'
#
generate_hw_forecast <- function(data,holdout_months,horizon_in_months,start_date,end_date,time_period) {
#Prepare preprocessing data
num = nrow(data)
start_year = as.integer(start_date/10000)
start_month = as.integer((start_date%%10000)/100)
end_year = as.integer(end_date/10000)
end_month = as.integer((end_date%%10000)/100)
time_period = as.integer(time_period)
start_week = as.integer(format(as.Date(toString(start_date) ,format='%Y%m%d'), "%W"))
end_week = as.integer(format(as.Date(toString(end_date) ,format='%Y%m%d'), "%W"))

if(time_period == 12){
x <- ts(data,start=c(start_year,start_month),end=c(end_year,end_month),frequency=12)
 }
 else if (time_period == 53){
x <- ts(data,start=c(start_year,start_week),end=c(end_year,end_week),frequency=53)
}

a0 <- data.frame(matrix(NA,nrow=time_period,ncol=5))
colnames(a0) <- c("Forecast","Low95PI","High95PI","Low90PI","High90PI")

#Model data
fit <- HoltWinters(x)
forecast <- forecast(fit,holdout_months+horizon_in_months+1,95)

#training fit
fitted <- data.frame(as.numeric(forecast$fitted))
colnames(fitted)<- c('Forecast')
fitted['Low95PI']=NA
fitted['High95PI']=NA
#Forecast values
mean <- data.frame(forecast)
colnames(mean) <- c("Forecast","Low95PI","High95PI")

## 90% PI level
forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
#training fit
fitted['Low90PI']=NA
fitted['High90PI']=NA
#Forecast values
mean['Low90PI']=forecast_90['Lo 90']
mean['High90PI']=forecast_90['Hi 90']

# Prepare output
a1 = rbind(fitted,mean)
a2 = rbind(a0,a1)
return (a2)
}

generate_hw_forecast_mult <- function(data,holdout_months,horizon_in_months,start_date,end_date,time_period) {
# Prepare preprocess data
num = nrow(data)
start_year = as.integer(start_date/10000)
start_month = as.integer((start_date%%10000)/100)
end_year = as.integer(end_date/10000)
end_month = as.integer((end_date%%10000)/100)

time_period = as.integer(time_period)
#print (holdout_months, horizon_in_months)
start_week = as.integer(format(as.Date(toString(start_date) ,format='%Y%m%d'), "%W"))
end_week = as.integer(format(as.Date(toString(end_date) ,format='%Y%m%d'), "%W"))

if(time_period == 12){
x <- ts(data,start=c(start_year,start_month),end=c(end_year,end_month),frequency=12)
 }
 else if (time_period == 53){
x <- ts(data,start=c(start_year,start_week),end=c(end_year,end_week),frequency=53)
}

a0 <- data.frame(matrix(NA,nrow=time_period,ncol=5))
colnames(a0) <- c("Forecast","Low95PI","High95PI","Low90PI","High90PI")
#Model data
fit <- HoltWinters(x, seasonal = "mult")
forecast <- forecast(fit,holdout_months+horizon_in_months+1,95)

#Training fit
fitted <- data.frame(as.numeric(forecast$fitted))
colnames(fitted)<- c('Forecast')
fitted['Low95PI']=NA
fitted['High95PI']=NA
#Forecast values
mean <- data.frame(forecast)
colnames(mean) <- c("Forecast","Low95PI","High95PI")

## 90% PI level
forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
#training fit
fitted['Low90PI']=NA
fitted['High90PI']=NA
#Forecast values
mean['Low90PI']=forecast_90['Lo 90']
mean['High90PI']=forecast_90['Hi 90']

# Prepare output
a1 = rbind(fitted,mean)
a2 = rbind(a0,a1)
return (a2)
}
#
# Model to forecast using ARIMA technique
#

generate_auto_arima <- function(data,holdout_months,horizon_in_months,time_period) {
  #prepare preprocessing
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data,frequency = time_period)

  #model data
  fit <- auto.arima(x,max.p = time_period,max.q = time_period,max.P=time_period, max.Q=time_period)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  mean <- data.frame(forecast)
  colnames(mean) <- c("Forecast","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  mean['Low90PI']=forecast_90['Lo 90']
  mean['High90PI']=forecast_90['Hi 90']

  # Prepare output
  a1 = rbind(fitted,mean)
  return (a1)
  }

#
# Model to forecast using BoxCox transformation and ARIMA technique
#
generate_processed_auto_arima <- function(data,holdout_months,horizon_in_months,time_period) {
  #Prepare preprocessing
  tmp=boxcox(data$Sales~1, lambda = seq(0,2,0.1) ) ##Box cox transformation
  time_period = as.integer(time_period)

  #Get the power for normality transformation
  trans_power=tmp$x[which.max(tmp$y)]
  trans_power= ifelse(trans_power==0,'log',trans_power)

  #Transform data
  data=data_transform(data,trans_power)
  num = nrow(data)
  x=ts(data = data,frequency = time_period)

  #Model data
  fit <- auto.arima(x,max.p = time_period,max.q = time_period,max.P=time_period, max.Q=time_period)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  trans_power=ifelse(trans_power=='log','exp',1/trans_power)
  fitted <- data.frame(data_transform(as.numeric(forecast$fitted),trans_power))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- as.data.frame(data_transform(as.data.frame(forecast),trans_power))
  colnames(forecast_fit) <- c("Forecast","Low95PI","High95PI")
  forecast_fit[forecast_fit['Low95PI'] > forecast_fit['High95PI'],"Low95PI"] = 0


  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90),
                               row.names = seq(1,33))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  forecast_fit['Low90PI'] = na.fill(data_transform(forecast_90['Lo 90'],trans_power),0)
  forecast_fit['High90PI']= na.fill(data_transform(forecast_90['Hi 90'],trans_power),0)
  forecast_fit[forecast_fit['Low90PI'] > forecast_fit['High90PI'],"Low90PI"] = 0
  #Prepare output
  a1 = rbind(fitted,forecast_fit)
  return (a1)
}

#
# Model to forecast using ETS techinique (SES/HW)
#
generate_forecast_ETS <- function(data,holdout_months,horizon_in_months,time_period) {
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data,frequency = time_period)
  fit <- ets(c(x),model="ZZZ")
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)
  #training fit
  fitted <- data.frame((as.numeric(forecast$fitted)))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- data.frame(forecast)
  colnames(forecast_fit) <- c("Forecast","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  forecast_fit['Low90PI']=forecast_90['Lo 90']
  forecast_fit['High90PI']=forecast_90['Hi 90']

  #Prepare output
  a1 = rbind(fitted,forecast_fit)
  return (a1)
}

generate_forecast_crostons <- function(data,holdout_months,horizon_in_months){
  forecast = crost(data$Sales,h=holdout_months+horizon_in_months+1,outplot=T, cost="mse")
  #training fit
  fitted <- data.frame((as.numeric(forecast$frc.in)))
  colnames(fitted)<- c('Forecast')

  #Forecast values
  forecast_fit <- data.frame(forecast$frc.out)
  colnames(forecast_fit) <- c("Forecast")


  #Prepare output
  a1 = rbind(fitted,forecast_fit)
  a1['Low90PI'] = 1/NA
  a1['High90PI'] = 1/NA
  #Forecast values
  a1['Low95PI'] = 1/NA
  a1['High95PI'] = 1/NA

  return (a1)
}


generate_forecast_nnet_AR<-function(data,holdout_months,horizon_in_months,time_period){

  #model data
  set.seed(19)
  time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = time_period)
  fit <- nnetar(x)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1)

  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  mean <- data.frame(as.numeric(forecast$mean))
  colnames(fitted)<- c('Forecast')
  colnames(mean)<- c('Forecast')
  # Prepare output
  a1 = rbind(fitted,mean)
  return (a1)
}
?nnetar
# generate_forecast_X13 <- function(data,holdout_months,horizon_in_months,start_date){
# #
# #   Requires 36 month of historic data to forecast
# #
#   x=ts(data = data,frequency = 12,start = c(as.integer(start_date/100),1))
#
#   m_fit <- seas(AirPassengers)
#   ft <- as.data.frame(series(m, "forecast.forecasts"))
#
#   #training fit
#   fitted <- data.frame(rep(NA,length(data$Sales)))
#   colnames(fitted)<- c('Forecast')
#
#   #Forecast values
#   forecast_fit <- data.frame(ft$forecast[1:horizon_in_months])
#   colnames(forecast_fit) <- c("Forecast")
#
#
#   #Prepare output
#   # No idea about CI and PI percentile so adding it to both
#   a1 = rbind(fitted,forecast_fit)
#   a1['Low90PI'] = ft$lowerci
#   a1['High90PI'] = ft$upperci
#   #Forecast values
#   a1['Low95PI'] = ft$lowerci
#   a1['High95PI'] = ft$upperci
#
#   return (a1)
# }


