import pandas as pd
import numpy as np

# Incoming Fields:
# UIN,YYYYMMDD,Comop,Sales,Month,Forecast,MAPE,Forecast_Type

def forecast_rankings(forecast_data):
    ds = forecast_data[['UIN', 'Comop', 'Forecast_Type', 'MAPE','Bias_Error']]
    ds.loc[:, "Bias_Error"] = np.abs(ds["Bias_Error"])
    ds = ds.drop_duplicates()
    g = ds.groupby(['UIN', 'Comop'])
    ds['Forecast_Rank'] = g['MAPE'].rank(method="dense", ascending=True)
    ds['Bias_Error_Rank'] = g['Bias_Error'].rank(method="dense", ascending=True)
    ds = ds.drop('MAPE', 1)
    ds = ds.drop('Bias_Error', 1)
    forecast_data_with_rankings = pd.merge(forecast_data,ds,how='left',on=['UIN', 'Comop', 'Forecast_Type'])
    return forecast_data_with_rankings
