#!/bin/sh
set -x

#Take the forecastoutput as input
file1=$1

dest=${file1}.withcolumnsadded.csv

#Split the dd_level2 columns into 5 columns(single pipe-separated field into 5 comma-separated fields 
head -1 $file1 | sed 's/dd_level2/c1,c2,c3,c4,c5/' > hdr.$$
sed -n '2,$p' $file1|sed 's/|/,/g' > xyz.csv1.$$;cat hdr xyz.csv1.$$ > $dest
#grep -v dd_reportingdate $file1|sed 's/|/,/g' > xyz.csv1.$$;cat hdr xyz.csv1.$$ > $dest

echo "Destination forecast file is $dest"

rm -f xyz.csv1.$$ hdr.$$
