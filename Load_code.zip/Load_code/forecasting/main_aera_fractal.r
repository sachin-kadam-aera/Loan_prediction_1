library(forecast)
library(MAPA)
# library(seasonal)
# Sys.setenv(X13_PATH = "/Users/sshetty/Downloads/x13assrc_V1.1_B19")
library(bsts)
library(MASS)
library(tsintermittent)
library(xgboost)
library(dplyr)
format_negatives<-function(x){
  try(x[x<0]<-0,silent=TRUE)
  return(x)
}
data_transform <- function(data,pow){
  if(pow == 'log'){
    return(log(1+data))
  }
  else if (pow=='exp'){
    return (exp(data)-1)
  }
  return(data^pow)
}

# #Test dataset
# data = read.csv('/Users/sshetty/git/release/datascience/forecasting/data/R_test/NAmerica_EMD.csv')
# holdout_months=3
# horizon_in_months=26
# start_date=201201
# end_date='20140901'
# time_unit='M'
#
###################Bivariate methods#########################
#generate_BI_ARIMAX <- function(Y,X,Xtest,rholdout_months,rhorizon_in_months,time_period)
generate_xgboost_fractal <- function(Train_Sales,data,data1,Test_Sales,holdout_months,horizon_in_months,time_period) {
data1 = data1[nrow(data)+1:nrow(Test_Sales),]
Test_Sales = Test_Sales[nrow(data)+1:nrow(Test_Sales),]

#print(data1)
#print(Test_Sales)
#print(length(Train_Sales))
#print(length(Test_Sales))
#print(length(data))
#:wq
print(length(data1))

drop<-c("Month")
a<-data
a<-a[!names(a) %in% drop]

#print(nrow(Train_Sales))
#print(nrow(Test_Sales))
#print(nrow(data))
#print(nrow(data1))
#model data
time_period = as.integer(time_period)
data$Sales = as.numeric(Train_Sales$Sales)
data1$Sales = as.numeric(Test_Sales)
sample_xgboost<-data1
num = nrow(data)

start =  (nrow(data) -  nrow(data[data$Sales!= 0,])) + 1
end = nrow(data); train_period = start:end; test_period = (end+1):(end+13);forecast_period =  (end+1):num
#print(start)
#print(end)
#Specify features here
features_da<-names(sample_xgboost)[c(1:ncol(sample_xgboost))]
features_da<-features_da[!features_da %in% c("Month","Sales")]
data_xgboost_complete<-sample_xgboost
wltst_da=train_period[(length(train_period)-5):length(train_period)]
data_xgboost_train <- data # sample_xgboost[dplyr::setdiff(train_period,wltst_da),]
#print("Train test split  DONE---------------------")
#Specify the target variable name
target_da<-'Sales'
data_xgboost_complete[,features_da] <- as.numeric(data_xgboost_complete[,features_da])
#Specify the cross - validation matrix to build ensembles
dval_da <- xgb.DMatrix(data=data.matrix(data_xgboost_complete[wltst_da,features_da]),
                       label=data.matrix(data_xgboost_complete[wltst_da,target_da]),missing=NA)

watchlist_da <- list(dval=dval_da)

#List the flexible parameters for model to tune
# eta<-c(0.3,0.1,0.5)
# max_depth<-c(5,7)
# subsample<-c(1,0.7)
# colsample_bytree<-c(0.4,0.7,1)
eta<-c(0.3)
max_depth<-c(7)
subsample<-c(0.7)
colsample_bytree<-c(1.0)
data_xgboost_train[,features_da] <- as.numeric(data_xgboost_train[,features_da])
formula = paste("Sales ~ ", paste0(features_da,collapse = "+" ))
model1 <- lm(formula,data = data_xgboost_train)



modelcoef <- na.omit(model1$coefficients)
#print("-----STarting the model-----")

if(length(modelcoef)>1){
  set.seed(2017)
  clf_qty_da2 <-     xgb.train(params=list(objective="reg:linear", booster = "gbtree", eta=eta,max_depth=max_depth,
                                        subsample=subsample, colsample_bytree=colsample_bytree) ,
                            data = xgb.DMatrix(data=data.matrix(data_xgboost_train[,features_da]),label=data.matrix(data_xgboost_train[,target_da]),missing = NA),
                            nrounds = 300,
                            verbose = 0,
                            print_every_n = 5,
                            # early_stopping_rounds = 30,
                            eval_metric='rmse',
                            watchlist = watchlist_da,
                            maximize = FALSE )
  #View(data1[,features_da])
  pred_qty_da<-predict(clf_qty_da2,xgb.DMatrix(data.matrix(data1[,features_da]),missing=NA))
  fit_qty_da<-predict(clf_qty_da2,xgb.DMatrix(data.matrix(data[,features_da]),missing=NA))
  pred_qty_da = as.data.frame(format_negatives(pred_qty_da))
  fit_qty_da = as.data.frame(format_negatives(fit_qty_da))
  colnames(fit_qty_da)<- c('Forecast')
  colnames(pred_qty_da)<- c('Forecast')
  a1 = rbind(fit_qty_da,pred_qty_da)}else{
  a1 = data.frame(c(data_xgboost_train$Sales,rep(0,time_period)))
  colnames(a1) <- c("Forecast")
  a1['Low95PI']=NA
  a1['High95PI']=NA
  a1['Low90PI']=NA
  a1['High90PI']=NA
  return(a1)
}}
generate_BI_BSTS <- function(Train_Sales,data,data1,Test_Sales,holdout_months,horizon_in_months,time_period){

  # data = data[order(data$YYYYMM),]
  # data1 = data[data$YYYYMM >= 201740,]
  # data1$Sales_log = log1p(data1$Sales)
  # data = data[data$YYYYMM < 201740,]

  data1 = data1[nrow(data)+1:nrow(Test_Sales),]
  Test_Sales = Test_Sales[nrow(data)+1:nrow(Test_Sales),]

  #print(data1)
  #print(Test_Sales)
  #print(length(Train_Sales))
  #print(length(Test_Sales))
  #print(length(data))
  #:wq
  print(length(data1))


 #print(nrow(Train_Sales))
  print(nrow(Test_Sales))
  #print(nrow(data))
  print(nrow(data1))
  #model data
  time_period = as.integer(time_period)
  data$Sales = Train_Sales
  data1$Sales = Test_Sales
  data$Sales=ts(data$Sales,frequency = 13)
  data$Sales_log<-ts(log1p(data$Sales),frequency = 13)

  imp_variables<-names(data[,c(1:ncol(data))])
  imp_variables<-imp_variables[!imp_variables %in% c("Sales","Sales_log","Month")]
  Formula<-as.formula(paste("Sales~",paste(imp_variables,sep = "",collapse = "+")))

  Formula_log<-as.formula(paste("Sales_log~",paste(imp_variables,sep = "",collapse = "+")))


  ss1<- AddSeasonal(list(),data$Sales, nseasons = 13)
  ss1<-AddSemilocalLinearTrend(ss1,data$Sales)
  ss1<-AddSeasonal(ss1,data$Sales,nseasons =13 ,season.duration = 4)

  ss2<- AddSeasonal(list(),data$Sales_log, nseasons = 13)
  ss2<-AddSemilocalLinearTrend(ss2,data$Sales_log)
  ss2<-AddSeasonal(ss2,data$Sales_log,nseasons =13 ,season.duration = 4)

  fit <- bsts(Formula, state.specification = ss1, data = data, niter = 1000, ping=0, seed=2016)
  fit_log <- bsts(Formula_log, state.specification = ss2, data = data, niter = 1000, ping=0, seed=2016)

  #fit <- bsts(x, state.specification = ss1, niter = 1000, ping=0, seed=2016)
  burn1 = 500
  forecast <-predict.bsts(fit, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast_log <-predict.bsts(fit_log, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast <-predict.bsts(fit, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))
  forecast_log <-predict.bsts(fit_log, data1[,imp_variables] ,horizon =holdout_months, burn=burn1, quantiles = c(.025, .975))

  #training fit

  fitted <- (-colMeans(fit$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales))
  fitted <- data.frame(as.numeric(fitted))
  mean <- data.frame(as.numeric(forecast$mean))

  #  burn1 = 100
  fitted_log <- (-colMeans(fit_log$one.step.prediction.errors[-(1:burn1),])+as.numeric(data$Sales_log))
  fitted_log <- data.frame(as.numeric(expm1(fitted_log)))
  mean_log <- data.frame(as.numeric(expm1(forecast_log$mean)))


  colnames(fitted)<- c('Forecast')
  colnames(mean)<- c('Forecast')

  colnames(fitted_log)<- c('Forecast')
  colnames(mean_log)<- c('Forecast')

  # Prepare output

  a1 = rbind(fitted,mean)
  a2 = rbind(fitted_log,mean_log)

  a1$Forecast = format_negatives(a1$Forecast)
  a2$Forecast = format_negatives(a2$Forecast)

  actual = data1$Sales[1:13]; pred = mean$Forecast[1:13] ; pred_log = mean_log$Forecast[1:13]
  ind  = which(actual != 0 );  actual_1 = actual[ind]; pred1 = pred[ind] ; pred2 = pred_log[ind]

  mape_ex1<-mean(abs((pred1-actual_1)/actual_1))
  mape_ex2<-mean(abs((pred2-actual_1)/actual_1))


  if(mape_ex1<= mape_ex2){final_out = a1 }
  else {final_out = a2}

  final_out['Low95PI']=NA
  final_out['High95PI']=NA
  final_out['Low90PI']=NA
  final_out['High90PI']=NA
  #print(a2)
  return (final_out)
}


generate_BI_ARIMAX <- function(Train_Sales,data,data1,Test_Sales,holdout_months,horizon_in_months,time_period){
data$Sales = as.numeric(Train_Sales$Sales)

drop<-c("Month")
a<-data
a<-a[!names(a) %in% drop]

#if(nrow(a)==0){next}
#if (length(a)==sum(is.na(a))) {next}

#a[min(which(!is.na(a))):max(which(!is.na(a))),]
#if(length(a)<8) {next}
names(a)
num = nrow(data)

  start =  (nrow(data) -  nrow(data[data$Sales!= 0,])) + 1
  end = nrow(data); train_period = start:end;forecast_period =  1:holdout_months
  #print(start)
  #print(end)
  #print(head(a))
  #test_period = (end+1):(end+13);
  b = a[start:end,]
  #print(colnames(b))
  min.model=lm(b[,"Sales"]~ 1, data = b)
  tmp_var = names(b)[!names(b) %in% c("Month","Sales")]
  #features_da<-features_da[!features_da %in% c("Month","Sales")]
#formula = paste("Sales ~ ", paste0(features_da,collapse = "+" ))
  biggest<-paste("Sales ~ ", paste0(tmp_var,collapse = "+" ))
  step_arimax<-step(min.model,direction = "forward",scope = biggest)

vardf<-data.frame(var=names(step_arimax$coefficients),beta=as.numeric(step_arimax$coefficients))
imp_var_arimax <- na.omit(vardf)
if(nrow(imp_var_arimax)<2){
  imp_var_arimax$var<-c("E1")
}
imp_var_arimax<-imp_var_arimax[!imp_var_arimax$var %in% c("(Intercept)"),]
imp_var_arimax<-imp_var_arimax[!imp_var_arimax%in% c("QuarterQ3","QuarterQ4","QuarterQ2")]


t <- data.frame(Important_Variables=imp_var_arimax$var,Beta=abs(imp_var_arimax$beta))
imp_var_arimax <- as.character(imp_var_arimax$var)

y <- decompose(ts(a[train_period,"Sales"],frequency = 13),type = "additive",filter = NULL)
#plot(y)

trend  <- y$trend
season <- y$seasonal
err    <- y$random

train  <- trend[min(which(!is.na(trend))):max(which(!is.na(trend)))]
#test   <- as.numeric(ts(a[test_period,"Sales"]))
train1 <- err[min(which(!is.na(err))):max(which(!is.na(err)))]
#test1  <- ts(a[test_period,"Sales"])

z <- snaive(season,h=(length(forecast_period)+13))$mean
x <- as.numeric(z)
#end
model1 <- lm(Sales~.,data = a)
modelcoef <- na.omit(model1$coefficients)
if(length(modelcoef)>1){
  fit.arima.imp_new <- auto.arima(log1p(train),xreg=ts(a[start:(start+length(train)-1),
                                                         c(imp_var_arimax)],frequency=13),stepwise = FALSE)
  forecast_arima.imp_new <- forecast(fit.arima.imp_new, h=(length(forecast_period)+13),
                                     xreg=a[c(train_period[(length(train_period)-1):(length(train_period))],
                                              forecast_period),c(imp_var_arimax)])$mean
}else{
  fit.arima.imp_new <- auto.arima(log1p(train),stepwise = FALSE)
  forecast_arima.imp_new <- forecast(fit.arima.imp_new, h=(length(forecast_period)+13))$mean
}
forecast_arima.imp_new <- expm1(as.numeric(forecast_arima.imp_new))

if(length(modelcoef)>1){
  error <- nnetar(train1,xreg =ts(a[start:(start+length(train)-1),c(imp_var_arimax)],
                                  frequency = 13),start.p = 1,start.q = 1)
  errforecast <- forecast(error,h=(length(forecast_period)+13),
                          xreg=a[c(train_period[(length(train_period)-1):(length(train_period))],
                                   forecast_period),c(imp_var_arimax)])$mean
}else{
  error <- nnetar(train1,start.p = 1,start.q = 1)
  errforecast <- forecast(error,h=(length(forecast_period)+13))$mean
}
errforecast <- as.numeric(errforecast)

pred_arimax <- forecast_arima.imp_new + errforecast + x
pred_arimax <- format_negatives(pred_arimax)

fitted <- expm1(fit.arima.imp_new$fitted)

forecast_values= c(fitted,pred_arimax)
# Prepare output


a1 = rep(NA,(num+holdout_months+horizon_in_months))
length(a1)
a1$Forecast<- forecast_values

a1 = as.data.frame(a1)

a1['Low95PI']=NA
a1['High95PI']=NA
a1['Low90PI']=NA
a1['High90PI']=NA
  #print(a2)
return (a1)
}

generate_hw_forecast <- function(data,holdout_months,horizon_in_months,start_date,end_date,time_period) {
#Prepare preprocessing data
num = nrow(data)
start_year = as.integer(start_date/10000)
start_month = as.integer((start_date%%10000)/100)
end_year = as.integer(end_date/10000)
end_month = as.integer((end_date%%10000)/100)
time_period = as.integer(time_period)
start_week = as.integer(format(as.Date(toString(start_date) ,format='%Y%m%d'), "%W"))
end_week = as.integer(format(as.Date(toString(end_date) ,format='%Y%m%d'), "%W"))

if(time_period == 12){
x <- ts(data,start=c(start_year,start_month),end=c(end_year,end_month),frequency=12)
 }
 else if (time_period == 53){
x <- ts(data,start=c(start_year,start_week),end=c(end_year,end_week),frequency=53)
}

a0 <- data.frame(matrix(NA,nrow=time_period,ncol=5))
colnames(a0) <- c("Forecast","Low95PI","High95PI","Low90PI","High90PI")

#Model data
fit <- HoltWinters(x)
forecast <- forecast(fit,holdout_months+horizon_in_months+1,95)

#training fit
fitted <- data.frame(as.numeric(forecast$fitted))
colnames(fitted)<- c('Forecast')
fitted['Low95PI']=NA
fitted['High95PI']=NA
#Forecast values
mean <- data.frame(forecast)
colnames(mean) <- c("Forecast","Low95PI","High95PI")

## 90% PI level
forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
#training fit
fitted['Low90PI']=NA
fitted['High90PI']=NA
#Forecast values
mean['Low90PI']=forecast_90['Lo 90']
mean['High90PI']=forecast_90['Hi 90']

# Prepare output
a1 = rbind(fitted,mean)
a2 = rbind(a0,a1)
return (a2)
}

generate_hw_forecast_mult <- function(data,holdout_months,horizon_in_months,start_date,end_date,time_period) {
# Prepare preprocess data
num = nrow(data)
start_year = as.integer(start_date/10000)
start_month = as.integer((start_date%%10000)/100)
end_year = as.integer(end_date/10000)
end_month = as.integer((end_date%%10000)/100)

time_period = as.integer(time_period)
#print (holdout_months, horizon_in_months)
start_week = as.integer(format(as.Date(toString(start_date) ,format='%Y%m%d'), "%W"))
end_week = as.integer(format(as.Date(toString(end_date) ,format='%Y%m%d'), "%W"))

if(time_period == 12){
x <- ts(data,start=c(start_year,start_month),end=c(end_year,end_month),frequency=12)
 }
 else if (time_period == 53){
x <- ts(data,start=c(start_year,start_week),end=c(end_year,end_week),frequency=53)
}

a0 <- data.frame(matrix(NA,nrow=time_period,ncol=5))
colnames(a0) <- c("Forecast","Low95PI","High95PI","Low90PI","High90PI")
#Model data
fit <- HoltWinters(x, seasonal = "mult")
forecast <- forecast(fit,holdout_months+horizon_in_months+1,95)

#Training fit
fitted <- data.frame(as.numeric(forecast$fitted))
colnames(fitted)<- c('Forecast')
fitted['Low95PI']=NA
fitted['High95PI']=NA
#Forecast values
mean <- data.frame(forecast)
colnames(mean) <- c("Forecast","Low95PI","High95PI")

## 90% PI level
forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
#training fit
fitted['Low90PI']=NA
fitted['High90PI']=NA
#Forecast values
mean['Low90PI']=forecast_90['Lo 90']
mean['High90PI']=forecast_90['Hi 90']

# Prepare output
a1 = rbind(fitted,mean)
a2 = rbind(a0,a1)
return (a2)
}
#
# Model to forecast using ARIMA technique
#

generate_auto_arima <- function(data,holdout_months,horizon_in_months,time_period) {
  #prepare preprocessing
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data,frequency = time_period)

  #model data
  fit <- auto.arima(x,max.p = time_period,max.q = time_period,max.P=time_period, max.Q=time_period)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  mean <- data.frame(forecast)
  colnames(mean) <- c("Forecast","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  mean['Low90PI']=forecast_90['Lo 90']
  mean['High90PI']=forecast_90['Hi 90']

  # Prepare output
  a1 = rbind(fitted,mean)
  return (a1)
  }

generate_auto_arima_fractal <- function(data,holdout_months,horizon_in_months,time_period) {
  #prepare preprocessing
 #prepare preprocessing
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data,frequency = 52)

  #model data
  fit <- auto.arima(x,seasonal=TRUE)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  mean <- data.frame(forecast$mean)
  colnames(mean) <- c("Forecast")
  mean['Low95PI']=NA
  mean['High95PI']=NA
  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  mean['Low90PI']=forecast_90['Lo 90']
  mean['High90PI']=forecast_90['Hi 90']

  # Prepare output
  a1 = rbind(fitted,mean)
  return (a1)
}
#
# Model to forecast using BoxCox transformation and ARIMA technique
#
generate_processed_auto_arima <- function(data,holdout_months,horizon_in_months,time_period) {
  #Prepare preprocessing
  tmp=boxcox(data$Sales~1, lambda = seq(0,2,0.1) ) ##Box cox transformation
  time_period = as.integer(time_period)

  #Get the power for normality transformation
  trans_power=tmp$x[which.max(tmp$y)]
  trans_power= ifelse(trans_power==0,'log',trans_power)

  #Transform data
  data=data_transform(data,trans_power)
  num = nrow(data)
  x=ts(data = data,frequency = time_period)

  #Model data
  fit <- auto.arima(x,max.p = time_period,max.q = time_period,max.P=time_period, max.Q=time_period)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  trans_power=ifelse(trans_power=='log','exp',1/trans_power)
  fitted <- data.frame(data_transform(as.numeric(forecast$fitted),trans_power))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- as.data.frame(na.fill(data_transform(as.data.frame(forecast),trans_power),0))
  colnames(forecast_fit) <- c("Forecast","Low95PI","High95PI")
  forecast_fit[forecast_fit['Low95PI'] > forecast_fit['High95PI'],"Low95PI"] = 0


  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90),
                               row.names = seq(1,33))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  forecast_fit['Low90PI'] = na.fill(data_transform(forecast_90['Lo 90'],trans_power),0)
  forecast_fit['High90PI']= na.fill(data_transform(forecast_90['Hi 90'],trans_power),0)
  forecast_fit[forecast_fit['Low90PI'] > forecast_fit['High90PI'],"Low90PI"] = 0
  #Prepare output
  a1 = rbind(fitted,forecast_fit)
  return (a1)
}
generate_forecast_crostons <- function(data,holdout_months,horizon_in_months){
  forecast = crost(data$Sales,h=holdout_months+horizon_in_months+1,outplot=T, cost="mse")
  #training fit
  fitted <- data.frame((as.numeric(forecast$frc.in)))
  colnames(fitted)<- c('Forecast')

  #Forecast values
  forecast_fit <- data.frame(forecast$frc.out)
  colnames(forecast_fit) <- c("Forecast")


  #Prepare output
  a1 = rbind(fitted,forecast_fit)
  a1['Low90PI'] = 1/NA
  a1['High90PI'] = 1/NA
  #Forecast values
  a1['Low95PI'] = 1/NA
  a1['High95PI'] = 1/NA

  return (a1)
}

#
# Model to forecast using ETS techinique (SES/HW)
#
generate_forecast_ETS <- function(data,holdout_months,horizon_in_months,time_period) {
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data,frequency = time_period)
  fit <- ets(c(x),model="ZZZ")
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)
  #training fit
  fitted <- data.frame((as.numeric(forecast$fitted)))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- data.frame(forecast)
  colnames(forecast_fit) <- c("Forecast","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  forecast_fit['Low90PI']=forecast_90['Lo 90']
  forecast_fit['High90PI']=forecast_90['Hi 90']

  #Prepare output
  a1 = rbind(fitted,forecast_fit)
  return (a1)
}

generate_forecast_ETS_fractal <- function(data,holdout_months,horizon_in_months,time_period) {
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data,frequency = 13)
  fit <- ets(x,model="ZZA")
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)
  #training fit
  fitted <- data.frame((as.numeric(forecast$fitted)))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- data.frame(forecast)
  colnames(forecast_fit) <- c("Forecast","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA
  #Forecast values
  forecast_fit['Low90PI']=forecast_90['Lo 90']
  forecast_fit['High90PI']=forecast_90['Hi 90']

  #Prepare output
  a1 = rbind(fitted,forecast_fit)
  return (a1)
}


generate_forecast_nnet_AR<-function(data,holdout_months,horizon_in_months,time_period){

  #model data
  set.seed(19)
   time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = 13)
  fit <- nnetar(x, repeats=13,scale.inputs=TRUE)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  mean <- data.frame(as.numeric(forecast$mean))
  colnames(fitted)<- c('Forecast')
  colnames(mean)<- c('Forecast')
  # Prepare output

  a1 = rbind(fitted,mean)
  return (a1)
}

generate_forecast_nnet_fractal<-function(data,holdout_months,horizon_in_months,time_period){

  #model data
  set.seed(30)
   time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = 26)
  fit <- nnetar(x,repeats=2000,scale.inputs=TRUE)
  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)

  #training fit
  fitted <- data.frame(as.numeric(forecast$fitted))
  mean <- data.frame(as.numeric(forecast$mean))
  colnames(fitted)<- c('Forecast')
  colnames(mean)<- c('Forecast')
  # Prepare output

  a1 = rbind(fitted,mean)
  return (a1)
}
generate_USTLETS_Fractal <-function(data,holdout_months,horizon_in_months,time_period){
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = 13)

  #model data
  fit <- stlf(x,method='ets',h = holdout_months+horizon_in_months+1)

  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)
  #training fit
  fitted <- data.frame((as.numeric(forecast$fitted)))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- data.frame(forecast)

  colnames(forecast_fit) <- c("Forecast","Low85PI","High85PI","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  forecast_90 <- forecast_90[,1]
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA

  #Forecast values
  forecast_fit['Low90PI']=NA
  forecast_fit['High90PI']=NA

  #Prepare output
  a1 = rbind(fitted[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")],forecast_fit[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")])
  return (a1)

}

generate_USTLARIMA_Fractal <-function(data,holdout_months,horizon_in_months,time_period){
num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = 13)

  #model data
  fit <- stlf(x,method='arima',h = holdout_months+horizon_in_months+1)

  forecast <- forecast(fit,h=holdout_months+horizon_in_months+1,95)
  #training fit
  fitted <- data.frame((as.numeric(forecast$fitted)))
  colnames(fitted)<- c('Forecast')
  fitted['Low95PI']=NA
  fitted['High95PI']=NA
  #Forecast values
  forecast_fit <- data.frame(forecast)

  colnames(forecast_fit) <- c("Forecast","Low85PI","High85PI","Low95PI","High95PI")

  ## 90% PI level
  forecast_90 <- as.data.frame(forecast(fit,holdout_months+horizon_in_months+1,90))
  forecast_90 <- forecast_90[,1]
  #training fit
  fitted['Low90PI']=NA
  fitted['High90PI']=NA

  #Forecast values
  forecast_fit['Low90PI']=NA
  forecast_fit['High90PI']=NA

  #Prepare output
  a1 = rbind(fitted[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")],forecast_fit[, c("Forecast","Low90PI","High90PI","Low95PI","High95PI")])
  return (a1)
}

generate_forecast_mapa <- function(data,holdout_months,horizon_in_months,time_period) {
  #prepare preprocessing
  num = nrow(data)
  time_period = as.integer(time_period)
  x=ts(data = data$Sales,frequency = 13)

  #model data
  fit <- mapaest(x,model="ZZA")
  forecast <- mapafor(x,fit,h=holdout_months+horizon_in_months+1,comb = "w.mean",outplot = 0,95)

  #training fit
  fitted <- data.frame(as.numeric(forecast$infor))
  colnames(fitted)<- c('Forecast')
  #Forecast values
  mean <- data.frame(as.numeric(forecast$outfor))
  colnames(mean) <- c("Forecast")


  # Prepare output
  a1 = as.data.frame(rbind(fitted,mean))
  a1['Low90PI']=NA
  a1['High90PI']=NA
  a1['Low95PI']=NA
  a1['High95PI']=NA

  return (a1)
}

  generate_forecast_bsts_fractal<-function(data,holdout_months,horizon_in_months,time_period){

    #model data
    time_period = as.integer(time_period)
    x=ts(data = data$Sales,frequency = 52)

    ss4 <- AddSeasonal(list(),x, nseasons = 52)
    ss4 <- AddSeasonal(ss4,x, nseasons = 52,season.duration = 4)
    ss4<-AddSemilocalLinearTrend(ss4,x)
    fit <-bsts(x, state.specification = ss4, niter = 1000, ping=0, seed=2016)
    burn1 = 500
    forecast <-predict.bsts(fit,horizon =holdout_months+horizon_in_months+1, burn=burn1, 95, quantiles = c(.025, .975))

    #training fit

    fitted <- (-colMeans(fit$one.step.prediction.errors[-(1:burn1),])+as.numeric(x))
    fitted <- data.frame(as.numeric(fitted))
    mean <- data.frame(as.numeric(forecast$mean))
    colnames(fitted)<- c('Forecast')
    colnames(mean)<- c('Forecast')
    # Prepare output
    a1 = rbind(fitted,mean)
    a1['Low90PI']=NA
   a1['High90PI']=NA
   a1['Low95PI']=NA
   a1['High95PI']=NA
    return (a1)
  }

  #training fit
  #fitted <- data.frame(as.numeric(fit_forecast$fitted))
  #colnames(fitted)<- c('Forecast')

  #Forecast values
  #mean <- data.frame(as.numeric(fit_forecast$mean))
  #colnames(mean) <- c("Forecast")
  # Prepare output
  #a1 = rbind(fitted,mean)
  #return (a1)

#}
# generate_forecast_X13 <- function(data,holdout_months,horizon_in_months,start_date){
# #
# #   Requires 36 month of historic data to forecast
# #
#   x=ts(data = data,frequency = 12,start = c(as.integer(start_date/100),1))
#
#   m_fit <- seas(AirPassengers)
#   ft <- as.data.frame(series(m, "forecast.forecasts"))
#
#   #training fit
#   fitted <- data.frame(rep(NA,length(data$Sales)))
#   colnames(fitted)<- c('Forecast')
#
#   #Forecast values
#   forecast_fit <- data.frame(ft$forecast[1:horizon_in_months])
#   colnames(forecast_fit) <- c("Forecast")
#
#
#   #Prepare output
#   # No idea about CI and PI percentile so adding it to both
#   a1 = rbind(fitted,forecast_fit)
#   a1['Low90PI'] = ft$lowerci
#   a1['High90PI'] = ft$upperci
#   #Forecast values
#   a1['Low95PI'] = ft$lowerci
#   a1['High95PI'] = ft$upperci
#
#   return (a1)
# }

