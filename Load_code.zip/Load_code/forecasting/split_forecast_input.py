import pandas as pd
import numpy as np
import forecast_config
from datetime import datetime
from dateutil.rrule import rrule, MONTHLY, WEEKLY,DAILY
from datetime import datetime, timedelta




# Update forecast configuration parameter
conf_read_input = forecast_config.getConfig('RunScript')
time_frequency = conf_read_input['time_frequency']

def week_number_transformation(data):
    old_weeknumbers = list(data['WeekNumber'])
    years = list(data['YYYYMMDD'].astype('str').str[:4])
    new_weeknumbers = []
    year_flag = '00'
    for i in range(len(old_weeknumbers)):
        if old_weeknumbers[i]=='00':
            year_flag = years[i]
        if years[i]==year_flag:
            new_weeknumbers.append(str(int(old_weeknumbers[i]) + 1).zfill(2))
        else:
            new_weeknumbers.append(str(old_weeknumbers[i]).zfill(2))
    data['WeekNumber'] = new_weeknumbers
    return data

def split_forecast_input(data1, UIN, Comop, holdout_date, last_date, horizon_in_months):
    def get_horizon_months(last_date, horizon_in_months):
        month = (last_date % 10000)/100
        year = int(last_date / 10000)
       
        m_column = pd.DataFrame([])
        year_column = pd.DataFrame([])
        for i in range(0, horizon_in_months):
            j = (i + month) % 12
            k = year + int((i + month) / 12)
            if j == 0:
                j = 12
                k = k - 1
            year_month = k * 100 + j
    
        datecol = [d.strftime('%Y%m%d') for d in pd.date_range(start=datetime.strptime(str(last_date),'%Y%m%d'),end=datetime.strptime(str(year_month)  , '%Y%m'),freq='M')]   
                     
        
        return datecol
 
    def get_horizon_weeks(last_date, horizon_in_months):
        month = last_date % 10000
        year = int(last_date / 10000)
        # print year, month
        m_column = pd.DataFrame([])
        year_column = pd.DataFrame([])
        next_date = last_date
        for i in range(0, horizon_in_months):
            date_N_days_ago = datetime.strptime(str(next_date), '%Y%m%d') + timedelta(days=7)
            next_date = date_N_days_ago.strftime('%Y%m%d')
           
        datecol = [dt.strftime('%Y%m%d') for dt in rrule(WEEKLY, dtstart=datetime.strptime(str(last_date), '%Y%m%d'), until=datetime.strptime(str(next_date), '%Y%m%d'))]    
     
        return datecol
    

    # Prepare Training Dataset
    train = data1[data1.YYYYMMDD < holdout_date]
    X = train.drop('Sales', 1).drop('UIN', 1).drop('Comop', 1).drop('YYYYMMDD', 1)
    Y = pd.DataFrame(train.Sales)
#    print X
    # Add forecast horizon 
#    data1 = week_number_transformation(data1)
    test = data1  # used for both insample and holdout calculations
    if time_frequency=='Weekly':
        horizon_rows = get_horizon_weeks(last_date, horizon_in_months-1)
    elif time_frequency=='Monthly':
        horizon_rows = get_horizon_months(last_date, horizon_in_months+1)
    
    horizon_rows = pd.DataFrame(horizon_rows)
    horizon_rows.columns = ['YYYYMMDD']
    horizon_rows['Month']= horizon_rows['YYYYMMDD'].astype('str').str[4:6]
    horizon_rows['WeekNumber'] = horizon_rows.YYYYMMDD.apply(lambda x: datetime.strptime(str(x),'%Y%m%d').strftime('%W'))
    horizon_rows['WeekNumber'] = horizon_rows['WeekNumber'].apply(lambda x:str(x).zfill(2))
    horizon_rows['UIN'] = UIN
    horizon_rows['Comop'] = Comop
 #   horizon_rows = week_number_transformation(horizon_rows)
    horizon_rows['Sales'] = np.nan
    test = test.append(horizon_rows).reset_index().drop('index', 1)
    # print test


    # Prepare Test Dataset which contains horizon also 
    # but testing will be done in holdout only.
    Xtest = test.drop('Sales', 1).drop('UIN', 1).drop('Comop', 1).drop('YYYYMMDD', 1)
    Ytest = pd.DataFrame(test.Sales)

    # For new variables, fill NAs in test data according to the last value in training data.
    Xtest = Xtest.fillna(method='ffill')
#    print Xtest
    return test, X, Y, Xtest, Ytest


