# -*- coding: utf-8 -*-
"""
Created by Shravan Shetty
Generates non seasonal ARMA model. Calculates best AR value depending on the AIC
value of the model.
"""

import pandas as pd
import statsmodels.api as sm
import numpy as np
from numpy import linalg
from split_forecast_input import split_forecast_input
from forecast_error import forecast_error, get_confidence_interval
from sklearn.metrics import make_scorer
from sklearn.cross_validation import PredefinedSplit
from sklearn.grid_search import GridSearchCV
import forecast_config


def getMAPE(actual_data,forecast_data):
    """
    get MAPE for data
    :param forecast_data: pandas dataframe/Series/Array
    :param actual_data: pandas dataframe/Series/Array
    :return: Float value
    """
    actual_data = actual_data if isinstance(actual_data, pd.DataFrame) else pd.DataFrame(actual_data)
    actual_data.reset_index(drop=True,inplace=True)
    forecast_data = forecast_data if isinstance(forecast_data, pd.DataFrame) else pd.DataFrame(forecast_data)
    forecast_data.columns = ['Sales']
    return np.mean(np.abs(actual_data - forecast_data)/actual_data).Sales


def get_forecast_ARMA_MAPE(data1,UIN,Comop,last_date,holdout_date,horizon_in_months):
    if len(data1[data1.YYYYMMDD<holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']): # this ensures min. 2 year of data for forecasting
        print UIN, "insufficient historical data"
        return
    try:
        #horizon_in_months = 24
        #Prepare Training and Test dataset
        data2,X,Y,Xtest,Ytest = split_forecast_input(data1,UIN,Comop,holdout_date,last_date,horizon_in_months)
        Y.index=pd.to_datetime(data2.YYYYMMDD[:len(Y)],format='%Y%m%d')
    
       ## Optimzed Auto regressor for ARMA models
        #Model building: Finding the best AR
        arma_model = sm.tsa.ARMA(Y, (0, 0)).fit(disp=False)
        minModel = {"model":arma_model, "MAPE":float("inf") }

        for d in range(0,6):
            for p in range(0,6):
                try:
                    arma_model = sm.tsa.ARMA(Y, (p, d)).fit(disp=False)
                    test_data = Ytest[len(Y):].dropna()
                    arma_MAPE = getMAPE(arma_model.forecast(len(test_data))[0], test_data)
                    if arma_MAPE < minModel['MAPE']:
                        minModel = {"model": arma_model, "MAPE": arma_MAPE}
                except Exception:
                    pass
        #Forecasting
        Ytest.index=pd.to_datetime(data2.YYYYMMDD,format='%Y%m%d')
        Y_pred1 = minModel['model'].fittedvalues.append(pd.DataFrame(minModel['model'].forecast(len(Ytest)-len(Y))[0]))
        Y_pred1.index=Ytest.index = range(0,len(Ytest))
        Y_pred1.columns = ['Forecast']
        Y_pred1.Forecast = Y_pred1.Forecast.apply(lambda x: max(1,x))

        ## Get the forecast error (APE)
        Y_compare= forecast_error(data2,Ytest,Y_pred1,holdout_date,last_date)

        # Printing MAPE to confirm correct results during development
        print "ARMA-MAPE: UIN =", UIN, "Comop=",Comop, "MAPE =",Y_compare.APE.mean(),"Bias= ",Y_compare.Bias_Error.iloc[1]

        # Return full dataset with
        # Columns for Forecast, MAPE and Forecast_Type
        Y_return = pd.DataFrame(data2).join(Y_pred1)
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['MAPE'] = Y_compare.APE.mean() # This is a single number
        Y_return['Forecast_Type'] = 'ARMA'
        return Y_return
    except ValueError:
        print UIN, "ValueError in ARMA Step"
        return
    except linalg.LinAlgError:
        print UIN, "SVD Error: Did not Converge in ARMA step"
        return
    except Exception as e:
        print "Exception in ARMA step:  ", e
        return
    
