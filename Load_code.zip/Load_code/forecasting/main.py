#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Apr  5 15:58:01 2018

@author: vikranthole
"""

import os
import forecast_config
import pandas as pd
import sys
from time import time, localtime, strftime
import datetime
import calendar
from read_data import read_data
from generate_forecast import get_forecast
from generate_forecast_mult import get_forecast_mult
from generate_forecast_mult_v2 import get_forecast_mult_v2
from generate_forecast_mult_box_cox import get_forecast_mult_box_cox
from generate_forecast_hw import get_forecast_hw
from generate_forecast_hw_mult import get_forecast_hw_mult
from generate_forecast_arima import generate_auto_arima
from generate_auto_regressive_arima import get_forecast_auto_regressive
from generate_forecast_processed_arima import generate_processed_auto_arima
from forecast_rankings import forecast_rankings
from generate_forecast_ETS import generate_auto_ets
from generate_forecast_croston import generate_auto_croston
from generate_forecast_gradientBoosting import get_forecast_gradientBoosting
from generate_forecast_randomforest import get_forecast_randomForest
from generate_auto_regressive_arma_MAPE import get_forecast_ARMA_MAPE
from generate_auto_regressive_arima_ma import get_forecast_auto_regressive_ma
from generate_forecast_nnet_AR import generate_nnet_AR
from generate_forecast_LassoCV import get_forecast_LassoCV
from generate_forecast_RidgeCV import get_forecast_RidgeCV
from generate_forecast_LarsLassoCV import get_forecast_LarsLassoCV
from generate_forecast_RidgeKernel import get_forecast_RidgeKernel
import numpy as np
from QueueProcessor import MultiProcessQueue

#from generate_forecast_fbprophet import generate_prophet
# from generate_forecast_XGBoost import get_forecast_XGBoost




def last_day_of_month(any_day):
    next_month = any_day.replace(day=28) + datetime.timedelta(days=4)  # this will never fail
    ret =  next_month - datetime.timedelta(days=next_month.day)
    ret = ret.strftime('%Y%m%d')
    return ret



def create_dir_not_exist(directory_path):
    """
    Checks if a directory_path exists, if not creates it
    :param directory_path:
    :return: None
    """
    import os
    if not os.path.isdir(directory_path):
        print "Creating new directory at location {0}".format(os.curdir + "/" + directory_path)
        os.mkdir(directory_path)


def arg_parameters(argv, def_argk):
    """
    Updates command line argument to the forecast configurations. Need forecast.ini keys as method parameter and system arguments.
    argv: Command line argument supplied by user
    def_argk : Keys related to Forecast.ini
    return Updated forecast_configuration with system arguments
    """
    import getopt
    cmd = map(lambda x: x + "=", def_argk)
    default_cmd = " ".join(["python main.py"] +
                           map(lambda x: "--{0} <{0}>".format(x), def_argk))
    try:
        opts, args = getopt.getopt(argv, "h", cmd)
    except getopt.GetoptError:
        print default_cmd
        sys.exit(2)
    for opt, arg in opts:
        if opt == '-h':
            sys.exit()
        elif (opt.strip('-') + "=") in cmd:
            forecast_config.setConfig(opt.strip('-'), arg.strip())
    return forecast_config.getConfig()


t0 = time()
today = datetime.date.today()
# Update forecast configuration parameter
conf_run_script = arg_parameters(
    sys.argv[1:], forecast_config.getConfig('RunScript').keys())
print "Forecast Configurations are: ", ' '.join(["{0}={1}".format(k, v) for k, v in conf_run_script.items()])

run_type = conf_run_script['run_type']
company = conf_run_script['company']
ReportingYYYYMMDDDD = (int(today.year) * 100 +
                     int(today.month)) * 100 + int(today.day)

print "Company is {0} and Run Type is {1}".format(company, run_type)

create_dir_not_exist('result')
create_dir_not_exist('result/' + company)
time_frequency = forecast_config.getConfig('RunScript')['time_frequency']
batch_size= forecast_config.getConfig('RunScript')['batch_size']
full_output = []

# Format output file so that it can take any file
output_file = conf_run_script['output_file']
output_file = list(output_file.rpartition('.'))
# if user didn't give fileformat,  last index will contain the filename.
if output_file[1] != '.':
    output_file[0] = output_file[2]

input_file = 'data/' + company + "/" + conf_run_script['input_file']
output_timestamp = strftime('%Y_%m_%d', localtime())
output_file = "result/{1}/{0}_{1}_{2}.csv".format(
    output_file[0], company, output_timestamp)
tmp_output_file = "result/{0}/Intermediate_result_{0}_{1}.csv".format(
    company, output_timestamp)
create_dir_not_exist('logs')

log_file = 'logs/log' + output_timestamp + '.txt'
logfile = open(log_file, 'w+')
logfile.write('The program started at %s ' % datetime.datetime.now())

if run_type == '0':
    logfile.write('in pre-compute mode\n')
elif run_type == '1':
    logfile.write('in on-demand mode\n')

logfile.write('Reading sales records from %s \n' % input_file)
# Dates are not inclusive
last_date = int(conf_run_script['last_date'])  # last date is not inclusive
# holdout date is not inclusive
holdout_date = int(conf_run_script['holdout_date'])
if time_frequency =="Monthly":
    try:
        last_date = int(last_day_of_month(datetime.datetime.strptime(str(last_date), '%Y%m')))
        holdout_date = int(last_day_of_month(datetime.datetime.strptime(str(holdout_date), '%Y%m')))
    except:
        pass


logfile.write('Last Date\t\t %d \n' % last_date)
logfile.write('Holdout Date\t %d \n' % holdout_date)

horizon_in_months = int(conf_run_script["horizon_period"])

t1 = time()
# IMPORT HISTORICAL SALES DATA
# Expected fields: ['UIN','Comop','CompanyCode','YYYYMMDD','Sales']
data = read_data(input_file)  # Month field gets added here
CC_map = data[['UIN', 'CompanyCode']].drop_duplicates()
CC_map.columns = ['dim_partid', 'dd_companycode']
data = data.drop('CompanyCode', 1)

logfile.write(
    '\nModule 1: Read data completed successfully in %7.2f seconds \n' % (time() - t1))

data["grain"] = data['Comop'].astype(str) + "--" + data['UIN'].astype(str)
total_grain = data.grain.unique().size

logfile.write('Total Grains \t\t%d \n' % (total_grain))
logfile.write('\nModule 2: Generate Forecasts starting..\n')

# Starting generate Forecasts
forecast_algo = [generate_auto_arima, generate_processed_auto_arima,
                 generate_auto_ets, generate_auto_croston,
                 generate_nnet_AR,
                 get_forecast_mult, get_forecast,
                 get_forecast_hw, get_forecast_hw_mult,
                 get_forecast_mult_v2, get_forecast_mult_box_cox, get_forecast_auto_regressive,
                 get_forecast_auto_regressive_ma, get_forecast_RidgeCV, get_forecast_randomForest,
                 get_forecast_gradientBoosting,
                 get_forecast_RidgeKernel,
                 get_forecast_LassoCV, get_forecast_LarsLassoCV]
#forecast_algo = [generate_processed_auto_arima, generate_auto_arima, generate_auto_ets, get_forecast_randomForest, get_forecast_LassoCV, get_forecast_RidgeKernel]

def my_task(data1):
    data1 = data1[data1.YYYYMMDD < last_date]  # As Last date is not inclusive
    data1 = data1.sort_values(['YYYYMMDD'],ascending=[1])
    data1 = data1.drop('grain', axis=1).reset_index(
        drop=True)  # This is very important step
    # Write to the queue
    store = pd.DataFrame([])
    for func in forecast_algo:
        store = store.append(func(
            *(data1, data1.UIN[0], data1.Comop[0], last_date, holdout_date, horizon_in_months)))
    return store


_start = time()
mpq = MultiProcessQueue(int(conf_run_script['num_process']))
data_mpq = 0

data_grain_list = list(data.grain.unique())
batch_size = int(forecast_config.getConfig('RunScript')['batch_size'])
full_output = []
batch_list = []
round_no = 0
for i in range(0,len(data_grain_list),batch_size):
    batch = data_grain_list[i:i+batch_size]
    batch_list.append(batch)

print "Forecasting {0} Batches with Batch Size {1}".format(len(batch_list),batch_size)
for i in range(len(batch_list)):
    batch = batch_list[i]
    mpq = MultiProcessQueue(int(conf_run_script['num_process']))
    data_mpq = 0
    t_batch_start = time()
    try:
        for grain in batch:
            data1 = data[data.grain == grain]
            if len(data1[data1.YYYYMMDD < holdout_date]) >= int(conf_run_script['min_training_period']):
                data_mpq += 1
                mpq.enqueue(my_task, data1)

        store = []
        if data_mpq > 0:
            # Running Multiprocessing Queues
            print "Forecasting {1} products in Batch {0},".format(i+1,data_mpq)
            mpq.execute(i+1,len(batch_list))
            for j in range(data_mpq):
                store += [mpq.dequeue()]
        else:
            import sys
            print "Nothing to forecast"
            sys.exit(1)
        # Tell child processes to stop
        store = pd.concat(store)
        #full_output.append(store)

        #store = pd.concat(full_output)
        print "Grains Count",len(store[['UIN','Comop']].drop_duplicates())
        print "Sending  numbers to Queue() took %s seconds" % ((time() - _start))

        if store.empty:
            print "There is an insufficient data for running the forecast. Please add  more data or change min_training_period in forecast.ini"
            sys.exit(-1)
        store = store.reset_index()
        store = store.drop('index', 1)

        store.to_csv(tmp_output_file, index=False)
        # Completed: Run forecasting

        logfile.write('Total Part/Plant combination explored %d \n' % i)
        # logfile.write('Total Part/Plant combination forecasted %d \n' % (len(store[['UIN', 'Comop']].drop_duplicates())))
        # logfile.write('Total Parts forecasted %d \n' % (len(store[['UIN']].drop_duplicates())))
        logfile.write(
            'Module 2: Generate Forecasts complete in %7.2f seconds\n' % (time() - t1))
        logfile.write('Total Plants forecasted %d \n' %
                      (len(store[['Comop']].drop_duplicates())))
        logfile.write(
            'Module 2: Generate Forecasts complete in %7.2f seconds\n' % (time() - t1))

        logfile.write('\nModule 3: Generate Forecast Rankings..\n')
        t1 = time()
        # Forecast Ranking
        store = forecast_rankings(store)

        logfile.write('Module 3: Forecast ranking completed\n')


        # store['Forecast_Sample'] = store.YYYYMMDD.apply(lambda x: 'Test' if x > holdout_date else 'Train')
        store['Forecast_Sample'] = store.YYYYMMDD.apply(
            lambda x: 'Horizon' if x >= last_date else 'Test' if x >= holdout_date else 'Train')

        # Rename Columns for Output
        col_mapping = {'Comop': 'dd_level2', 'Forecast': 'ct_forecastquantity', 'Forecast_Type': 'dd_forecasttype',
                       'High90PI': 'ct_high90pi', 'High95PI': 'ct_high95pi', 'Low90PI': 'ct_low90pi', 'Low95PI': 'ct_low95pi',
                       'MAPE': 'ct_mape', 'Month': 'dd_month', 'Sales': 'ct_salesquantity', 'UIN': 'dim_partid',
                       'YYYYMMDD': 'dd_yearmonth',
                       'Forecast_Rank': 'dd_forecastrank', 'Forecast_Sample': 'dd_forecastsample',
                       'Bias_Error': 'dd_bias_error', 'Bias_Error_Rank': 'dd_bias_error_rank'}
        # When extra variables are used in input data, but not need to be used in
        # output
        store = store[col_mapping.keys()]
        store.columns = [col_mapping[col] for col in store.columns]


        store['dd_forecastdate'] = store.dd_yearmonth
        # Format the Dates in a proper format
        store['dd_reportingdate'] = datetime.datetime.strptime(str(ReportingYYYYMMDDDD), '%Y%m%d').strftime('%d %b %Y')
        store['dd_holdoutdate'] = datetime.datetime.strptime(str(holdout_date), '%Y%m%d').strftime('%d %b %Y')
        store['dd_lastdate'] = datetime.datetime.strptime(str(last_date), '%Y%m%d').strftime('%d %b %Y')

        store = store.drop('dd_yearmonth', 1)


        if run_type == '1':
            store['dd_forecastmode'] = 'on-demand'
        elif run_type == '0':
            store['dd_forecastmode'] = 'pre-computed'

        store = pd.merge(store, CC_map, how='left', on=['dim_partid'])
        # Intermediate result
        store.to_csv(tmp_output_file, index=False)

        # Reorder Columns for output and Finalize the Confidence interval
        prediction_interval = '90'
        # filters data according to the required prediction intervals
        store = store.iloc[:,
                           ~store.columns.str.contains('ct.*[0-9][0-9]pi') | store.columns.str.contains('.*' + prediction_interval + 'pi')]

        # Renames and Generalizing PIs to Low and High values
        for pattern, mapper in [('low' + prediction_interval, 'ct_lowpi'), ('high' + prediction_interval, 'ct_highpi')]:
            store.columns = store.columns.to_series().map(
                lambda col: mapper if pattern in col else col)

        store = store[['dd_reportingdate', 'dd_forecastdate',
                       'dim_partid', 'dd_level2', 'ct_salesquantity', 'ct_forecastquantity', 'ct_lowpi', 'ct_highpi', 'ct_mape',
                       'dd_lastdate', 'dd_holdoutdate',
                       'dd_forecastsample', 'dd_forecasttype', 'dd_forecastrank', 'dd_forecastmode', 'dd_companycode',
                       'dd_bias_error_rank', 'dd_bias_error']]

        # Forecast Capping with more than million using following logic:
        # Forecast = meanHistoricSales + 3*Std_devHistoricSales
        # HighPI = Forecast + 3 *Std_devHistoricSales
        capping = float(conf_run_script['demand_capping'])
        # Create capping columns
        store["capping"] = False
        if store[store.ct_forecastquantity > capping].shape[0] > 1:
            store.loc[store.ct_forecastquantity > capping, "capping"] = True
            # Get the grain
            store["grain"] = store['dim_partid'].astype(
                str) + "--" + store['dd_level2'].astype(str)
            cap_grain = store[store.capping]['grain'].drop_duplicates()

            # filter data by grain and historic data
            cap_avg_sales = store[(store.grain.isin(cap_grain))]
            cap_avg_sales = cap_avg_sales.query(
                'dd_forecastsample=="Train" or dd_forecastsample=="Test"')

            # Group by to get avg sales and std_dev for each grains
            cap_avg_sales = cap_avg_sales.groupby(
                'grain')['ct_salesquantity'].agg([np.std])
            for store_grain in cap_grain:
                tmp_index = store.query(
                    "capping == True and grain == '{0}'".format(store_grain)).index
                store.loc[tmp_index, "ct_forecastquantity"] = capping
                store.loc[tmp_index, "ct_highpi"] = capping + \
                    3 * cap_avg_sales.ix[store_grain, "std"]
                store.loc[tmp_index, "ct_lowpi"] = capping - \
                    3 * cap_avg_sales.ix[store_grain, "std"]
            store = store.drop('grain', axis=1)

        # Capping High PI to maximum value of 3*Forecast quantity
        store.ct_highpi = store.apply(lambda row: min(
            row.ct_highpi, 3 * row.ct_forecastquantity), axis=1)
        
        if round_no==0:

            # write to a file or use in downstream process
            store.to_csv(tmp_output_file, index=False)
            store.drop('capping', axis=1).to_csv(output_file, index=False)
        else:
            # write to a file or use in downstream process
            store.to_csv(tmp_output_file, index=False)
            store = store.drop('capping', axis=1)
            
            temp_forecast = pd.read_csv(output_file)
            store = pd.concat([temp_forecast,store])       
            store.to_csv(output_file, index=False)
            
        round_no = round_no+1    
        t = time() - t0
        batch_time = time() -t_batch_start
        logfile.write(str(i+1) +'\nBatch Completed')
        logfile.write('\nWrote Batch forecasts to ' + output_file)
        logfile.write(
            '\nThis Batch completed successfully and took %7.2f seconds\n' % batch_time)
        print 'Batch Completed %s \n' % str(i+1)
        print 'Wrote Batch forecasts to %s \n' % output_file
        print 'The Batch completed successfully and took %7.2f seconds\n' % t

    except ValueError as e:
        print "Issue in Batch Data", e
        pass
    except Exception as e:
        print "Issue in Batch Data", e
        pass
t = time() - t0
logfile.write('The Forecast completed successfully and took %7.2f seconds\n' % t)
print 'The Forecast completed successfully and took %7.2f seconds\n' % t
logfile.close()
