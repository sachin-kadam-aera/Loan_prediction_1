__author__ = 'sshetty'
# -*- coding: utf-8 -*-
"""
Created by Shravan Shetty
Generate Random forest using log level data.
"""

import pandas as pd
import numpy as np
from numpy import linalg
from sklearn.grid_search import GridSearchCV
from sklearn.ensemble import GradientBoostingRegressor
from split_forecast_input import split_forecast_input
from create_seasonality_var import create_seasonality_var
from forecast_error import forecast_error, get_confidence_interval
import forecast_config

conf_read_input = forecast_config.getConfig('RunScript')
time_frequency = conf_read_input['time_frequency']

def get_forecast_gradientBoosting(data1, UIN, Comop, last_date, holdout_date, horizon_in_months):
    if len(data1[data1.YYYYMMDD < holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']):  # this ensures min. 2 year of data for forecasting
        print UIN, "insufficient historical data"
        return
    try:
        # horizon_in_months = 4
        # Prepare Training and Test dataset
        data2, X, Y, Xtest, Ytest = split_forecast_input(data1, UIN, Comop, holdout_date, last_date, horizon_in_months)
    
        # Prepare for Mulitplicative Linear Regression
        if time_frequency == "Monthly":
            X = create_seasonality_var(X,'Monthly')
            Xtest = create_seasonality_var(Xtest,'Monthly')
        elif time_frequency == "Weekly":
            X = create_seasonality_var(X,'Weekly')
            Xtest = create_seasonality_var(Xtest,'Weekly')
        else:
            X = create_seasonality_var(X,'Monthly')
            Xtest = create_seasonality_var(Xtest,'Monthly')
        #X = create_seasonality_var(X)
        #Xtest = create_seasonality_var(Xtest)
    
        Y = pd.DataFrame(Y.Sales).apply(lambda x: np.log(x))
        X['t'] = X.index
        Xtest['t'] = Xtest.index
    
        # Create a cross validation object
        from sklearn import cross_validation
        # Simple K-Fold cross validation. 10 folds.
        cv = cross_validation.KFold(len(X), n_folds=10)
        # Create Gradient Boosting object
        forest = GridSearchCV(GradientBoostingRegressor(random_state=55), cv=cv, n_jobs=1,
                              param_grid={"learning_rate": np.linspace(0.05, 0.4, 5),
                                          "n_estimators": [50, 100, 150, 200], "max_depth": [2, 3, 4]
                                          })
    
        
        # Train the model using the training sets
        # Fit the training data to the Survived labels and create the decision trees
        forest = forest.fit(X, Y['Sales'])
        Y_pred1 = pd.DataFrame(forest.predict(Xtest))
        Y_pred1.columns = ['Forecast']
        Y_pred1.Forecast = Y_pred1.Forecast.apply(lambda x: max(1, np.exp(x)))

        Y_compare = forecast_error(data2, Ytest, Y_pred1, holdout_date, last_date)

        # Printing MAPE to confirm correct results during development

        print "Gradient Boosting: UIN =", UIN, "Comop=", Comop, "MAPE =", Y_compare.APE.mean(), "Bias= ", \
            Y_compare.Bias_Error.iloc[1]

        # Return full dataset with
        # Columns for Forecast, MAPE and Forecast_Type

        Y_return = pd.DataFrame(data2).join(Y_pred1)

        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['MAPE'] = Y_compare.APE.mean()  # This is a single number
        Y_return['Forecast_Type'] = 'Gradient Boosting'
        return Y_return

    except ValueError as e:
        print UIN, "ValueError in Gradient Boosting Step", e
        return
    except linalg.LinAlgError:
        print UIN, "SVD Error: Did not Converge in Gradient Boosting step"
        return
    except Exception as e:
        print "Exception in Gradient Boosting step:  ", e
        return


