Python packages:
--------------------------
Check requirements.txt file which contains all the packages.
To install these packges run the following commands:
pip install -r requirements.txt
Check link http://www.idiotinside.com/2015/05/10/python-auto-generate-requirements-txt/


R packages
--------------------------
To install these packages please use r_install_pkgs.R file. Run it using following command
Rscript r_install_pkgs.R
This will install following packages
‘tsintermittent’
'forecast'
'MASS'
‘seasonal’
`lubridate`
`dplyr`

For X13 forecast,
In main.R, set the path for X13 installation directory (X13_PATH)
Also, check the installation for X13 https://github.com/christophsax/seasonal/wiki/Compiling-X-13ARIMA-SEATS-from-Source-for-OS-X


