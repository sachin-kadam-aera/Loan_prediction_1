# -*- coding: utf-8 -*-
"""
Created on Fri Sep 30 14:49:26 2016

@author: vikranthole
"""

import pandas as pd
import numpy as np
from datetime import datetime
from dateutil.rrule import rrule, MONTHLY, WEEKLY,DAILY
from dateutil.relativedelta import relativedelta     
from datetime import timedelta

   
def imputingMissingValues(df,last_date,time_frequency):
    """
    Impute values for missing date between min date in df for unique grain to last_date
    :param df:        DataFrame with 'UIN', 'Comop','YYYYMMDD', 'salesqty' columns
    :param last_date: String date
    :return           DataFrame 
    
    """ 
    df['YYYYMMDD'] = df['YYYYMMDD'].apply(lambda x: int(x))
    df['YYYYMMDD'] = df['YYYYMMDD'].astype('str')
    
    df['grain'] = df.UIN.astype(np.str)+"____" +df.Comop.astype(np.str)+"____"+df.CompanyCode.astype(np.str)
    
    df_drop = df[df['Sales']>0]
    df_drop = df_drop.groupby(['grain'])['Sales'].sum().reset_index()
    df_drop = df_drop[df_drop['Sales']>0]
    
    df = df[df.grain.isin(df_drop['grain'])]
    
    df = df.groupby(['grain', 'YYYYMMDD']).sum().reset_index()
    df = df.sort_values(['YYYYMMDD'], ascending=[1])
    
    min_p_date= df[df['Sales']>0].groupby(['grain'])['YYYYMMDD'].min().to_dict()
    from datetime import datetime
    if time_frequency =="Monthly":
        from datetime import datetime
	try:
    	    last_date = datetime.strptime(last_date, '%Y%m').strftime('%Y%m%d')
	except:
   	     pass
        end_date = datetime.strptime(str(last_date), '%Y%m%d').replace(day=1) - relativedelta(days=1)
    elif time_frequency =="Weekly":
        end_date = datetime.strptime(str(last_date), '%Y%m%d') - timedelta(days=datetime.strptime(str(last_date), '%Y%m%d').weekday())
    end_date = datetime.strftime(end_date, '%Y%m%d')
    
    UIN_dict = df.groupby('grain').apply(lambda dfr:dfr.drop('grain',axis=1).to_dict(orient='list')).to_dict()
    
    UIN_list = list(df.grain.unique())
    all_UIN_list = []
    for key in UIN_list:
        
        if time_frequency =="Monthly":
            all_dates = pd.date_range(start=str(min_p_date[key]), end=str(end_date), 
                             freq='M').strftime('%Y-%m-%d').tolist()
        elif time_frequency =="Weekly":
            all_dates = pd.date_range(start=str(min_p_date[key]), end=str(end_date), 
                             freq='W-MON').strftime('%Y-%m-%d').tolist()
        
        
        all_dates.sort()
        
        
        temp = df[df.grain==key]
        temp[['UIN','Comop','CompanyCode']] = temp['grain'].str.split('____',expand=True)
        temp.drop('grain', axis=1, inplace=True)
        temp_agg_op = {}
        for col in temp.columns:
            if col in ['UIN','Comop','CompanyCode','YYYYMMDD']:
                pass
            else:
                temp_agg_op[col] = 'sum'
        
        
        temp = temp.set_index(pd.DatetimeIndex(temp['YYYYMMDD']))
        temp.drop('YYYYMMDD', axis=1, inplace=True)
        if time_frequency =="Monthly":
            output = temp.resample('M').agg(temp_agg_op)
        elif time_frequency =="Weekly":
            output = temp.resample('W-MON',closed='left',label='left').agg(temp_agg_op)
        
        
        
        output.fillna(0, inplace=True)
    
        
        output= output.reindex(pd.DatetimeIndex(all_dates), fill_value=0)
        output = output.reset_index()
        output.rename(columns={'index': 'YYYYMMDD'}, inplace=True)
        output['YYYYMMDD'] = output['YYYYMMDD'].dt.strftime('%Y%m%d')
        output['UIN'] = key.split('____')[0]
        output['Comop'] = key.split('____')[1]
        output['CompanyCode'] = key.split('____')[2]
        
        all_UIN_list.append(output)
            
    
    df = pd.concat(all_UIN_list, ignore_index=True)
    df['YYYYMMDD'] = df['YYYYMMDD'].apply(lambda x: int(x))
    reg_column_list = ['UIN', 'Comop','CompanyCode','YYYYMMDD', 'Sales']
    left_cols = list(set(df.columns).difference(set(reg_column_list)))
        
    df = df[reg_column_list +left_cols]
    
    
    
    
    return df

