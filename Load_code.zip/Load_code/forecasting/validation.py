#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 11 10:10:35 2018

@author: vikranthole
"""

import pandas as pd
import numpy as np
import datetime

def na_check(data):
    total_nan = data.isnull().sum().sum()
    if total_nan>0:
        return False
    else:
        return True
    
def date_format_check(data):
    try:
        data1 =  pd.to_datetime(data['YYYYMMDD'], format='%Y%m%d')
        return True
    except:
        return False
    
def sales_check(data):
    try:
        data['Sales'] =  data['Sales'].astype('float')
        return True
    except:
        return False    
    
    
def feature_check(data):
    try:
        reg_column_list = ['UIN', 'Comop','CompanyCode','YYYYMMDD', 'Sales']
        left_cols = list(set(data.columns).difference(set(reg_column_list)))
        if len(left_cols)>0:
            for col in left_cols:
                data[col] = data[col].astype('float')                       
            return True
        else:
            return True
    except:
        return False 
    
    
    
def data_validation(data):
    na_test = na_check(data)
    date_format_test = date_format_check(data)
    sales_test = sales_check(data)
    feature_test = feature_check(data)
    if (na_test==True) and (date_format_test==True) and (sales_test==True) and (feature_test==True):
        return True
    else:
        return False

