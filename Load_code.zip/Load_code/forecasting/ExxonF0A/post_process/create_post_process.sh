#!/bin/bash

set -o errexit
USER1=$(whoami)

fvar_replace_name=$1
tvar_replace_name=$2
new_file_name=$3
process_name=$4

echo "fact table var :"$fvar_replace_name
echo "tmp table var :"$tvar_replace_name
echo "new file name :"$new_file_name
echo "Process name :"$process_name

if [ -f /efs/datascience/aera-datascience/deploy/forecasting/ExxonF0A/post_process/$new_file_name ]
then
mv /efs/datascience/aera-datascience/deploy/forecasting/ExxonF0A/post_process/$new_file_name /efs/datascience/aera-datascience/deploy/forecasting/ExxonF0A/post_process/$new_file_name.previousversion
fi

sed "s/fvar_name/$fvar_replace_name/g" /efs/datascience/aera-datascience/deploy/forecasting/ExxonF0A/post_process/template_post_process.sql |sed "s/tvar_name/$tvar_replace_name/g"|sed "s/var_proces_name/$process_name/g" >> /efs/datascience/aera-datascience/deploy/forecasting/ExxonF0A/post_process/$new_file_name

chmod 777 /efs/datascience/aera-datascience/deploy/forecasting/ExxonF0A/post_process/$new_file_name
