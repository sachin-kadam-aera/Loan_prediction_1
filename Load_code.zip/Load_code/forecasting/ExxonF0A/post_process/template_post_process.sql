open schema EXXONMOBIL;

CREATE TABLE IF NOT EXISTS FACT_POSTPROC_Exxon_fvar_name (
FACT_POSTPROC_Exxon_fvar_nameID DECIMAL(36,0),
DD_JOBID                          VARCHAR(100) UTF8,
DD_PROJECTID                      VARCHAR(100) UTF8,
DD_FORECASTDATE                   VARCHAR(100) UTF8,
DD_GRAIN1                         VARCHAR(100) UTF8,
DD_GRAIN2                         VARCHAR(100) UTF8,
DD_GRAIN3                         VARCHAR(100) UTF8,
DD_GRAINDEFINATION                VARCHAR(100) UTF8,
DD_FORECASTALGORITHM              VARCHAR(100) UTF8,
DD_FORECASTRANK                   VARCHAR(100) UTF8,
CT_SALESQUANTITY                  DECIMAL(36,4),
CT_FORECASTQUANTITY               DECIMAL(36,4),
CT_RANKINGMETRICVALUE             DECIMAL(36,4),
DD_ACTUALDATEVALUE                VARCHAR(100) UTF8,
DD_DATEVALUEDEFINATION            VARCHAR(100) UTF8,
DD_RM_PROCESSING_RESULT           VARCHAR(400) UTF8,
DD_FF_PROCESSING_RESULT           VARCHAR(400) UTF8,
DD_REPORTINGDATE                  VARCHAR(100) UTF8,
CT_RANKINGMODE_FORECASTQUANTITY   DECIMAL(36,4),
DD_LATESTREPORTINGDATE            VARCHAR(100) UTF8,
DD_BL_ISBEST                      VARCHAR(40) UTF8,
DD_PASSED_ALL_TESTS               VARCHAR(100) UTF8,
DD_RANKINGMETRICNAME              VARCHAR(100) UTF8,
DD_ADDITIONALMETRICS              VARCHAR(400) UTF8,
DD_ALGORITHMTYPE                  VARCHAR(100) UTF8,
CT_CONFIDENCELEVELLOWER           DECIMAL(18,6),
CT_CONFIDENCELEVELUPPER           DECIMAL(18,6),
DD_ENDOFTRAININGOUTPERIOD         VARCHAR(100) UTF8,
DD_ENDOFHOLDOUTPERIOD             VARCHAR(100) UTF8,
DD_FORECASTSAMPLE_NEW             VARCHAR(7) ,
DD_SNAPSHOTDATE_DATEFORMAT        VARCHAR(11) UTF8,
DD_LATEST_FLAG 	 			            VARCHAR(11),
DD_PROCESS_NAME                   VARCHAR(200)
);

/*
DROP TABLE IF EXISTS stg_currentrunparam_tvar_name
CREATE TABLE stg_currentrunparam_tvar_name
(
dd_jobid varchar(100),
dd_reportingdate varchar(11)
)
insert into  stg_currentrunparam_tvar_name
(
dd_jobid,
dd_reportingdate  --1st of the next month(e.g lag-1)
)
SELECT '41bb0804a73e44edb811595da1c27742',
to_char(to_date('202106','YYYYMM'),'DD MON YYYY')  dd_reportingdate
select * from stg_currentrunparam_tvar_name
desc  tmp_postproc_Exxon_tvar_name
*/

DROP TABLE IF EXISTS tmp_postproc_Exxon_tvar_name;
CREATE TABLE tmp_postproc_Exxon_tvar_name
AS
SELECT f.*,
d.dd_holdout_date dd_endoftrainingoutperiod,
d.dd_last_date dd_endofholdoutperiod,
CASE WHEN f.DD_ACTUALDATEVALUE <= d.dd_holdout_date THEN 'Train'
WHEN f.DD_ACTUALDATEVALUE <= d.dd_last_date THEN 'Test'
ELSE 'Horizon'
END DD_FORECASTSAMPLE_NEW,
c.dd_reportingdate dd_snapshotdate_dateformat
FROM FACT_FORECASTOUTPUT_CORTEX_DATA f
INNER JOIN dim_jobmetadata_cortex_data d
ON d.dd_jobid = f.dd_jobid, stg_currentrunparam_tvar_name c
WHERE d.dd_jobid = c.dd_jobid;

UPDATE tmp_postproc_Exxon_tvar_name
SET dd_grain1 = 'Not Set'
WHERE dd_grain1 IS NULL;

UPDATE tmp_postproc_Exxon_tvar_name
SET dd_grain2 = 'Not Set'
WHERE dd_grain2 IS NULL;

UPDATE tmp_postproc_Exxon_tvar_name
SET dd_grain3 = 'Not Set'
WHERE dd_grain3 IS NULL;

/* remove 100 M forecast */
DROP TABLE IF EXISTS tmp_deletemethods_fcstctrl_tvar_name;
CREATE TABLE tmp_deletemethods_fcstctrl_tvar_name
AS
SELECT DISTINCT dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM
FROM tmp_postproc_Exxon_tvar_name
WHERE ct_forecastquantity >= 10000000 and CT_RANKINGMODE_FORECASTQUANTITY >= 10000000
AND DD_FORECASTALGORITHM <> 'FALL_BACK_NAIVE';

DELETE FROM tmp_postproc_Exxon_tvar_name s
WHERE EXISTS ( SELECT 1 FROM tmp_deletemethods_fcstctrl_tvar_name t
where s.dd_grain1 = t.dd_grain1
AND s.dd_grain2 = t.dd_grain2
AND s.dd_grain3 = t.dd_grain3
AND s.dd_FORECASTALGORITHM = t.dd_FORECASTALGORITHM);

DROP TABLE IF EXISTS tmp_deletemethods_nulls_all_period_tvar_name;
CREATE TABLE tmp_deletemethods_nulls_all_period_tvar_name
AS
SELECT distinct dd_grain1,dd_grain2,dd_grain3,DD_FORECASTALGORITHM,ct_forecastquantity, CT_RANKINGMODE_FORECASTQUANTITY,
dd_forecastdate
FROM tmp_postproc_Exxon_tvar_name f
where (ct_forecastquantity IS NULL)
AND DD_FORECASTALGORITHM <> 'FALL_BACK_NAIVE';

DELETE FROM tmp_postproc_Exxon_tvar_name s
WHERE EXISTS ( SELECT 1 FROM tmp_deletemethods_nulls_all_period_tvar_name t
where s.dd_grain1 = t.dd_grain1
AND s.dd_grain2 = t.dd_grain2
AND s.dd_grain3 = t.dd_grain3
AND s.dd_FORECASTALGORITHM = t.dd_FORECASTALGORITHM);

DROP TABLE IF EXISTS tmp_deletemethods_nulls_test_tvar_name;
CREATE TABLE tmp_deletemethods_nulls_test_tvar_name
AS
SELECT distinct dd_grain1,dd_grain2,dd_grain3,DD_FORECASTALGORITHM,ct_forecastquantity, CT_RANKINGMODE_FORECASTQUANTITY,
dd_forecastdate
FROM tmp_postproc_Exxon_tvar_name f
where DD_FORECASTSAMPLE_NEW = 'Test'
and (CT_RANKINGMODE_FORECASTQUANTITY IS NULL)
AND DD_FORECASTALGORITHM <> 'FALL_BACK_NAIVE';

DELETE FROM tmp_postproc_Exxon_tvar_name s
WHERE EXISTS ( SELECT 1 FROM tmp_deletemethods_nulls_test_tvar_name t
where s.dd_grain1 = t.dd_grain1
AND s.dd_grain2 = t.dd_grain2
AND s.dd_grain3 = t.dd_grain3
AND s.dd_FORECASTALGORITHM = t.dd_FORECASTALGORITHM);

/* Cleanup algorithms that have problems in output */
DROP TABLE IF EXISTS tmp_sanitychecks_sales_tvar_name;
CREATE TABLE tmp_sanitychecks_sales_tvar_name
AS
SELECT dd_grain1,
dd_grain2,
dd_grain3,
DD_FORECASTALGORITHM,
min(DD_FORECASTDATE) min_DD_FORECASTDATE,
max(DD_FORECASTDATE) max_DD_FORECASTDATE,
count(*) cnt,
sum(CT_SALESQUANTITY) sum_ct_salesquantity,
avg(CT_SALESQUANTITY) avg_ct_salesquantity,
median(CT_SALESQUANTITY) median_ct_salesquantity,
min(CT_SALESQUANTITY) min_ct_salesquantity,
max(CT_SALESQUANTITY) max_ct_salesquantity,
stddev(CT_SALESQUANTITY) stdev_ct_salesquantity,
stddev(CT_SALESQUANTITY)/case when avg(CT_SALESQUANTITY) <= 0 THEN 1 ELSE avg(CT_SALESQUANTITY) END cov_ct_salesquantity
FROM tmp_postproc_Exxon_tvar_name
WHERE dd_forecastdate >= to_date(dd_endofholdoutperiod, 'YYYYMM') - INTERVAL '11' MONTH
AND dd_forecastdate <= to_date(dd_endofholdoutperiod, 'YYYYMM')
GROUP BY dd_grain1, dd_grain2, dd_grain3, DD_FORECASTALGORITHM;

DROP TABLE IF EXISTS tmp_sanitychecks_fcst_tvar_name;
CREATE TABLE tmp_sanitychecks_fcst_tvar_name
AS
SELECT dd_grain1, dd_grain2, dd_grain3,
DD_FORECASTALGORITHM,
min(DD_FORECASTDATE) min_DD_FORECASTDATE,
max(DD_FORECASTDATE) max_DD_FORECASTDATE,
count(*) cnt,
sum(ct_forecastquantity) sum_ct_forecastquantity,
avg(ct_forecastquantity) avg_ct_forecastquantity,
median(ct_forecastquantity) median_ct_forecastquantity,
min(ct_forecastquantity) min_ct_forecastquantity,
max(ct_forecastquantity) max_ct_forecastquantity,
stddev(ct_forecastquantity) stdev_ct_forecastquantity,
stddev(ct_forecastquantity)/case when avg(ct_forecastquantity) <= 0 THEN 1 ELSE avg(ct_forecastquantity) END cov_ct_forecastquantity
FROM tmp_postproc_Exxon_tvar_name
WHERE dd_forecastdate >= to_date(dd_endofholdoutperiod, 'YYYYMM') + INTERVAL '1' MONTH
AND dd_forecastdate <= to_date(dd_endofholdoutperiod, 'YYYYMM') + INTERVAL '12' MONTH
GROUP BY dd_grain1, dd_grain2, dd_grain3, DD_FORECASTALGORITHM;

DROP TABLE IF EXISTS tmp_forecastmethod_exceptions_tvar_name;
CREATE TABLE tmp_forecastmethod_exceptions_tvar_name
AS
SELECT f.dd_grain1, f.dd_grain2,f.dd_grain3, f.dd_forecastalgorithm, f.avg_ct_forecastquantity,
f.max_ct_forecastquantity,
s.median_ct_salesquantity,
s.avg_ct_salesquantity, s.max_ct_salesquantity
FROM tmp_sanitychecks_fcst_tvar_name f, tmp_sanitychecks_sales_tvar_name s
WHERE f.dd_grain1 = s.dd_grain1
AND f.dd_grain2 = s.dd_grain2
AND f.dd_grain3 = s.dd_grain3
AND f.dd_forecastalgorithm = s.dd_forecastalgorithm
AND f.max_ct_forecastquantity > 2 * max_ct_salesquantity;

DELETE FROM tmp_postproc_Exxon_tvar_name f
WHERE EXISTS ( SELECT 1 FROM tmp_forecastmethod_exceptions_tvar_name e
WHERE f.dd_grain1 = e.dd_grain1
AND f.dd_grain2 = e.dd_grain2
AND f.dd_grain3 = e.dd_grain3
AND f.dd_forecastalgorithm = e.dd_forecastalgorithm
AND f.dd_forecastalgorithm NOT IN ('FALL_BACK_NAIVE'));

/* remove flat forecast */
DROP TABLE IF EXISTS tmp_deletemethods_flat_fcst_tvar_name;
CREATE TABLE tmp_deletemethods_flat_fcst_tvar_name
AS
SELECT DISTINCT dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM, stddev(ct_forecastquantity) std_fcst,
avg(ct_forecastquantity) avg_fcst, stddev(ct_forecastquantity)/nullif(avg(ct_forecastquantity),0) cov
FROM tmp_postproc_Exxon_tvar_name
where dd_forecastdate >= to_date(dd_endofholdoutperiod, 'YYYYMM') + INTERVAL '1' MONTH
AND DD_FORECASTALGORITHM <> 'FALL_BACK_NAIVE'
GROUP BY  dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM
HAVING  stddev(ct_forecastquantity)/nullif(avg(ct_forecastquantity),0)  < 0.05;

DELETE FROM tmp_postproc_Exxon_tvar_name s
WHERE EXISTS ( SELECT 1 FROM tmp_deletemethods_flat_fcst_tvar_name t
where s.dd_grain1 = t.dd_grain1
AND s.dd_grain2 = t.dd_grain2
AND s.dd_grain3 = t.dd_grain3
AND s.dd_FORECASTALGORITHM = t.dd_FORECASTALGORITHM);

/* remove flat trend forecast */
DROP TABLE IF EXISTS tmp_get_consdiffs_fcst_tvar_name;
CREATE TABLE tmp_get_consdiffs_fcst_tvar_name
AS
SELECT DISTINCT dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM, ct_forecastquantity, DD_actualdatevalue,
lag(ct_forecastquantity, 1) over(PARTITION BY dd_grain1 ,dd_grain2, dd_grain3,dd_FORECASTALGORITHM ORDER BY DD_actualdatevalue ) lag1_fcst,
(lag(ct_forecastquantity, 1) over(PARTITION BY dd_grain1 ,dd_grain2, dd_grain3,dd_FORECASTALGORITHM ORDER BY DD_actualdatevalue )
- ct_forecastquantity) consecutive_diff
FROM tmp_postproc_Exxon_tvar_name
where dd_forecastdate > to_date(dd_endofholdoutperiod, 'YYYYMM')
AND DD_FORECASTALGORITHM <> 'FALL_BACK_NAIVE'
ORDER BY dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM,DD_actualdatevalue;

DROP TABLE IF EXISTS tmp_deletemethods_flat_trend_tvar_name;
CREATE TABLE tmp_deletemethods_flat_trend_tvar_name
AS
SELECT DISTINCT dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM, stddev(consecutive_diff) std_fcst
FROM tmp_get_consdiffs_fcst_tvar_name
GROUP BY  dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM
HAVING  stddev(consecutive_diff) < 0.2;

DELETE FROM tmp_postproc_Exxon_tvar_name s
WHERE EXISTS ( SELECT 1 FROM tmp_deletemethods_flat_trend_tvar_name t
where s.dd_grain1 = t.dd_grain1
AND s.dd_grain2 = t.dd_grain2
AND s.dd_grain3 = t.dd_grain3
AND s.dd_FORECASTALGORITHM = t.dd_FORECASTALGORITHM
AND s.dd_forecastalgorithm NOT IN ('FALL_BACK_NAIVE'));

/* remove if more than 25% of zeros are present */
drop table if exists tmp_fcst_cnt_zero_tvar_name;
create table  tmp_fcst_cnt_zero_tvar_name
as
select t.dd_Grain1, t.dd_Grain2, t.dd_Grain3, t.dd_forecastalgorithm,  t.dd_forecastrank,zero.zero_count,
count(t.DD_ACTUALDATEVALUE) over (partition by t.dd_Grain1, t.dd_Grain2, t.dd_Grain3, t.dd_forecastrank) date_count,
case
when zero.zero_count >= round(1/4 * count(t.DD_ACTUALDATEVALUE) over (partition by t.dd_Grain1, t.dd_Grain2, t.dd_Grain3, t.dd_forecastrank)) then 'fail'
else 'pass' end as results
from tmp_postproc_Exxon_tvar_name  t
inner join (
select a.dd_Grain1, a.dd_Grain2, a.dd_Grain3, a.dd_forecastrank, a.dd_forecastalgorithm,
count(a.CT_FORECASTQUANTITY)  zero_count
from tmp_postproc_Exxon_tvar_name a
where a.CT_FORECASTQUANTITY = 0
and dd_forecastdate > to_date(dd_endofholdoutperiod, 'YYYYMM')
group by a.dd_Grain1, a.dd_Grain2, a.dd_Grain3, a.dd_forecastrank, a.dd_forecastalgorithm
) as zero
on t.dd_Grain1 = zero.dd_Grain1
and t.dd_Grain2 = zero.dd_Grain2
and t.dd_Grain3 = zero.dd_Grain3
and t.dd_forecastalgorithm = zero.dd_forecastalgorithm
where  t.dd_forecastalgorithm <> 'FALL_BACK_NAIVE'
and  dd_forecastdate > to_date(dd_endofholdoutperiod, 'YYYYMM');

DROP TABLE IF EXISTS tmp_deletemethods_many_zeros_tvar_name;
CREATE TABLE tmp_deletemethods_many_zeros_tvar_name
AS
SELECT DISTINCT dd_grain1 ,dd_grain2, dd_grain3, dd_FORECASTALGORITHM
FROM tmp_fcst_cnt_zero_tvar_name
where results = 'fail' ;

DELETE FROM tmp_postproc_Exxon_tvar_name s
WHERE EXISTS ( SELECT 1 FROM tmp_deletemethods_many_zeros_tvar_name t
where s.dd_grain1 = t.dd_grain1
AND s.dd_grain2 = t.dd_grain2
AND s.dd_grain3 = t.dd_grain3
AND s.dd_FORECASTALGORITHM = t.dd_FORECASTALGORITHM);

/* Remove zeros forecast methods (and no zero in sales) */
drop table if exists tmp_last_12_saleszero_tvar_name;
create table tmp_last_12_saleszero_tvar_name
as
select dd_Grain1, dd_Grain2, dd_Grain3,dd_forecastalgorithm, count(CT_SALESQUANTITY)  sales_nonzero
from tmp_postproc_Exxon_tvar_name a
where dd_forecastdate >= to_date(dd_endofholdoutperiod, 'YYYYMM') - INTERVAL '11' MONTH
AND dd_forecastdate <= to_date(dd_endofholdoutperiod, 'YYYYMM')
and CT_SALESQUANTITY > 0.1
AND DD_FORECASTALGORITHM <> 'FALL_BACK_NAIVE'
GROUP BY dd_grain1, dd_grain2, dd_grain3, DD_FORECASTALGORITHM;

drop table if exists tmp_next_12_fcstzero_tvar_name;
create table tmp_next_12_fcstzero_tvar_name
as
select dd_Grain1, dd_Grain2, dd_Grain3,dd_forecastalgorithm, count(ct_forecastquantity)  fcstzero
from tmp_postproc_Exxon_tvar_name
where dd_forecastdate <= to_date(dd_endofholdoutperiod, 'YYYYMM') + INTERVAL '12' MONTH
AND dd_forecastdate > to_date(dd_endofholdoutperiod, 'YYYYMM')
and ct_forecastquantity <= 0
AND DD_FORECASTALGORITHM <> 'FALL_BACK_NAIVE'
GROUP BY dd_grain1, dd_grain2, dd_grain3, DD_FORECASTALGORITHM;

drop table if exists next12_month_fcst_zero_tvar_name;
create table  next12_month_fcst_zero_tvar_name
as
select l.dd_Grain1, l.dd_Grain2, l.dd_Grain3, l.dd_forecastalgorithm, l.sales_nonzero, n.fcstzero
from  tmp_last_12_saleszero_tvar_name l
inner join tmp_next_12_fcstzero_tvar_name n
on l.dd_grain1 = n.dd_grain1
AND l.dd_grain2 = n.dd_grain2
AND l.dd_grain3 = n.dd_grain3
AND l.dd_forecastalgorithm = n.dd_forecastalgorithm
WHERE l.sales_nonzero = 12;

DELETE FROM tmp_postproc_Exxon_tvar_name f
WHERE EXISTS ( SELECT 1 FROM next12_month_fcst_zero_tvar_name e
WHERE f.dd_grain1 = e.dd_grain1
AND f.dd_grain2 = e.dd_grain2
AND f.dd_grain3 = e.dd_grain3
AND f.dd_forecastalgorithm = e.dd_forecastalgorithm)
AND f.dd_forecastalgorithm NOT IN ('FALL_BACK_NAIVE');

/* re-ranking */
DROP TABLE IF EXISTS tmp_rerankforecast_tvar_name;
CREATE TABLE tmp_rerankforecast_tvar_name
AS
SELECT dd_grain1,
dd_grain2,
dd_grain3,
DD_FORECASTALGORITHM,
sum(ct_salesquantity) ct_salesquantity,
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_mae,
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_bias,
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))) ct_rmse,
RANK() OVER(PARTITION BY dd_grain1, dd_grain2, dd_grain3 ORDER BY
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))),
DD_FORECASTALGORITHM) dd_forecastranknew
FROM tmp_postproc_Exxon_tvar_name
WHERE DD_FORECASTSAMPLE_NEW = 'Test'
AND dd_forecastalgorithm <> 'FALL_BACK_NAIVE'
GROUP BY 1,2,3,4 ;

DROP TABLE IF EXISTS tmp_distinctgrains_rankedfcst_tvar_name;
CREATE TABLE tmp_distinctgrains_rankedfcst_tvar_name
AS
SELECT distinct dd_grain1, dd_grain2, dd_grain3
FROM tmp_rerankforecast_tvar_name;

UPDATE tmp_postproc_Exxon_tvar_name f
SET f.dd_forecastrank = -1;

UPDATE tmp_postproc_Exxon_tvar_name f
SET f.dd_forecastrank = t.dd_forecastranknew,
f.CT_RANKINGMETRICVALUE = t.ct_mae
FROM tmp_postproc_Exxon_tvar_name f, tmp_rerankforecast_tvar_name t
WHERE f.dd_grain1 = t.dd_grain1
AND f.dd_grain2 = t.dd_grain2
AND f.dd_grain3 = t.dd_grain3
AND f.dd_forecastalgorithm = t.dd_forecastalgorithm;

/* Grains that don't have any other algorithm should use Naive */
UPDATE tmp_postproc_Exxon_tvar_name f
SET f.dd_forecastrank = 1
FROM tmp_postproc_Exxon_tvar_name f
WHERE f.dd_forecastalgorithm = 'FALL_BACK_NAIVE'
AND NOT EXISTS ( SELECT 1 FROM tmp_distinctgrains_rankedfcst_tvar_name t
WHERE t.dd_grain1 = f.dd_grain1
AND t.dd_grain2 = f.dd_grain2
AND t.dd_grain3 = f.dd_grain3);

UPDATE FACT_POSTPROC_Exxon_fvar_name
SET DD_LATEST_FLAG = 'N';

DELETE * FROM FACT_POSTPROC_Exxon_fvar_name
where dd_jobid in (select distinct dd_jobid from tmp_postproc_Exxon_tvar_name);

insert into FACT_POSTPROC_Exxon_fvar_name (
FACT_POSTPROC_Exxon_fvar_nameID ,
DD_JOBID                           ,
DD_PROJECTID                       ,
DD_FORECASTDATE                    ,
DD_GRAIN1                          ,
DD_GRAIN2                          ,
DD_GRAIN3                          ,
DD_GRAINDEFINATION                 ,
DD_FORECASTALGORITHM               ,
DD_FORECASTRANK                    ,
CT_SALESQUANTITY                  ,
CT_FORECASTQUANTITY               ,
CT_RANKINGMETRICVALUE             ,
DD_ACTUALDATEVALUE                 ,
DD_DATEVALUEDEFINATION             ,
DD_RM_PROCESSING_RESULT            ,
DD_FF_PROCESSING_RESULT            ,
DD_REPORTINGDATE                   ,
CT_RANKINGMODE_FORECASTQUANTITY   ,
DD_LATESTREPORTINGDATE             ,
DD_BL_ISBEST                      ,
DD_PASSED_ALL_TESTS                ,
DD_RANKINGMETRICNAME               ,
DD_ADDITIONALMETRICS               ,
DD_ALGORITHMTYPE                   ,
CT_CONFIDENCELEVELLOWER           ,
CT_CONFIDENCELEVELUPPER           ,
DD_ENDOFTRAININGOUTPERIOD          ,
DD_ENDOFHOLDOUTPERIOD              ,
DD_FORECASTSAMPLE_NEW                 ,
DD_SNAPSHOTDATE_DATEFORMAT         ,
DD_LATEST_FLAG
)
select
(
select
ifnull(max(FACT_POSTPROC_Exxon_fvar_nameID), 0)
from FACT_POSTPROC_Exxon_fvar_name m) + row_number()
over(order by '') as FACT_POSTPROC_Exxon_fvar_nameID,
cp.DD_JOBID                           ,
DD_PROJECTID                       ,
DD_FORECASTDATE                    ,
DD_GRAIN1                          ,
DD_GRAIN2                          ,
DD_GRAIN3                          ,
DD_GRAINDEFINATION                 ,
DD_FORECASTALGORITHM               ,
DD_FORECASTRANK                    ,
CT_SALESQUANTITY                  ,
CT_FORECASTQUANTITY               ,
CT_RANKINGMETRICVALUE             ,
DD_ACTUALDATEVALUE                 ,
DD_DATEVALUEDEFINATION             ,
DD_RM_PROCESSING_RESULT            ,
DD_FF_PROCESSING_RESULT            ,
cp.DD_REPORTINGDATE                   ,
CT_RANKINGMODE_FORECASTQUANTITY   ,
DD_LATESTREPORTINGDATE             ,
DD_BL_ISBEST                      ,
DD_PASSED_ALL_TESTS                ,
DD_RANKINGMETRICNAME               ,
DD_ADDITIONALMETRICS               ,
DD_ALGORITHMTYPE                   ,
CT_CONFIDENCELEVELLOWER           ,
CT_CONFIDENCELEVELUPPER           ,
DD_ENDOFTRAININGOUTPERIOD          ,
DD_ENDOFHOLDOUTPERIOD              ,
DD_FORECASTSAMPLE_NEW                 ,
DD_SNAPSHOTDATE_DATEFORMAT         ,
'Y'
from tmp_postproc_Exxon_tvar_name f
INNER JOIN stg_currentrunparam_tvar_name cp
ON f.dd_jobid = cp.dd_jobid;

UPDATE FACT_POSTPROC_Exxon_fvar_name
SET DD_PROCESS_NAME = replace('var_proces_name','_',' ') ;
