

DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
AS
SELECT '28 '||to_char(current_date,'MON YYYY') dd_reportingdate;


DROP TABLE IF EXISTS STAGE_FOSALESFORECAST_IBP_REGULAR;
CREATE TABLE STAGE_FOSALESFORECAST_IBP_REGULAR (
DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
DD_PARTNUMBER       VARCHAR(40)  NOT NULL ,
DD_COUNTRYPLANNINGGROUP VARCHAR(40),
CT_SALESQUANTITY    DECIMAL(36,6),
CT_FORECASTQUANTITY DECIMAL(36,6),
CT_LOWPI            DECIMAL(36,6),
CT_HIGHPI           DECIMAL(36,6),
CT_MAPE             DECIMAL(36,6),
DD_LASTDATE         VARCHAR(50)  NOT NULL ,
DD_HOLDOUTDATE      VARCHAR(50)  NOT NULL ,
DD_FORECASTSAMPLE   VARCHAR(50)  NOT NULL ,
DD_FORECASTTYPE     VARCHAR(50)  NOT NULL ,
DD_FORECASTRANK     DECIMAL(18,0),
DD_FORECASTMODE     VARCHAR(50)  NOT NULL ,
DD_COMPANYCODE      VARCHAR(50)  NOT NULL ,
CT_BIAS_ERROR_RANK  DECIMAL(18,6),
CT_BIAS_ERROR       DECIMAL(18,6)
);


DROP TABLE IF EXISTS STAGE_FOSALESFORECAST_IBP_RFH;
CREATE TABLE STAGE_FOSALESFORECAST_IBP_RFH
AS
SELECT * FROM STAGE_FOSALESFORECAST_IBP_REGULAR;


IMPORT INTO STAGE_FOSALESFORECAST_IBP_REGULAR
( DD_REPORTINGDATE , DD_FORECASTDATE, DD_PARTNUMBER, DD_COUNTRYPLANNINGGROUP,
 CT_SALESQUANTITY , CT_FORECASTQUANTITY, CT_LOWPI , CT_HIGHPI, CT_MAPE, DD_LASTDATE, DD_HOLDOUTDATE , DD_FORECASTSAMPLE,
 DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE , CT_BIAS_ERROR_RANK , CT_BIAS_ERROR)
FROM LOCAL CSV FILE '/efs/datascience/EMD586/data/output/emdibp_reg_forecast_results.csv.gz' COLUMN SEPARATOR = ',' SKIP = 1;

IMPORT INTO STAGE_FOSALESFORECAST_IBP_RFH
( DD_REPORTINGDATE , DD_FORECASTDATE, DD_PARTNUMBER, DD_COUNTRYPLANNINGGROUP,
 CT_SALESQUANTITY , CT_FORECASTQUANTITY, CT_LOWPI , CT_HIGHPI, CT_MAPE, DD_LASTDATE, DD_HOLDOUTDATE , DD_FORECASTSAMPLE,
 DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE , CT_BIAS_ERROR_RANK , CT_BIAS_ERROR)
FROM LOCAL CSV FILE '/efs/datascience/EMD586/data/output/emdibp_rfh_forecast_results.csv.gz' COLUMN SEPARATOR = ',' SKIP = 1;


DROP TABLE IF EXISTS tmp_reportingdates;
CREATE TABLE tmp_reportingdates
AS
SELECT m.dd_reportingdate dd_reportingdate_current,
to_char((to_date(m.dd_reportingdate,'DD MON YYYY') - INTERVAL '1' MONTH),'DD MON YYYY') dd_reportingdate_m1,
to_char((to_date(m.dd_reportingdate,'DD MON YYYY') - INTERVAL '2' MONTH),'DD MON YYYY') dd_reportingdate_m2
FROM tmp_maxrptdate m;


DROP TABLE IF EXISTS tmp_STAGE_FOSALESFORECAST_IBP_combined;
CREATE TABLE tmp_STAGE_FOSALESFORECAST_IBP_combined
AS
SELECT reg.*,rfh.ct_forecastquantity ct_forecastquantity_fh,
cast(0 as decimal(18,2)) ct_mapeorig_current,
cast(0 as decimal(18,2)) ct_mapeorig_m1,
cast(0 as decimal(18,2)) ct_mapeorig_m2,
cast(0 as decimal(18,2)) ct_mape_crossvalidated3months,
cast(0 as int) dd_forecastrank_current,
cast(0 as int) dd_forecastrank_crossvalidated3months,
CAST(1 AS INT) dim_dateidforecast,
CAST(1 AS INT) dim_dateidreporting 
FROM STAGE_FOSALESFORECAST_IBP_REGULAR_bkp reg INNER JOIN 
STAGE_FOSALESFORECAST_IBP_RFH_bkp rfh
ON reg.DD_PARTNUMBER = rfh.DD_PARTNUMBER
AND reg.DD_COUNTRYPLANNINGGROUP = rfh.DD_COUNTRYPLANNINGGROUP
AND reg.DD_FORECASTDATE = rfh.DD_FORECASTDATE
AND reg.dd_forecasttype = rfh.dd_forecasttype;

DROP TABLE IF EXISTS tmp_distinct_grains_2months0;
CREATE TABLE tmp_distinct_grains_2months0
AS
SELECT DISTINCT DD_PARTNUMBER,DD_COUNTRYPLANNINGGROUP,dd_forecastdate
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined
WHERE to_char(to_date(to_char(dd_forecastdate),'YYYYMMDD'),'YYYYMM')
in (to_char((current_date - interval '1' month),'YYYYMM'),to_char((current_date - interval '2' month),'YYYYMM'))
AND ct_salesquantity IN (0,1)
AND dd_forecasttype in ('Random Forest','Gradient Boosting');

DELETE FROM tmp_STAGE_FOSALESFORECAST_IBP_combined s
WHERE dd_forecasttype in ('Random Forest','Gradient Boosting')
AND EXISTS ( select 1 from tmp_distinct_grains_2months0 t
WHERE t.DD_PARTNUMBER = s.DD_PARTNUMBER
AND t.DD_COUNTRYPLANNINGGROUP = s.DD_COUNTRYPLANNINGGROUP);


UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined t
SET t.dd_reportingdate = m.dd_reportingdate
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined t,tmp_maxrptdate m;


DELETE FROM fact_fosalesforecast_ibp f
where dd_reportingdate
in ( select dd_reportingdate from tmp_maxrptdate);


UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
tmp_STAGE_FOSALESFORECAST_IBP_combined f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
tmp_STAGE_FOSALESFORECAST_IBP_combined f
WHERE to_date(to_char(f.dd_forecastdate),'YYYYMMDD') = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid;


UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined
SET  ct_forecastquantity_fh =  ct_forecastquantity
WHERE ct_forecastquantity_fh IS NULL
AND dd_forecastsample IN ('Test','Horizon');


DROP TABLE IF EXISTS tmp_mape_current;
CREATE TABLE tmp_mape_current
AS
SELECT reg.DD_PARTNUMBER,reg.DD_COUNTRYPLANNINGGROUP, reg.DD_FORECASTTYPE,
sum(case when ct_salesquantity <= 1 THEN 0 ELSE 1 END) ct_nonzeromonths,
avg(case when ct_salesquantity <= 1 THEN NULL ELSE 
abs(ct_salesquantity - ct_forecastquantity)/abs(ct_salesquantity) END) ct_mape_current
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined reg
WHERE dd_forecastsample = 'Test'
GROUP BY reg.DD_PARTNUMBER,reg.DD_COUNTRYPLANNINGGROUP, reg.DD_FORECASTTYPE;
 

UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET reg.ct_mapeorig_current = 100 * t.ct_mape_current
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined reg, tmp_mape_current t
WHERE reg.DD_PARTNUMBER = t.dd_partnumber
AND reg.DD_COUNTRYPLANNINGGROUP = t.DD_COUNTRYPLANNINGGROUP
AND reg.dd_forecasttype = t.dd_forecasttype;

/*
SELECT *
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined
where ct_mapeorig_current is null and dd_forecastsample = 'Test'
AND dd_partnumber = '1139380001' and DD_COUNTRYPLANNINGGROUP = 'DK DENMARK'
order by DD_PARTNUMBER,DD_COUNTRYPLANNINGGROUP,dd_forecasttype
limit 20;
*/

UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET reg.ct_mapeorig_m1 = f.ct_mapeorig_current
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined reg,
( SELECT DISTINCT dd_prdid,dd_countryplanninggroup,
dd_forecasttype,avg(ct_mapeorig_current) ct_mapeorig_current  
FROM fact_fosalesforecast_ibp f,tmp_reportingdates r
WHERE f.dd_reportingdate = r.dd_reportingdate_m1
AND dd_forecastsample = 'Test'
GROUP BY dd_prdid,dd_countryplanninggroup,
dd_forecasttype) f
WHERE f.dd_prdid = reg.dd_partnumber
AND f.dd_countryplanninggroup = reg.dd_countryplanninggroup
AND f.dd_forecasttype = reg.dd_forecasttype;


UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET reg.ct_mapeorig_m2 = f.ct_mapeorig_current
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined reg,
( SELECT DISTINCT dd_prdid,dd_countryplanninggroup,
dd_forecasttype,avg(ct_mapeorig_current) ct_mapeorig_current  
FROM fact_fosalesforecast_ibp f,tmp_reportingdates r
WHERE f.dd_reportingdate = r.dd_reportingdate_m2
AND dd_forecastsample = 'Test'
GROUP BY dd_prdid,dd_countryplanninggroup,
dd_forecasttype) f
WHERE f.dd_prdid = reg.dd_partnumber
AND f.dd_countryplanninggroup = reg.dd_countryplanninggroup
AND f.dd_forecasttype = reg.dd_forecasttype;


UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET ct_mapeorig_current = ct_mape
WHERE ct_mapeorig_current IS NULL;


UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET ct_mapeorig_m2 = ct_mape
WHERE ct_mapeorig_m2 IS NULL;

UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET ct_mapeorig_m1 = ct_mape
WHERE ct_mapeorig_m1 IS NULL;


UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET reg.ct_mape_crossvalidated3months = (ct_mapeorig_current + ct_mapeorig_m1 + ct_mapeorig_m2)/3;



DROP TABLE IF EXISTS tmp_calcforecastrank;
CREATE TABLE tmp_calcforecastrank
AS
SELECT dd_partnumber,dd_countryplanninggroup,dd_forecasttype,
dense_rank() over(partition by dd_partnumber,dd_countryplanninggroup 
ORDER BY ct_mapeorig_current,dd_forecasttype) dd_forecastrank_current,
dense_rank() over(partition by dd_partnumber,dd_countryplanninggroup 
ORDER BY ct_mape_crossvalidated3months,dd_forecasttype) dd_forecastrank_crossvalidated3months
FROM ( SELECT DISTINCT dd_partnumber,dd_countryplanninggroup,dd_forecasttype,ct_mapeorig_current,ct_mape_crossvalidated3months 
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined reg 
WHERE dd_forecastsample = 'Test')t;

UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined reg
SET reg.dd_forecastrank_current = t.dd_forecastrank_current,
reg.dd_forecastrank_crossvalidated3months = t.dd_forecastrank_crossvalidated3months
FROM tmp_STAGE_FOSALESFORECAST_IBP_combined reg,tmp_calcforecastrank t
WHERE reg.dd_partnumber = t.dd_partnumber
AND reg.dd_countryplanninggroup = t.dd_countryplanninggroup
AND reg.dd_forecasttype = t.dd_forecasttype;

UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
tmp_STAGE_FOSALESFORECAST_IBP_combined f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE tmp_STAGE_FOSALESFORECAST_IBP_combined f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
tmp_STAGE_FOSALESFORECAST_IBP_combined f
WHERE to_date(to_char(f.dd_forecastdate),'YYYYMMDD') = d.datevalue;

insert into fact_fosalesforecast_ibp
(
fact_fosalesforecast_ibpid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
DD_PRDID,
DD_COUNTRYPLANNINGGROUP,
dd_dmdgroup,
DD_ENDCUSTOMERPLANNINGGROUP,
DD_CHANNELPLANNINGGROUP
)
select
(select max(ifnull(fact_fosalesforecast_ibpid,1)) from fact_fosalesforecast_ibp) + row_number() over(order by '') fact_fosalesforecast_ibpid,
1 dim_partid,
1 dim_plantid,
'Not Set' dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity_fh,
ct_lowpi,
ct_highpi,
ct_mape_crossvalidated3months,
dd_forecastrank_crossvalidated3months,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
reg.dd_partnumber DD_PRDID,
reg.dd_COUNTRYPLANNINGGROUP DD_COUNTRYPLANNINGGROUP,
'ALL' dd_dmdgroup,
'All' DD_ENDCUSTOMERPLANNINGGROUP,
'ALL' DD_CHANNELPLANNINGGROUP
from tmp_STAGE_FOSALESFORECAST_IBP_combined reg;


UPDATE fact_fosalesforecast_ibp f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE fact_fosalesforecast_ibp f
SET dd_latestreporting = 'Yes'
FROM fact_fosalesforecast_ibp f,tmp_maxrptdate r
where f.dd_reportingdate = r.dd_reportingdate ;

        
/* Populate No. of Days */
UPDATE fact_fosalesforecast_ibp f
SET f.dd_daysinmonth = extract(day from d.datevalue)||'D'
FROM fact_fosalesforecast_ibp f,dim_date d, tmp_maxrptdate r
WHERE f.dim_dateidforecast = d.dim_dateid
AND r.dd_reportingdate = f.dd_reportingdate;

UPDATE fact_fosalesforecast_ibp f
SET dd_forecastflag_regular_vs_ims_vs_outlierfullhist = 'Outlier with Full History'
FROM fact_fosalesforecast_ibp f, tmp_maxrptdate t
WHERE f.dd_reportingdate  = t.dd_reportingdate;


DROP TABLE IF EXISTS tmp_allgrains_previousmonth;
CREATE TABLE tmp_allgrains_previousmonth
AS
SELECT DISTINCT DD_PRDID,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,dd_CHANNELPLANNINGGROUP,
min(to_date(to_char(dd_forecastdate),'YYYYMMDD')) min_fcstdate,
max(to_date(to_char(dd_forecastdate),'YYYYMMDD')) max_fcstdate
FROM FACT_FOSALESFORECAST_IBP f , tmp_maxrptdate t
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = to_date(t.dd_reportingdate,'DD MON YYYY') - INTERVAL '1' MONTH
AND dd_forecastrank = 1
GROUP BY DD_PRDID,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,dd_CHANNELPLANNINGGROUP;

DROP TABLE IF EXISTS tmp_allgrains_currentmonth;
CREATE TABLE tmp_allgrains_currentmonth
AS
SELECT DISTINCT DD_PRDID,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,dd_CHANNELPLANNINGGROUP
FROM FACT_FOSALESFORECAST_IBP f , tmp_maxrptdate t
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = to_date(t.dd_reportingdate,'DD MON YYYY')	
AND dd_forecastrank = 1
AND YEAR(to_date(to_char(dd_forecastdate),'YYYYMMDD')) = YEAR(to_date(f.dd_reportingdate,'DD MON YYYY'))
AND MONTH(to_date(to_char(dd_forecastdate),'YYYYMMDD')) = MONTH(to_date(f.dd_reportingdate,'DD MON YYYY'));

DROP TABLE IF EXISTS  tmp_missinggrains_currentmonth;
CREATE TABLE tmp_missinggrains_currentmonth
AS
SELECT o.*, CAST('Needs Investigation' AS VARCHAR(200)) dd_missingforecast_reason
FROM tmp_allgrains_previousmonth o
WHERE NOT EXISTS ( SELECT 1 FROM tmp_allgrains_currentmonth c
WHERE c.dd_prdid = o.dd_prdid
AND c.DD_COUNTRYPLANNINGGROUP = o.DD_COUNTRYPLANNINGGROUP
AND c.DD_ENDCUSTOMERPLANNINGGROUP = o.DD_ENDCUSTOMERPLANNINGGROUP
AND c.dd_CHANNELPLANNINGGROUP = o.dd_CHANNELPLANNINGGROUP);


UPDATE tmp_missinggrains_currentmonth t
SET dd_missingforecast_reason = 
'Max date with sales > 0 is : ' || to_char(max_fcstdate)
FROM tmp_missinggrains_currentmonth t,tmp_maxrptdate m
WHERE (to_date(m.dd_reportingdate,'DD MON YYYY') - t.max_fcstdate)/30 > 6;  

UPDATE tmp_missinggrains_currentmonth t
SET dd_missingforecast_reason = 'Less then 15 non-zero sales'
FROM tmp_missinggrains_currentmonth t
WHERE NOT EXISTS ( SELECT 1 FROM tmp_saleshistoryinputforfcst_6months b 
WHERE b.cnt >= 15
AND t.dd_prdid = b.partnumber
AND t.DD_COUNTRYPLANNINGGROUP = b.plantcode)
AND t.dd_missingforecast_reason = 'Needs Investigation';


UPDATE FACT_FOSALESFORECAST_IBP  f
SET f.dd_missingforecast_reason = t.dd_missingforecast_reason
FROM FACT_FOSALESFORECAST_IBP  f
INNER JOIN tmp_missinggrains_currentmonth t
ON t.dd_prdid = f.dd_prdid
AND t.DD_COUNTRYPLANNINGGROUP = f.DD_COUNTRYPLANNINGGROUP
AND t.DD_ENDCUSTOMERPLANNINGGROUP = f.DD_ENDCUSTOMERPLANNINGGROUP
AND t.dd_CHANNELPLANNINGGROUP = f.dd_CHANNELPLANNINGGROUP, tmp_maxrptdate m
WHERE to_char(to_date(f.dd_reportingdate,'DD MON YYYY'),'YYYYMM') 
= to_char(to_date(m.dd_reportingdate,'DD MON YYYY') - INTERVAL '1' MONTH,'YYYYMM');


DROP TABLE IF EXISTS tmp_currentfcst_rank;
CREATE TABLE tmp_currentfcst_rank
AS
SELECT DISTINCT f.dd_reportingdate,dd_prdid,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,DD_CHANNELPLANNINGGROUP,
dd_forecasttype,dd_forecastrank,avg((ct_forecastquantity - ct_salesquantity)/ct_salesquantity) ct_mape,
rank() over(partition by f.dd_reportingdate,dd_prdid,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,DD_CHANNELPLANNINGGROUP 
order by dd_forecastrank,avg((ct_forecastquantity - ct_salesquantity)/ct_salesquantity),dd_forecasttype) dd_forecastrank1
FROM fact_fosalesforecast_ibp f, tmp_maxrptdate m
WHERE f.dd_reportingdate = m.dd_reportingdate
AND dd_forecastsample = 'Test'
GROUP BY f.dd_reportingdate,dd_prdid,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,DD_CHANNELPLANNINGGROUP,
dd_forecasttype,dd_forecastrank;

UPDATE fact_fosalesforecast_ibp f
SET f.dd_forecastrank = r1.dd_forecastrank1
FROM fact_fosalesforecast_ibp f,  tmp_currentfcst_rank r1
WHERE f.dd_prdid = r1.dd_prdid
AND f.DD_COUNTRYPLANNINGGROUP = r1.DD_COUNTRYPLANNINGGROUP
AND f.DD_ENDCUSTOMERPLANNINGGROUP = r1.DD_ENDCUSTOMERPLANNINGGROUP
AND f.DD_CHANNELPLANNINGGROUP = r1.DD_CHANNELPLANNINGGROUP
AND f.dd_forecasttype = r1.dd_forecasttype
AND f.dd_reportingdate = r1.dd_reportingdate
AND ifnull(f.dd_forecastrank,-1) <> ifnull(r1.dd_forecastrank1,-2);


DROP TABLE IF EXISTS tmp_previousofhforecast;
CREATE TABLE tmp_previousofhforecast
AS
select distinct  f.dd_reportingdate,dd_prdid,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,DD_CHANNELPLANNINGGROUP,
sum(CT_FORECASTQUANTITY) ct_next3monthfcst
FROM fact_fosalesforecast_ibp f,tmp_maxrptdate m
WHERE (f.dd_reportingdate = m.dd_reportingdate
OR to_date(f.dd_reportingdate,'DD MON YYYY') = to_date(m.dd_reportingdate,'DD MON YYYY')-interval '1' month)
AND dd_forecastrank = 1
AND to_number(to_char(to_date(to_char(dd_forecastdate),'YYYYMMDD'),'YYYYMM')) > to_number(to_char(to_date(m.dd_reportingdate,'DD MON YYYY'),'YYYYMM'))
AND to_number(to_char(to_date(to_char(dd_forecastdate),'YYYYMMDD'),'YYYYMM')) <= to_number(to_char(to_date(m.dd_reportingdate,'DD MON YYYY')+INTERVAL '3' MONTH,'YYYYMM')) 
GROUP BY f.dd_reportingdate,dd_prdid,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,DD_CHANNELPLANNINGGROUP;


UPDATE tmp_previousofhforecast
SET ct_next3monthfcst = 0.01
WHERE ct_next3monthfcst = 0;

DROP TABLE IF EXISTS tmp_highvol;
CREATE TABLE tmp_highvol
AS
SELECT DISTINCT f1.dd_prdid,f1.DD_COUNTRYPLANNINGGROUP,f1.DD_ENDCUSTOMERPLANNINGGROUP,f1.DD_CHANNELPLANNINGGROUP,
CASE WHEN f1.ct_next3monthfcst > f2.ct_next3monthfcst THEN f1.ct_next3monthfcst/f2.ct_next3monthfcst 
ELSE f2.ct_next3monthfcst/f1.ct_next3monthfcst END 
ct_variability,
f1.ct_next3monthfcst newfcst3months,f2.ct_next3monthfcst prevfcst3months
FROM tmp_previousofhforecast f1,tmp_previousofhforecast f2, tmp_maxrptdate m
WHERE f1.dd_prdid = f2.dd_prdid
AND f1.DD_COUNTRYPLANNINGGROUP = f2.DD_COUNTRYPLANNINGGROUP
AND f1.DD_ENDCUSTOMERPLANNINGGROUP = f2.DD_ENDCUSTOMERPLANNINGGROUP
AND f1.DD_CHANNELPLANNINGGROUP = f2.DD_CHANNELPLANNINGGROUP
AND to_date(f1.dd_reportingdate, 'DD MON YYYY') = to_date(m.dd_reportingdate, 'DD MON YYYY') - INTERVAL '1' MONTH
AND f2.dd_reportingdate = m.dd_reportingdate
AND (f1.ct_next3monthfcst > 2*f2.ct_next3monthfcst OR f1.ct_next3monthfcst < 0.5*f2.ct_next3monthfcst) ;


UPDATE fact_fosalesforecast_ibp f
set dd_highvariabilityforecastflag = 'No'
FROM fact_fosalesforecast_ibp f,tmp_maxrptdate m
WHERE f.dd_reportingdate = m.dd_reportingdate;

UPDATE fact_fosalesforecast_ibp f
SET f.ct_forecastvariability_nextmonth = t.ct_variability,
dd_highvariabilityforecastflag = 'Yes'
FROM fact_fosalesforecast_ibp f, tmp_highvol t, tmp_maxrptdate m
WHERE f.dd_prdid = t.dd_prdid
AND f.DD_COUNTRYPLANNINGGROUP = t.DD_COUNTRYPLANNINGGROUP
AND f.DD_ENDCUSTOMERPLANNINGGROUP = t.DD_ENDCUSTOMERPLANNINGGROUP
AND f.DD_CHANNELPLANNINGGROUP = t.DD_CHANNELPLANNINGGROUP
AND f.dd_reportingdate = m.dd_reportingdate
AND f.dd_forecastrank = 1;


UPDATE fact_fosalesforecast_ibp f
SET f.DD_STATFCSTREF = 'NA'
FROM fact_fosalesforecast_ibp f,tmp_maxrptdate m
WHERE f.DD_STATFCSTREF IS NULL
AND f.dd_reportingdate = m.dd_reportingdate;

UPDATE FACT_FOSALESFORECAST_IBP f
SET f.dd_STATFCSTREF = t.STATFCSTREF
FROM FACT_FOSALESFORECAST_IBP f,
(select  prdid,countryplanninggroup,to_date(substr(ibpkfdate,1,7),'YYYY-MM') ibpkfdate_dtfmt, statfcstref,
dense_rank() over(partition by prdid,countryplanninggroup,to_date(substr(ibpkfdate,1,7),'YYYY-MM') order by statfcstref) dd_rankstatref
from EMDOTHERDATASOURCESBE3.IBP_INOUTFUSIONSTAT 
where ibpkfname = 'YSELECTEDORDERSTATADJUSTED'
AND statfcstref NOT LIKE '%NA%') t, tmp_maxrptdate m
where f.dd_prdid = t.prdid
and f.dd_COUNTRYPLANNINGGROUP = t.COUNTRYPLANNINGGROUP
AND f.dd_reportingdate = m.dd_reportingdate
AND t.ibpkfdate_dtfmt = to_date(substr(to_char(f.dd_forecastdate),1,6),'YYYYMM') 
AND t.dd_rankstatref = 1;


