import pandas as pd

def create_seasonality_var(X, time_frequency):
    # just_dummies = pd.get_dummies(X['Month'], prefix='m')
    # X=X.join(just_dummies)
    #print X
    #X=X.reset_index()
    #X=X.drop('index',1).drop('Month',1)
    # X=X.drop('Month',1)
    if (time_frequency == 'Monthly') :
        X=X.drop('WeekNumber',1)
        catg_cols =  ['Month']
        dummy = pd.get_dummies(X, columns=catg_cols)
    elif (time_frequency == 'Weekly') :
        X=X.drop('Month',1)
        catg_cols =   ['WeekNumber']
        dummy = pd.get_dummies(X, columns=catg_cols)
        temp_cols = dummy.columns
        if 'WeekNumber_53' in temp_cols:
            pass
        else:
            dummy['WeekNumber_53']=0
        if 'WeekNumber_00' in temp_cols:
             pass
        else:
            dummy['WeekNumber_00']=0
        temp_col = list(dummy.columns)
        temp_col.sort()
        dummy = dummy[temp_col]

    return dummy
