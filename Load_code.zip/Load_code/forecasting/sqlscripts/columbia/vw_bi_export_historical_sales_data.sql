
/* Create a de-normalized table containing data from sod,agidate,afssize,part and customer soldto */
/* Using AGI date for Columbia. For others, this can be salesord date, sched delivery date etc */
DROP TABLE IF EXISTS tmp_sod_denorm_fcst;
CREATE TABLE tmp_sod_denorm_fcst
AS
SELECT agi.datevalue agidate,s.size, c.country,
p.partnumber_noleadzero, p.genderrollup, p.fitdescription, p.fitcode, p.strategiccategory_columbia, p.strategiccategorydescription_columbia, p.divisiondescription , 
f.ct_goodsissuedqty_columbia ct_salesquantity
FROM fact_salesorderdelivery f, dim_date agi, dim_afssize s, dim_part p, dim_customer_soldto c
WHERE f.dim_dateidactualgoodsissue = agi.dim_dateid AND year(agi.datevalue) >= 2013
AND f.dim_afssizeid = s.dim_afssizeid
AND f.dim_partid = p.dim_partid
AND f.dim_customeridsoldto = c.dim_customer_soldtoid  AND c.country in ('US' , 'CA')
AND f.ct_goodsissuedqty_columbia > 0;



/* Get the Min and Max Dates For Creating a List of Year Month Periods */
drop table if exists tmp_saleshistory_daterange;

create table tmp_saleshistory_daterange as
select max(agidate) maxdate, min(agidate) mindate
FROM tmp_sod_denorm_fcst;



/* Get all Year Month Periods based on Min and Max Dates */
/* Using companycode = Not Set as company code does not matter. If it did, we would need to add that in previous query and user here in join*/

drop table if exists tmp_saleshistory_yyyymm;

create table tmp_saleshistory_yyyymm as
select calendaryear, calendarmonthnumber, calendarmonthid, datevalue
from dim_date, tmp_saleshistory_daterange
where datevalue between mindate and maxdate
and dayofmonth = 1
and companycode = 'Not Set';


/* Select partattrs,size,country combinations which have non-zero sales data available for atleast 12 months from 2013 onwards */
drop table if exists tmp_saleshistory_grain12;

create table tmp_saleshistory_grain12 as
select f.partnumber_noleadzero,f.genderrollup,f.fitdescription,f.fitcode,f.strategiccategory_columbia,f.strategiccategorydescription_columbia,f.divisiondescription, 
f.size, f.country, year(agidate) agidateyear, month(agidate) agidatemonth, count(*)
FROM tmp_sod_denorm_fcst f
group by f.partnumber_noleadzero,f.genderrollup,f.fitdescription,f.fitcode,f.strategiccategory_columbia,f.strategiccategorydescription_columbia,f.divisiondescription,
f.size, f.country, year(agidate), month(agidate)
having count(*) >= 12;

/* Remove all  rows from denorm where less than 12 month data is available */
DELETE FROM tmp_sod_denorm_fcst f
WHERE NOT EXISTS ( SELECT 1 FROM tmp_saleshistory_grain12 t 
		WHERE t.partnumber_noleadzero = f.partnumber_noleadzero 
		AND t.genderrollup = f.genderrollup AND t.fitdescription = f.fitdescription 
		AND t.fitcode = f.fitcode
		AND t.strategiccategory_columbia = f.strategiccategory_columbia 
		AND t.strategiccategorydescription_columbia = f.strategiccategorydescription_columbia
		AND t.divisiondescription = f.divisiondescription	
		AND t.size = f.size AND t.country = f.country);

/* Create final table for bcp out */
DROP TABLE IF EXISTS stage_saleshistory;
CREATE TABLE stage_saleshistory 
AS
SELECT 
year(f.agidate) agidateyear, month(f.agidate) agidatemonth,
f.partnumber_noleadzero, f.genderrollup, f.fitdescription, f.fitcode, f.strategiccategory_columbia, f.strategiccategorydescription_columbia, 
f.divisiondescription , f.size, f.country,sum(f.ct_salesquantity) ct_salesquantity
FROM tmp_sod_denorm_fcst f
GROUP BY year(f.agidate), month(f.agidate),
f.partnumber_noleadzero, f.genderrollup, f.fitdescription, f.fitcode, f.strategiccategory_columbia, f.strategiccategorydescription_columbia,
f.divisiondescription , f.size, f.country;

/* Populate 0 qty in those months where there were no sales */
INSERT INTO stage_saleshistory
SELECT year(y.datevalue) agidateyear,  month(y.datevalue) agidatemonth, f.partnumber_noleadzero, f.genderrollup, f.fitdescription, 
f.fitcode, f.strategiccategory_columbia, f.strategiccategorydescription_columbia,
f.divisiondescription , f.size, f.country,0 ct_salesquantity
FROM tmp_saleshistory_yyyymm y,
( SELECT DISTINCT f.partnumber_noleadzero, f.genderrollup, f.fitdescription, f.fitcode, f.strategiccategory_columbia, f.strategiccategorydescription_columbia,
f.divisiondescription , f.size, f.country
FROM tmp_sod_denorm_fcst f) f
WHERE NOT EXISTS ( SELECT 1 FROM stage_saleshistory t 
                WHERE t.partnumber_noleadzero = f.partnumber_noleadzero
                AND t.genderrollup = f.genderrollup AND t.fitdescription = f.fitdescription
                AND t.fitcode = f.fitcode
                AND t.strategiccategory_columbia = f.strategiccategory_columbia
                AND t.strategiccategorydescription_columbia = f.strategiccategorydescription_columbia
                AND t.divisiondescription = f.divisiondescription
                AND t.size = f.size AND t.country = f.country
		AND t.agidatemonth = month(y.datevalue) AND t.agidateyear = year(y.datevalue));


call vectorwise(combine 'stage_saleshistory');

/*\i VWbcp.sh columbia stage_saleshistory ALL ',' /home/fusionops/sa*/
select 1;
