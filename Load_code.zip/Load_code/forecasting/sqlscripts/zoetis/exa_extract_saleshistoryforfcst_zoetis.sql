open schema zoetise8c;

DROP TABLE IF EXISTS tmp_saleshistory_raw;
CREATE TABLE tmp_saleshistory_raw
(
dd_partnumber varchar(20),
dd_plant varchar(10) default 'abc',
dd_company varchar(5) default 'abc',
dd_calendarmonthid int,
ct_salesquantity decimal(8,0)
);


IMPORT INTO tmp_saleshistory_raw(dd_partnumber,dd_calendarmonthid,ct_salesquantity)
FROM LOCAL CSV FILE '/Users/lokeshkamani/DSWork/poc_customer/zoetis/ForecastingPrdDeployment/forecastinput_all/saleshistory_zoetis_complete.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1;

DROP TABLE IF EXISTS tmp_fosf_distinctpartplant;
CREATE TABLE tmp_fosf_distinctpartplant
AS
SELECT DISTINCT dd_partnumber,dd_plant,dd_company
FROM tmp_saleshistory_raw;

/* Distinct yyyymm from min to max date */
DROP TABLE IF EXISTS tmp_fosf_distinctyyyymm;
CREATE TABLE tmp_fosf_distinctyyyymm
AS
SELECT DISTINCT calendarmonthid dd_calendarmonthid
FROM dim_date
WHERE companycode = 'Not Set'
AND calendarmonthid >= 201311
AND calendarmonthid <= 201811;

/* Cross join to capture all distinct part-plant-dates */
DROP TABLE IF EXISTS tmp_saleshistory_fosf;
CREATE TABLE tmp_saleshistory_fosf
AS
SELECT t.*,d.dd_calendarmonthid,cast(0 as decimal(10,0))  ct_salesquantity
FROM tmp_fosf_distinctpartplant t,tmp_fosf_distinctyyyymm d;

/* Update actual sales qty from raw sales history file */
UPDATE tmp_saleshistory_fosf
SET ct_salesquantity = r.ct_salesquantity
FROM tmp_saleshistory_fosf t,tmp_saleshistory_raw r
WHERE t.dd_partnumber = r.dd_partnumber
AND t.dd_plant = r.dd_plant
AND t.dd_company = r.dd_company
AND t.dd_calendarmonthid = r.dd_calendarmonthid;


/* Take backup of historic sales */
DROP TABLE IF EXISTS tmp_backup_saleshistory_fosf_deleted;
CREATE TABLE tmp_backup_saleshistory_fosf_deleted
AS
SELECT f.*,cast('' as varchar(30)) dd_deletion_flag
FROM tmp_saleshistory_fosf f
WHERE 1=2;


/* Delete all rows before the first non-zero sales month */
INSERT INTO tmp_backup_saleshistory_fosf_deleted
SELECT s.*,'Trailing_0s' dd_deletion_flag
FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND s.dd_calendarmonthid < nz.dd_calendarmonthid
and s.ct_salesquantity <= 0 );

DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND s.dd_calendarmonthid < nz.dd_calendarmonthid
and s.ct_salesquantity <= 0 );

/* Delete part-plants with all zeros */
INSERT INTO tmp_backup_saleshistory_fosf_deleted
SELECT s.*,'All_0s' dd_deletion_flag
FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) dd_calendarmonthid from tmp_saleshistory_fosf
                                                                GROUP BY dd_partnumber,dd_plant
                                                                HAVING MAX(ct_salesquantity) = 0) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant);

DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) dd_calendarmonthid from tmp_saleshistory_fosf
								GROUP BY dd_partnumber,dd_plant
								HAVING MAX(ct_salesquantity) = 0) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant);


/* Delete part-plants where first start date is after Jan-2017. e.g as of Jan-2018, atleast 6 months of training + 6 months of holdout is available */
INSERT INTO tmp_backup_saleshistory_fosf_deleted
SELECT s.*,'SalesStartAfterJan2017' dd_deletion_flag
FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) min_dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND nz.min_dd_calendarmonthid >= 201701);

DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) min_dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND nz.min_dd_calendarmonthid >= 201701);


/* Parts that are not selling any more - No sales after Mar-2018 */
INSERT INTO tmp_backup_saleshistory_fosf_deleted
SELECT s.*,'SalesStartAfterJan2017' dd_deletion_flag
FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,max(dd_calendarmonthid) max_dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND nz.max_dd_calendarmonthid <= 201803);

DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,max(dd_calendarmonthid) max_dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND nz.max_dd_calendarmonthid <= 201803);


EXPORT (SELECT * FROM tmp_saleshistory_fosf ORDER BY dd_partnumber,dd_plant,dd_calendarmonthid,dd_company)
INTO LOCAL CSV FILE '/Users/lokeshkamani/DSWork/poc_customer/zoetis/ForecastingPrdDeployment/forecastinput_all/saleshistory_prepared_all6runs.csv.gz' COLUMN SEPARATOR = ','  REPLACE;


/* Create a table to park all part-plants which are not going to be forecasted */
DROP TABLE IF EXISTS tmp_unforecasted_parts_fosf;
CREATE TABLE tmp_unforecasted_parts_fosf
AS
SELECT *
FROM tmp_fosf_distinctpartplant t
WHERE NOT EXISTS ( SELECT 1 FROM  tmp_saleshistory_fosf f WHERE f.dd_partnumber = t.dd_partnumber AND f.dd_plant = t.dd_plant);

