/* Delete data from stage table and load from latest forecast file */
open schema fusionopsdemo;
DROP TABLE IF EXISTS stage_fosalesforecast;
CREATE TABLE stage_fosalesforecast (
DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
DD_PARTNUMBER       VARCHAR(40)  NOT NULL ,
DD_LEVEL2           VARCHAR(40) ,
CT_SALESQUANTITY    DECIMAL(36,6),
CT_FORECASTQUANTITY DECIMAL(36,6),
CT_LOWPI            DECIMAL(36,6),
CT_HIGHPI           DECIMAL(36,6),
CT_MAPE             DECIMAL(36,6),
DD_LASTDATE         VARCHAR(50)  NOT NULL ,
DD_HOLDOUTDATE      VARCHAR(50)  NOT NULL ,
DD_FORECASTSAMPLE   VARCHAR(50)  NOT NULL ,
DD_FORECASTTYPE     VARCHAR(50)  NOT NULL ,
DD_FORECASTRANK     DECIMAL(18,0),
DD_FORECASTMODE     VARCHAR(50)  NOT NULL ,
DD_COMPANYCODE      VARCHAR(50)  NOT NULL ,
CT_BIAS_ERROR_RANK  DECIMAL(18,6),
CT_BIAS_ERROR       DECIMAL(18,6)
--dd_partnumber          VARCHAR(40) ,
--dd_plantcode              VARCHAR(40) ,
--DD_DMDGROUP         VARCHAR(10)
);


/*
IMPORT INTO stage_fosalesforecast FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/jul2017zoetis/stage_fosalesforecast.csv.gz' 
COLUMN SEPARATOR = ',' SKIP = 1;
*/

/* Populate the forecast here by changing the path or ensure its populated before the script runs */

IMPORT INTO stage_fosalesforecast FROM LOCAL CSV FILE '/home/fusionops/ispring/import/ZoetisE8C/stage_fosalesforecast.csv.gz' 
COLUMN SEPARATOR = ',' SKIP = 1;


DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from stage_fosalesforecast ;

DELETE FROM fact_fosalesforecast f
WHERE EXISTS ( SELECT 1 FROM tmp_maxrptdate r WHERE r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY'));

/* Create a de-normalized table containing data from Sales Order */

drop table if exists tmp_saleshistory_grain_reqmonths;
drop table if exists tmp_saleshistory_grain_reqmonths_2;

drop table if exists fact_fosalesforecast_temp;
create table fact_fosalesforecast_temp as
select * from fact_fosalesforecast WHERE 1=2;

alter table fact_fosalesforecast_temp add column dd_forecastdatevalue date default '1900-01-01';

/* Cap Bias Error and MAPE */
UPDATE stage_fosalesforecast
SET ct_bias_error = 1000000
WHERE ct_bias_error > 1000000;

UPDATE stage_fosalesforecast
SET ct_mape = 1000000
WHERE ct_mape > 1000000;

insert into fact_fosalesforecast_temp
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plantcode
)
select  (select ifnull(max(fact_fosalesforecastid), 0) from fact_fosalesforecast m)
+ row_number() over(order by dd_partnumber,dd_level2,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecastid,
1 dim_partid,
1 dim_plantid,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
--TO_DATE(sf.dd_reportingdate,'DD MON YYYY') dd_reportingdate, --ifnull(cast(sf.dd_reportingdate as date),'1 Jan 1900'),
upper(sf.dd_reportingdate),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mape,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
case when sf.dd_forecastdate is null then cast('1900-01-01' as date)
else cast(concat(substring(sf.dd_forecastdate,1,4) , '-' ,
substring(sf.dd_forecastdate,5,2) , '-' ,
substring(sf.dd_forecastdate,7,2) ) as date)
end dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
sf.dd_partnumber dd_partnumber,
sf.dd_level2 dd_plantcode
from stage_fosalesforecast sf;

UPDATE fact_fosalesforecast_temp f
SET f.dim_partid = dp.dim_partid
from dim_part dp,fact_fosalesforecast_temp f
WHERE f.dd_partnumber = dp.partnumber
AND f.dd_plantcode = dp.plant;

UPDATE fact_fosalesforecast_temp f
SET f.dim_plantid = pl.dim_plantid
from dim_plant pl, dim_part p,fact_fosalesforecast_temp f
WHERE f.dim_partid = p.dim_partid
AND p.plant = pl.plantcode
AND p.projectsourceid = 1
AND f.dim_plantid <> pl.dim_plantid;

UPDATE fact_fosalesforecast_temp f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
fact_fosalesforecast_temp f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE fact_fosalesforecast_temp f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
fact_fosalesforecast_temp f
WHERE f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid;

insert into fact_fosalesforecast
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plantcode
)
select
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plantcode
from fact_fosalesforecast_temp;

DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from stage_fosalesforecast ;

/*
DELETE FROM fact_fosalesforecast f
WHERE TO_DATE(dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from tmp_maxrptdate)*/

/* Update future sales to NULL */
UPDATE fact_fosalesforecast f
SET ct_salesquantity = NULL
FROM dim_date d,fact_fosalesforecast f,tmp_maxrptdate r
WHERE ct_salesquantity = 0
AND f.dim_dateidforecast = d.dim_dateid
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND d.datevalue >= to_date(f.dd_reportingdate,'YYYY-MM-DD');

/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE fact_fosalesforecast f
set ct_highpi = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE ct_highpi = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE fact_fosalesforecast f
set ct_lowpi = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE ct_lowpi = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

/* Format reporting date as DD MON YYYY */
UPDATE fact_fosalesforecast f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD MON YYYY')
where f.dd_reportingdate like '%-%-%';

DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from stage_fosalesforecast ;


/* Rerank for mult forecasts having same ranks */

DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf;
CREATE TABLE tmp_upd_fcstrank_fosf
as
select distinct f.dd_reportingdate,dd_partnumber,dd_plantcode,dd_forecasttype,dd_forecastrank
from fact_fosalesforecast f,tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;

select *
from tmp_upd_fcstrank_fosf
order by dd_reportingdate,dd_partnumber,dd_plantcode,dd_forecasttype,dd_forecastrank
limit 2;

--This should insert 0 rows as for same fcst type, there cannot be different ranks
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dd_partnumber = t2.dd_partnumber
and t1.dd_plantcode = t2.dd_plantcode
and t1.dd_forecasttype = t2.dd_forecasttype
and t1.dd_forecastrank <> t2.dd_forecastrank;

select *
from tmp_upd_fcstrank_fosf2
order by dd_reportingdate,dd_partnumber,dd_plantcode,dd_forecasttype,dd_forecastrank
limit 2;

--These are the cases with issues ( different methods, same rank )
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dd_partnumber = t2.dd_partnumber
and t1.dd_plantcode = t2.dd_plantcode
and t1.dd_forecasttype <> t2.dd_forecasttype
and t1.dd_forecastrank = t2.dd_forecastrank;

select *
from tmp_upd_fcstrank_fosf2
order by dd_reportingdate,dd_partnumber,dd_plantcode,dd_forecasttype,dd_forecastrank
limit 2;

--Get all rows corresponding to these rptdate,dmdunit,loc
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf3;
CREATE TABLE tmp_upd_fcstrank_fosf3
as
select t1.*,rank() over(partition by dd_reportingdate,dd_partnumber,dd_plantcode  order by dd_forecastrank,dd_forecasttype) dd_rank_new
from tmp_upd_fcstrank_fosf t1
WHERE EXISTS ( SELECT 1 FROM tmp_upd_fcstrank_fosf2 t2
    where t1.dd_reportingdate = t2.dd_reportingdate
    and t1.dd_partnumber = t2.dd_partnumber
    and t1.dd_plantcode = t2.dd_plantcode);

select *
from tmp_upd_fcstrank_fosf3
order by dd_reportingdate,dd_partnumber,dd_plantcode,dd_forecastrank,dd_forecasttype
limit 2;

UPDATE fact_fosalesforecast f
SET f.dd_forecastrank = t.dd_rank_new
FROM fact_fosalesforecast f,tmp_upd_fcstrank_fosf3 t
where f.dd_reportingdate = t.dd_reportingdate
and f.dd_partnumber = t.dd_partnumber
and f.dd_plantcode = t.dd_plantcode
and f.dd_forecastrank = t.dd_forecastrank
and f.dd_forecasttype = t.dd_forecasttype;

UPDATE fact_fosalesforecast f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE fact_fosalesforecast f
SET dd_latestreporting = 'Yes'
FROM fact_fosalesforecast f,tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;


/****************************************/

/* Populate all part-plants which were not forecasted from APO. Use latest 3 months Moving Avg */
DROP TABLE IF EXISTS tmp_forecastedparts;
CREATE TABLE tmp_forecastedparts
AS
SELECT DISTINCT dd_partnumber,dd_plantcode
FROM fact_fosalesforecast 
WHERE dd_latestreporting = 'Yes';

/*
DROP TABLE IF EXISTS tmp_saleshistory_raw_allparts;
CREATE TABLE tmp_saleshistory_raw_allparts
(
dd_partnumber varchar(20),
dd_plant varchar(10),
dd_company varchar(5),
dd_calendarmonthid int,
ct_salesquantity decimal(8,0)
);


IMPORT INTO tmp_saleshistory_raw_allparts FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/jul2017zoetis/zoetis_saleshist_jul2017.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 0;
*/

DROP TABLE IF EXISTS tmp_saleshistory_raw;
CREATE TABLE tmp_saleshistory_raw
AS
SELECT a.*
FROM tmp_saleshistory_raw_allparts a
WHERE NOT EXISTS ( SELECT 1 FROM tmp_forecastedparts f where a.dd_partnumber = f.dd_partnumber
AND a.dd_plant = f.dd_plantcode);


DROP TABLE IF EXISTS tmp_fosf_distinctpartplant;
CREATE TABLE tmp_fosf_distinctpartplant
AS
SELECT DISTINCT dd_partnumber,dd_plant,dd_company
FROM tmp_saleshistory_raw;

/* Ensure that all dates in Train,Test,Horizon are covered */
DROP TABLE IF EXISTS tmp_fosf_distinctyyyymm;
CREATE TABLE tmp_fosf_distinctyyyymm
AS
SELECT DISTINCT calendarmonthid dd_calendarmonthid,
/* to_date(to_char(calendarmonthid),'YYYYMM') + interval '1' month - interval '1' day */
to_char(t.dd_forecastdate) dd_forecastdate,
t.dd_forecastsample,
dd_holdoutdate,dd_lastdate,dd_forecastmode
FROM dim_date d inner join (select distinct dd_forecastdate,dd_forecastsample,dd_holdoutdate,dd_lastdate,dd_forecastmode
from fact_fosalesforecast
where dd_forecastrank = 1 and  dd_latestreporting = 'Yes') t on to_date(to_char(t.dd_forecastdate),'YYYYMMDD') = d.datevalue
WHERE companycode = 'Not Set'
AND calendarmonthid >= 201406
AND calendarmonthid <= 201906;

/* Cross join to capture all distinct part-plant-dates */
DROP TABLE IF EXISTS tmp_saleshistory_fosf;
CREATE TABLE tmp_saleshistory_fosf
AS
SELECT t.*,d.dd_calendarmonthid,d.dd_forecastdate,d.dd_forecastsample,
dd_holdoutdate,dd_lastdate,dd_forecastmode,
cast(0 as decimal(8,0))  ct_salesquantity
FROM tmp_fosf_distinctpartplant t,tmp_fosf_distinctyyyymm d;

UPDATE tmp_saleshistory_fosf
SET ct_salesquantity = r.ct_salesquantity
FROM tmp_saleshistory_fosf t,tmp_saleshistory_raw r
WHERE t.dd_partnumber = r.dd_partnumber
AND t.dd_plant = r.dd_plant
AND t.dd_company = r.dd_company
AND t.dd_calendarmonthid = r.dd_calendarmonthid;


/* Delete all parts that do not have any data for 3 month avg calculation */
DROP TABLE IF EXISTS tmp_min_salesdate;
CREATE TABLE tmp_min_salesdate
AS
SELECT a.dd_partnumber,a.dd_plant,min(dd_calendarmonthid) min_dd_calendarmonthid
FROM tmp_saleshistory_fosf a
WHERE a.ct_salesquantity > 0
GROUP BY  a.dd_partnumber,a.dd_plant;

DELETE FROM tmp_saleshistory_fosf a
WHERE EXISTS (SELECT 1 FROM tmp_min_salesdate b WHERE a.dd_partnumber = b.dd_partnumber
AND a.dd_plant = b.dd_plant
AND b.min_dd_calendarmonthid > 201701);

/* Delete all rows before the first non-zero sales month */
DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND s.dd_calendarmonthid < nz.dd_calendarmonthid 
and s.ct_salesquantity = 0 );


/* Rank by dates */
DROP TABLE IF EXISTS tmp_saleshistory_fosf_dateranked;
CREATE TABLE tmp_saleshistory_fosf_dateranked
AS
SELECT f.*,
row_number() over(partition by f.dd_partnumber,f.dd_plant ORDER BY f.dd_calendarmonthid) sr_no_reverse
FROM tmp_saleshistory_fosf f;


/* Calculate moving average fcsts */
DROP TABLE IF EXISTS tmp_fcst_3monthavg;
CREATE TABLE tmp_fcst_3monthavg
AS
SELECT a.dd_partnumber,a.dd_plant,a.dd_calendarmonthid,a.ct_salesquantity,
a.dd_forecastdate,a.dd_forecastsample,
a.dd_holdoutdate,a.dd_lastdate,a.dd_forecastmode,
avg(b.ct_salesquantity) ct_forecastquantity_movingavg,
cast(0 as decimal(18,4)) ct_mape
FROM tmp_saleshistory_fosf_dateranked a LEFT OUTER JOIN tmp_saleshistory_fosf_dateranked b
ON a.dd_partnumber = b.dd_partnumber
AND a.dd_plant = b.dd_plant
AND a.dd_calendarmonthid - b.dd_calendarmonthid <= 3
AND a.dd_calendarmonthid > b.dd_calendarmonthid
GROUP BY a.dd_partnumber,a.dd_plant,a.dd_calendarmonthid,a.ct_salesquantity,a.dd_forecastdate,a.dd_forecastsample,
a.dd_holdoutdate,a.dd_lastdate,a.dd_forecastmode;

UPDATE tmp_fcst_3monthavg a
SET a.ct_forecastquantity_movingavg = b.ct_forecastquantity_movingavg
FROM tmp_fcst_3monthavg a,tmp_fcst_3monthavg b
WHERE a.dd_partnumber = b.dd_partnumber
AND a.dd_plant = b.dd_plant
AND a.dd_calendarmonthid > 201704
AND b.dd_calendarmonthid = 201704;

UPDATE tmp_fcst_3monthavg
SET ct_salesquantity = 1
WHERE ct_salesquantity = 0
AND dd_forecastsample = 'Test';

DROP TABLE IF EXISTS tmp_fcst_3monthavg_withmape;
CREATE TABLE tmp_fcst_3monthavg_withmape
AS
SELECT a.dd_partnumber,a.dd_plant,100 * avg(abs((ct_forecastquantity_movingavg - ct_salesquantity)/ct_salesquantity)) ct_mape
FROM tmp_fcst_3monthavg a
WHERE dd_forecastsample = 'Test'
GROUP BY a.dd_partnumber,a.dd_plant;

UPDATE tmp_fcst_3monthavg a
SET a.ct_mape = b.ct_mape
FROM tmp_fcst_3monthavg a, tmp_fcst_3monthavg_withmape b
WHERE a.dd_partnumber = b.dd_partnumber
AND a.dd_plant = b.dd_plant;


INSERT INTO fact_fosalesforecast
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_partnumber,
dd_plantcode,
dd_latestreporting
)
select  (select ifnull(max(fact_fosalesforecastid), 0) from fact_fosalesforecast m)
+ row_number() over(order by sf.dd_partnumber,sf.dd_plant) as fact_fosalesforecastid,
1 dim_partid,
1 dim_plantid,
'Not Set' dd_companycode ,
to_char(r.dd_reportingdate,'DD MON YYYY'),
1 as dim_dateidreporting,
'Moving Avg' dd_forecasttype,
'Not Set' dd_forecastsample,
sf.dd_forecastdate,
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity_movingavg,
sf.ct_forecastquantity_movingavg * 0.8 ct_lowpi,
sf.ct_forecastquantity_movingavg * 1.2 ct_highpi,
sf.ct_mape,
1 dd_forecastrank,
sf.dd_holdoutdate,
sf.dd_lastdate,
sf.dd_forecastmode,
NULL ct_bias_error,
NULL ct_bias_error_rank,
sf.dd_partnumber dd_partnumber,
sf.dd_plant dd_plantcode,
'Yes' dd_latestreporting
from tmp_fcst_3monthavg sf,tmp_maxrptdate r;

