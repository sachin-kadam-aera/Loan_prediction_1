/* ZOETISE data populate quer
/* Before running export, replacde NA in forecast output file with blanks */
/* */

open schema zoetise8c;

DROP TABLE IF EXISTS stage_fosalesforecast;
CREATE TABLE stage_fosalesforecast (
dd_reportingdate varchar(50) ,
dd_forecastdate int,
dim_partid varchar(200),/* Combined forecast grain */
dd_level2 varchar(10) default 'Not Set',
ct_salesquantity DECIMAL(36,6),
ct_forecastquantity DECIMAL(36,6),
ct_lowpi DECIMAL(36,6),
ct_highpi DECIMAL(36,6),
ct_mape DECIMAL(36,6),
dd_lastdate varchar(30),
dd_holdoutdate varchar(30),
dd_forecastsample varchar(50),
dd_forecasttype varchar(100),
dd_forecastrank int,
dd_forecastmode varchar(20) default 'Not Set',
dd_companycode varchar(20) default 'Not Set',
dd_bias_error_rank DECIMAL(36,6),
dd_bias_error DECIMAL(36,6),

/* Additional columns */
dd_productapo varchar(20),
dd_partnumber varchar(20),
dd_businessareaapo varchar(20),
dd_plantcode varchar(20),
dd_salesorg varchar(20),
dd_forecastdatevalue date default '1900-01-01',
ct_forecastquantity_fullhistory decimal(36,6),
ct_ape_currentmonth_regular decimal(36,6),
ct_ape_currentmonth_fullhistfcst decimal(36,6),
ct_actualsales_last1year_fromrptdate decimal(18,2),
ct_forecast_next1year_fromrptdate decimal(18,2),
ct_abserror_reg decimal(18,2),
ct_abserror_rfh decimal(18,2),
ct_mape_modified decimal(18,2),
dd_forecastrank_modified int
);

/* Import reg */
IMPORT INTO stage_fosalesforecast 
(
dim_partid,dd_forecasttype,dd_forecastdate,dd_forecastsample,ct_salesquantity,ct_forecastquantity,ct_forecastquantity_fullhistory,ct_mape,dd_forecastrank
)
FROM LOCAL CSV FILE '/home/lkamani/zoetis/forecastoutput/zoetis_junefcst.csv.gz' 
COLUMN SEPARATOR = ',' SKIP = 1 ;

UPDATE stage_fosalesforecast
SET dd_productapo = substr(dim_partid,1,8),
dd_partnumber = substr(dim_partid,1,8);

UPDATE stage_fosalesforecast
SET dd_businessareaapo = substr(dim_partid,10,4),
dd_plantcode = substr(dim_partid,10,4);

UPDATE stage_fosalesforecast
SET dd_salesorg = substr(dim_partid,15,4);

/* Update actual sales and additional columns */

UPDATE stage_fosalesforecast
SET ct_abserror_reg = abs(ct_salesquantity-ct_forecastquantity),
ct_abserror_rfh = abs(ct_salesquantity-ct_forecastquantity_fullhistory),
ct_ape_currentmonth_regular = abs(ct_salesquantity-ct_forecastquantity)/ct_salesquantity,
ct_ape_currentmonth_fullhistfcst = abs(ct_salesquantity-ct_forecastquantity_fullhistory)/ct_salesquantity
WHERE ct_salesquantity > 1;

/* Where actual sales is 0, update ape = 100% */
UPDATE stage_fosalesforecast
SET ct_ape_currentmonth_regular= 1,
ct_ape_currentmonth_fullhistfcst = 1
WHERE ct_salesquantity <= 1;

UPDATE stage_fosalesforecast
SET dd_reportingdate = '01 JUN 2018';

DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate,
dd_reportingdate dd_reportingdate_char
from stage_fosalesforecast ;


/* Update last one year's actual and next one year's forecast */
DROP TABLE IF EXISTS tmp_actualsales_previous1year;
CREATE TABLE tmp_actualsales_previous1year
AS
SELECT dim_partid,case when sum(ct_salesquantity) > 0 THEN sum(ct_salesquantity) ELSE 1 END ct_actualsales_last1year_fromrptdate
FROM stage_fosalesforecast
WHERE dd_forecasttype = 'Auto ETS'	/* Ensure no dups using rank 1 or using a specific method */
AND to_date(to_char(dd_forecastdate),'YYYYMMDD') >= to_date(dd_reportingdate,'DD MON YYYY') - INTERVAL '1' YEAR
AND to_date(to_char(dd_forecastdate),'YYYYMMDD') <= to_date(dd_reportingdate,'DD MON YYYY') - INTERVAL '1' DAY
GROUP BY dim_partid;

UPDATE stage_fosalesforecast s
SET s.ct_actualsales_last1year_fromrptdate = t.ct_actualsales_last1year_fromrptdate
FROM stage_fosalesforecast s,tmp_actualsales_previous1year t
WHERE s.dim_partid = t.dim_partid;

/* Update next 1 year's forecast */
DROP TABLE IF EXISTS tmp_fcst_next1yr;
CREATE TABLE tmp_fcst_next1yr
AS
SELECT dim_partid,sum(ct_forecastquantity_fullhistory) ct_forecast_next1year_fromrptdate
FROM stage_fosalesforecast
WHERE dd_forecasttype = 'Auto ETS'
AND to_date(to_char(dd_forecastdate),'YYYYMMDD') <= to_date(dd_reportingdate,'DD MON YYYY') + INTERVAL '1' YEAR
AND to_date(to_char(dd_forecastdate),'YYYYMMDD') >= to_date(dd_reportingdate,'DD MON YYYY') 
GROUP BY dim_partid;

UPDATE stage_fosalesforecast s
SET s.ct_forecast_next1year_fromrptdate = t.ct_forecast_next1year_fromrptdate
FROM stage_fosalesforecast s,tmp_fcst_next1yr t
WHERE s.dim_partid = t.dim_partid;

DROP TABLE IF EXISTS tmp_bigdeviationsinnext1year;
CREATE TABLE tmp_bigdeviationsinnext1year
AS
SELECT DISTINCT dim_partid,dd_forecasttype,ct_forecast_next1year_fromrptdate/ct_actualsales_last1year_fromrptdate ct_ratio_fcst_actual_1yr
FROM stage_fosalesforecast
WHERE  (ct_forecast_next1year_fromrptdate/ct_actualsales_last1year_fromrptdate > 3
OR ct_forecast_next1year_fromrptdate/ct_actualsales_last1year_fromrptdate < 0.3)
AND dd_forecasttype <> 'Auto ETS';

/* Delete forecasts with big deviations. If all are highly volatile, Auto ETS will still remain  */
DELETE FROM stage_fosalesforecast s
WHERE EXISTS ( SELECT 1 FROM tmp_bigdeviationsinnext1year d WHERE d.dim_partid = s.dim_partid AND d.dd_forecasttype = s.dd_forecasttype );


/* Update modified MAPE using ct_ape_currentmonth_regular */
UPDATE stage_fosalesforecast s
SET ct_mape_modified = t.ct_mape_modified
FROM stage_fosalesforecast s,
(SELECT dim_partid,dd_forecasttype,avg(ct_ape_currentmonth_regular) ct_mape_modified 
FROM stage_fosalesforecast WHERE dd_forecastsample = 'Test' GROUP BY dim_partid,dd_forecasttype) t
WHERE s.dim_partid = t.dim_partid AND s.dd_forecasttype = t.dd_forecasttype;

/* Rerank according to special logic */
DROP TABLE IF EXISTS tmp_stage_fosalesforecast_rerank;
CREATE TABLE tmp_stage_fosalesforecast_rerank
AS
SELECT dim_partid,dd_forecasttype,ct_mape_modified,
rank() over(partition by dim_partid ORDER BY ct_mape_modified,dd_forecasttype ) dd_forecastrank_new
FROM stage_fosalesforecast
WHERE dd_forecastsample = 'Test'
GROUP BY dim_partid,dd_forecasttype,ct_mape_modified;

UPDATE stage_fosalesforecast s
SET s.dd_forecastrank_modified = t.dd_forecastrank_new
FROM stage_fosalesforecast s,tmp_stage_fosalesforecast_rerank t
WHERE s.dim_partid = t.dim_partid
AND s.dd_forecasttype = t.dd_forecasttype;

/* Delete forecast for given snapshot date, if it already exists */
DELETE FROM fact_fosalesforecast f
WHERE TO_DATE(dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from tmp_maxrptdate);

insert into fact_fosalesforecast
(
fact_fosalesforecastid, 
dd_productapo, dd_businessareaapo, dd_salesorg,
dd_companycode, dd_forecastdate, dd_reportingdate,
ct_salesquantity, ct_forecastquantity, ct_forecastquantity_fullhistory,
ct_lowpi, ct_highpi, ct_mape,
dd_lastdate, dd_holdoutdate, dd_forecastmode,
dd_forecasttype,
dim_dateidreporting, dim_dateidforecast, dd_forecastdatevalue,
dd_partnumber, DD_FORECASTSAMPLE, DD_FORECASTRANK 
)
select  (select ifnull(max(fact_fosalesforecastid), 0) from fact_fosalesforecast m)
+ row_number() over(order by dd_partnumber,dd_companycode,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecastid,
dd_productapo, dd_businessareaapo, dd_salesorg,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
ifnull(sf.dd_forecastdate,1),
upper(sf.dd_reportingdate),
sf.ct_salesquantity, sf.ct_forecastquantity, sf.ct_forecastquantity_fullhistory,
sf.ct_lowpi, sf.ct_highpi, sf.ct_mape_modified,
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
ifnull(sf.dd_forecasttype,'Not Set') dd_forecasttype,
1 as dim_dateidreporting,
1 as dim_dateidforecast,
case when sf.dd_forecastdate is null then cast('1900-01-01' as date) else to_date(to_char(sf.dd_forecastdate),'YYYYMMDD') END AS dd_forecastdatevalue,
sf.dd_partnumber dd_partnumber, DD_FORECASTSAMPLE, DD_FORECASTRANK_modified 
from stage_fosalesforecast sf;

UPDATE fact_fosalesforecast f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
fact_fosalesforecast f
WHERE f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid
AND f.dd_reportingdate = '01 JUN 2018';

/* Update future sales to NULL */
/*
UPDATE fact_fosalesforecast f
SET ct_salesquantity = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE ct_salesquantity = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Horizon';
*/

/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE fact_fosalesforecast f
set ct_highpi = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE fact_fosalesforecast f
set ct_lowpi = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE fact_fosalesforecast f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE fact_fosalesforecast f
SET dd_latestreporting = 'Yes'
FROM fact_fosalesforecast f,tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate;

/* End of Update */
/* Global Part */

UPDATE fact_fosalesforecast f
SET f.dim_globalpartid = dp.dim_globalpartid
FROM dim_globalpart dp, fact_fosalesforecast f
WHERE f.dd_productapo = dp.PARTNUMBER_NOLEADZERO;


EXPORT (SELECT dd_reportingdate,dim_partid,dd_forecasttype,dd_forecastdate,ct_salesquantity,ct_forecastquantity,ct_forecastquantity_fullhistory,
ct_ape_currentmonth_regular, ct_ape_currentmonth_fullhistfcst,ct_mape_modified,dd_forecastrank_modified 
FROM stage_fosalesforecast
ORDER BY dd_reportingdate,dim_partid,dd_forecasttype,dd_forecastdate)
INTO LOCAL CSV FILE '/home/lkamani/zoetis/forecast_jun_final.csv.gz'
WITH COLUMN NAMES
REPLACE;

--dim_partid,dd_forecasttype,dd_forecastdate,ct_salesquantity,ct_forecastquantity,ct_forecastquantity_fullhistory,ct_mape,dd_forecastrank












