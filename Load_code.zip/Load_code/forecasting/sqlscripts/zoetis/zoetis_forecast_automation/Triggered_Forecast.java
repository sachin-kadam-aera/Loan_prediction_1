 StringBuffer output = new StringBuffer();
System.out.println("Zoetis_SWB:Helloooooooooo");
Process p;

try {
    int count = 0;
    Log_Debug_Message("Zoetis_SWB: Calling Before Pre-Process call Shell script");
    p = Runtime.getRuntime().exec("sudo -i -u fusionops /efs/datascience/ZoetisE8C/scripts/Exasol/forecasting/connect_prod_forecast01_zoiets.sh");
    
    Log_Debug_Message("Zoetis_SWB: Forecast call finished Shell script");
    InputStreamReader in = new InputStreamReader(p.getInputStream());
    BufferedReader reader = new BufferedReader(in);
    String line = "";
    
    while ((line = reader.readLine()) != null) {
        count = count + 1;
        Log_Debug_Message(count+". Zoetis_SWB Output"+line);
        logDebug(count+". Zoetis_SWB Output"+line);
        System.out.println("Helloooooooooo");
        System.out.println("Zoetis_SWB Output"+line);
        output.append(line + "\n");
    }
    p.destroy();
    reader.close();
    
} catch (Exception e) {
    e.printStackTrace();
}        