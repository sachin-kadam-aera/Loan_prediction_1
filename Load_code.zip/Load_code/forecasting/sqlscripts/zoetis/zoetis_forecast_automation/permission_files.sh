cd /efs/datascience/ZoetisE8C/
chmod 777 -R data