DROP TABLE IF EXISTS TMP_line_execute;
CREATE TABLE TMP_line_execute
(
 DD_line DECIMAL(18,0)
);

insert into TMP_line_execute
values(1);


DROP TABLE IF EXISTS TMP_SALESHISTORY_RAW;
CREATE TABLE TMP_SALESHISTORY_RAW (
    DD_PARTNUMBER      VARCHAR(100),
    DD_PLANT           VARCHAR(10) DEFAULT 'abc',
    DD_COMPANY         VARCHAR(5) DEFAULT 'abc',
    DD_CALENDARMONTHID DECIMAL(18,0),
    CT_SALESQUANTITY   DECIMAL(18,4)
);

insert INTO tmp_saleshistory_raw
(DD_PARTNUMBER,DD_CALENDARMONTHID,CT_SALESQUANTITY)
select prdapo.col__bic_z9amatnr ||'-'|| bussapo.col_bus_area ||'-'|| slsorgapo.col_salesorg,
to_char(to_date( dd_fmy.MonthYear ,'Mon YYYY'),'YYYYMM'),
sum(f.ct_col_biczgdpkf_07) as ct_col_biczgdpkf_07
from fact_apo_demandplanning_ui f
inner join dim_apo_new_bic_z9amatnr prdapo
on prdapo.dim_apo_new_bic_z9amatnrid = f.dim_apo_new_bic_z9amatnrid
inner join dim_apo_newbus_area bussapo
on bussapo.dim_apo_newbus_areaid = f.dim_apo_newbus_areaid
inner join dim_apo_newsalesorg slsorgapo
on slsorgapo.dim_apo_newsalesorgid = f.dim_apo_newsalesorgid
inner join dim_date dd_fmy
on dd_fmy.dim_dateid = f.dim_dateidfiscalcalendar
where dd_fmy.datevalue between '2013-01-01' and '2019-12-31'
group by prdapo.col__bic_z9amatnr ||'-'|| bussapo.col_bus_area ||'-'|| slsorgapo.col_salesorg,
to_char(to_date( dd_fmy.MonthYear ,'Mon YYYY'),'YYYYMM')
order by prdapo.col__bic_z9amatnr ||'-'|| bussapo.col_bus_area ||'-'|| slsorgapo.col_salesorg,
to_char(to_date( dd_fmy.MonthYear ,'Mon YYYY'),'YYYYMM');


insert into TMP_line_execute
values(2);

DROP TABLE IF EXISTS tmp_fosf_distinctpartplant;
CREATE TABLE tmp_fosf_distinctpartplant
AS
SELECT DISTINCT dd_partnumber,dd_plant,dd_company
FROM tmp_saleshistory_raw;
insert into TMP_line_execute
values(3);

DROP TABLE IF EXISTS tmp_fosf_distinctyyyymm;
CREATE TABLE tmp_fosf_distinctyyyymm
AS
SELECT DISTINCT calendarmonthid dd_calendarmonthid
FROM dim_date
WHERE companycode = 'Not Set'
AND calendarmonthid >= 201406
AND calendarmonthid <= 201706;

insert into TMP_line_execute
values(4);

DROP TABLE IF EXISTS tmp_saleshistory_fosf;
CREATE TABLE tmp_saleshistory_fosf
AS
SELECT t.*,d.dd_calendarmonthid,convert(numeric(18,0),0) as ct_salesquantity
FROM tmp_fosf_distinctpartplant t,tmp_fosf_distinctyyyymm d;

insert into TMP_line_execute
values(5);

UPDATE tmp_saleshistory_fosf
SET ct_salesquantity = r.ct_salesquantity
FROM tmp_saleshistory_fosf t,tmp_saleshistory_raw r
WHERE t.dd_partnumber = r.dd_partnumber
AND t.dd_plant = r.dd_plant
AND t.dd_company = r.dd_company
AND t.dd_calendarmonthid = r.dd_calendarmonthid;

insert into TMP_line_execute
values(6);

DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) dd_calendarmonthid from tmp_saleshistory_fosf
where ct_salesquantity > 0 GROUP BY dd_partnumber,dd_plant) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant AND s.dd_calendarmonthid < nz.dd_calendarmonthid
and s.ct_salesquantity = 0 );

insert into TMP_line_execute
values(7);

DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,min(dd_calendarmonthid) dd_calendarmonthid from tmp_saleshistory_fosf
								GROUP BY dd_partnumber,dd_plant
								HAVING MAX(ct_salesquantity) = 0) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant);

insert into TMP_line_execute
values(8);

DELETE FROM tmp_saleshistory_fosf s
WHERE EXISTS ( SELECT 1 FROM ( select dd_partnumber,dd_plant,count(*) cnt from tmp_saleshistory_fosf
								GROUP BY dd_partnumber,dd_plant
								HAVING count(*) <15) nz
WHERE nz.dd_partnumber = s.dd_partnumber AND nz.dd_plant = s.dd_plant);

insert into TMP_line_execute
values(9);

EXPORT (SELECT * FROM tmp_saleshistory_fosf where DD_PARTNUMBER='10000002-8221-7941' ORDER BY dd_partnumber,dd_plant,dd_calendarmonthid,dd_company)
INTO LOCAL CSV FILE '/efs/datascience/ZoetisE8C/data/input/zoetis_sales_history_apo.csv.gz' COLUMN SEPARATOR = ','  REPLACE;

insert into TMP_line_execute
values(10);

DROP TABLE IF EXISTS tmp_unforecasted_parts_fosf;
CREATE TABLE tmp_unforecasted_parts_fosf
AS
SELECT *
FROM tmp_fosf_distinctpartplant t
WHERE NOT EXISTS ( SELECT 1 FROM  tmp_saleshistory_fosf f WHERE f.dd_partnumber = t.dd_partnumber AND f.dd_plant = t.dd_plant);

insert into TMP_line_execute
values(11);
