StringBuffer output = new StringBuffer();
System.out.println("Zoetis_SWB:Helloooooooooo");
Process p;

try {
    int count = 0;
    p = Runtime.getRuntime().exec("/efs/datascience/ZoetisE8C/scripts/Exasol/forecasting/permission_files.sh");
    InputStreamReader in = new InputStreamReader(p.getInputStream());
    BufferedReader reader = new BufferedReader(in);
    String line = "";
    
    while ((line = reader.readLine()) != null) {
        count = count + 1;
        Log_Debug_Message(count+". Zoetis_SWB Output"+line);
        logDebug(count+". Zoetis_SWB Output"+line);
        System.out.println("Zoetis_SWB Output"+line);
        output.append(line + "\n");
    }
    p.destroy();
    reader.close();
    
} catch (Exception e) {
    e.printStackTrace();
}      