
#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo -e "\e[31;43m***** TEST SCRIPT FOR Zoetis *****\e[0m"
echo SSH passed to target server, moving on..
echo "This script call Forecast01 script"
HOST=10.105.5.56
status=$(ssh -o BatchMode=yes -o ConnectTimeout=5 fusionops@$HOST echo ok 2>&1)
if [[ $status == ok ]]; then
        echo SSH passed to target server, moving on...
        ssh -o StrictHostKeyChecking=no fusionops@$HOST '/home/fusionops/zoiets_forecast/trigger_forecast_zoiets.sh'

elif [[ $status == "Permission denied"* ]] ; then
    echo I am unable to communicate to target host PPPPPPPPPPPPPPPPPPPP
fi