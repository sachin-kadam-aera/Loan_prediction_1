
import pandas as pd
import sys

filename1 = "zoetis_sales_history_apo.csv.gz"#sys.argv[1]
print filename1
path = "/efs/datascience/ZoetisE8C/data/input/"
#path1 = "/efs/datascience/MerckDE6/forecast/datascience/forecasting/"
path1 = "/home/fusionops/zoiets_forecast/datascience/forecasting/"
filename = path+filename1
print filename
data = pd .read_csv(filename,names = ['dim_partid','dd_level2','comp','dd_forecastdate','sales'] ,converters={u'dim_partid': lambda x: str(x),u'dd_level2': lambda x: str(x)})

last_date1 = max(data['dd_forecastdate'])
import datetime
import calendar
import datetime
from dateutil import relativedelta
last_date = last_date1
print last_date

def last_day_of_month(any_day):
    any_day = datetime.datetime.strptime(any_day, '%Y%m')
    any_day = any_day + relativedelta.relativedelta(months=1)
    next_month = any_day.replace(day=28) + datetime.timedelta(days=4)  # this will never fail
    last_day_month =  next_month - datetime.timedelta(days=next_month.day)
    last_day_month = last_day_month.strftime('%Y%m%d')
    return last_day_month

last_date = str(last_date1)
last_date1 = last_day_of_month(last_date)
print last_date1


def last_day_of_holdout_date(any_day):
    any_day = datetime.datetime.strptime(any_day, '%Y%m')
    any_day = any_day - relativedelta.relativedelta(months=2)
    next_month = any_day.replace(day=28) + datetime.timedelta(days=4)  # this will never fail
    last_day_month =  next_month - datetime.timedelta(days=next_month.day)
    last_day_month = last_day_month.strftime('%Y%m%d')
    return last_day_month

last_date = max(data['dd_forecastdate'])
last_date = str(last_date)
holdout_date1 = last_day_of_holdout_date(last_date)
print holdout_date1

#holdout_date1 = last_date1 - 3
last_date = str(last_date1)
holdout_date = str(holdout_date1)
print last_date
print holdout_date

#import datetime
#dt = datetime.datetime.now().strftime ("%d%b%y")

f = open(path1+"forecast.ini","w")

f.write("[RunScript]")
f.write("\n")
f.write("run_type:1")
f.write("\n")
f.write("company:zoiets")
f.write("\n")
f.write("input_file:"+filename1)
f.write("\n")
f.write("output_file:zoiets_forecast_auto_3MHO.csv")
f.write("\n")
f.write("holdout_date:"+holdout_date)#%holdout_date
f.write("\n")
f.write("last_date:"+last_date)#%last_date
f.write("\n")
f.write("demand_capping:1000000000")
f.write("\n")
f.write("num_process:45")
f.write("\n")
f.write("input_columns:UIN,Comop,CompanyCode,YYYYMMDD,Sales")
f.write("\n")
f.write("separator:,")
f.write("\n")
f.write("min_training_period:12")
f.write("\n")
f.write("horizon_period:60")
f.write("\n")
f.write("time_frequency:Monthly")
f.write("\n")
f.write("batch_size:1000")
f.write("\n")
f.write("minimum_quantity:1")
f.write("\n")
f.close()