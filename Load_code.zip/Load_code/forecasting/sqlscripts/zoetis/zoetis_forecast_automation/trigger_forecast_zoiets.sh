#trigger_forecast_zoiets.sh
echo "Connect forecast01 server...."
# copy sales
cp /efs/datascience/ZoetisE8C/data/input/zoetis_sales_history_apo.csv.gz /home/fusionops/zoiets_forecast/datascience/forecasting/data/zoiets/
echo "copy saleshistory file to server...."
# create forecast_ini
cd /home/fusionops/zoiets_forecast/
python ./create_forecast_ini_zoiets.py
echo "Forecast.ini file created...."

cd /home/fusionops/zoiets_forecast/datascience/forecasting/
echo "Forecast Tribggered...."
python ./main.py 1> zoiets_forecast.log 2>zoiets_forecast.err
echo "Forecast Completed...."
cd /home/fusionops/zoiets_forecast/datascience/forecasting/result/
chmod 777 -R zoiets
cd /home/fusionops/zoiets_forecast/datascience/forecasting/result/zoiets/
gzip zoiets_forecast_auto_3MHO.csv

cp zoiets_forecast_auto_3MHO.csv.gz /efs/datascience/ZoetisE8C/data/output/
echo "Forecast post-Prrocess is completed ...."
# post-process forecast result
