Zoetis Forecast Automation
Triggered Forecast
Process Name : ZOITES MONTHLY REGULAR FORECAST
Process Id : D2EBC092_F8A9_41C9_A9A7_59F23114852A

Populate Forecast Result
Process Name : ZOITES_POPULATION_FORECAST_V1
Process Id : EA3AD7DE_C63B_49EC_85AE_B0B89622E461

Sever IP :10.105.5.56

Forecast Result Path
/efs/datascience/ZoetisE8C/data/output

Path Forecast Scripts
/home/fusionops/zoiets_forecast/

Script Names
1.	Sales Extraction script 
/efs/datascience/ZoetisE8C/scripts/Exasol/forecasting/exa_extract_saleshistoryforfcst_zoetis_v1.sql

2.	permission_files.sh
/efs/datascience/ZoetisE8C/scripts/Exasol/forecasting/permission_files.sh

3.	connect_prod_forecast01_zoiets.sh
efs/datascience/ZoetisE8C/scripts/Exasol/forecasting/connect_prod_forecast01_zoiets.sh

4.	trigger_forecast_zoiets.sh
      /home/fusionops/zoiets_forecast/trigger_forecast_zoiets.sh
1.	create_forecast_ini_zoiets.py
/home/fusionops/zoiets_forecast/create_forecast_ini_zoiets.py
2.	main.py
/home/fusionops/zoiets_forecast/datascience/forecasting

5.	forecast result Population script
efs/datascience/ZoetisE8C/scripts/Exasol/forecasting/populate_test_forecast_result.sql

