EXPORT (
SELECT 
substr(dd_combined_productbusareasalesorg,15,4) 'SALESORG',
substr(dd_combined_productbusareasalesorg,10,4) 'BUS_AREA',
substr(dd_combined_productbusareasalesorg,1,8) '/BIC/Z9AMATNR',
'0'||substr(dd_forecastdate,5,2) ||substr(dd_forecastdate,1,4) 'FISCPER',
ROUND(ct_forecastquantity,0) '/BIC/ZGDPKF_56',
round(case when ct_lowpi < 0 then 0 else ct_lowpi end,0) '/BIC/ZGDPKF_26',
round(case when ct_highpi < 0 then 0 else ct_highpi end,0) '/BIC/ZGDPKF_30',
round(100 * ct_mape,0) '/BIC/ZGDPKF_14',
'GPU' 'Unit'
FROM fact_fosalesforecast
WHERE to_date(dd_reportingdate,'DD MON YYYY') = (SELECT MAX(to_date(dd_reportingdate,'DD MON YYYY')) FROM fact_fosalesforecast)
AND dd_forecastrank = 1
AND to_date(left(dd_forecastdate,6),'YYYYMM') >= current_date() - INTERVAL '1' YEAR
ORDER BY dd_combined_productbusareasalesorg,dd_forecastdate
)
INTO LOCAL CSV FILE '/mnt/sftp/zoetis/upload/Aera_forecast.csv.gz'
COLUMN SEPARATOR = ','
WITH COLUMN NAMES
REPLACE