/* ZOETISE data populate query*/
/* */

DROP TABLE IF EXISTS stage_fosalesforecast;
CREATE TABLE stage_fosalesforecast (
dd_reportingdate varchar(50)  NOT NULL ,
dd_forecastdate int,
dim_partid varchar(200),/* Combined forecast grain */
dd_level2 varchar(10) default 'Not Set',
ct_salesquantity DECIMAL(36,6),
ct_forecastquantity DECIMAL(36,6),
ct_lowpi DECIMAL(36,6),
ct_highpi DECIMAL(36,6),
ct_mape DECIMAL(36,6),
dd_lastdate varchar(30),
dd_holdoutdate varchar(30),
dd_forecastsample varchar(50),
dd_forecasttype varchar(100),
dd_forecastrank int,
dd_forecastmode varchar(20) default 'Not Set',
dd_companycode varchar(20) default 'Not Set',
dd_bias_error_rank DECIMAL(36,6),
dd_bias_error DECIMAL(36,6),
/* Additional columns */
dd_productapo varchar(20),
dd_businessareaapo varchar(20),
dd_salesorg varchar(20),
dd_forecastdatevalue date default '1900-01-01',
ct_forecastquantity_fullhistory decimal(36,6),
ct_ape_currentmonth decimal(36,6),
ct_ape_currentmonth_fullhistfcst decimal(36,6),
ct_actualsales_last1year_fromrptdate decimal(18,2),
ct_forecast_next1year_fromrptdate decimal(18,2)
);

/* Import reg */
IMPORT INTO stage_fosalesforecast 
(
dd_reportingdate,dd_forecastdate,dim_partid,dd_level2,ct_salesquantity,ct_forecastquantity,ct_lowpi,ct_highpi,ct_mape,dd_lastdate,dd_holdoutdate,dd_forecastsample,dd_forecasttype,dd_forecastrank,dd_forecastmode,dd_companycode,dd_bias_error_rank,dd_bias_error
)
FROM LOCAL CSV FILE '/home/lkamani/zoetis/forecastoutput/reg_aerafcst.csv.gz' 
COLUMN SEPARATOR = ',' SKIP = 1 ;


/* Import fh */
IMPORT INTO stage_fosalesforecast_fullhist 
(
dd_reportingdate,dd_forecastdate,dim_partid,dd_level2,ct_salesquantity,ct_forecastquantity,ct_lowpi,ct_highpi,ct_mape,dd_lastdate,dd_holdoutdate,dd_forecastsample,dd_forecasttype,dd_forecastrank,dd_forecastmode,dd_companycode,dd_bias_error_rank,dd_bias_error
)
FROM LOCAL CSV FILE '/home/lkamani/zoetis/forecastoutput/rfh_aerafcst.csv.gz' 
COLUMN SEPARATOR = ',' SKIP = 1 ;

/* Update full history forecast qty in a separate column */
UPDATE stage_fosalesforecast s
SET s.ct_forecastquantity_fullhistory = f.ct_forecastquantity
FROM stage_fosalesforecast s,stage_fosalesforecast_fullhist f
WHERE s.dd_reportingdate = f.dd_reportingdate
AND s.dd_forecastdate = f.dd_forecastdate
AND s.dim_partid = f.dim_partid
AND s.dd_level2 = f.dd_level2
AND s.dd_forecasttype = f.dd_forecasttype;

DROP TABLE stage_fosalesforecast_fullhist;

UPDATE stage_fosalesforecast
SET dd_productapo = substr(dim_partid,1,8),
dd_partnumber = substr(dim_partid,1,8);

UPDATE stage_fosalesforecast
SET dd_businessareaapo = substr(dim_partid,10,4),
dd_plantcode = substr(dim_partid,10,4);

UPDATE stage_fosalesforecast
SET dd_salesorg = substr(dim_partid,15,4);

/* Update actual sales and additional columns */


UPDATE stage_fosalesforecast
SET ct_ape_currentmonth = abs(ct_salesquantity-ct_forecastquantity)/ct_salesquantity,
ct_ape_currentmonth_fullhistfcst = abs(ct_salesquantity-ct_forecastquantity_fullhistory)//ct_salesquantity
WHERE ct_salesquantity > 1;

UPDATE stage_fosalesforecast
SET ct_ape_currentmonth = 100,
ct_ape_currentmonth_fullhistfcst = 100
WHERE ct_salesquantity <= 1;

/* Rerank according to special logic */
DROP TABLE IF EXISTS tmp_stage_fosalesforecast_rerank;
CREATE TABLE tmp_stage_fosalesforecast_rerank
AS
SELECT dd_productapo,dd_businessareaapo,dd_salesorg,dim_partid,dd_forecasttype,
avg(abs(ct_salesquantity-ct_forecastquantity)/ct_salesquantity) ct_mape_recalc,
rank() over(partition by dd_productapo,dd_businessareaapo,dd_salesorg,dim_partid ORDER BY avg(abs(ct_salesquantity-ct_forecastquantity)/ct_salesquantity),dd_forecasttype ) dd_forecastrank_new
FROM stage_fosalesforecast
WHERE dd_forecastsample = 'Test'
AND ct_salesquantity > 1
GROUP BY dd_productapo,dd_businessareaapo,dd_salesorg,dim_partid,dd_forecasttype;

UPDATE stage_fosalesforecast s
SET s.dd_forecastrank = t.dd_forecastrank_new
FROM stage_fosalesforecast s,tmp_stage_fosalesforecast_rerank t
WHERE s.dim_partid = t.dim_partid
AND s.dd_forecasttype = t.dd_forecasttype;

DROP TABLE IF EXISTS stage_fosalesforecast_fullhist;
CREATE TABLE stage_fosalesforecast_fullhist
AS
SELECT * FROM stage_fosalesforecast WHERE 1=2;

UPDATE stage_fosalesforecast
SET dd_reportingdate = '01 JAN 2018';

DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate,
dd_reportingdate dd_reportingdate_char
from stage_fosalesforecast ;

/* Delete forecast for given snapshot date, if it already exists */
DELETE FROM fact_fosalesforecast f
WHERE TO_DATE(dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from tmp_maxrptdate);

insert into fact_fosalesforecast
(
fact_fosalesforecastid, dim_partid, dim_plantid,
dd_productapo, dd_businessareaapo, dd_salesorg,
dd_companycode, dd_forecastdate, dd_reportingdate,
ct_salesquantity, ct_forecastquantity, ct_forecastquantity_fullhistory,
ct_lowpi, ct_highpi, ct_mape,
dd_lastdate, dd_holdoutdate, dd_forecastmode,
ct_bias_error_rank, ct_bias_error, dd_forecasttype,
dim_dateidreporting, dim_dateidforecast, dd_forecastdatevalue,
dd_partnumber, DD_FORECASTSAMPLE, DD_FORECASTRANK 
)
select  (select ifnull(max(fact_fosalesforecastid), 0) from fact_fosalesforecast m)
+ row_number() over(order by dd_partnumber,dd_companycode,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecastid,
ifnull((select min(dim_partid) from dim_part dp where trim(leading '0' from ifnull(dp.partnumber,0)) = sf.dd_partnumber),1) dim_partid,
1 AS dim_plantid,
dd_productapo, dd_businessareaapo, dd_salesorg,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
ifnull(sf.dd_forecastdate,1),
upper(sf.dd_reportingdate),
sf.ct_salesquantity, sf.ct_forecastquantity, sf.ct_forecastquantity_fullhistory,
sf.ct_lowpi, sf.ct_highpi, sf.ct_mape,
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
ct_bias_error_rank, ct_bias_error, ifnull(sf.dd_forecasttype,'Not Set') dd_forecasttype,
1 as dim_dateidreporting,
1 as dim_dateidforecast,
case when sf.dd_forecastdate is null then cast('1900-01-01' as date) else to_date(to_char(sf.dd_forecastdate),'YYYYMMDD') END AS dd_forecastdatevalue,
sf.dd_partnumber dd_partnumber, DD_FORECASTSAMPLE, DD_FORECASTRANK 
from stage_fosalesforecast sf;

UPDATE fact_fosalesforecast f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
fact_fosalesforecast_temp f
WHERE f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid
AND f.dd_reportingdate = '01 JAN 2018';

/* Update future sales to NULL */
/*
UPDATE fact_fosalesforecast f
SET ct_salesquantity = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE ct_salesquantity = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Horizon';
*/

/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE fact_fosalesforecast f
set ct_highpi = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE fact_fosalesforecast f
set ct_lowpi = NULL
FROM fact_fosalesforecast f,tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE fact_fosalesforecast f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE fact_fosalesforecast f
SET dd_latestreporting = 'Yes'
FROM fact_fosalesforecast f,tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate;

/* End of Update */
/* Global Part */

UPDATE fact_fosalesforecast f
SET f.dim_globalpartid = dp.dim_globalpartid
FROM dim_globalpart dp, fact_fosalesforecast f
WHERE f.dd_productapo = dp.PARTNUMBER_NOLEADZERO;















