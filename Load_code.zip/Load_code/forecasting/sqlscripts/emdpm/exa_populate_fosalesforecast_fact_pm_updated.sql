

/* Delete data from stage table and load from latest forecast file */
open schema emd586;

/* execute script unforecastparts imputation*/

DROP TABLE IF EXISTS stage_fosalesforecast_pm;
CREATE TABLE stage_fosalesforecast_pm (
		DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
		DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
		DD_PARTNUMBER       VARCHAR(40)  NOT NULL ,
		dd_businessunit     VARCHAR(40)  NOT NULL ,
		DD_LEVEL2           VARCHAR(40) ,
		CT_SALESQUANTITY    DECIMAL(36,6),
		CT_FORECASTQUANTITY DECIMAL(36,6),
		CT_LOWPI            DECIMAL(36,6),
		CT_HIGHPI           DECIMAL(36,6),
		CT_MAPE             DECIMAL(36,6),
		DD_LASTDATE         VARCHAR(50)  ,
		DD_HOLDOUTDATE      VARCHAR(50)  ,
		DD_FORECASTSAMPLE   VARCHAR(50)  ,
		DD_FORECASTTYPE     VARCHAR(50)  ,
		DD_FORECASTRANK     DECIMAL(18,0),
		DD_FORECASTMODE     VARCHAR(50)  ,
		DD_COMPANYCODE      VARCHAR(50)  ,
		CT_BIAS_ERROR_RANK  DECIMAL(18,6),
		CT_BIAS_ERROR       DECIMAL(18,6),
		DD_FORECASTEDFLAG VARCHAR(3) DEFAULT 'Yes',
		DD_FLAG_MIN_HISTORY VARCHAR(3) DEFAULT 'No',
		DD_FLAG_HOLDOUT VARCHAR(3) DEFAULT 'No',
		DD_FLAG_ALL_SALES_0 VARCHAR(3) DEFAULT 'No',
		DD_REASONFORFILTERINGOUT VARCHAR(40)
);
/*Output file split partnumber and dd_businessunit column 
run postprocess script /Users/priyankahole/learn/EMDPM/SQLSCRIPT/postprocess_emdpm.sh */

/* Import the FCST output to stage table */
IMPORT INTO stage_fosalesforecast_pm 
(
		DD_REPORTINGDATE,   
		DD_FORECASTDATE,    
		DD_PARTNUMBER,    
		DD_LEVEL2,           
		CT_SALESQUANTITY,   
		CT_FORECASTQUANTITY,
		CT_LOWPI,           
		CT_HIGHPI ,         
		CT_MAPE,            
		DD_LASTDATE,        
		DD_HOLDOUTDATE,     
		DD_FORECASTSAMPLE,  
		DD_FORECASTTYPE,    
		DD_FORECASTRANK,    
		DD_FORECASTMODE,    
		DD_COMPANYCODE,     
		CT_BIAS_ERROR_RANK, 
		CT_BIAS_ERROR,
		dd_businessunit
)
FROM LOCAL CSV FILE 'Path' 
COLUMN SEPARATOR = ',' SKIP = 1;


DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate,
dd_reportingdate dd_reportingdate_char
from stage_fosalesforecast_pm ;

DROP TABLE IF EXISTS tmp_maxrptdate1;
CREATE TABLE tmp_maxrptdate1
as
select to_char(max (TO_DATE(dd_reportingdate,'DD MON YYYY')), 'DD MON YYYY')dd_reportingdate
from  fact_fosalesforecast_pm;

DELETE FROM fact_fosalesforecast_pm f
WHERE TO_DATE(dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from tmp_maxrptdate) ;

ALTER TABLE stage_fosalesforecast_pm add column DD_FORECASTEDFLAG VARCHAR(3) ;

UPDATE stage_fosalesforecast_pm
set DD_FORECASTEDFLAG = 'Yes';

/* Insert data for unforecasted parts from table tmp_unforecastedparts to table stage_fosalesforecast_pm */
DELETE FROM stage_fosalesforecast_pm
WHERE DD_FORECASTEDFLAG = 'No';
---------------------------------------------------------------------------------------
insert into stage_fosalesforecast_pm
(
	DD_REPORTINGDATE ,
	DD_FORECASTDATE ,
	DD_PARTNUMBER ,
	DD_LEVEL2 ,
	CT_SALESQUANTITY ,
	CT_FORECASTQUANTITY ,
	CT_LOWPI ,
	CT_HIGHPI ,
	CT_MAPE ,
	DD_LASTDATE ,
	DD_HOLDOUTDATE ,
	DD_FORECASTSAMPLE ,
	DD_FORECASTTYPE ,
	DD_FORECASTRANK ,
	DD_FORECASTMODE ,
	DD_COMPANYCODE ,
	CT_BIAS_ERROR_RANK ,
	CT_BIAS_ERROR,
	DD_FORECASTEDFLAG,
	DD_FLAG_MIN_HISTORY,
	DD_FLAG_HOLDOUT,
	DD_FLAG_ALL_SALES_0,
	DD_REASONFORFILTERINGOUT,
	dd_businessunit
)
select 
	m.dd_reportingdate_char DD_REPORTINGDATE ,
	to_char((to_date((DD_CALMONTH||'01'),'YYYYMMDD') + interval '1' month - interval '1' day),'YYYYMMDD') DD_FORECASTDATE ,
	a.DD_PRODUCT ,
	a.DD_KEYCOUNTRY,
	a.CT_ORDERINTAKE ,
	NULL CT_FORECASTQUANTITY,
	NULL CT_LOWPI,
	NULL CT_HIGHPI,
	NULL CT_MAPE,
	NULL DD_LASTDATE,
	NULL DD_HOLDOUTDATE,
	NULL DD_FORECASTSAMPLE ,
	'None' DD_FORECASTTYPE ,
	1 DD_FORECASTRANK ,
	NULL DD_FORECASTMODE ,
	NULL DD_COMPANYCODE ,
	NULL CT_BIAS_ERROR_RANK ,
	NULL CT_BIAS_ERROR ,
	'No' DD_FORECASTEDFLAG,
	a.DD_FLAG_MIN_HISTORY,
	a.DD_FLAG_HOLDOUT,
	DD_FLAG_ALL_SALES_0,
	a.DD_REASONFORFILTERINGOUT,
	dd_businessunit
from tmp_unforecastedparts2 a,tmp_maxrptdate m ;
---------------------------------------------------------------------------------------
drop table if exists tmp_saleshistory_grain_reqmonths;
drop table if exists tmp_saleshistory_grain_reqmonths_2;

drop table if exists fact_fosalesforecast_temp;
create table fact_fosalesforecast_temp as
select * from fact_fosalesforecast_pm WHERE 1=2;

alter table fact_fosalesforecast_temp add column dd_forecastdatevalue date default '1900-01-01';
---------------------------------------------------------------------------------------
insert into fact_fosalesforecast_temp
(
		fact_fosalesforecast_pmid,
		dim_partid,
		dim_plantid,
		dd_companycode,
		dd_reportingdate,
		dim_dateidreporting,
		dd_forecasttype,
		dd_forecastsample,
		dd_forecastdate,
		dim_dateidforecast,
		ct_salesquantity,
		ct_forecastquantity,
		ct_lowpi,
		ct_highpi,
		ct_mape,
		dd_forecastrank,
		dd_holdoutdate,
		dd_lastdate,
		dd_forecastmode,
		dd_forecastdatevalue,
		ct_bias_error,
		ct_bias_error_rank,
		dd_dmdunit,
		dd_loc,
		dd_dmdgroup,
		dd_forecastedflag,
		DD_FLAG_MIN_HISTORY,
		DD_FLAG_HOLDOUT,
		DD_FLAG_ALL_SALES_0,
		DD_REASONFORFILTERINGOUT,
		dd_businessunit
)
select  (select ifnull(max(fact_fosalesforecast_pmid), 0) from fact_fosalesforecast_pm m)
+ row_number() over(order by dd_partnumber,dd_level2,dd_businessunit,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecast_pmid,
ifnull((select min(dim_mdg_partid) from dim_mdg_part dp where dp.partnumber = sf.dd_partnumber),1) dim_partid,
ifnull((select min(dim_plantid) from dim_plant pl where pl.plantcode = sf.dd_level2),1) dim_plantid,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
--TO_DATE(sf.dd_reportingdate,'DD MON YYYY') dd_reportingdate, --ifnull(cast(sf.dd_reportingdate as date),'1 Jan 1900'),
upper(sf.dd_reportingdate),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mape,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
case when sf.dd_forecastdate is null then cast('1900-01-01' as date)
else to_date(to_char(sf.dd_forecastdate),'YYYYMMDD') END 
dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
sf.dd_partnumber dd_dmdunit,
sf.dd_level2 dd_loc,
sf.dd_companycode dd_dmdgroup,
DD_FORECASTEDFLAG,
DD_FLAG_MIN_HISTORY,
DD_FLAG_HOLDOUT,
DD_FLAG_ALL_SALES_0,
DD_REASONFORFILTERINGOUT,
dd_businessunit
from stage_fosalesforecast_pm sf;

---------------------------------------------------------------------------------------

UPDATE fact_fosalesforecast_temp f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from dim_date d  where d.companycode ='Not Set' group by datevalue)d,
fact_fosalesforecast_temp f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

---------------------------------------------------------------------------------------

UPDATE fact_fosalesforecast_temp f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
fact_fosalesforecast_temp f
WHERE f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid;
---------------------------------------------------------------------------------------
insert into fact_fosalesforecast_pm
(
fact_fosalesforecast_pmid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup,
dd_forecastedflag,
DD_FLAG_MIN_HISTORY,
DD_FLAG_HOLDOUT,
DD_FLAG_ALL_SALES_0,
DD_REASONFORFILTERINGOUT,
dd_businessunit
)
select
fact_fosalesforecast_pmid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup,
dd_forecastedflag,
DD_FLAG_MIN_HISTORY,
DD_FLAG_HOLDOUT,
DD_FLAG_ALL_SALES_0,
DD_REASONFORFILTERINGOUT,
dd_businessunit
from fact_fosalesforecast_temp;

---------------------------------------------------------------------------------------

/* Update future sales to NULL */
UPDATE fact_fosalesforecast_pm f
SET ct_salesquantity = NULL
FROM fact_fosalesforecast_pm f,tmp_maxrptdate r
WHERE ct_salesquantity = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Horizon';

/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE fact_fosalesforecast_pm f
set ct_highpi = NULL
FROM fact_fosalesforecast_pm f,tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE fact_fosalesforecast_pm f
set ct_lowpi = NULL
FROM fact_fosalesforecast_pm f,tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';
---------------------------------------------------------------------------------------
/* Format reporting date as DD MON YYYY */
UPDATE fact_fosalesforecast_pm f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD MON YYYY')
where f.dd_reportingdate like '%-%-%';

/* Rerank for mult forecasts having same ranks */
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf;
CREATE TABLE tmp_upd_fcstrank_fosf
as
select distinct f.dd_reportingdate,dd_dmdunit,dd_loc,dd_businessunit,dd_forecasttype,dd_forecastrank
from fact_fosalesforecast_pm f,tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;

--This should insert 0 rows as for same fcst type, there cannot be different ranks
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dd_dmdunit = t2.dd_dmdunit
and t1.dd_loc = t2.dd_loc
and t1.dd_businessunit = t2.dd_businessunit
and t1.dd_forecasttype = t2.dd_forecasttype
and t1.dd_forecastrank <> t2.dd_forecastrank;

--These are the cases with issues ( different methods, same rank )
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dd_dmdunit = t2.dd_dmdunit
and t1.dd_loc = t2.dd_loc
and t1.dd_businessunit = t2.dd_businessunit
and t1.dd_forecasttype <> t2.dd_forecasttype
and t1.dd_forecastrank = t2.dd_forecastrank;

---------------------------------------------------------------------------------------

--Get all rows corresponding to these rptdate,dmdunit,loc
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf3;
CREATE TABLE tmp_upd_fcstrank_fosf3
as
select t1.*,rank() over(partition by dd_reportingdate,dd_dmdunit,dd_loc,dd_businessunit  order by dd_forecastrank,dd_forecasttype) dd_rank_new
from tmp_upd_fcstrank_fosf t1
WHERE EXISTS ( SELECT 1 FROM tmp_upd_fcstrank_fosf2 t2
    where t1.dd_reportingdate = t2.dd_reportingdate
    and t1.dd_dmdunit = t2.dd_dmdunit
    and t1.dd_loc = t2.dd_loc
    and t1.dd_businessunit = t2.dd_businessunit);

UPDATE fact_fosalesforecast_pm f
SET f.dd_forecastrank = t.dd_rank_new
FROM fact_fosalesforecast_pm f,tmp_upd_fcstrank_fosf3 t
where f.dd_reportingdate = t.dd_reportingdate
and f.dd_dmdunit = t.dd_dmdunit
and f.dd_loc = t.dd_loc
and f.dd_businessunit = t.dd_businessunit
and f.dd_forecastrank = t.dd_forecastrank
and f.dd_forecasttype = t.dd_forecasttype;
---------------------------------------------------------------------------------------
UPDATE fact_fosalesforecast_pm f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE fact_fosalesforecast_pm f
SET dd_latestreporting = 'Yes'
FROM fact_fosalesforecast_pm f,tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;
---------------------------------------------------------------------------------------
DROP TABLE IF EXISTS tmp_upd_ct_next12monthsfopsfcst;
CREATE TABLE tmp_upd_ct_next12monthsfopsfcst
as
select f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.dd_businessunit,f.dd_forecasttype,
d.datevalue dd_forecastdate,d.datevalue + interval '11' month dd_forecastdate_plus11,
sum(f1.ct_forecastquantity) ct_next12monthsfopsfcst
FROM fact_fosalesforecast_pm f inner join fact_fosalesforecast_pm f1
ON f.dd_reportingdate = f1.dd_reportingdate AND f.dd_dmdunit = f1.dd_dmdunit AND f.dd_loc = f1.dd_loc
AND f.dd_businessunit =f1.dd_businessunit AND f.dd_forecasttype = f1.dd_forecasttype
INNER JOIN dim_date d on d.dim_dateid = f.dim_dateidforecast
INNER JOIN dim_date d1 on d1.dim_dateid = f1.dim_dateidforecast
WHERE d1.datevalue >= d.datevalue
AND d1.datevalue <= d.datevalue + interval '11' month
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
GROUP BY f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.dd_businessunit,f.dd_forecasttype,d.datevalue,d.datevalue + interval '11' month;

UPDATE fact_fosalesforecast_pm f
SET f.ct_next12monthsfopsfcst = f1.ct_next12monthsfopsfcst
FROM fact_fosalesforecast_pm f inner join dim_date d ON d.dim_dateid = f.dim_dateidforecast
inner join tmp_upd_ct_next12monthsfopsfcst f1
ON f.dd_reportingdate = f1.dd_reportingdate AND f.dd_dmdunit = f1.dd_dmdunit AND f.dd_loc = f1.dd_loc
AND f.dd_businessunit = f1.dd_businessunit AND f.dd_forecasttype = f1.dd_forecasttype
WHERE f1.dd_forecastdate = d.datevalue;
---------------------------------------------------------------------------------------

/* Prices for last 3 months before the current month */
DROP TABLE IF EXISTS emd586.tmp_upd_cogs_emd_latestdate;
CREATE TABLE emd586.tmp_upd_cogs_emd_latestdate
AS
SELECT dp.partnumber,rank() over( partition by dp.partnumber order by d.datevalue desc) sr_no,
(amt_cogsfixedplanrate_emd ) amt_cogsfixedplanrate_emd_gbl,
amt_cogsactualrate_emd,
(amt_StdUnitPrice * amt_exchangerate_gbl ) amt_StdUnitPrice_gbl
FROM emd586.fact_inventoryhistory fih inner join emd586.dim_mdg_part dp on dp.dim_mdg_partid = fih.dim_mdg_partid
INNER JOIN emd586.dim_date d on d.dim_dateid = fih.dim_dateidsnapshot AND d.datevalue >= last_day(current_date) - interval '3' month
AND (amt_cogsfixedplanrate_emd > 0 or amt_cogsactualrate_emd > 0 or amt_StdUnitPrice * amt_exchangerate_gbl > 0);
--WHERE d.datevalue >= current_date - interval '1' year;
---------------------------------------------------------------------------------------
DROP TABLE IF EXISTS emd586.tmp_upd_cogs_emd_latestdate_avg;
CREATE TABLE emd586.tmp_upd_cogs_emd_latestdate_avg
AS
SELECT partnumber,avg(amt_cogsfixedplanrate_emd_gbl) amt_cogsfixedplanrate_emd_gbl,
avg(amt_cogsactualrate_emd) amt_cogsactualrate_emd_gbl,
avg(amt_StdUnitPrice_gbl) amt_StdUnitPrice_gbl
from emd586.tmp_upd_cogs_emd_latestdate
WHERE sr_no = 1
group by partnumber;

UPDATE emd586.tmp_upd_cogs_emd_latestdate_avg
SET amt_cogsfixedplanrate_emd_gbl  = amt_cogsactualrate_emd_gbl
WHERE amt_cogsfixedplanrate_emd_gbl is null or amt_cogsfixedplanrate_emd_gbl <= 0;

UPDATE emd586.tmp_upd_cogs_emd_latestdate_avg
SET amt_cogsfixedplanrate_emd_gbl  = amt_StdUnitPrice_gbl
WHERE amt_cogsfixedplanrate_emd_gbl is null or amt_cogsfixedplanrate_emd_gbl <= 0;

UPDATE fact_fosalesforecast_pm f
SET f.amt_cogsrate_or_stdunitprice_gbl = t.amt_cogsfixedplanrate_emd_gbl
FROM fact_fosalesforecast_pm f,emd586.tmp_upd_cogs_emd_latestdate_avg t
WHERE f.dd_dmdunit = t.partnumber;
---------------------------------------------------------------------------------------


DROP TABLE IF EXISTS tmp_amt_sellingpriceperunit_gbl;
CREATE TABLE tmp_amt_sellingpriceperunit_gbl
AS
SELECT dp.partnumber,avg(fso.amt_UnitPrice * amt_exchangerate_gbl) amt_sellingpriceperunit_gbl_oldmethod,
avg(amt_exchangerate_gbl * amt_UnitPriceUoM/(CASE WHEN fso.ct_PriceUnit <> 0 THEN fso.ct_PriceUnit ELSE 1 END)) amt_sellingpriceperunit_gbl
FROM fact_salesorder fso inner join dim_mdg_part dp on dp.dim_mdg_partid = fso.dim_mdg_partid
INNER JOIN dim_date d on d.dim_dateid = fso.dim_dateidsocreated
left outer join dim_currency tra on tra.dim_currencyid = fso.dim_currencyid_tra
left outer join dim_currency lcl on lcl.dim_currencyid = fso.dim_currencyid
left outer join dim_currency gbl on tra.dim_currencyid = fso.dim_currencyid_gbl
WHERE d.datevalue >= current_date - interval '1' year
AND ct_ScheduleQtySalesUnit > 0
group by dp.partnumber;

UPDATE fact_fosalesforecast_pm f
SET f.amt_sellingpriceperunit_gbl = t.amt_sellingpriceperunit_gbl
FROM fact_fosalesforecast_pm f,tmp_amt_sellingpriceperunit_gbl t
WHERE f.dd_dmdunit = t.partnumber;
---------------------------------------------------------------------------------------


DROP TABLE IF EXISTS tmp_total_margin_salesytd;
CREATE TABLE tmp_total_margin_salesytd
AS
SELECT dd_reportingdate,
sum(AMT_SELLINGPRICEPERUNIT_GBL * ct_salesquantity) revenue_totalsales,
sum(amt_cogsrate_or_stdunitprice_gbl * ct_salesquantity) cogs_totalsales,
sum(AMT_SELLINGPRICEPERUNIT_GBL * (ct_salesquantity + ct_forecastquantity)) revenue_totalsales_plus_fcst,
sum(amt_cogsrate_or_stdunitprice_gbl * (ct_salesquantity + ct_forecastquantity)) cogs_totalsales_plus_fcst,
sum(AMT_SELLINGPRICEPERUNIT_GBL * (ct_salesquantity + CT_STSC_MARKETFCST_BASEPLUSNONBASEMINUSTARGETIMPACT)) revenue_totalsales_plus_jdafcst,
sum(amt_cogsrate_or_stdunitprice_gbl * (ct_salesquantity + CT_STSC_MARKETFCST_BASEPLUSNONBASEMINUSTARGETIMPACT)) cogs_totalsales_plus_jdafcst
FROM fact_fosalesforecast_pm f inner join dim_date d on d.dim_dateid = f.dim_dateidforecast
WHERE AMT_SELLINGPRICEPERUNIT_GBL > 0
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
AND amt_cogsrate_or_stdunitprice_gbl > 0
AND year(d.datevalue) >= year(current_date)
GROUP BY dd_reportingdate;

UPDATE fact_fosalesforecast_pm f
SET f.ct_marginpercent_salesytd = 100 * (t.revenue_totalsales - t.cogs_totalsales)/t.revenue_totalsales,
f.ct_marginpercent_salesplusfcst_currentyear = 100 * (t.revenue_totalsales_plus_fcst-t.cogs_totalsales_plus_fcst)/t.revenue_totalsales_plus_fcst,
f.ct_marginpercent_salesplusjdafcst_currentyear = 100 * (t.revenue_totalsales_plus_jdafcst-t.cogs_totalsales_plus_jdafcst)/t.revenue_totalsales_plus_jdafcst
FROM fact_fosalesforecast_pm f,tmp_total_margin_salesytd t
WHERE f.dd_reportingdate = t.dd_reportingdate;
---------------------------------------------------------------------------------------


DROP TABLE IF EXISTS tmp_first3horizonmonths;
CREATE TABLE tmp_first3horizonmonths
AS
SELECT distinct dd_reportingdate,fcstdate
from
(
SELECT dd_reportingdate,fcstdate,rank() over(partition by dd_reportingdate order by fcstdate) dd_rank
FROM ( SELECT DISTINCT dd_reportingdate,to_date(to_char(dd_forecastdate),'YYYYMMDD') fcstdate
from fact_fosalesforecast_pm f where dd_forecastsample = 'Horizon'))
WHERE dd_rank in (1,2,3)
AND to_date(dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r);


DROP TABLE IF EXISTS tmp_fcst_mad;
CREATE TABLE tmp_fcst_mad
AS
SELECT f.dd_reportingdate,dd_dmdunit,dd_loc,dd_businessunit,dd_forecasttype,abs(sum(ct_salesquantity-ct_forecastquantity)) ct_mad_testperiod
FROM fact_fosalesforecast_pm f,(SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)t,tmp_first3horizonmonths t1
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = t.dd_reportingdate
AND f.dd_reportingdate = t1.dd_reportingdate
AND to_date(to_char(f.dd_forecastdate),'YYYYMMDD') = t1.fcstdate
GROUP BY dd_dmdunit,dd_loc,dd_businessunit,dd_forecasttype,f.dd_reportingdate;

UPDATE fact_fosalesforecast_pm f
SET f.ct_mad_testperiod = t.ct_mad_testperiod
FROM fact_fosalesforecast_pm f,tmp_fcst_mad t
WHERE f.dd_dmdunit = t.dd_dmdunit AND f.dd_loc = t.dd_loc 
and f.dd_businessunit = t.dd_businessunit and f.dd_forecasttype = t.dd_forecasttype
AND f.dd_reportingdate = t.dd_reportingdate;

---------------------------------------------------------------------------------------

DROP TABLE IF EXISTS tmp_fcst_ape;
CREATE TABLE tmp_fcst_ape
AS
SELECT f.dd_reportingdate,dd_dmdunit,dd_loc,dd_businessunit,abs(sum(ct_salesquantity-ct_forecastquantity)/sum(ct_salesquantity)) ct_ape_testperiod,
dd_forecasttype
FROM fact_fosalesforecast_pm f,(SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)t,tmp_first3horizonmonths t1
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = t.dd_reportingdate
AND f.dd_reportingdate = t1.dd_reportingdate
AND to_date(to_char(f.dd_forecastdate),'YYYYMMDD') = t1.fcstdate
GROUP BY dd_dmdunit,dd_loc,dd_businessunit,dd_forecasttype,f.dd_reportingdate;

UPDATE fact_fosalesforecast_pm f
SET f.ct_ape_testperiod = t.ct_ape_testperiod * 100
FROM fact_fosalesforecast_pm f,tmp_fcst_ape t
WHERE f.dd_dmdunit = t.dd_dmdunit AND f.dd_loc = t.dd_loc 
AND f.dd_businessunit = t.dd_businessunit AND f.dd_reportingdate = t.dd_reportingdate
AND f.dd_forecasttype = t.dd_forecasttype;
---------------------------------------------------------------------------------------
/* Update column CT_CONSENSUSPLAN */
DROP TABLE IF EXISTS tmp_upd_producthierarchy;
CREATE TABLE tmp_upd_producthierarchy
( producthierarchy varchar(18));

insert into tmp_upd_producthierarchy
values ('LSP'),('LCS'),('LCR'),('LPM'),('YXA'),('YXD'),('YXE'),('YXH'),('YXJ'),('ZWH'),('ZWJ');

DROP TABLE IF EXISTS tmp_upd_fosfpm_consensusplan;
CREATE TABLE tmp_upd_fosfpm_consensusplan
as
select f.dd_product, f.dd_keycountry,f.dd_businessunit, f.dd_calmonth, sum(ct_consensusplan) ct_consensusplan
from fact_apoforecastanalytics f, dim_mdg_part dp
where f.DD_CURRENTSNAPHOTDATE =  'Yes'
and dp.dim_mdg_partid = f.dim_mdg_partid
and dp.aporelevance in ('1','2','4')
and substr(dp.producthierarchy,1,3) not in (select producthierarchy from tmp_upd_producthierarchy)
group by  dd_product, dd_keycountry,dd_businessunit, dd_calmonth;

update fact_fosalesforecast_pm f
set f.ct_consensusplan = t.ct_consensusplan
from tmp_upd_fosfpm_consensusplan t, fact_fosalesforecast_pm f
where f.dd_dmdunit = t.dd_product
and f.dd_loc = t.dd_keycountry
and f.dd_businessunit = t.dd_businessunit
and substr(f.dd_forecastdate,1,6) = t.dd_calmonth
and dd_latestreporting = 'Yes';
---------------------------------------------------------------------------------------
/* Update unforecast part */

/*update 3M_AVG FORECAST_METHOD_FLAG */
update  fact_fosalesforecast_pm 
set dd_FORECAST_METHOD_FLAG = '3M AVG'
from fact_fosalesforecast_pm
where dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r) and --change latest reporting date
DD_FORECASTTYPE = 'None' and DD_FORECASTEDFLAG ='No';

update  fact_fosalesforecast_pm 
set dd_FORECAST_METHOD_FLAG ='MACHINE LEARNING'
from fact_fosalesforecast_pm
where dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r) and --change latest reporting date
DD_FORECASTEDFLAG ='Yes';
---------------------------------------------------------------------------------------
/* Calculate 3MMA for unforecast part*/
Drop table if EXISTS tmp_3mma_unforecast_sales;
create table tmp_3mma_unforecast_sales
as
select distinct dd_dmdunit, dd_loc ,dd_businessunit, dd_forecastdate, QUANTITY
from 
(select tmp.dd_dmdunit, tmp.dd_loc,tmp.dd_businessunit, tmp.dd_forecastdate, SUM(ct_salesquantity) as QUANTITY
from fact_fosalesforecast_pm tmp
where DD_FORECASTTYPE = 'None' and DD_FORECASTEDFLAG ='No'and
dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r) 
and dd_FORECAST_METHOD_FLAG = '3M AVG'
group by tmp.dd_dmdunit, tmp.dd_loc ,tmp.dd_businessunit, tmp.dd_forecastdate
order by tmp.dd_dmdunit, tmp.dd_loc,tmp.dd_businessunit, tmp.dd_forecastdate
)upd
order by dd_dmdunit, dd_loc ,dd_businessunit, dd_forecastdate;

DROP TABLE IF EXISTS tmp_3mma_unforecast;
create table tmp_3mma_unforecast
as
select distinct dd_dmdunit, dd_loc ,dd_businessunit, dd_forecastdate, QUANTITY,
	(lag(QUANTITY,1)  over (partition by dd_dmdunit,dd_loc,dd_businessunit order by dd_dmdunit,dd_loc,dd_businessunit,dd_forecastdate )+
	lag(QUANTITY,2) over (partition by dd_dmdunit,dd_loc,dd_businessunit order by dd_dmdunit,dd_loc,dd_businessunit,dd_forecastdate)+QUANTITY)/3 as ct_3MMA_unforecast
from --fact_fosalesforecast_pm t1 ,
(select tmp.dd_dmdunit, tmp.dd_loc,tmp.dd_businessunit, tmp.dd_forecastdate, SUM(ct_salesquantity) as QUANTITY
from fact_fosalesforecast_pm tmp
where DD_FORECASTTYPE = 'None' and DD_FORECASTEDFLAG ='No'and 
dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r) 
and dd_FORECAST_METHOD_FLAG = '3M AVG'
group by tmp.dd_dmdunit, tmp.dd_loc ,tmp.dd_businessunit, tmp.dd_forecastdate
order by tmp.dd_dmdunit, tmp.dd_loc,tmp.dd_businessunit, tmp.dd_forecastdate
)upd
order by dd_dmdunit, dd_loc ,dd_businessunit, dd_forecastdate;

update fact_fosalesforecast_pm 
set ct_3mma_unforcatedparts = cast(ct_3MMA_unforecast as decimal(36,4))
from fact_fosalesforecast_pm t1 inner join tmp_3mma_unforecast t2
on t1.dd_dmdunit = t2.dd_dmdunit 
and t1.dd_loc = t2.dd_loc 
and t1.dd_businessunit =t2.dd_businessunit
and t1.dd_forecastdate = t2.dd_forecastdate 
where t1.DD_FORECASTTYPE = 'None' 
and t1.DD_FORECASTEDFLAG ='No'
and t1.dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r) ;
---------------------------------------------------------------------------------------

drop table if exists tmp_horizon3mma;
create table tmp_horizon3mma
as
select  dd_dmdunit, dd_loc,dd_businessunit,ct_3mma_unforcatedparts,dd_forecastdate from fact_fosalesforecast_pm
where dd_forecastdate = (select max(dd_forecastdate)from fact_fosalesforecast_pm where dd_forecastsample = 'Test'
and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r))
and DD_FORECASTEDFLAG ='Yes' and dd_FORECAST_METHOD_FLAG ='MACHINE LEARNING'
)
and DD_FORECASTTYPE = 'None' and DD_FORECASTEDFLAG ='No'
and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r)
order by dd_dmdunit, dd_loc,dd_businessunit,dd_forecastdate ;

---------------------------------------------------------------------------------------

/* Update 3mma in horizon */
update fact_fosalesforecast_pm t2
set t2.ct_3mma_unforcatedparts = t.ct_3mma_unforcatedparts
--select t2.dd_reportingdate,t2.dd_dmdunit, t2.dd_loc, t2.dd_businessunit,t2.ct_3mma_unforcatedparts , t.ct_3mma_unforcatedparts
from fact_fosalesforecast_pm t2,tmp_horizon3mma_apr2018 t
where t.dd_dmdunit = t2.dd_dmdunit AND t.dd_loc = t2.dd_loc AND t.dd_businessunit = t2.dd_businessunit
and t2.dd_forecastdate > (SELECT max(dd_forecastdate)from fact_fosalesforecast_pm where DD_FORECASTSAMPLE = 'Test'
 and DD_FORECASTEDFLAG ='Yes' and dd_FORECAST_METHOD_FLAG ='MACHINE LEARNING'
 and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r))
and t2.dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r)
and t2.DD_FORECASTEDFLAG ='No';

---------------------------------------------------------------------------------------

/* Update BASE UNIT OF MEASURE */

update fact_fosalesforecast_pm
set t2.DD_BASEUOM_BASEDONBU = (select distinct DD_BASEUNITOFMEASURE from fact_APOForecastAnalytics
where DD_PRODFROMPREVSNAPSHOT = 'N'AND (lower(DD_CURRENTSNAPHOTDATE) = lower('Yes')) )
from fact_fosalesforecast_pm where 
dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r);--'15 MAR 2018'

-------------------------------------------------------------------------------------

/* Update Forecast sample 3MMA*/
drop table if exists tmp_forecastsample
create table tmp_forecastsample
as
select distinct dd_forecastdate,dd_forecastsample FROM fact_fosalesforecast_pm f 
where dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r ) 
and dd_FORECAST_METHOD_FLAG = 'MACHINE LEARNING'
order by 1;

update fact_fosalesforecast_pm
set f.dd_forecastsample = t.tmp_forecastsample
FROM fact_fosalesforecast_pm f,tmp_forecastsample t where f.dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r ) 
and dd_FORECAST_METHOD_FLAG = '3M AVG'and DD_FORECASTTYPE = 'None' and DD_FORECASTEDFLAG ='No'
and f.dd_forecastdate = t.dd_forecastdate
---------------------------------------------------------------------------------------
/* Update Last Date 3MMA */
update fact_fosalesforecast_pm
set t2.DD_LASTDATE = (select distinct DD_LASTDATE from fact_fosalesforecast_pm 
  where DD_FORECASTEDFLAG ='Yes'
  and dd_FORECAST_METHOD_FLAG = 'MACHINE LEARNING' 
  and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r)
 )
from fact_fosalesforecast_pm t2
where t2.dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r)
and DD_FORECASTTYPE = 'None' and DD_FORECASTEDFLAG ='No';

/*Update Holdout Date 3MMA*/
update fact_fosalesforecast_pm
set t2.DD_HOLDOUTDATE = (select distinct DD_HOLDOUTDATE from fact_fosalesforecast_pm 
where DD_FORECASTEDFLAG ='Yes'
and dd_FORECAST_METHOD_FLAG = 'MACHINE LEARNING' 
and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r)
)
from fact_fosalesforecast_pm t2
where t2.dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r)
and DD_FORECASTTYPE = 'None' and DD_FORECASTEDFLAG ='No';


/*Calculate  Volatility(  volatilitysegments )*/
drop table if exists tmp_upd_ct_volatility_percent;
CREATE TABLE tmp_upd_ct_volatility_percent
AS
SELECT dd_dmdunit,dd_loc,dd_businessunit,sum(CASE WHEN dd_forecastsample in ('Train','Test') THEN (ct_salesquantity) ELSE (ct_forecastquantity) END) ct_salesquantity,
d.monthyear
from fact_fosalesforecast_pm f inner join dim_date d on d.dim_dateid = f.dim_dateidforecast
WHERE --dd_dmdunit = '1000971050' and dd_loc = 'KR' and dd_businessunit = 'PM3' and
dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r )
AND dd_forecastdate >to_number(to_char((current_date - interval '12' month),'YYYYMMDD')) 
and dd_forecastdate < to_number(to_char((current_date),'YYYYMMDD'))
GROUP BY dd_dmdunit,dd_loc,dd_businessunit,d.monthyear ;

DROP TABLE IF EXISTS tmp_upd_ct_volatility_percent_STDDEV;
CREATE TABLE tmp_upd_ct_volatility_percent_STDDEV
AS
SELECT dd_dmdunit,dd_loc,dd_businessunit,
stddev(ct_salesquantity) ct_salesquantity_sd,
avg(ct_salesquantity) ct_salesquantity_avg,
case when avg(ct_salesquantity) = 0 then  0 ELSE 100 * stddev(ct_salesquantity)/avg(ct_salesquantity) END ct_volatility_percent,
case when avg(ct_salesquantity) = 0 THEN 0 ELSE stddev(ct_salesquantity)/avg(ct_salesquantity)END  ct_cov,
case when avg(ct_salesquantity) = 0 THEN 'Exception' ELSE 'Good' END dd_flag
from tmp_upd_ct_volatility_percent
group by dd_dmdunit,dd_loc,dd_businessunit;

UPDATE fact_fosalesforecast_pm f
SET f.ct_volatility_percent = t.ct_volatility_percent
FROM fact_fosalesforecast_pm f, tmp_upd_ct_volatility_percent_STDDEV t
WHERE f.dd_dmdunit = t.dd_dmdunit and f.dd_loc = t.dd_loc and f.dd_businessunit = t.dd_businessunit
and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r );

UPDATE fact_fosalesforecast_pm f
SET f.ct_cov = t.ct_cov
FROM fact_fosalesforecast_pm f, tmp_upd_ct_volatility_percent_STDDEV t
WHERE f.dd_dmdunit = t.dd_dmdunit and f.dd_loc = t.dd_loc and f.dd_businessunit = t.dd_businessunit
and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r );

DROP TABLE IF EXISTS tmp_cov;
CREATE TABLE tmp_cov
AS
SELECT distinct dd_dmdunit,dd_loc,dd_businessunit,ct_volatility_percent,ct_cov
from fact_fosalesforecast_pm f
where dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r );

UPDATE fact_fosalesforecast_pm f
SET f.dd_volatilitysegments = 'Z'
FROM fact_fosalesforecast_pm f,tmp_cov r
WHERE f.dd_dmdunit = r.dd_dmdunit and f.dd_loc = r.dd_loc and f.dd_businessunit = r.dd_businessunit
AND r.ct_cov >= 0.67  and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r );

UPDATE fact_fosalesforecast_pm f
SET f.dd_volatilitysegments = 'Y'
FROM fact_fosalesforecast_pm f,
tmp_cov r 
WHERE f.dd_dmdunit = r.dd_dmdunit and f.dd_loc = r.dd_loc and f.dd_businessunit = r.dd_businessunit
AND (r.ct_cov >= 0.33 
AND r.ct_cov < 0.67 ) and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r );

UPDATE fact_fosalesforecast_pm f
SET f.dd_volatilitysegments = 'X'
FROM fact_fosalesforecast_pm f,
tmp_cov r 
WHERE f.dd_dmdunit = r.dd_dmdunit and f.dd_loc = r.dd_loc and f.dd_businessunit = r.dd_businessunit
AND r.ct_cov < 0.33  and dd_reportingdate = (SELECT DISTINCT upper(r.DD_REPORTINGDATE_CHAR) from emd586.tmp_maxrptdate r );

/* END UPDATE */
