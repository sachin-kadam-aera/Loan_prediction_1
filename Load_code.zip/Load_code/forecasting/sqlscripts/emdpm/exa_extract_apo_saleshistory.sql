/* 

Description :-Script to extract the data for EMD-PM for monthly forecast,developer has to run the forecast every month before 9th
Author :- Varun Sharma/Priyanka Hole
Date :- 11th April 2018
Version :- 1
*/

OPEN SCHEMA EMD586;
DROP TABLE IF EXISTS tmp_aposaleshist_export_forfopsfcst;
CREATE TABLE tmp_aposaleshist_export_forfopsfcst AS
SELECT   resultset.totalrows, 
         resultset.col_ord_0 dd_product, 
         resultset.col_ord_1 dd_keycountry, 
         resultset.col_ord_2 dd_businessunit, 
         resultset.col_ord_3 dd_calmonth, 
         resultset.col_ord_4 dd_BaseUnitofMeasure, 
         resultset.col_ord_5 CT_ORDERINTAKE 
FROM     ( 
                SELECT Max(x.rowseqno) OVER() totalrows, 
                       x.* 
                FROM   ( 
                              SELECT Count(*) OVER() rowseqno, 
                                     mfltr.* 
                              FROM   ( 
                                            SELECT rowcnt_0.* 
                                            FROM   ( 
                                                              SELECT     f_apofa.dd_product           Col_ord_0,
                                                                         f_apofa.dd_keycountry        Col_ord_1,
                                                                         f_apofa.dd_businessunit      Col_ord_2 ,
                                                                         f_apofa.dd_calmonth          Col_ord_3,
                                                                         f_apofa.dd_baseunitofmeasure Col_ord_4,
                                                                         Round(Sum(ct_orderintake),2) Col_ord_5
                                                              FROM       fact_apoforecastanalytics    AS f_apofa
                                                              INNER JOIN dim_mdg_part                 AS dpmdg
                                                              ON         f_apofa.dim_mdg_partid = dpmdg.dim_mdg_partid
                                                              INNER JOIN dim_bwproducthierarchyapo AS bwprh
                                                              ON         f_apofa.dim_bwproducthierarchyid = bwprh.dim_bwproducthierarchyapoid
                                                              WHERE      ( ( 
                                                                                               Lower(dpmdg.producthierarchy) NOT LIKE Lower('LSP%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('LCS%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('LCR%')
                                                                                    AND        Lower(dpmdg.producthierarchy ) NOT LIKE Lower('LPM%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('YXA%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('YXD%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('YXE%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('YXH%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('YXJ%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('ZWH%')
                                                                                    AND        Lower(dpmdg.producthierarchy) NOT LIKE Lower('ZWJ%')))
                                                              AND        ( 
                                                                                    Lower(dpmdg.aporelevance) IN (Lower('1'),
                                                                                                                  Lower('2'),
                                                                                                                  Lower('4')) )
                                                              AND        ( 
                                                                                    Lower(f_apofa.dd_currentsnaphotdate) = Lower('Yes'))
                                                              AND        f_apofa.dd_prodfromprevsnapshot = 'N'
                                                                         --AND (lower(f_apofa.dd_businessunit) = lower('PM2'))     /* Change this line for as per business unit */
                                                              GROUP BY   f_apofa.dd_product, 
                                                                         f_apofa.dd_keycountry, 
                                                                         f_apofa.dd_businessunit,
                                                                         f_apofa.dd_baseunitofmeasure,
                                                                         dpmdg.partdescription, 
                                                                         f_apofa.dd_calmonth, 
                                                                         bwprh.businessline) rowcnt_0) mfltr ) x ) resultset
ORDER BY resultset.col_ord_0, 
         resultset.col_ord_1, 
         resultset.col_ord_2 , 
         resultset.col_ord_3 , 
         resultset.col_ord_4;

/* Get the min AND max Sched Dlvry Date */
DROP TABLE IF EXISTS tmp_saleshistory_daterange; 
CREATE TABLE tmp_saleshistory_daterange AS 
  SELECT CURRENT_DATE maxdate, 
         (select current_date - interval '60' month) mindate; 

DROP TABLE IF EXISTS tmp_saleshistory_yyyymm; 
CREATE TABLE tmp_saleshistory_yyyymm AS 
  SELECT DISTINCT calendaryear, 
                  calendarmonthnumber, 
                  calendarmonthid --, datevalue 
  FROM   dim_date, 
         tmp_saleshistory_daterange 
  WHERE  datevalue BETWEEN mindate AND maxdate 
         AND dayofmonth = 1 
         AND companycode = 'Not Set' 
  ORDER  BY calendarmonthid; 

---------------------------------------------
INSERT INTO tmp_aposaleshist_export_forfopsfcst 
            (dd_product, 
             dd_keycountry, 
             dd_businessunit, 
             dd_calmonth, 
             ct_orderintake) 
SELECT DISTINCT dd_product, 
                dd_keycountry, 
                dd_businessunit, 
                y.calendarmonthid dd_calmonth, 
                0                 ct_salesquantity 
FROM   tmp_saleshistory_yyyymm y, 
       (SELECT DISTINCT f.dd_product, 
                        f.dd_keycountry, 
                        f.dd_businessunit 
        FROM   tmp_aposaleshist_export_forfopsfcst f) f 
WHERE  NOT EXISTS (SELECT 1 
                   FROM   tmp_aposaleshist_export_forfopsfcst t 
                   WHERE  t.dd_product = f.dd_product 
                          AND t.dd_keycountry = f.dd_keycountry 
                          AND t.dd_businessunit = f.dd_businessunit 
                          AND t.dd_calmonth = y.calendarmonthid) 
ORDER  BY dd_product, 
          dd_keycountry, 
          dd_businessunit, 
          y.calendarmonthid; 

/* Table to maintain the data that is being discarded */
DROP TABLE IF EXISTS tmp_unforecastedparts;
CREATE TABLE tmp_unforecastedparts AS 
SELECT f.*, 
       Cast(NULL AS VARCHAR(40)) dd_reasonforfilteringout, 
       Cast(NULL AS VARCHAR(3))  dd_flag_All_Sales_0, 
       Cast(NULL AS VARCHAR(3))  dd_Flag_leading_0, 
       Cast(NULL AS VARCHAR(3))  dd_Flag_min_history , 
       Cast(NULL AS VARCHAR(3))  dd_Flag_holdout, 
       Cast(NULL AS VARCHAR(3))  dd_flag_sales_in_horizon_period 
FROM   tmp_aposaleshist_export_forfopsfcst f 
WHERE  1=2;

/* Collect some stats in tmp table */
DROP TABLE IF EXISTS tmp_clean_aposaleshist_forfopsfcst; 
CREATE TABLE tmp_clean_aposaleshist_forfopsfcst AS 
  SELECT dd_product, 
         dd_keycountry, 
         dd_businessunit, 
         Min(dd_calmonth) min_dd_calmonth 
  FROM   tmp_aposaleshist_export_forfopsfcst b 
  WHERE  ct_orderintake > 0 
  GROUP  BY dd_product, 
            dd_keycountry, 
            dd_businessunit; 
------------------------------------
/* 1. Remove all rows with data in or after current month  */

/* Get the rows having data for current month or after that into tmp_unforecastedparts table*/ 
INSERT INTO tmp_unforecastedparts 
            (dd_product, 
             dd_keycountry, 
             dd_businessunit, 
             dd_calmonth, 
             ct_orderintake, 
             dd_reasonforfilteringout, 
             dd_flag_sales_in_horizon_period) 
SELECT dd_product, 
       dd_keycountry, 
       dd_businessunit, 
       dd_calmonth, 
       ct_orderintake, 
       'Sales in Horizon Period' dd_reasonforfilteringout, 
       'Yes'                     dd_flag_sales_in_horizon_period 
FROM   tmp_aposaleshist_export_forfopsfcst 
WHERE  dd_calmonth > to_number(to_char((current_date),'YYYYMM')); 


/* Delete them */
DELETE FROM tmp_aposaleshist_export_forfopsfcst a 
WHERE  To_number(a.dd_calmonth) >= To_number(To_char(( CURRENT_DATE ), 'YYYYMM')); 

------------------------------------

/* 2. Remove product/key-country pairs having all 0's */
DROP TABLE IF EXISTS tmp_del_all_sales_0; 
CREATE TABLE tmp_del_all_sales_0 AS 
  SELECT DISTINCT dd_product, 
                  dd_keycountry, 
                  dd_businessunit, 
                  Sum(ct_orderintake) sum_sales 
  FROM   tmp_aposaleshist_export_forfopsfcst 
  GROUP  BY dd_product, 
            dd_keycountry, 
            dd_businessunit 
  HAVING Sum(ct_orderintake) <= 0; 
------------------------------------
/* Get the rows having all sales 0 into tmp_unforecastedparts table */
INSERT INTO tmp_unforecastedparts 
            (dd_product, 
             dd_keycountry, 
             dd_businessunit, 
             dd_calmonth, 
             ct_orderintake, 
             dd_reasonforfilteringout, 
             dd_flag_all_sales_0) 
SELECT f.dd_product, 
       f.dd_keycountry, 
       f.dd_businessunit, 
       f.dd_calmonth, 
       f.ct_orderintake, 
       'All Sales 0 in test-train Period' dd_reasonforfilteringout, 
       'Yes'                              dd_flag_All_Sales_0 
FROM   tmp_aposaleshist_export_forfopsfcst f, 
       tmp_del_all_sales_0 t 
WHERE  f.dd_product = t.dd_product 
       AND f.dd_keycountry = t.dd_keycountry 
       AND f.dd_businessunit = t.dd_businessunit; 

/* Delete them */ 
DELETE FROM tmp_aposaleshist_export_forfopsfcst a 
WHERE  EXISTS (SELECT 1 
               FROM   tmp_del_all_sales_0 b 
               WHERE  a.dd_product = b.dd_product 
                      AND a.dd_keycountry = b.dd_keycountry 
                      AND a.dd_businessunit = b.dd_businessunit); 
------------------------------------
/* 3. Remove all months till the first non-zero sale */ 

/* Getting all rows befotre the 1st non-zero sale for each grain */ 
INSERT INTO tmp_unforecastedparts 
            (dd_product, 
             dd_keycountry, 
             dd_businessunit, 
             dd_calmonth, 
             ct_orderintake, 
             dd_reasonforfilteringout, 
             dd_flag_leading_0) 
SELECT a.dd_product, 
       a.dd_keycountry, 
       a.dd_businessunit, 
       a.dd_calmonth, 
       a.ct_orderintake, 
       'Leading 0 Sales' dd_reasonforfilteringout, 
       'Yes'             dd_Flag_leading_0 
FROM   tmp_aposaleshist_export_forfopsfcst a, 
       tmp_clean_aposaleshist_forfopsfcst b 
WHERE  a.dd_product = b.dd_product 
       AND a.dd_keycountry = b.dd_keycountry 
       AND a.dd_businessunit = b.dd_businessunit 
       AND dd_calmonth < b.min_dd_calmonth; 

/* Delete them */
DELETE FROM tmp_aposaleshist_export_forfopsfcst a 
WHERE  EXISTS (SELECT 1 
               FROM   tmp_clean_aposaleshist_forfopsfcst b 
               WHERE  a.dd_product = b.dd_product 
                      AND a.dd_keycountry = b.dd_keycountry 
                      AND a.dd_businessunit = b.dd_businessunit 
                      AND a.dd_calmonth < b.min_dd_calmonth); --967755 
------------------------------------

/* 4. Remove all part-country pairs where no. of data points is less than 12+3 */ 
DROP TABLE IF EXISTS tmp_check_min_history; 
CREATE TABLE tmp_check_min_history AS 
  SELECT dd_product, 
         dd_keycountry, 
         dd_businessunit, 
         Count(*) cnt 
  FROM   tmp_aposaleshist_export_forfopsfcst 
  GROUP  BY dd_product, 
            dd_keycountry, 
            dd_businessunit 
  HAVING Count(*) < 15; 
------------------------------------
/*  Getting all rows having history less than 12 + 3 */
INSERT INTO tmp_unforecastedparts 
            (dd_product, 
             dd_keycountry, 
             dd_businessunit, 
             dd_calmonth, 
             ct_orderintake, 
             dd_reasonforfilteringout, 
             dd_flag_min_history) 
SELECT a.dd_product, 
       a.dd_keycountry, 
       a.dd_businessunit, 
       a.dd_calmonth, 
       a.ct_orderintake, 
       'less-than-12-month-training' dd_reasonforfilteringout, 
       'Yes'                         dd_Flag_min_history 
FROM   tmp_aposaleshist_export_forfopsfcst a, 
       tmp_check_min_history b 
WHERE  a.dd_product = b.dd_product 
       AND a.dd_keycountry = b.dd_keycountry 
       AND a.dd_businessunit = b.dd_businessunit; 

/* Delete Them */
DELETE FROM tmp_aposaleshist_export_forfopsfcst a 
WHERE  EXISTS (SELECT 1 
               FROM   tmp_check_min_history b 
               WHERE  a.dd_product = b.dd_product 
                      AND a.dd_keycountry = b.dd_keycountry 
                      AND a.dd_businessunit = b.dd_businessunit); 
------------------------------------
/* 5. Remove all part-country pairs having no sales in holdout period */ 
DROP TABLE IF EXISTS tmp_cnt_nonzero_in_holdout; 
CREATE TABLE tmp_cnt_nonzero_in_holdout AS 
  SELECT dd_product, 
         dd_keycountry, 
         dd_businessunit, 
         Count(*) cnt_nonzero 
  FROM   tmp_aposaleshist_export_forfopsfcst 
  WHERE  dd_calmonth IN ( To_char(CURRENT_DATE - INTERVAL '1' month, 'YYYYMM'), 
                          To_char(CURRENT_DATE - INTERVAL '2' month, 'YYYYMM'),
			     To_char(CURRENT_DATE - INTERVAL '3' month, 'YYYYMM')) 
         AND ct_orderintake > 0 
  GROUP  BY dd_product, 
            dd_keycountry, 
            dd_businessunit; 

/*  Getting all rows having no sales in holdout period */
INSERT INTO tmp_unforecastedparts 
            (dd_product, 
             dd_keycountry, 
             dd_businessunit, 
             dd_calmonth, 
             ct_orderintake, 
             dd_reasonforfilteringout, 
             dd_flag_holdout) 
SELECT a.dd_product, 
       a.dd_keycountry, 
       a.dd_businessunit, 
       a.dd_calmonth, 
       a.ct_orderintake, 
       'All months with 0 sales in Holdout' dd_reasonforfilteringout, 
       'Yes'                                dd_Flag_holdout 
FROM   tmp_aposaleshist_export_forfopsfcst a 
WHERE  NOT EXISTS (SELECT 1 
                   FROM   tmp_cnt_nonzero_in_holdout b 
                   WHERE  a.dd_product = b.dd_product 
                          AND a.dd_keycountry = b.dd_keycountry 
                          AND a.dd_businessunit = b.dd_businessunit); 

/* Delete them */
DELETE FROM tmp_aposaleshist_export_forfopsfcst a 
WHERE  NOT EXISTS (SELECT 1 
                   FROM   tmp_cnt_nonzero_in_holdout b 
                   WHERE  a.dd_product = b.dd_product 
                          AND a.dd_keycountry = b.dd_keycountry 
                          AND a.dd_businessunit = b.dd_businessunit); 

------------------------------------
/* 6. Remove all part-country pairs having less than

/* Create table for FCST INPUT */
DROP TABLE IF EXISTS saleshistory_emd_pm_previousextractdate; 
CREATE TABLE saleshistory_emd_pm_previousextractdate 
AS 
SELECT * FROM   saleshistory_emd_pm; 

DROP TABLE IF EXISTS saleshistory_emd_pm; 
CREATE TABLE saleshistory_emd_pm AS 
  SELECT dd_product, 
         dd_keycountry, 
         dd_businessunit, 
         'abc' companycode, 
         dd_calmonth, 
         ct_orderintake 
  FROM   tmp_aposaleshist_export_forfopsfcst 
  ORDER  BY dd_product, 
            dd_keycountry, 
            dd_businessunit, 
            dd_calmonth; 
------------------------------------
/* Export saleshistory_emd_pm into a csv file */

EXPORT 
(SELECT   	    concat(dd_product,'|',dd_businessunit), 
                  dd_keycountry, 
                  'abc' companycode, 
                  dd_calmonth, 
                  ct_orderintake 
         FROM     saleshistory_emd_pm 
         ORDER BY dd_product, 
                  dd_keycountry, 
                  dd_businessunit, 
                  dd_calmonth) INTO local csv FILE 'path csv file' COLUMN separator = ',' ;
------------------------------------
/* Remove the parts from tmp_unforecastedparts that are present in saleshistory_emd_pm */
DELETE FROM tmp_unforecastedparts a 
WHERE  EXISTS (SELECT 1 
               FROM   saleshistory_emd_pm b 
               WHERE  a.dd_product = b.dd_product 
                      AND a.dd_keycountry = b.dd_keycountry 
                      AND a.dd_businessunit = b.dd_businessunit); 

------------------------------------------------------------------------------------------------------------------------------------------------
-- Imputation Calculation

DROP TABLE IF EXISTS tmp_unforecastedparts2; 
CREATE TABLE tmp_unforecastedparts2 AS 
  SELECT * 
  FROM   tmp_unforecastedparts 
  WHERE  dd_calmonth >=(select min(dd_calmonth) from SALESHISTORY_EMD_PM); 

DROP TABLE IF EXISTS tmp_saleshistory_daterange; 
CREATE TABLE tmp_saleshistory_daterange AS 
select 	(select current_date + interval '35' month)  maxdate,
	 	(select current_date - interval '37' month) mindate;

------------------
DROP TABLE IF EXISTS tmp_unforecasted_saleshistory_yyyymm; 
CREATE TABLE tmp_unforecasted_saleshistory_yyyymm AS 
  SELECT DISTINCT calendaryear, 
                  calendarmonthnumber, 
                  calendarmonthid --, datevalue 
  FROM   dim_date, 
         tmp_saleshistory_daterange 
  WHERE  datevalue BETWEEN mindate AND maxdate 
         AND dayofmonth = 1 
         AND companycode = 'Not Set' 
  ORDER  BY calendarmonthid; 

------------------
INSERT INTO tmp_unforecastedparts2 
            (dd_product, 
             dd_keycountry, 
             dd_businessunit, 
             dd_calmonth, 
             ct_orderintake) 
SELECT DISTINCT dd_product, 
                dd_keycountry, 
                dd_businessunit, 
                y.calendarmonthid dd_calmonth, 
                0                 ct_salesquantity 
FROM   tmp_unforecasted_saleshistory_yyyymm y, 
       (SELECT DISTINCT f.dd_product, 
                        f.dd_keycountry, 
                        f.dd_businessunit 
        FROM   tmp_unforecastedparts2 f) f 
WHERE  NOT EXISTS (SELECT 1 
                   FROM   tmp_unforecastedparts2 t 
                   WHERE  t.dd_product = f.dd_product 
                          AND t.dd_keycountry = f.dd_keycountry 
                          AND t.dd_businessunit = f.dd_businessunit 
                          AND t.dd_calmonth = y.calendarmonthid) 
ORDER  BY dd_product, 
          dd_keycountry, 
          dd_businessunit, 
          y.calendarmonthid; 

------------------

DROP TABLE IF EXISTS tmp_clean_unforecastedparts2; 
CREATE TABLE tmp_clean_unforecastedparts2 AS 
  SELECT dd_product, 
         dd_keycountry, 
         dd_businessunit, 
         Min(dd_calmonth) min_dd_calmonth 
  FROM   tmp_unforecastedparts2 b 
  WHERE  ct_orderintake > 0 
  GROUP  BY dd_product, 
            dd_keycountry, 
            dd_businessunit; 



DELETE FROM tmp_unforecastedparts2 a 
WHERE  EXISTS (SELECT 1 
               FROM   tmp_clean_unforecastedparts2 b 
               WHERE  a.dd_product = b.dd_product 
                      AND a.dd_keycountry = b.dd_keycountry 
                      AND a.dd_businessunit = b.dd_businessunit 
                      AND a.dd_calmonth < b.min_dd_calmonth); 

------------------
UPDATE tmp_unforecastedparts2 
SET    dd_flag_sales_in_horizon_period = Ifnull(( 
       dd_flag_sales_in_horizon_period ), 'Yes') 
FROM   tmp_unforecastedparts2 
WHERE  dd_calmonth >= To_number(To_char(( CURRENT_DATE ), 'YYYYMM')); 
------------------
UPDATE tmp_unforecastedparts2 
SET    dd_reasonforfilteringout = Ifnull(( dd_reasonforfilteringout ), 'Sales in Horizon Period') 
FROM   tmp_unforecastedparts2 
WHERE  dd_calmonth >= To_number(To_char(( CURRENT_DATE ), 'YYYYMM')); 
------------------
UPDATE tmp_unforecastedparts2 
SET    ct_orderintake = 0 
WHERE  dd_calmonth >= To_number(To_char(( CURRENT_DATE ), 'YYYYMM')); 

------------------

DROP TABLE IF EXISTS tmp_aposaleshist_export_forfopsfcst_current_snapshot;
DROP TABLE IF EXISTS tmp_previous_snapshots_aposaheshist;
DROP TABLE IF EXISTS tmp_previous_snapshots_aposaheshist_2;
DROP TABLE IF EXISTS tmp_aposaleshist_export_forfopsfcst_previous_snapshots;
DROP TABLE IF EXISTS tmp_aposaleshist_export_forfopsfcst;
DROP TABLE IF EXISTS tmp_clean_aposaleshist_forfopsfcst;
DROP TABLE IF EXISTS tmp_clean_aposaleshist_forfopsfcst;
DROP TABLE IF EXISTS tmp_aposaleshist_export_forfopsfcst;
DROP TABLE IF EXISTS tmp_check_min_history;
DROP TABLE IF EXISTS tmp_cnt_nonzero_in_holdout;


