
open schema emd586;
DROP TABLE IF EXISTS STAGE_FOSALESFORECAST_ibp;
CREATE TABLE STAGE_FOSALESFORECAST_ibp (
DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
DD_PARTNUMBER       VARCHAR(40)  NOT NULL ,
DD_LEVEL2           VARCHAR(40) ,
DD_COUNTRYPLANNINGGROUP     VARCHAR(40) UTF8,
DD_ENDCUSTOMERPLANNINGGROUP VARCHAR(40) UTF8,
DD_CHANNELPLANNINGGROUP     VARCHAR(40) UTF8,
CT_SALESQUANTITY    DECIMAL(36,6),
CT_FORECASTQUANTITY DECIMAL(36,6),
CT_LOWPI            DECIMAL(36,6),
CT_HIGHPI           DECIMAL(36,6),
CT_MAPE             DECIMAL(36,6),
DD_LASTDATE         VARCHAR(50)  NOT NULL ,
DD_HOLDOUTDATE      VARCHAR(50)  NOT NULL ,
DD_FORECASTSAMPLE   VARCHAR(50)  NOT NULL ,
DD_FORECASTTYPE     VARCHAR(50)  NOT NULL ,
DD_FORECASTRANK     DECIMAL(18,0),
DD_FORECASTMODE     VARCHAR(50)  NOT NULL ,
DD_COMPANYCODE      VARCHAR(50)  NOT NULL ,
CT_BIAS_ERROR_RANK  DECIMAL(18,6),
CT_BIAS_ERROR       DECIMAL(18,6)
);

IMPORT INTO emd586.STG_FOSALESFORECAST_IBP 
(
 DD_REPORTINGDATE ,
 DD_FORECASTDATE,
 DD_PARTNUMBER,
 DD_COUNTRYPLANNINGGROUP,
 DD_ENDCUSTOMERPLANNINGGROUP,
 DD_CHANNELPLANNINGGROUP,
 CT_SALESQUANTITY ,
 CT_FORECASTQUANTITY,
 CT_LOWPI ,
 CT_HIGHPI,
 CT_MAPE,
 DD_LASTDATE,
 DD_HOLDOUTDATE ,
 DD_FORECASTSAMPLE,
 DD_FORECASTTYPE,
 DD_FORECASTRANK,
 DD_FORECASTMODE,
 DD_COMPANYCODE ,
 CT_BIAS_ERROR_RANK ,
 CT_BIAS_ERROR)
FROM LOCAL CSV FILE 
'<path>' 
COLUMN SEPARATOR = ',' SKIP = 1;

DROP TABLE IF EXISTS emd586.tmp_maxrptdate;
CREATE TABLE emd586.tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from emd586.STG_FOSALESFORECAST_IBP ;

DELETE FROM fact_fosalesforecast_ibp f
WHERE EXISTS ( SELECT 1 FROM emd586.tmp_maxrptdate t where t.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY'));

UPDATE emd586.STG_FOSALESFORECAST_IBP 
SET ct_lowpi = 0
WHERE ct_lowpi < 0;

drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths_2;

drop table if exists emd586.fact_fosalesforecast_ibp_temp;
create table emd586.fact_fosalesforecast_ibp_temp as
select * from emd586.fact_fosalesforecast_ibp WHERE 1=2;

alter table emd586.fact_fosalesforecast_ibp_temp add column dd_forecastdatevalue date default '1900-01-01';

delete from emd586.number_fountain m WHERE m.table_name = 'fact_fosalesforecast_ibp';

insert into emd586.number_fountain
select  'fact_fosalesforecast_ibp',
ifnull(max(d.fact_fosalesforecast_ibpid),
	ifnull((select min(s.dim_projectsourceid * s.multiplier)
			from emd586.dim_projectsource s),0))
from emd586.fact_fosalesforecast_ibp d
WHERE d.fact_fosalesforecast_ibpid <> 1;


insert into emd586.fact_fosalesforecast_ibp_temp
(
fact_fosalesforecast_ibpid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
DD_PRDID,
DD_COUNTRYPLANNINGGROUP,
dd_dmdgroup,
DD_ENDCUSTOMERPLANNINGGROUP,
DD_CHANNELPLANNINGGROUP
)
select  (select ifnull(m.max_id, 0) from emd586.number_fountain m WHERE m.table_name = 'fact_fosalesforecast_ibp')
+ row_number() over(order by dd_partnumber,dd_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,
DD_CHANNELPLANNINGGROUP,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecast_ibpid ,
1 dim_partid,--ifnull((select min(dim_mdg_partid) from emd586.dim_mdg_part dp where dp.partnumber = sf.dd_partnumber),1) dim_partid,
1 dim_plantid,--ifnull((select min(dim_plantid) from emd586.dim_plant pl where pl.plantcode = sf.dd_level2),1) dim_plantid,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
--TO_DATE(sf.dd_reportingdate,'DD MON YYYY') dd_reportingdate, --ifnull(cast(sf.dd_reportingdate as date),'1 Jan 1900'),
upper(sf.dd_reportingdate),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mape,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
case when sf.dd_forecastdate is null then cast('1900-01-01' as date)
else cast(concat(substring(sf.dd_forecastdate,1,4) , '-' ,
substring(sf.dd_forecastdate,5,2) , '-' ,
substring(sf.dd_forecastdate,7,2) ) as date)
end dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
sf.dd_partnumber DD_PRDID,
sf.dd_COUNTRYPLANNINGGROUP DD_COUNTRYPLANNINGGROUP,
sf.dd_companycode dd_dmdgroup,
sf.DD_ENDCUSTOMERPLANNINGGROUP DD_ENDCUSTOMERPLANNINGGROUP,
sf.DD_CHANNELPLANNINGGROUP DD_CHANNELPLANNINGGROUP
from emd586.STG_FOSALESFORECAST_ibp sf;

/* No plant in part for emd */
/*
UPDATE emd586.fact_fosalesforecast_ibp_temp f
SET f.dim_plantid = pl.dim_plantid,
    f.dw_update_date = current_timestamp
from emd586.dim_plant pl, EMD586.dim_mdg_part p,emd586.fact_fosalesforecast_ibp_temp f
WHERE f.dim_partid = p.dim_mdg_partid
AND p.plant = pl.plantcode
AND p.projectsourceid = 1
AND f.dim_plantid <> pl.dim_plantid*/

UPDATE emd586.fact_fosalesforecast_ibp_temp f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from emd586.dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
emd586.fact_fosalesforecast_ibp_temp f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE emd586.fact_fosalesforecast_ibp_temp f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from emd586.dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
emd586.fact_fosalesforecast_ibp_temp f
WHERE f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid;

insert into emd586.fact_fosalesforecast_ibp
(
fact_fosalesforecast_ibpid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdgroup,
DD_PRDID,
DD_COUNTRYPLANNINGGROUP,
DD_ENDCUSTOMERPLANNINGGROUP,
DD_CHANNELPLANNINGGROUP
)
select
fact_fosalesforecast_ibpid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdgroup,
DD_PRDID,
DD_COUNTRYPLANNINGGROUP,
DD_ENDCUSTOMERPLANNINGGROUP,
DD_CHANNELPLANNINGGROUP
from emd586.fact_fosalesforecast_ibp_temp;



/* Update future sales to NULL */
UPDATE emd586.fact_fosalesforecast_ibp f
SET ct_salesquantity = NULL
FROM emd586.fact_fosalesforecast_ibp f,emd586.tmp_maxrptdate r
/*WHERE ct_salesquantity = 0
AND*/ WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Horizon';

/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE emd586.fact_fosalesforecast_ibp f
set ct_highpi = NULL
FROM emd586.fact_fosalesforecast_ibp f,emd586.tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train'
AND ct_highpi IS NOT NULL;

UPDATE emd586.fact_fosalesforecast_ibp f
set ct_lowpi = NULL
FROM emd586.fact_fosalesforecast_ibp f,emd586.tmp_maxrptdate r
WHERE TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train'
AND ct_lowpi IS NOT NULL;

/* Format reporting date as DD MON YYYY */
UPDATE emd586.fact_fosalesforecast_ibp f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD MON YYYY')
where f.dd_reportingdate like '%-%-%';

DROP TABLE IF EXISTS emd586.tmp_maxrptdate;
CREATE TABLE emd586.tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from emd586.STG_FOSALESFORECAST_ibp ;

/* As per discussion with Anshuman on 19th Aug 2016, do not delete these rows */
/*
delete
from emd586.fact_fosalesforecast_ibp f
where exists ( select 1 from emd586.dim_date d
	where f.dim_dateidforecast = d.dim_dateid
	and year(d.datevalue) >= 2019)
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from emd586.tmp_maxrptdate)
*/


/* Populate No. of Days */
UPDATE emd586.fact_fosalesforecast_ibp f
SET f.dd_daysinmonth = extract(day from d.datevalue)||'D'
FROM emd586.fact_fosalesforecast_ibp f,emd586.dim_date d, emd586.tmp_maxrptdate r
WHERE f.dim_dateidforecast = d.dim_dateid
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

/* Rerank for mult forecasts having same ranks */

DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf;
CREATE TABLE tmp_upd_fcstrank_fosf
as
select distinct f.dd_reportingdate,DD_PRDID,DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,
DD_CHANNELPLANNINGGROUP,dd_forecasttype,dd_forecastrank
from fact_fosalesforecast_ibp f,emd586.tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;



--This should insert 0 rows as for same fcst type, there cannot be different ranks
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.DD_PRDID = t2.DD_PRDID
and t1.DD_COUNTRYPLANNINGGROUP = t2.DD_COUNTRYPLANNINGGROUP
and t1.DD_ENDCUSTOMERPLANNINGGROUP = t2.DD_ENDCUSTOMERPLANNINGGROUP
and t1.DD_CHANNELPLANNINGGROUP = t2.DD_CHANNELPLANNINGGROUP
and t1.dd_forecasttype = t2.dd_forecasttype
and t1.dd_forecastrank <> t2.dd_forecastrank;


--These are the cases with issues ( different methods, same rank )
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.DD_PRDID = t2.DD_PRDID
and t1.DD_COUNTRYPLANNINGGROUP = t2.DD_COUNTRYPLANNINGGROUP
and t1.DD_ENDCUSTOMERPLANNINGGROUP = t2.DD_ENDCUSTOMERPLANNINGGROUP
and t1.DD_CHANNELPLANNINGGROUP = t2.DD_CHANNELPLANNINGGROUP
and t1.dd_forecasttype <> t2.dd_forecasttype
and t1.dd_forecastrank = t2.dd_forecastrank;


--Get all rows corresponding to these rptdate,grain(4cols)
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf3;
CREATE TABLE tmp_upd_fcstrank_fosf3
as
select t1.*,rank() over(partition by dd_reportingdate,DD_PRDID,
DD_COUNTRYPLANNINGGROUP,DD_ENDCUSTOMERPLANNINGGROUP,DD_CHANNELPLANNINGGROUP  order by dd_forecastrank,dd_forecasttype) dd_rank_new
from tmp_upd_fcstrank_fosf t1
WHERE EXISTS ( SELECT 1 FROM tmp_upd_fcstrank_fosf2 t2
    where t1.dd_reportingdate = t2.dd_reportingdate
and t1.DD_PRDID = t2.DD_PRDID
and t1.DD_COUNTRYPLANNINGGROUP = t2.DD_COUNTRYPLANNINGGROUP
and t1.DD_ENDCUSTOMERPLANNINGGROUP = t2.DD_ENDCUSTOMERPLANNINGGROUP
and t1.DD_CHANNELPLANNINGGROUP = t2.DD_CHANNELPLANNINGGROUP);


UPDATE fact_fosalesforecast_ibp f
SET f.dd_forecastrank = t.dd_rank_new
FROM fact_fosalesforecast_ibp f,tmp_upd_fcstrank_fosf3 t
where f.dd_reportingdate = t.dd_reportingdate
and t.DD_PRDID = f.DD_PRDID
and t.DD_COUNTRYPLANNINGGROUP = f.DD_COUNTRYPLANNINGGROUP
and t.DD_ENDCUSTOMERPLANNINGGROUP = f.DD_ENDCUSTOMERPLANNINGGROUP
and t.DD_CHANNELPLANNINGGROUP = f.DD_CHANNELPLANNINGGROUP
and f.dd_forecastrank = t.dd_forecastrank
and f.dd_forecasttype = t.dd_forecasttype;

UPDATE emd586.fact_fosalesforecast_ibp f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE emd586.fact_fosalesforecast_ibp f
SET dd_latestreporting = 'Yes'
FROM emd586.fact_fosalesforecast_ibp f,emd586.tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;


DROP TABLE IF EXISTS tmp_upd_ct_next12monthsfopsfcst;
CREATE TABLE tmp_upd_ct_next12monthsfopsfcst
as
select f.dd_reportingdate,f.DD_PRDID,
f.DD_COUNTRYPLANNINGGROUP,f.DD_ENDCUSTOMERPLANNINGGROUP,f.DD_CHANNELPLANNINGGROUP,f.dd_forecasttype,
d.datevalue dd_forecastdate,d.datevalue + interval '11' month dd_forecastdate_plus11,
sum(f1.ct_forecastquantity) ct_next12monthsfopsfcst
FROM fact_fosalesforecast_ibp f inner join fact_fosalesforecast_ibp f1
ON f.dd_reportingdate = f1.dd_reportingdate 
and f1.DD_PRDID = f.DD_PRDID
and f1.DD_COUNTRYPLANNINGGROUP = f.DD_COUNTRYPLANNINGGROUP
and f1.DD_ENDCUSTOMERPLANNINGGROUP = f.DD_ENDCUSTOMERPLANNINGGROUP
and f1.DD_CHANNELPLANNINGGROUP = f.DD_CHANNELPLANNINGGROUP
AND f.dd_forecasttype = f1.dd_forecasttype
INNER JOIN dim_date d on d.dim_dateid = f.dim_dateidforecast
INNER JOIN dim_date d1 on d1.dim_dateid = f1.dim_dateidforecast
WHERE d1.datevalue >= d.datevalue
AND d1.datevalue <= d.datevalue + interval '11' month
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
GROUP BY f.dd_reportingdate,f.DD_PRDID,
f.DD_COUNTRYPLANNINGGROUP,f.DD_ENDCUSTOMERPLANNINGGROUP,f.DD_CHANNELPLANNINGGROUP,f.dd_forecasttype,
d.datevalue,d.datevalue + interval '11' month;

UPDATE fact_fosalesforecast_ibp f
SET f.ct_next12monthsfopsfcst = f1.ct_next12monthsfopsfcst
FROM fact_fosalesforecast_ibp f inner join dim_date d ON d.dim_dateid = f.dim_dateidforecast
    inner join tmp_upd_ct_next12monthsfopsfcst f1
ON f.dd_reportingdate = f1.dd_reportingdate 
and f1.DD_PRDID = f.DD_PRDID
and f1.DD_COUNTRYPLANNINGGROUP = f.DD_COUNTRYPLANNINGGROUP
and f1.DD_ENDCUSTOMERPLANNINGGROUP = f.DD_ENDCUSTOMERPLANNINGGROUP
and f1.DD_CHANNELPLANNINGGROUP = f.DD_CHANNELPLANNINGGROUP
AND f.dd_forecasttype = f1.dd_forecasttype
WHERE f1.dd_forecastdate = d.datevalue;


DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths_2;
drop table if exists emd586.fact_fosalesforecast_ibp_temp;
DROP TABLE IF EXISTS emd586.backup_fact_fosalesforecast_ibp_largefcstqty;
DROP TABLE IF EXISTS emd586.tmp_custmapes_fosp;
DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf1;
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf3;
DROP TABLE IF EXISTS tmp_gaincritlt0;
DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape;
DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_upd;
DELETE FROM emd586.STG_FOSALESFORECAST_ibp;

