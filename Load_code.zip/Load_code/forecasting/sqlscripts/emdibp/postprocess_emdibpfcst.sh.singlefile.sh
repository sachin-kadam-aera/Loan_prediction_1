#!/bin/sh
set -x

#file0=$1
file0=stage_fosalesforecast_ibp.csv.gz
file1=`basename $file0 .gz`

if [ -f $file0 ]
then
gunzip $file0
fi

dest=${file1}.withcolumnsadded.csv

head -1 $file1 | sed 's/dd_level2/countryplanninggroup,endcustomerplanninggroup,channelplanninggroup/' > hdr.$$

grep -v dd_reportingdate $file1|sed 's/|/,/g' > xyz.csv1.$$;cat hdr.$$ xyz.csv1.$$ > $dest

gzip $dest

echo "Output file is ${dest}.gz"

rm -f xyz.csv1.$$ hdr.$$

