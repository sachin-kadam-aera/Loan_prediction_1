OPEN SCHEMA RECKITT_BENCKISER;

DROP TABLE IF EXISTS tmp_saleshistory;
CREATE TABLE tmp_saleshistory
(
sku varchar(200),
businessunit varchar(10),
dd_dummy varchar(3),
calendarmonthid int,
ct_salesquantity decimal(18,4)
);


/* Using queries */
/*
DROP TABLE IF EXISTS tmp_extract_saleshistory;
CREATE TABLE tmp_extract_saleshistory
AS
SELECT dp.dd_sku,substr(calendarweekyr,1,4)||substr(calendarweekyr,6,2) dd_yyyyww, --to_char(rd.datevalue,'YYYYWW') dd_yyyyww, 
ct_scheduleqtybaseuom
FROM fact_salesorder f inner join dim_part dp on f.dim_partid = dp.dim_partid
INNER JOIN dim_salesorderrejectreason r on f.dim_salesorderrejectreasonid = r.dim_salesorderrejectreasonid
INNER JOIN dim_documentcategory catg on catg.dim_documentcategoryidid = f.dim_documentcategoryidid
INNER JOIN dim_date reqdt on reqdt.dim_dateid = f.dim_dateidscheddeliveryreq
WHERE r.REJECTREASONCODE = 'Not Set'
AND catg.DOCUMENTCATEGORY = 'C'
AND dp.sku <> 'Not Set'
AND f.ct_scheduleqtybaseuom > 0;

EXPORT (select * from tmp_extract_saleshistory order by sku, businessunit, calendarmonthid)
INTO LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/RB_DF_input_imputed.csv'
COLUMN SEPARATOR = ',' REPLACE;

*/

 
/* Existing extract file prepared by Hima */

DROP TABLE IF EXISTS tmp_saleshistory_1;
CREATE TABLE tmp_saleshistory_1
AS
SELECT *
FROM tmp_saleshistory 
WHERE 1=2;

IMPORT INTO tmp_saleshistory_1
FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/RB_DF_input_imputed.csv.gz'
column separator = ','
COLUMN DELIMITER = '"'
SKIP = 0;

INSERT INTO tmp_saleshistory
(sku,businessunit,dd_dummy,calendarmonthid,ct_salesquantity)
SELECT sku,  businessunit, 'abc' dummy,
calendarmonthid,sum(ct_salesquantity) ct_salesquantity
FROM tmp_saleshistory_1
GROUP by sku,businessunit,calendarmonthid;

/* Min/Max condition already handled in input data by Hima RB_DF_input_imputed.csv */
/*
DROP TABLE IF EXISTS tmp_spfbusinessunit_53weeks;
CREATE TABLE tmp_spfbusinessunit_53weeks
AS
SELECT distinct sku, businessunit, count(*) cnt_weeks,sum(ct_salesquantity) ct_totalsales,
rank() over(order by sum(ct_salesquantity) desc) dd_rank
FROM tmp_saleshistory
WHERE ct_salesquantity > 0
GROUP BY sku,businessunit
HAVING MIN(calendarmonthid) <= 201606 
AND MAX(calendarmonthid) >= 201738;
*/

/*
EXPORT (select * from tmp_saleshistory order by sku, businessunit, calendarmonthid)
INTO LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/ul_saleshistory_all_201738.csv'
COLUMN SEPARATOR = ',' REPLACE;
*/





/*******************************************************************/
/**********************Outlier Treatment****************************/
/*******************************************************************/

/* Mark outliers and update with mean - Do this iteratively */

/* Define min zscore and max. no of outliers */
DROP TABLE IF EXISTS tmp_threshold_zscores_outliercounts;
CREATE TABLE tmp_threshold_zscores_outliercounts
AS
SELECT 
4 ct_zscore_min,
3 ct_no_of_outliers_max;

/* Holdout period last week is 201735 */
DROP TABLE IF EXISTS tmp_saleshistory_calc;
CREATE TABLE tmp_saleshistory_calc
AS
SELECT t.*,0 ct_count_outliers,
'N' outlierflag
FROM tmp_saleshistory t;

/* Outlier - Level 1*/
DROP TABLE IF EXISTS tmp_meansd_recalc;
CREATE TABLE tmp_meansd_recalc
AS
SELECT t1.*,t.mean_ct_salesquantity,t.sd_ct_salesquantity,
abs(t1.ct_salesquantity-t.mean_ct_salesquantity)/t.sd_ct_salesquantity ct_zscore
FROM tmp_saleshistory_calc t1,
(SELECT sku,businessunit,avg(ct_salesquantity) mean_ct_salesquantity,
stddev(ct_salesquantity) sd_ct_salesquantity
FROM tmp_saleshistory_calc
WHERE calendarmonthid <= 201735	
GROUP BY sku,businessunit) t
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t1.calendarmonthid <= 201735
AND t.sd_ct_salesquantity > 0;

DROP TABLE IF EXISTS tmp_outlier_currentlevel;
CREATE TABLE tmp_outlier_currentlevel
AS
SELECT t.*,rank() over(partition by sku,businessunit order by ct_zscore desc,calendarmonthid desc) dd_rank,
cast(0 as decimal(18,4)) ct_salesquantity_outlierreplaced
FROM tmp_meansd_recalc t;

select count(*)
FROM tmp_outlier_currentlevel t
WHERE dd_rank = 1 AND t.ct_zscore >= 4;

/* Recalculate the mean after ignoring the rank 1 row. Update this value for the rank 1 row */
UPDATE tmp_outlier_currentlevel t
SET t.ct_salesquantity_outlierreplaced = t1.ct_salesquantity_outlierreplaced
FROM tmp_outlier_currentlevel t, 
(SELECT sku,businessunit,avg(ct_salesquantity) ct_salesquantity_outlierreplaced 
FROM tmp_outlier_currentlevel 
WHERE dd_rank >= 2 AND outlierflag = 'N'  /* Use points which are not an outlier in current or previous iteration */
GROUP BY sku,businessunit) t1
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t.dd_rank = 1 
AND t.ct_zscore >= 4;


/* Replace the top outlier with mean calculated in iteration 1 */
UPDATE tmp_saleshistory_calc t
SET t.ct_salesquantity = t1.ct_salesquantity_outlierreplaced,
t.ct_count_outliers  = ct_count_outliers + 1,
t.outlierflag = 'Y'
FROM tmp_saleshistory_calc t,tmp_outlier_currentlevel t1
WHERE t.sku = t1.sku AND t.businessunit = t1.businessunit
AND t1.dd_rank = 1 AND t1.ct_zscore >= 4
AND ((t.calendarmonthid = t1.calendarmonthid) OR (t.outlierflag = 'Y'));

/* Outlier - Level 2*/
DROP TABLE IF EXISTS tmp_meansd_recalc;
CREATE TABLE tmp_meansd_recalc
AS
SELECT t1.*,t.mean_ct_salesquantity,t.sd_ct_salesquantity,
abs(t1.ct_salesquantity-t.mean_ct_salesquantity)/t.sd_ct_salesquantity ct_zscore
FROM tmp_saleshistory_calc t1,
(SELECT sku,businessunit,avg(ct_salesquantity) mean_ct_salesquantity,
stddev(ct_salesquantity) sd_ct_salesquantity
FROM tmp_saleshistory_calc
WHERE calendarmonthid <= 201735
GROUP BY sku,businessunit) t
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t1.calendarmonthid <= 201735
AND t.sd_ct_salesquantity > 0;

DROP TABLE IF EXISTS tmp_outlier_currentlevel;
CREATE TABLE tmp_outlier_currentlevel
AS
SELECT t.*,rank() over(partition by sku,businessunit order by ct_zscore desc,calendarmonthid desc) dd_rank,
cast(0 as decimal(18,4)) ct_salesquantity_outlierreplaced
FROM tmp_meansd_recalc t;

select count(*)
FROM tmp_outlier_currentlevel t
WHERE dd_rank = 1 AND t.ct_zscore >= 4;

/* Recalculate the mean after ignoring the rank 1 row. Update this value for the rank 1 row */
UPDATE tmp_outlier_currentlevel t
SET t.ct_salesquantity_outlierreplaced = t1.ct_salesquantity_outlierreplaced
FROM tmp_outlier_currentlevel t, 
(SELECT sku,businessunit,avg(ct_salesquantity) ct_salesquantity_outlierreplaced 
FROM tmp_outlier_currentlevel 
WHERE dd_rank >= 2 AND outlierflag = 'N'  /* Use points which are not an outlier in current or previous iteration */
GROUP BY sku,businessunit) t1
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t.dd_rank = 1 
AND t.ct_zscore >= 4;


/* Replace the top outlier with mean calculated in iteration 2 */
UPDATE tmp_saleshistory_calc t
SET t.ct_salesquantity = t1.ct_salesquantity_outlierreplaced,
t.ct_count_outliers  = ct_count_outliers + 1,
t.outlierflag = 'Y'
FROM tmp_saleshistory_calc t,tmp_outlier_currentlevel t1
WHERE t.sku = t1.sku AND t.businessunit = t1.businessunit
AND t1.dd_rank = 1 AND t1.ct_zscore >= 4
AND ((t.calendarmonthid = t1.calendarmonthid) OR (t.outlierflag = 'Y'));

/* Outlier - Level 3*/
DROP TABLE IF EXISTS tmp_meansd_recalc;
CREATE TABLE tmp_meansd_recalc
AS
SELECT t1.*,t.mean_ct_salesquantity,t.sd_ct_salesquantity,
abs(t1.ct_salesquantity-t.mean_ct_salesquantity)/t.sd_ct_salesquantity ct_zscore
FROM tmp_saleshistory_calc t1,
(SELECT sku,businessunit,avg(ct_salesquantity) mean_ct_salesquantity,
stddev(ct_salesquantity) sd_ct_salesquantity
FROM tmp_saleshistory_calc
WHERE calendarmonthid <= 201735
GROUP BY sku,businessunit) t
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t1.calendarmonthid <= 201735
AND t.sd_ct_salesquantity > 0;

DROP TABLE IF EXISTS tmp_outlier_currentlevel;
CREATE TABLE tmp_outlier_currentlevel
AS
SELECT t.*,rank() over(partition by sku,businessunit order by ct_zscore desc,calendarmonthid desc) dd_rank,
cast(0 as decimal(18,4)) ct_salesquantity_outlierreplaced
FROM tmp_meansd_recalc t;

select count(*)
FROM tmp_outlier_currentlevel t
WHERE dd_rank = 1 AND t.ct_zscore >= 4;

/* Recalculate the mean after ignoring the rank 1 row. Update this value for the rank 1 row */
UPDATE tmp_outlier_currentlevel t
SET t.ct_salesquantity_outlierreplaced = t1.ct_salesquantity_outlierreplaced
FROM tmp_outlier_currentlevel t, 
(SELECT sku,businessunit,avg(ct_salesquantity) ct_salesquantity_outlierreplaced 
FROM tmp_outlier_currentlevel 
WHERE dd_rank >= 2 AND outlierflag = 'N'  /* Use points which are not an outlier in current or previous iteration */
GROUP BY sku,businessunit) t1
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t.dd_rank = 1
AND t.ct_zscore >= 4;


/* Replace the top outlier with mean calculated in iteration 3 */
UPDATE tmp_saleshistory_calc t
SET t.ct_salesquantity = t1.ct_salesquantity_outlierreplaced,
t.ct_count_outliers  = ct_count_outliers + 1,
t.outlierflag = 'Y'
FROM tmp_saleshistory_calc t,tmp_outlier_currentlevel t1
WHERE t.sku = t1.sku AND t.businessunit = t1.businessunit
AND t1.dd_rank = 1 AND t1.ct_zscore >= 4
AND ((t.calendarmonthid = t1.calendarmonthid) OR (t.outlierflag = 'Y'));

/* Outlier - Level 4*/
DROP TABLE IF EXISTS tmp_meansd_recalc;
CREATE TABLE tmp_meansd_recalc
AS
SELECT t1.*,t.mean_ct_salesquantity,t.sd_ct_salesquantity,
abs(t1.ct_salesquantity-t.mean_ct_salesquantity)/t.sd_ct_salesquantity ct_zscore
FROM tmp_saleshistory_calc t1,
(SELECT sku,businessunit,avg(ct_salesquantity) mean_ct_salesquantity,
stddev(ct_salesquantity) sd_ct_salesquantity
FROM tmp_saleshistory_calc
WHERE calendarmonthid <= 201735
GROUP BY sku,businessunit) t
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t1.calendarmonthid <= 201735
AND t.sd_ct_salesquantity > 0;

DROP TABLE IF EXISTS tmp_outlier_currentlevel;
CREATE TABLE tmp_outlier_currentlevel
AS
SELECT t.*,rank() over(partition by sku,businessunit order by ct_zscore desc,calendarmonthid desc) dd_rank,
cast(0 as decimal(18,4)) ct_salesquantity_outlierreplaced
FROM tmp_meansd_recalc t;

select count(*)
FROM tmp_outlier_currentlevel t
WHERE dd_rank = 1 AND t.ct_zscore >= 4;

/* Recalculate the mean after ignoring the rank 1 row. Update this value for the rank 1 row */
UPDATE tmp_outlier_currentlevel t
SET t.ct_salesquantity_outlierreplaced = t1.ct_salesquantity_outlierreplaced
FROM tmp_outlier_currentlevel t, 
(SELECT sku,businessunit,avg(ct_salesquantity) ct_salesquantity_outlierreplaced 
FROM tmp_outlier_currentlevel 
WHERE dd_rank >= 2 AND outlierflag = 'N'  /* Use points which are not an outlier in current or previous iteration */
GROUP BY sku,businessunit) t1
WHERE t.sku = t1.sku and t.businessunit = t1.businessunit
AND t.dd_rank = 1
AND t.ct_zscore >= 4;


/* Replace the top outlier with mean calculated in iteration 4 */
UPDATE tmp_saleshistory_calc t
SET t.ct_salesquantity = t1.ct_salesquantity_outlierreplaced,
t.ct_count_outliers  = ct_count_outliers + 1,
t.outlierflag = 'Y'
FROM tmp_saleshistory_calc t,tmp_outlier_currentlevel t1
WHERE t.sku = t1.sku AND t.businessunit = t1.businessunit
AND t1.dd_rank = 1 AND t1.ct_zscore >= 4
AND ((t.calendarmonthid = t1.calendarmonthid) OR (t.outlierflag = 'Y'));


/* Update counts for sku/bu */
/* So, for each sku-bu pair, you can see the total no. of outliers */
UPDATE tmp_saleshistory_calc t
SET t.ct_count_outliers = t1.cnt
FROM tmp_saleshistory_calc t, 
(SELECT sku,businessunit,count(*) cnt FROM tmp_saleshistory_calc
WHERE outlierflag = 'Y'
GROUP BY sku,businessunit) t1
WHERE t.sku = t1.sku AND t.businessunit = t1.businessunit;

/* Distinct sku-businessunit that have outliers */
SELECT COUNT(DISTINCT sku||businessunit) from tmp_saleshistory_calc
WHERE ct_count_outliers >= 1;

DROP TABLE IF EXISTS tmp_saleshistory_outlier;
CREATE TABLE tmp_saleshistory_outlier
AS
SELECT sku,businessunit,dd_dummy,calendarmonthid,ct_salesquantity
FROM tmp_saleshistory_calc
WHERE ct_count_outliers >= 1
ORDER BY sku,businessunit,dd_dummy,calendarmonthid;

/* This should have exactly the same count as tmp_saleshistory_outlier */
DROP TABLE IF EXISTS tmp_saleshistory_outlier_orig;
CREATE TABLE tmp_saleshistory_outlier_orig
AS
SELECT t.sku,t.businessunit,t.dd_dummy,t.calendarmonthid,t.ct_salesquantity
FROM tmp_saleshistory t
WHERE EXISTS (SELECT 1 FROM tmp_saleshistory_calc t1
WHERE t1.ct_count_outliers >= 1
AND t.sku = t1.sku AND t.businessunit = t1.businessunit)
ORDER BY t.sku,t.businessunit,t.dd_dummy,t.calendarmonthid;

/*
INSERT INTO tmp_saleshistory_outlier
SELECT t.sku,t.businessunit,t.dd_dummy,t.calendarmonthid,t.ct_salesquantity
FROM tmp_saleshistory_outlier_orig t
WHERE calendarmonthid > 201735;
*/

EXPORT (select * from tmp_saleshistory_outlier order by sku, businessunit, calendarmonthid)
INTO LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/rb_saleshistory_outliertreated.csv.gz'
COLUMN SEPARATOR = ',' REPLACE;



EXPORT (select * from tmp_saleshistory_outlier_orig order by sku, businessunit, calendarmonthid)
INTO LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/tmp_saleshistory_outlier_orig.csv.gz'
COLUMN SEPARATOR = ',' REPLACE;

/* Validation */
SELECT *
FROM tmp_saleshistory_calc
WHERE sku = '02340-09000-10' and businessunit = 1086
ORDER BY calendarmonthid;

