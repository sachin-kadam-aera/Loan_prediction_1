
/* Has MAD calculations */


open schema reckitt_benckiser;


DROP TABLE IF EXISTS stage_fosalesforecastweekly_combined;
CREATE TABLE stage_fosalesforecastweekly_combined (
DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
dd_partnumber       VARCHAR(150)  NOT NULL ,
dd_plant           VARCHAR(40) ,
CT_SALESQUANTITY    DECIMAL(36,6),
CT_FORECASTQUANTITY DECIMAL(36,6),
CT_LOWPI            DECIMAL(36,6),
CT_HIGHPI           DECIMAL(36,6),
CT_mad             DECIMAL(36,6),
DD_LASTDATE         VARCHAR(50)  ,
DD_HOLDOUTDATE      VARCHAR(50)  ,
DD_FORECASTSAMPLE   VARCHAR(50)  ,
DD_FORECASTTYPE     VARCHAR(50)  ,
DD_FORECASTRANK     DECIMAL(18,0),
DD_FORECASTMODE     VARCHAR(50)  ,
DD_COMPANYCODE      VARCHAR(50)  ,
CT_BIAS_ERROR_RANK  DECIMAL(36,6),
CT_BIAS_ERROR       DECIMAL(36,6),
DD_FORECASTEDFLAG VARCHAR(3) DEFAULT 'Yes',
DD_FLAG_MIN_HISTORY VARCHAR(3) DEFAULT 'No',
DD_FLAG_HOLDOUT VARCHAR(3) DEFAULT 'No',
DD_Forecast_approach VARCHAR(50) DEFAULT 'OutlierTreatedWithFullHist',
DD_FORECAST_QUANTITY   VARCHAR(50) DEFAULT 'Ordered Quantity',
DD_FORECASTGRAIN  VARCHAR(50) DEFAULT 'SKU-BusinessUnit',
ct_forecastquantity_regular decimal(18,4),
ct_forecastquantity_rfh decimal(18,4),
ct_forecastquantity_outlier decimal(18,4),
ct_forecastquantity_ofh decimal(18,4),
ct_highpi_regular decimal(18,4),
ct_highpi_rfh decimal(18,4),
ct_highpi_outlier decimal(18,4),
ct_highpi_ofh decimal(18,4),
ct_lowpi_regular decimal(18,4),
ct_lowpi_rfh decimal(18,4),
ct_lowpi_outlier decimal(18,4),
ct_lowpi_ofh decimal(18,4),
ct_mad_holdout_basedonregularfcst decimal(18,4),
ct_mad_horizon_basedonfullhistforecast decimal(18,4),
ct_mad_holdout_basedonoutlierfcst decimal(18,4),
ct_mad_horizon_basedonofhforecast decimal(18,4),
ct_bias_holdout_basedonregularfcst decimal(18,4),
ct_bias_horizon_basedonfullhistforecast decimal(18,4),
ct_bias_holdout_basedonoutlierfcst decimal(18,4),
ct_bias_horizon_basedonofhforecast decimal(18,4),
dd_bestapproach_by_mad_holdout varchar(100) default 'Regular',
ct_bestforecastquantiy decimal(18,4),
ct_bestmadholdout decimal(18,4),
ct_bestmadhorizon decimal(18,4),
ct_bestbiasholdout decimal(18,4),
ct_bestbiashorizon decimal(18,4),
dd_forecastrank_regular int,
dd_forecastrank_outlier int,
dd_forecastrank_bestapproach int,
dd_sku10 varchar(11),
dd_sku12 varchar(20) default 'Not Set',
dd_businessunit varchar(10) default 'Not Set',
dd_customercode varchar(30) default 'Not Set',
dd_active_sku12_mappedtosku10 varchar(20) default 'Not Set',
dd_zerofcst_changedto_one varchar(1) default 'N',
dd_zerosales_changedto_one varchar(1) default 'N'
);

DROP TABLE IF EXISTS stage_fosalesforecastweekly_regular;
CREATE TABLE stage_fosalesforecastweekly_regular 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;

DROP TABLE IF EXISTS stage_fosalesforecastweekly_rfh;
CREATE TABLE stage_fosalesforecastweekly_rfh 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;


DROP TABLE IF EXISTS stage_fosalesforecastweekly_outlier;
CREATE TABLE stage_fosalesforecastweekly_outlier 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;

DROP TABLE IF EXISTS stage_fosalesforecastweekly_ofh;
CREATE TABLE stage_fosalesforecastweekly_ofh 
AS
SELECT *
FROM stage_fosalesforecastweekly_combined;



/* Import the FCST output file into stage table */
IMPORT INTO stage_fosalesforecastweekly_regular
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/f1_r.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

IMPORT INTO stage_fosalesforecastweekly_rfh
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/f2_rfh.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

IMPORT INTO stage_fosalesforecastweekly_outlier
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/f3_o.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

IMPORT INTO stage_fosalesforecastweekly_ofh
(
DD_REPORTINGDATE, DD_FORECASTDATE, dd_partnumber, dd_plant, CT_SALESQUANTITY, CT_FORECASTQUANTITY,
CT_LOWPI, CT_HIGHPI , CT_mad, DD_LASTDATE, DD_HOLDOUTDATE,
DD_FORECASTSAMPLE, DD_FORECASTTYPE, DD_FORECASTRANK, DD_FORECASTMODE, DD_COMPANYCODE, CT_BIAS_ERROR_RANK, CT_BIAS_ERROR)
FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/f4_ofh.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;


UPDATE stage_fosalesforecastweekly_regular
set dd_reportingdate = '23 APR 2018';
UPDATE stage_fosalesforecastweekly_rfh
set dd_reportingdate = '23 APR 2018';
UPDATE stage_fosalesforecastweekly_outlier
set dd_reportingdate = '23 APR 2018';
UPDATE stage_fosalesforecastweekly_ofh
set dd_reportingdate = '23 APR 2018';



UPDATE stage_fosalesforecastweekly_regular
set dd_forecastsample = 'Validation'
WHERE dd_forecastdate >= '201753' AND dd_forecastdate <= '201812';
UPDATE stage_fosalesforecastweekly_rfh
set dd_forecastsample = 'Validation'
WHERE dd_forecastdate >= '201753' AND dd_forecastdate <= '201812';
UPDATE stage_fosalesforecastweekly_outlier
set dd_forecastsample = 'Validation'
WHERE dd_forecastdate >= '201753' AND dd_forecastdate <= '201812';
UPDATE stage_fosalesforecastweekly_ofh
set dd_forecastsample = 'Validation'
WHERE dd_forecastdate >= '201753' AND dd_forecastdate <= '201812';

SELECT dd_forecastsample,min(dd_forecastdate), max(dd_forecastdate)
FROM stage_fosalesforecastweekly_regular
GROUP BY dd_forecastsample;

/* Update actual sales for validation period */
DROP TABLE IF EXISTS tmp_2grain_saleshistory;
CREATE TABLE tmp_2grain_saleshistory
(
dd_partnumber varchar(20),
dd_plant varchar(10),
dd_dummy varchar(20),
dd_yyyymm char(6),
ct_salesquantity decimal(18,4)
);

IMPORT INTO tmp_2grain_saleshistory
FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/customerPOC/RB/data/rb_historysku10-bu_imputed.csv.gz'
COLUMN SEPARATOR = ',' SKIP = 1
REJECT LIMIT 0;

UPDATE stage_fosalesforecastweekly_regular r
SET r.ct_salesquantity = t.ct_salesquantity
FROM stage_fosalesforecastweekly_regular r,tmp_2grain_saleshistory t
WHERE r.dd_partnumber = t.dd_partnumber
and r.dd_plant = t.dd_plant
AND substr(r.dd_forecastdate,1,6) = t.dd_yyyymm
AND r.dd_forecastsample = 'Validation';

UPDATE stage_fosalesforecastweekly_rfh r
SET r.ct_salesquantity = t.ct_salesquantity
FROM stage_fosalesforecastweekly_rfh r,tmp_2grain_saleshistory t
WHERE r.dd_partnumber = t.dd_partnumber
and r.dd_plant = t.dd_plant
AND substr(r.dd_forecastdate,1,6) = t.dd_yyyymm
AND r.dd_forecastsample = 'Validation';

UPDATE stage_fosalesforecastweekly_outlier r
SET r.ct_salesquantity = t.ct_salesquantity
FROM stage_fosalesforecastweekly_outlier r,tmp_2grain_saleshistory t
WHERE r.dd_partnumber = t.dd_partnumber
and r.dd_plant = t.dd_plant
AND substr(r.dd_forecastdate,1,6) = t.dd_yyyymm
AND r.dd_forecastsample = 'Validation';

UPDATE stage_fosalesforecastweekly_ofh r
SET r.ct_salesquantity = t.ct_salesquantity
FROM stage_fosalesforecastweekly_ofh r,tmp_2grain_saleshistory t
WHERE r.dd_partnumber = t.dd_partnumber
and r.dd_plant = t.dd_plant
AND substr(r.dd_forecastdate,1,6) = t.dd_yyyymm
AND r.dd_forecastsample = 'Validation';


