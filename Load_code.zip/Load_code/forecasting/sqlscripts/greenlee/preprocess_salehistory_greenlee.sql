/* Create Stg_saleshistory_input - To Load complete history into a temp table*/

DROP TABLE IF EXISTS stg_saleshistory_input;
create table stg_saleshistory_input(
        period varchar(100) ,
        custhier01 varchar(100) ,
        maingroup varchar(100) ,
        grp varchar(100) ,
        material varchar(100) ,
        plnt varchar(100) ,
        orderquantity varchar(100) 
);
-- RUN ON INT1 
/* change the input filename */
/*Load the data into Stg table using vwload command - stg_saleshistory_input  */
/*INPUT FLAT FILE LOCATION SHOULD BE --> Flat File path : /home/fusionops/ispring/import/textron/Greenlee_full_history_upto_may15.txt */

/home/fusionops/ispring/db/schema_migration/bin/wrapper_loadtable_vw.sh 10.102.4.160 textron stg_saleshistory_input Period,CustHier01,Maingroup,Grp,Material,Plnt,OrderQuantity /home/fusionops/ispring/import/Textron/Greenlee_full_history_upto_may15.txt ',' nodf null_blank skipheader_yes noescape noenclosed ISO88591

/* create full history table (One more backup table) */
DROP TABLE IF EXISTS greenlee_fullhistory_uptomay;
create table greenlee_fullhistory_uptomay
as select * from stg_saleshistory_input where 1=2;

/* Create a stage table to do calculations */
DROP TABLE IF EXISTS Stage_sales_history_input;
create table Stage_sales_history_input
as select * from greenlee_fullhistory_uptomay;

/* Table to hold the unwanted parts having custhier01 = 'A274' */
DROP TABLE IF EXISTS A274deletingparts;
create table A274deletingparts ( Material varchar(50) );

-- RUN ON INT1 
/* Load the parts to be dropped from a flat file */
/* Flat File path : /home/fusionops/work/ankita/greenlee/A274deletingparts.txt */

/home/fusionops/ispring/db/schema_migration/bin/wrapper_loadtable_vw.sh 10.102.4.160 textron A274deletingparts Material /home/fusionops/ispring/import/textron/A274deletingparts.txt ',' nodf null_blank skipheader_yes noescape noenclosed ISO88591

/* Delete unwanted parts */
delete from  Stage_sales_history_input
where material in (select material from A274deletingparts ) and custhier01 = 'A274';

/* Table to hold the unwanted parts having custhier01 = 'A017' */
DROP TABLE IF EXISTS A017deletingparts;
create table A017deletingparts ( Material varchar(50) );

/* Load the parts to be dropped from a flat file */

insert into A017deletingparts values
('50110500'),
('50607656'),
('50607663'),
('50607670'),
('50607687'),
('50607694'),
('50607700'),
('52075682'), 
('52079859');

/* Delete unwanted parts */
delete from Stage_sales_history_input
where material in (select material from A017deletingparts ) and custhier01 = 'A017';

/* update plant (plnt) to a constant value = 'abc' */
update Stage_sales_history_input
set plnt = 'abc';

/*AGGREGATION STEP - Aggregate the 'orderquantity' in table 'stage_saleshistory_greenlee' at part,plant,period */

Drop table if exists stage_saleshistory_aggregated;
Create table stage_saleshistory_aggregated
as
select material,plnt,period,sum(orderquantity) orderquantity
from Stage_sales_history_input
group by material,plnt,period
order by material,period;

/*IMPUTATIONS Script  */

drop table if exists ddate;
create table ddate (calendarmonthid varchar(10));

insert into ddate values 
('201201'),('201202'),('201203'),('201204'),('201205'),('201206'),('201207'),('201208'),('201209'),('201210'),('201211'),('201212'),
('201301'),('201302'),('201303'),('201304'),('201305'),('201306'),('201307'),('201308'),('201309'),('201310'),('201311'),('201312'),
('201401'),('201402'),('201403'),('201404'),('201405'),('201406'),('201407'),('201408'),('201409'),('201410'),('201411'),('201412'),
('201501'),('201502'),('201503'),('201504'),('201505'),('201506'),('201507'),('201508'),('201509'),('201510'),('201511'),('201512'),
('201601'),('201602'),('201603'),('201604'),('201605'),('201606'),('201607'),('201608'),('201609'),('201610'),('201611'),('201612'),
('201701'),('201702'),('201703'),('201704'),('201705');

/* Rank the months from 1 to 65 */

DROP TABLE IF EXISTS tmp_monthids_ranked;
CREATE TABLE tmp_monthids_ranked
AS
SELECT distinct calendarmonthid,rank() over(order by calendarmonthid) dd_rank_calendarid
from (select distinct calendarmonthid from ddate
    where calendarmonthid >= '201201'
    and calendarmonthid <= '201705') t
order by calendarmonthid;

/* Create the final table with rows added to missing period. */

drop table if exists stage_saleshistory_input;
create table stage_saleshistory_input
as
select p.material as material,p.plnt as plant, 
p.calendarmonthid as period, coalesce(a.orderquantity, 0) as orderquantity
from
	(select material,plnt,Calendarmonthid
	from (select material, plnt, min(period) as mindate,max(period) as maxdate
		from stage_saleshistory_aggregated
		group by material, plnt) q cross join tmp_monthids_ranked tmp 
		where tmp.calendarmonthid between q.mindate 
		and '201705' 
	)p left join stage_saleshistory_aggregated a
	on p.material = a.material
	and p.plnt = a.plnt
	and p.calendarmonthid = a.period
order by p.material, p.plnt, p.calendarmonthid;

--Imputation Ends

-- Add columns to stage_saleshistory_input for outlier handling ( ct_orderqty_outlier, ct_countofparts, dd_outlierflag)

alter table stage_saleshistory_input add column ct_orderqty_outlier decimal(18,4) not null default 0;
alter table stage_saleshistory_input add column ct_countofparts int not null default 0;
alter table stage_saleshistory_input add column dd_outlierflag varchar(7) not null default 'Not Set';

-- outlier treatment

--create a table to maintain avg, lower avg and upper avg for each part

drop table if exists tmp_sales_greenlee1;
create table tmp_sales_greenlee1
as
select material,avg(orderquantity) avgqty
from stage_saleshistory_input
group by material;

/* Add columns lessthanavg, morethanavg */

alter table tmp_sales_greenlee1 add column lessthanavg decimal(18,4);
alter table tmp_sales_greenlee1 add column morethanavg decimal(18,4);

/* Update columns lessthanavg, morethanavg */

update tmp_sales_greenlee1 set lessthanavg = avgqty - 0.2*avgqty;
update tmp_sales_greenlee1 set morethanavg = avgqty + 0.2*avgqty;

/*Create table to maintain count of each part/orderquantity pair */
drop table if exists countpartqty;
create table countpartqty
as
select material,orderquantity,count(*) counts
from stage_saleshistory_input
group by material,orderquantity
order by material,orderquantity;

 /* Add columns lessthanavg - 20% less of avg, morethanavg - 20% of more avg, avgqty - avg(orderqty), 
 rank - ranking of orderqty in asc order, rankreverse - ranking of orderqty in desc order  */

alter table countpartqty add column morethanavg decimal(18,4);
alter table countpartqty add column lessthanavg decimal(18,4);
alter table countpartqty add column avgqty decimal(18,4);
alter table countpartqty add column rank int;
alter table countpartqty add column rankreverse int;

/* Update Avg Value */
update countpartqty1 c
from tmp_sales_greenlee1 t
set c.morethanavg = t.morethanavg
where t.material = c.material;

/* Update Lower Avg Value */
update countpartqty1 c
from tmp_sales_greenlee1 t
set c.lessthanavg = t.lessthanavg
where t.material = c.material;

/* Update Upper Avg Value */
update countpartqty1 c
from tmp_sales_greenlee1 t
set c.avgqty = t.avgqty
where t.material = c.material;

/* Rank the order quantity for each material in ascending order of orderquantity */ 
drop table if exists rank_table;
create table rank_table
as
select material,orderquantity,
dense_rank() over(partition by material order by orderquantity ) as rank 
from countpartqty1;

/* Rank the order quantity for each material in descending order of order quantity */ 
drop table if exists rankreverse_table;
create table rankreverse_table
as
select material,orderquantity,
dense_rank() over(partition by material order by orderquantity desc ) as rankreverse 
from countpartqty1;

/* Update the ascending rank */
update countpartqty1  c
from rank_table f
set c.rank = f.rank
where f.material = c.material 
and f.orderquantity = c.orderquantity;

/* Update the descending rank */
update countpartqty1  c
from rankreverse_table f
set c.rankreverse = f.rankreverse
where f.material = c.material 
and f.orderquantity = c.orderquantity;

/* Outlier Logic - 

Case 1: There is no outlier. 
Action: Do not do anything. 

Case 2: There's only 1 DISTINCT outlier. 
Action: Replace that outlier with mean

Case 3: There are exactly 2 DISTINCT outliers e.g 65 and 75. 
Action: Replace both with 100. 

Case 4: There are 6 outliers with some duplicates. e.g 65,65,65, 75,77,79
Action: Replace 65's if their count is < 2. Here, even if we consider the lowest point(65), it has > 3 rows. So, do not update anything. 

Case 5: There are 6 outliers with some duplicates. e.g 65, 75,75,75,75,75
Action: Replace only 65. Do not replace 75 as that will change the count of updated points to > 2. 

Case 6: There are 3 outliers with some duplicates. e.g 65, 65,75
Action: Replace only 65. As count of 2 is reached at 65, no need to replace 75. */

/* Part/orderqty pair having rank = 1(Least Orderqty) and count = 2 */
update stage_saleshistory_input f 
from countpartqty1 c 
set ct_orderqty_outlier = avgqty 
where rank = 1 and counts = 2 
and f.material = c.material 
and f.orderquantity = c.orderquantity 
and f.orderquantity < lessthanavg;

/* Part/orderqty pair having rank_reverse = 1(Highest Orderqty) and count = 2 */
update stage_saleshistory_input f 
from countpartqty1 c 
set ct_orderqty_outlier = avgqty 
where rankreverse = 1 and counts = 2 
and f.material = c.material 
and f.orderquantity = c.orderquantity 
and f.orderquantity > morethanavg;

/* Part/orderqty pair having rank = 1(Least Orderqty) and count = 1 */
update stage_saleshistory_input f 
from countpartqty1 c 
set ct_orderqty_outlier = avgqty 
where rank = 1 and counts = 1 
and f.material = c.material 
and f.orderquantity = c.orderquantity 
and f.orderquantity < lessthanavg;

/* Part/orderqty pair having rank_reverse = 1(Highest Orderqty) and count = 1 */
update stage_saleshistory_input f 
from countpartqty1 c 
set ct_orderqty_outlier = avgqty 
where rankreverse = 1 and counts = 1 
and f.material = c.material 
and f.orderquantity = c.orderquantity 
and f.orderquantity > morethanavg;

/* Table holding parts having rank = 1/2 and count = 1 */
drop table if exists twomaterial1;
create table twomaterial1
as 
select * from countpartqty1 c 
where rank = 1 and counts = 1 
or rank = 2 and counts = 1;

/* Table holding parts having count = 1 and same part exists twice in above table(for rank = 1 and rank = 2) */
drop table if exists two_material1;
create table two_material1 
as select * from twomaterial1 
where material in 
(select material from twomaterial1 group by material having count(*) = 2);

/* Table holding parts having rank_reverse = 1/2 and count = 1 */
drop table if exists twomaterialreverse1;
create table twomaterialreverse1
as 
select * from countpartqty1 c 
where rankreverse = 1 and counts = 1 
or rankreverse = 2 and counts = 1;

/* Table holding parts having count = 1 and same part exists twice in above table(for rank_reverse = 1 and rank = 2) */
drop table if exists two_materialreverse1;
create table two_materialreverse1 
as select * from twomaterialreverse1 
where material in 
(select material from twomaterialreverse1 group by material having count(*) = 2);

/* Update orderqty to avg value where rank = 2 and count = 1 */
update  stage_saleshistory_input f 
from two_material1 c 
set ct_orderqty_outlier = avgqty 
where rank = 2 and counts = 1 
and f.material = c.material 
and f.orderquantity = c.orderquantity 
and f.orderquantity < lessthanavg;

/* Update orderqty to avg value where rank_reverse = 2 and count = 1 */
update stage_saleshistory_input f 
from two_materialreverse1 c 
set ct_orderqty_outlier = avgqty 
where rankreverse = 2 and counts = 1 
and f.material = c.material 
and f.orderquantity = c.orderquantity 
and f.orderquantity > morethanavg;

/* Apply Order qty outlier = order qty where it is not an outlier */
update stage_saleshistory_input
set ct_orderqty_outlier = orderquantity 
where ct_orderqty_outlier = 0;

/* Set the outlier flag to 'Y' where orderqty is updated to Avg */
update  stage_saleshistory_input
 set dd_outlierflag = 'Y'
 where orderquantity <> ct_orderqty_outlier;
  
/* Set the outlier flag to 'N' where orderqty not updated to Avg */
 update stage_saleshistory_input 
 set dd_outlierflag = 'N'
 where dd_outlierflag = 'Not Set';
 
/* Table containing count of non-0 orderqty value for each part */
drop table if exists tmp_countofparts;
create table tmp_countofparts 
as 
select count(period) ct_countofparts,material 
from  stage_saleshistory_input
where orderquantity <> 0
group by material 
order by material;

/* Update ct_countofparts in the stage table */
update stage_saleshistory_input s 
from tmp_countofparts t 
set s.ct_countofparts = t.ct_countofparts 
where s.material = t.material;

-- Outlier Treatment Ends 

/* Applying logic as 
	i. check minimum history (minimum should be 12)
	ii. minimum 1 non-0 sales in holdout period (holdout period - Mar17, Apr17, May17) */

Drop table if exists forecast_input_greenlee;
create table forecast_input_greenlee
as
select *
from stage_saleshistory_input
where ct_countofparts >= 12
and material in 
	(select material 
	from stage_saleshistory_input
	where period in ('201703','201704','201705') -- Current date to 2 months behind 
	and ct_orderqty_outlier <> 0
	group by material
	having count(ct_orderqty_outlier) >= 1)
order by material,period;

/* Prepare a final table from stage table having format as required for forecast input. 5 columns - part,plat,dd_level2, period, orderqty */
DROP TABLE IF EXISTS input_file_greenlee_may17;
create table input_file_greenlee_may17
as 
select material, plant, 'abc' dd_level2, period, ct_orderqty_outlier
from Forecast_input_greenlee;

?
/* Take bcp of input_file_greenlee_may17 to create a flat file*/
/* Not sur ehow this can be done on AWS STG */


------------------------------------------End of Preparation Of Input File-----------------------------------------------------------------------


