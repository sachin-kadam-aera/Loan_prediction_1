/* v4.4: Add D-chain and delivery plant. Also added last 2 queries to prepare output forecast flat file for Greenlee ftp */
/* v4.01 with finmonth */
/* v2.1 : Add Selling price */

/* Truncate stage_fosalesforecast */
DROP TABLE IF EXISTS stage_fosalesforecast;
create table stage_fosalesforecast(
        dd_forecastdate integer not null default 1,
        partnumber varchar(50) collate ucs_basic,
        plantcode varchar(20) collate ucs_basic,
        ct_salesquantity decimal(36,6),
        ct_mape decimal(36,6),
        dd_forecastsample varchar(50) not null default 'Not Set' collate ucs_basic,
        dd_forecasttype varchar(50) not null default 'Not Set' collate ucs_basic,
        dd_forecastrank integer not null default 0,
        dd_forecastmode varchar(50) not null default 'Not Set' collate ucs_basic,
        dd_companycode varchar(50) not null default 'Not Set' collate ucs_basic,
        ct_highpi decimal(36,6),
        ct_lowpi decimal(36,6),
        dd_lastdate varchar(50) not null default 'NA' collate ucs_basic,
        dd_holdoutdate varchar(50) not null default 'NA' collate ucs_basic,
        dd_reportingdate varchar(50) not null default 'NA' collate ucs_basic,
        dd_bias_error decimal(18,6),
        dd_bias_error_rank decimal(18,6),
        ct_forecastquantity decimal(36,6),
        dd_csdmaterialstatuscode varchar(7) collate ucs_basic,
        dd_deliveryplant varchar(7) collate ucs_basic
);

/* Populate latest forecast output file in table - stage_fosalesforecast */
/* change the input filename */
/home/fusionops/ispring/db/schema_migration/bin/wrapper_loadtable_vw.sh 10.102.4.160 textron stage_fosalesforecast dd_reportingdate,dd_forecastdate,partnumber,plantcode,ct_salesquantity,ct_forecastquantity,ct_lowpi,ct_highpi,ct_mape,dd_lastdate,dd_holdoutdate,dd_forecastsample,dd_forecasttype,dd_forecastrank,dd_forecastmode,dd_companycode,dd_bias_error_rank,dd_bias_error /home/fusionops/ispring/import/Textron444/fcst_900parts_withplant_18jun_textron_2017_06_19__06_37.csv ',' nodf null_blank skipheader_yes noescape noenclosed ISO88591

DROP TABLE IF EXISTS tmp_part_dchain_dlvrplant;
CREATE TABLE tmp_part_dchain_dlvrplant
as
select distinct
partnumber,
CSDMaterialStatusCode,
DeliveryPlant,
salesorgcode
FROM dim_partsales
WHERE CSDMaterialStatusCode in ('04','09','12','10')
AND salesorgcode = '1300';

DROP TABLE IF EXISTS tmp_dim_partsales_distinct_nosalesorg;
CREATE TABLE tmp_dim_partsales_distinct_nosalesorg
AS
SELECT d.partnumber,d.deliveryplant,min(dim_partsalesid) dim_partsalesid
FROM dim_partsales d 
WHERE EXISTS ( SELECT 1 
		FROM tmp_part_dchain_dlvrplant t 
		WHERE t.partnumber = d.partnumber
		AND t.salesorgcode = d.salesorgcode
		AND t.DeliveryPlant = d.DeliveryPlant
		AND t.CSDMaterialStatusCode = d.CSDMaterialStatusCode
			)
GROUP BY d.partnumber,d.deliveryplant;

DROP TABLE IF EXISTS tmp_dim_part_minid;
CREATE TABLE tmp_dim_part_minid
AS
SELECT DISTINCT dp1.*
FROM dim_part dp1,tmp_dim_partsales_distinct_nosalesorg t
WHERE dp1.partnumber = t.partnumber
AND dp1.plant = t.DeliveryPlant;

UPDATE stage_fosalesforecast sf
FROM tmp_dim_part_minid dp
SET plantcode = dp.plant
WHERE lpad(sf.partnumber,18,'0') = lpad(dp.partnumber,18,'0');

UPDATE stage_fosalesforecast sf
FROM tmp_part_dchain_dlvrplant t
SET sf.dd_CSDMaterialStatusCode = t.CSDMaterialStatusCode
WHERE lpad(sf.partnumber,18,'0') = lpad(t.partnumber,18,'0');

UPDATE stage_fosalesforecast sf
FROM tmp_part_dchain_dlvrplant t
SET sf.dd_deliveryplant = t.deliveryplant
WHERE lpad(sf.partnumber,18,'0') = lpad(t.partnumber,18,'0');

drop table if exists fact_fosalesforecast_temp;
create table fact_fosalesforecast_temp as
select * from fact_fosalesforecast WHERE 1=2;

DROP TABLE IF EXISTS tmp_maxrptdate;
CREATE TABLE tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from stage_fosalesforecast ;

DELETE FROM fact_fosalesforecast
where cast(dd_reportingdate as date) in ( select dd_reportingdate from tmp_maxrptdate);

alter table fact_fosalesforecast_temp add column dd_forecastdatevalue ansidate not null default '1900-01-01';

delete from number_fountain m WHERE m.table_name = 'fact_fosalesforecast';

insert into number_fountain
select 	'fact_fosalesforecast',
	ifnull(max(d.fact_fosalesforecastid),
			ifnull((select s.dim_projectsourceid * s.multiplier from dim_projectsource s),0))
		from fact_fosalesforecast d
		WHERE d.fact_fosalesforecastid <> 1;

insert into fact_fosalesforecast_temp
(
	fact_fosalesforecastid,
	dim_partid,
	dim_plantid,
	dd_companycode,
	dd_reportingdate,
	dim_dateidreporting,
	dd_forecasttype,
	dd_forecastsample,
	dd_forecastdate,
	dim_dateidforecast,
	ct_salesquantity,
	ct_forecastquantity,
	ct_lowpi,
	ct_highpi,
	ct_mape,
	dd_forecastrank,
	dd_holdoutdate,
	dd_lastdate,
	dd_forecastmode,
	dd_forecastdatevalue,
	dd_bias_error,
	dd_bias_error_rank,
        dd_financialmonthyear,
	dd_CSDMaterialStatusCode,dd_deliveryplant,
	dd_partnumber
)
select 	(select ifnull(m.max_id, 0) from number_fountain m WHERE m.table_name = 'fact_fosalesforecast') + row_number() over() as fact_fosalesforecastid,
ifnull(dp.dim_partid,1),
ifnull(pl.dim_plantid,1) as dim_plantid,
ifnull(sf.dd_companycode,'Not Set'),
ifnull(cast(sf.dd_reportingdate as date),'1 Jan 1900'),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
--cast(to_char(finmo.dd_forecastdate , 'YYYYMMDD') as int) dd_forecastdate, 
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mape,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
case when sf.dd_forecastdate is null then cast('1900-01-01' as ansidate)
else cast(concat(substring(sf.dd_forecastdate,1,4) , '-' ,
	substring(sf.dd_forecastdate,5,2) , '-' ,
	substring(sf.dd_forecastdate,7,2) ) as ansidate)
end dd_forecastdatevalue,
dd_bias_error,
dd_bias_error_rank,
substr(sf.dd_forecastdate,0,4) || substr(sf.dd_forecastdate,5,2) dd_financialmonthyear,
	sf.dd_CSDMaterialStatusCode,sf.dd_deliveryplant,lpad(sf.partnumber,18,'0') dd_partnumber
from stage_fosalesforecast sf /*inner join tmp_dim_partsales_distinct_nosalesorg d on d.partnumber = lpad(sf.partnumber,18,'0') and d.deliveryplant = sf.plantcode*/
LEFT OUTER join tmp_dim_part_minid dp on dp.partnumber = lpad(sf.partnumber,18,'0') AND dp.plant = sf.plantcode
LEFT OUTER join dim_plant pl on pl.plantcode = sf.plantcode ;

select count(distinct lpad(sf.partnumber,18,'0')) from stage_fosalesforecast sf;
select count(distinct dd_partnumber) from fact_fosalesforecast_temp;

UPDATE fact_fosalesforecast_temp f
from dim_date d
SET f.dim_dateidreporting = d.dim_dateid,
 f.dw_update_date = current_timestamp
where   d.companycode = 'Not Set' AND to_date(f.dd_reportingdate,'YYYY-MM-DD') = d.datevalue;

UPDATE fact_fosalesforecast_temp f
from dim_date d,dim_plant pl
SET f.dim_dateidforecast = d.dim_dateid,
    f.dw_update_date = current_timestamp
WHERE f.dd_forecastdatevalue = d.datevalue and f.dim_plantid = pl.dim_plantid
AND d.companycode = pl.companycode
AND f.dim_dateidforecast <> d.dim_dateid;
/*WHERE 	d.companycode = 'Not Set' AND f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid*/


insert into fact_fosalesforecast
(
	fact_fosalesforecastid,
	dim_partid,
	dim_plantid,
	dd_companycode,
	dd_reportingdate,
	dim_dateidreporting,
	dd_forecasttype,
	dd_forecastsample,
	dd_forecastdate,
	dim_dateidforecast,
	ct_salesquantity,
	ct_forecastquantity,
	ct_lowpi,
	ct_highpi,
	ct_mape,
	dd_forecastrank,
	dd_holdoutdate,
	dd_lastdate,
	dd_forecastmode,
	dd_bias_error,
	dd_bias_error_rank,dd_financialmonthyear,
	dd_CSDMaterialStatusCode,dd_deliveryplant,dd_partnumber
)
select
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
dd_bias_error,
dd_bias_error_rank,dd_financialmonthyear,
dd_CSDMaterialStatusCode,dd_deliveryplant,dd_partnumber
from fact_fosalesforecast_temp;

/* dd_reportingdate is varchar(50). Format it to DD MON YYYY instead of showing up as yyyy-mm-dd. */
UPDATE fact_fosalesforecast f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD MON YYYY')
where f.dd_reportingdate like '%-%-%';

UPDATE fact_fosalesforecast f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE fact_fosalesforecast f
FROM tmp_maxrptdate r
SET dd_latestreporting = 'Yes'
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;

/* Update future sales to NULL */
UPDATE fact_fosalesforecast f
FROM dim_date d
SET ct_salesquantity = NULL
WHERE ct_salesquantity = 0
AND f.dim_dateidforecast = d.dim_dateid
AND d.datevalue >= cast(dd_lastdate as date);

/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE fact_fosalesforecast f
set ct_highpi = NULL
WHERE ct_highpi = 0
AND dd_forecastsample = 'Train';

UPDATE fact_fosalesforecast f
set ct_lowpi = NULL
WHERE ct_lowpi = 0
AND dd_forecastsample = 'Train';



/* Rerank for mult forecasts having same ranks */

DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf;
CREATE TABLE tmp_upd_fcstrank_fosf
as
select distinct f.dd_reportingdate,dim_partid,dim_plantid,dd_forecasttype,dd_forecastrank
from fact_fosalesforecast f,tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;

--This should insert 0 rows as for same fcst type, there cannot be different ranks
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dim_partid = t2.dim_partid
and t1.dim_plantid = t2.dim_plantid
and t1.dd_forecasttype = t2.dd_forecasttype
and t1.dd_forecastrank <> t2.dd_forecastrank;


--These are the cases with issues ( different methods, same rank )
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dim_partid = t2.dim_partid
and t1.dim_plantid = t2.dim_plantid
and t1.dd_forecasttype <> t2.dd_forecasttype
and t1.dd_forecastrank = t2.dd_forecastrank;

--Get all rows corresponding to these rptdate,dmdunit,loc
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf3;
CREATE TABLE tmp_upd_fcstrank_fosf3
as
select t1.*,rank() over(partition by dd_reportingdate,dim_partid,dim_plantid  order by dd_forecastrank,dd_forecasttype) dd_rank_new
from tmp_upd_fcstrank_fosf t1
WHERE EXISTS ( SELECT 1 FROM tmp_upd_fcstrank_fosf2 t2 where t1.dd_reportingdate = t2.dd_reportingdate and t1.dim_partid = t2.dim_partid and t1.dim_plantid = t2.dim_plantid);


UPDATE fact_fosalesforecast f
FROM tmp_upd_fcstrank_fosf3 t
SET f.dd_forecastrank = t.dd_rank_new
where f.dd_reportingdate = t.dd_reportingdate
and f.dim_partid = t.dim_partid
and f.dim_plantid = t.dim_plantid
and f.dd_forecastrank = t.dd_forecastrank
and f.dd_forecasttype = t.dd_forecasttype;

/* Get latest SO date for each part before the reporting date */
DROP TABLE IF EXISTS tmp_ds_latestso;
CREATE TABLE tmp_ds_latestso
AS
SELECT fs2.dim_partid,max(socreated.datevalue) latestSOdate
FROM fact_salesorder fs2 ,dim_date socreated
WHERE fs2.dim_dateidsalesordercreated = socreated.dim_dateid
AND socreated.datevalue <= ( SELECT max(to_date(dd_reportingdate,'DD MON YYYY')) from fact_fosalesforecast )
AND fs2.ct_ScheduleQtySalesUnit > 0 AND fs2.amt_ScheduleTotal > 0
GROUP BY fs2.dim_partid;

/* Take average CP and SP of SOs on the latest SO creation date before fcst reporting date */
DROP TABLE IF EXISTS tmp_ds_latestsocpsp;
CREATE TABLE tmp_ds_latestsocpsp
AS
SELECT fs2.dim_partid,dp.partnumber,
AVG(amt_StdCost * fs2.amt_exchangerate_gbl/fs2.ct_ScheduleQtySalesUnit) amt_AvgCostPriceLatest_GBL,
/*AVG((fs2.amt_UnitPrice/case when ct_priceunit > 0 then ct_priceunit else 1 end) * fs2.amt_exchangerate_gbl) amt_AvgSellingPriceLatest_GBL*/
/*AVG((fs2.amt_UnitPriceUoM/case when ct_priceunit > 0 then ct_priceunit else 1 end) * fs2.amt_exchangerate_gbl) amt_AvgSellingPriceLatest_GBL*/
AVG(fs2.amt_ScheduleTotal * fs2.amt_exchangerate_gbl/fs2.ct_ScheduleQtySalesUnit) amt_AvgSellingPriceLatest_GBL
FROM fact_salesorder fs2 inner join dim_part dp on fs2.dim_partid = dp.dim_partid
INNER JOIN tmp_ds_latestso l ON fs2.dim_partid = l.dim_partid
INNER JOIN dim_date socreated ON fs2.dim_dateidsalesordercreated = socreated.dim_dateid AND socreated.datevalue = l.latestSOdate
WHERE fs2.ct_ScheduleQtySalesUnit > 0 AND fs2.amt_ScheduleTotal > 0 /*AND ct_priceunit > 0*/
GROUP BY fs2.dim_partid,dp.partnumber;

UPDATE fact_fosalesforecast fs2
FROM tmp_ds_latestsocpsp t
set fs2.amt_unitsellingprice_usd = t.amt_AvgSellingPriceLatest_GBL
WHERE fs2.dim_partid = t.dim_partid;

select *
from tmp_ds_latestsocpsp
WHERE partnumber like '%50000446%';

SELECT max(to_date(dd_reportingdate,'DD MON YYYY')) from fact_fosalesforecast;
update fact_fosalesforecast f
from dim_part dp, dim_producthierarchy ph
SET f.dim_producthierarchyid = ph.dim_producthierarchyid
WHERE f.dim_partid = dp.dim_partid
AND dp.ProductHierarchy = ph.ProductHierarchy;


call vectorwise(combine 'fact_fosalesforecast');
DROP TABLE IF EXISTS tmp_partvsmape;
CREATE TABLE tmp_partvsmape
AS
SELECT DISTINCT f.dim_partid,f.dim_plantid,
f.dd_reportingdate, f.dd_forecasttype,f.dd_forecastrank,ct_mape
FROM fact_fosalesforecast f inner join tmp_maxrptdate r on TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
WHERE dd_forecastsample = 'Test';

DROP TABLE IF EXISTS tmp_partvsmape_rerank;
CREATE TABLE tmp_partvsmape_rerank
AS
SELECT f.*,rank() over(partition by f.dim_plantid,f.dim_partid, f.dd_reportingdate order by ct_mape,dd_forecasttype desc) dd_rank
FROM tmp_partvsmape f;


UPDATE fact_fosalesforecast f
FROM tmp_partvsmape_rerank t
SET f.dd_forecastrank = t.dd_rank
WHERE f.dim_partid = t.dim_partid AND f.dim_plantid = t.dim_plantid
AND f.dd_reportingdate = t.dd_reportingdate
AND f.dd_forecasttype = t.dd_forecasttype;

call vectorwise (combine 'fact_fosalesforecast');


/* Create table for ftp to greenlee */
/*part, period, forecast, type, rank, delivery plant, d-chain value*/

DROP TABLE IF EXISTS tmp_forecastoutputforftp_onlyrank1;
CREATE TABLE tmp_forecastoutputforftp_onlyrank1
AS
SELECT f.dd_partnumber partnumber,d.calendarmonthid period,round(f.ct_forecastquantity,2) ForecastQty,
f.dd_forecasttype "ForecastType",f.dd_forecastrank "ForecastRank",
f.dd_deliveryplant "DeliveryPlant" ,dd_CSDMaterialStatusCode "DChainSpecStatusCode"
FROM fact_fosalesforecast f inner join dim_date d on f.dim_dateidforecast = d.dim_dateid
WHERE f.dd_forecastrank = 1
AND f.dd_latestreporting = 'Yes'
AND f.dd_forecastsample = 'Horizon'
ORDER BY f.dd_partnumber,d.calendarmonthid;


DROP TABLE IF EXISTS tmp_forecastoutputforftp_onlyrandomforest;
CREATE TABLE tmp_forecastoutputforftp_onlyrandomforest
AS
SELECT f.dd_partnumber partnumber,d.calendarmonthid period,round(f.ct_forecastquantity,2) ForecastQty,
f.dd_forecasttype "ForecastType",f.dd_forecastrank "ForecastRank",
f.dd_deliveryplant "DeliveryPlant" ,dd_CSDMaterialStatusCode "DChainSpecStatusCode"
FROM fact_fosalesforecast f inner join dim_date d on f.dim_dateidforecast = d.dim_dateid
WHERE f.dd_forecasttype = 'Random Forest'
AND f.dd_latestreporting = 'Yes'
AND f.dd_forecastsample = 'Horizon'
ORDER BY f.dd_partnumber,d.calendarmonthid;


