
/* Create table for ftp to greenlee */
/*part, period, forecast, type, rank, delivery plant, d-chain value*/

DROP TABLE IF EXISTS tmp_part_dchain_dlvrplant;
CREATE TABLE tmp_part_dchain_dlvrplant
as
select distinct
partnumber,
CSDMaterialStatusCode,
DeliveryPlant,
salesorgcode
FROM dim_partsales
WHERE CSDMaterialStatusCode in ('04','09','12','10')
AND salesorgcode = '1300';

SELECT *
FROM tmp_part_dchain_dlvrplant
WHERE partnumber like '%50017071%';

DROP TABLE IF EXISTS tmp_dim_partsales_distinct_nosalesorg;
CREATE TABLE tmp_dim_partsales_distinct_nosalesorg
AS
SELECT d.partnumber,d.deliveryplant,min(dim_partsalesid) dim_partsalesid
FROM dim_partsales d
WHERE EXISTS ( SELECT 1
                FROM tmp_part_dchain_dlvrplant t
                WHERE t.partnumber = d.partnumber
                AND t.salesorgcode = d.salesorgcode
                AND t.DeliveryPlant = d.DeliveryPlant
                AND t.CSDMaterialStatusCode = d.CSDMaterialStatusCode
                        )
GROUP BY d.partnumber,d.deliveryplant;

DROP TABLE IF EXISTS tmp_stage_fosalesforecast_outputfile;
CREATE TABLE tmp_stage_fosalesforecast_outputfile
AS
SELECT * FROM stage_fosalesforecast;

UPDATE tmp_stage_fosalesforecast_outputfile sf
FROM tmp_part_dchain_dlvrplant t
SET sf.dd_CSDMaterialStatusCode = t.CSDMaterialStatusCode
WHERE lpad(sf.partnumber,18,'0') = lpad(t.partnumber,18,'0');

UPDATE tmp_stage_fosalesforecast_outputfile sf
FROM tmp_part_dchain_dlvrplant t
SET sf.dd_deliveryplant = t.deliveryplant
WHERE lpad(sf.partnumber,18,'0') = lpad(t.partnumber,18,'0');

UPDATE tmp_stage_fosalesforecast_outputfile
SET dd_deliveryplant = 'Not Set'
WHERE dd_deliveryplant IS NULL;

UPDATE tmp_stage_fosalesforecast_outputfile
SET dd_CSDMaterialStatusCode = 'Not Set'
WHERE dd_CSDMaterialStatusCode IS NULL;

DROP TABLE IF EXISTS tmp_partvsmape;
CREATE TABLE tmp_partvsmape
AS
SELECT DISTINCT f.partnumber,f.dd_deliveryplant,
f.dd_reportingdate, f.dd_forecasttype,f.dd_forecastrank,ct_mape
FROM tmp_stage_fosalesforecast_outputfile f 
WHERE dd_forecastsample = 'Test';

DROP TABLE IF EXISTS tmp_partvsmape_rerank;
CREATE TABLE tmp_partvsmape_rerank
AS
SELECT f.*,rank() over(partition by f.partnumber,f.dd_deliveryplant, f.dd_reportingdate order by ct_mape asc,dd_forecasttype desc) dd_rank
FROM tmp_partvsmape f;


UPDATE tmp_stage_fosalesforecast_outputfile f
FROM tmp_partvsmape_rerank t
SET f.dd_forecastrank = t.dd_rank
WHERE f.partnumber = t.partnumber AND f.dd_deliveryplant = t.dd_deliveryplant
AND f.dd_reportingdate = t.dd_reportingdate
AND f.dd_forecasttype = t.dd_forecasttype;

DROP TABLE IF EXISTS tmp_forecastoutputforftp_onlyrank1;
CREATE TABLE tmp_forecastoutputforftp_onlyrank1
AS
SELECT f.partnumber,f.dd_forecastdate period,round(f.ct_forecastquantity,2) ForecastQty,
f.dd_forecasttype "ForecastType",f.dd_forecastrank "ForecastRank",
f.dd_deliveryplant "DeliveryPlant" ,f.dd_CSDMaterialStatusCode "DChainSpecStatusCode",
f.ct_mape "MAPE"
FROM tmp_stage_fosalesforecast_outputfile f
WHERE f.dd_forecastrank = 1
AND f.dd_forecastsample = 'Horizon'
ORDER BY f.partnumber,f.dd_forecastdate;


DROP TABLE IF EXISTS tmp_forecastoutputforftp_onlyrandomforest;
CREATE TABLE tmp_forecastoutputforftp_onlyrandomforest
AS
SELECT f.partnumber,f.dd_forecastdate period,round(f.ct_forecastquantity,2) ForecastQty,
f.dd_forecasttype "ForecastType",f.dd_forecastrank "ForecastRank",
f.dd_deliveryplant "DeliveryPlant" ,f.dd_CSDMaterialStatusCode "DChainSpecStatusCode",
f.ct_mape "MAPE"
FROM tmp_stage_fosalesforecast_outputfile f 
WHERE f.dd_forecasttype = 'Random Forest'
AND f.dd_forecastsample = 'Horizon'
ORDER BY f.partnumber,f.dd_forecastdate;
DROP TABLE IF EXISTS tmp_forecastoutputforftp_rank1andrandomforest;
CREATE TABLE tmp_forecastoutputforftp_rank1andrandomforest
AS
SELECT f.partnumber,substr(f.dd_forecastdate,0,6) period,cast(round(f.ct_forecastquantity,0) as decimal(12,0)) ForecastQty,
f.dd_forecasttype "ForecastType",f.dd_forecastrank "ForecastRank",
f.dd_deliveryplant "DeliveryPlant" ,f.dd_CSDMaterialStatusCode "DChainSpecStatusCode",
cast(f.ct_mape as decimal(12,2)) "MAPE"
FROM tmp_stage_fosalesforecast_outputfile f
WHERE f.dd_forecastrank = 1
AND f.dd_forecastsample = 'Horizon'
AND f.dd_forecasttype <> 'Random Forest'
AND f.dd_deliveryplant <> 'Not Set'
ORDER BY f.partnumber,f.dd_forecastdate;

DROP TABLE IF EXISTS tmp_forecastoutputforftp_onlyrandomforest;
CREATE TABLE tmp_forecastoutputforftp_onlyrandomforest
AS
SELECT f.partnumber,substr(f.dd_forecastdate,0,6) period,cast(round(f.ct_forecastquantity,0) as decimal(12,0)) ForecastQty,
f.dd_forecasttype "ForecastType",f.dd_forecastrank "ForecastRank",
f.dd_deliveryplant "DeliveryPlant" ,f.dd_CSDMaterialStatusCode "DChainSpecStatusCode",
cast(f.ct_mape as decimal(12,2)) "MAPE"
FROM tmp_stage_fosalesforecast_outputfile f
WHERE f.dd_forecasttype = 'Random Forest'
AND f.dd_forecastsample = 'Horizon'
AND f.dd_deliveryplant <> 'Not Set'
ORDER BY f.partnumber,f.dd_forecastdate;

INSERT INTO tmp_forecastoutputforftp_rank1andrandomforest
SELECT *
FROM tmp_forecastoutputforftp_onlyrandomforest;
