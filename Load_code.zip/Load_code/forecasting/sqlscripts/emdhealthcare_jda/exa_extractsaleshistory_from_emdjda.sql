open schema emd586;
/* Create temp tables */
DROP TABLE IF EXISTS emd586.stage_fosalesforecast;
create table emd586.stage_fosalesforecast(
dd_forecastdate integer default 1,
dim_partid int default 1,
dd_level2 varchar(50) default 'Not Set',
ct_salesquantity decimal(36,6), 
ct_mape decimal(36,6) ,
dd_forecastsample varchar(50) default 'Not Set',
dd_forecasttype varchar(50) default 'Not Set',
dd_forecastrank integer default 0,
dd_forecastmode varchar(50) default 'Not Set',
dd_companycode varchar(50) default 'Not Set',
ct_highpi decimal(36,6) ,
ct_lowpi decimal(36,6) ,
dd_lastdate varchar(50) default 'NA',
dd_holdoutdate varchar(50) default 'NA',
dd_reportingdate varchar(50) default 'NA',
dd_bias_error decimal(18,6),
dd_bias_error_rank decimal(18,6),
ct_forecastquantity decimal(36,6)
);

/***********************************************************************************************************************************/
/* Section 1: Export Sales/Shipment/Billing Data to stage_saleshistory.txt */
/***********************************************************************************************************************************/
/* Get the Min AND Max Dates For Creating a List of Year Month Periods */
/*  Fact used: Sales Order
Date used: Sched Dlvry Date */
/* ( Fact/Date may change depending on customer) */


/* Create a de-normalized table containing data from Sales Order */
DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
CREATE TABLE emd586.tmp_sod_denorm_fcst
AS
SELECT scheddlvrdate.datevalue scheddlvrdate,scheddlvrdate.calendarmonthid, s.STSC_HIST_DMDUNIT partnumber,s.STSC_HIST_LOC plantcode, 
SUM(CASE WHEN STSC_HIST_TYPE = 1 THEN 1 ELSE -1 END * s.STSC_HIST_QTY ) ct_salesquantity
FROM emdtempocc4.STSC_HIST s INNER JOIN emdtempocc4.dim_date scheddlvrdate ON scheddlvrdate.datevalue = s.STSC_HIST_STARTDATE
WHERE scheddlvrdate.companycode = 'Not Set'
AND STSC_HIST_EVENT NOT LIKE '%AUTO-CORRECT%'
AND EXISTS ( SELECT 1 FROM emdtempocc4.stsc_dfuview dfuview where dfuview.STSC_DFUVIEW_DMDUNIT = s.STSC_HIST_DMDUNIT AND dfuview.STSC_DFUVIEW_LOC = s.STSC_HIST_LOC AND dfuview.STSC_DFUVIEW_UDC_FCSTLEVEL  = '111')
AND NOT EXISTS ( SELECT 1 FROM emdtempocc4.stsc_dfuview d2 where d2.STSC_DFUVIEW_DMDUNIT = s.STSC_HIST_DMDUNIT AND d2.STSC_DFUVIEW_LOC = s.STSC_HIST_LOC AND d2.STSC_DFUVIEW_UDC_DFULIFECYCLE like 'O%')
GROUP BY scheddlvrdate.datevalue,scheddlvrdate.calendarmonthid,s.STSC_HIST_DMDUNIT,s.STSC_HIST_LOC;

/* Get all dim_partids which have atleast 18 months non-zero sales in last 2 calendar years - e.g if this is run in Apr 2016, it wil get all parts which have atleast 18 months data from Jan 2014 */
drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
create table emd586.tmp_saleshistory_grain_reqmonths
as
select distinct f.partnumber,plantcode
FROM (select distinct partnumber,plantcode,calendarmonthid FROM emd586.tmp_sod_denorm_fcst WHERE year(scheddlvrdate) >= year(current_date) - 2) f
group by f.partnumber,plantcode
having count(*) >= 18;

/* Remove all  rows from denorm WHERE less than 18 month data is available */
DELETE FROM emd586.tmp_sod_denorm_fcst f
WHERE NOT EXISTS ( SELECT 1 FROM emd586.tmp_saleshistory_grain_reqmonths t
WHERE t.partnumber = f.partnumber AND t.plantcode = f.plantcode);

drop table if exists emd586.tmp_saleshistory_grain_reqmonths;

/* CHC filter is optional. Can be used at the time of using reports */
/*DELETE FROM emd586.tmp_sod_denorm_fcst t
WHERE EXISTS ( SELECT 1 FROM emdtempocc4.dmdunit d where d.DMDUNIT_DMDUNIT = t.partnumber AND d.DMDUNIT_UDC_STRENGTH = 'CHC')
AND t.plantcode = 'LATAM'*/

/* Get the min AND max Sched Dlvry Date */
drop table if exists emd586.tmp_saleshistory_daterange;
create table emd586.tmp_saleshistory_daterange as
select max(scheddlvrdate.datevalue) maxdate, min(scheddlvrdate.datevalue) mindate
from emdtempocc4.STSC_HIST fs1, emdtempocc4.dim_date scheddlvrdate
WHERE fs1.STSC_HIST_STARTDATE = scheddlvrdate.datevalue AND scheddlvrdate.companycode = 'Not Set'
AND year(scheddlvrdate.datevalue) >= year(current_date) - 10;

/* Get all Year Month Periods based on Min AND Max Dates */
drop table if exists emd586.tmp_saleshistory_yyyymm;
create table emd586.tmp_saleshistory_yyyymm as
select distinct calendaryear, calendarmonthnumber, calendarmonthid --, datevalue
from emdtempocc4.dim_date, emd586.tmp_saleshistory_daterange
WHERE datevalue between mindate AND maxdate
AND dayofmonth = 1
AND companycode = 'Not Set'
order by calendarmonthid;
--order by datevalue

/* Create final table for bcp out */
DROP TABLE IF EXISTS emd586.stage_saleshistory1;
CREATE TABLE emd586.stage_saleshistory1
AS
SELECT
partnumber,plantcode as plantcode, 'ALL' as dd_companycode,
f.calendarmonthid yyyymm,
sum(f.ct_salesquantity) ct_salesquantity
FROM emd586.tmp_sod_denorm_fcst f
GROUP BY f.partnumber,plantcode,f.calendarmonthid
ORDER BY f.partnumber,plantcode,f.calendarmonthid;

/* Populate 0 qty in those months WHERE there were no sales */
INSERT INTO emd586.stage_saleshistory1
SELECT DISTINCT partnumber as dd_levelone, plantcode as plantcode,  'ALL' dd_companycode,
y.calendarmonthid yyyymm,
0 ct_salesquantity
FROM emd586.tmp_saleshistory_yyyymm y,
( SELECT DISTINCT f.partnumber,f.plantcode
FROM emd586.tmp_sod_denorm_fcst f) f
WHERE NOT EXISTS ( SELECT 1 FROM emd586.stage_saleshistory1 t
WHERE t.partnumber = f.partnumber AND t.plantcode = f.plantcode AND t.yyyymm = y.calendarmonthid )
ORDER BY partnumber,plantcode,y.calendarmonthid;

/* Sort by part and year-month */
DROP TABLE IF EXISTS emd586.stage_saleshistory;
CREATE TABLE emd586.stage_saleshistory
as
select * from emd586.stage_saleshistory1
order by partnumber,plantcode,yyyymm;
DROP TABLE IF EXISTS emd586.stage_saleshistory1;

/* Delete rows from sales history where month >= current month */
DROP TABLE IF EXISTS emd586.tmp_dim_date_fosf;
CREATE TABLE emd586.tmp_dim_date_fosf
AS
SELECT DISTINCT * FROM emdtempocc4.dim_date where datevalue = current_date AND companycode = 'Not Set';

DELETE FROM emd586.stage_saleshistory s
WHERE EXISTS ( SELECT 1 FROM emd586.tmp_dim_date_fosf d WHERE d.datevalue = current_date AND d.companycode = 'Not Set' AND d.calendarmonthid <= s.yyyymm );

/* Delete all rows before the first non-zero sales month */
DELETE FROM emd586.stage_saleshistory s
WHERE EXISTS ( SELECT 1 FROM ( select partnumber,plantcode,min(yyyymm) yyyymm from emd586.stage_saleshistory where ct_salesquantity > 0 GROUP BY partnumber,plantcode) nz
WHERE nz.partnumber = s.partnumber AND nz.plantcode = s.plantcode AND s.yyyymm < nz.yyyymm and s.ct_salesquantity = 0 );

/* Cleanup stage_fosalesforecast before it gets populated in step 2 */
DELETE FROM emd586.stage_fosalesforecast;

SELECT COUNT(DISTINCT partnumber||plantcode) from emd586.stage_saleshistory;
SELECT COUNT(DISTINCT partnumber) from emd586.stage_saleshistory;

DROP TABLE IF EXISTS emd586.tmp_distinct_dmdunit_histfcst;
CREATE TABLE emd586.tmp_distinct_dmdunit_histfcst
as
select distinct STSC_HISTFCST_DMDUNIT partnumber, STSC_HISTFCST_LOC  plantcode
from emdtempocc4.STSC_HISTFCST;

DELETE FROM emd586.stage_saleshistory a
WHERE NOT EXISTS ( SELECT 1 FROM emd586.tmp_distinct_dmdunit_histfcst b where a.partnumber = b.partnumber and a.plantcode = b.plantcode);

SELECT COUNT(DISTINCT partnumber||plantcode) from emd586.stage_saleshistory;
SELECT COUNT(DISTINCT partnumber) from emd586.stage_saleshistory;

/* There should be atleast 1 non-zero sales in test period */
DROP TABLE IF EXISTS tmp_saleshistoryinputforfcst_6months;
CREATE TABLE tmp_saleshistoryinputforfcst_6months
AS
SELECT partnumber,plantcode,count(*) cnt,max(yyyymm) max_calendarmonthid
from stage_saleshistory
WHERE ct_salesquantity > 0
GROUP BY partnumber,plantcode;

DELETE FROM tmp_saleshistoryinputforfcst_6months  s
WHERE s.max_calendarmonthid not in ( SELECT DISTINCT calendarmonthid from dim_date
        where companycode = 'Not Set' and datevalue >= last_day(current_date) - interval '6' month and datevalue < current_date - interval '1' month);


/* Delete parts that do not have at-least 1 point in last 6 months. Also, delete parts that have less than 15 months of total data as forecasting script cannot have min. training period of less than 12 months */
DELETE FROM stage_saleshistory t
WHERE NOT EXISTS ( SELECT 1 FROM tmp_saleshistoryinputforfcst_6months b where t.partnumber = b.partnumber and t.plantcode = b.plantcode AND cnt >= 15);

open schema emd586;
DROP TABLE IF EXISTS tmp_count_history;
CREATE TABLE tmp_count_history
AS
SELECT partnumber,plantcode,count(*) cnt,max(ct_salesquantity) max_ct_salesquantity
FROM stage_saleshistory
GROUP BY partnumber,plantcode;

DELETE FROM stage_saleshistory s
WHERE EXISTS ( select 1 from tmp_count_history t where t.partnumber = s.partnumber and t.plantcode = s.plantcode
and t.cnt < 15);

DELETE FROM stage_saleshistory s
WHERE EXISTS ( select 1 from tmp_count_history t where t.partnumber = s.partnumber and t.plantcode = s.plantcode
and t.max_ct_salesquantity <= 0);

DROP TABLE IF EXISTS emd586.tmp_distinct_dmdunit_dfuview;
CREATE TABLE emd586.tmp_distinct_dmdunit_dfuview
as
select distinct STSC_DFUVIEW_DMDUNIT partnumber, STSC_DFUVIEW_LOC  plantcode
from emdtempocc4.STSC_DFUVIEW;

DELETE FROM emd586.stage_saleshistory a
WHERE NOT EXISTS ( SELECT 1 FROM emd586.tmp_distinct_dmdunit_dfuview b where a.partnumber = b.partnumber and a.plantcode = b.plantcode);

SELECT COUNT(DISTINCT partnumber||plantcode) from emd586.stage_saleshistory;
SELECT COUNT(DISTINCT partnumber) from emd586.stage_saleshistory;

EXPORT (SELECT * FROM emd586.stage_saleshistory ORDER BY PARTNUMBER,PLANTCODE,YYYYMM,DD_COMPANYCODE) INTO LOCAL CSV FILE '/Users/lokeshk/DSWork/EMD/forecasting/emd586_stage_saleshistory.csv.gz' COLUMN SEPARATOR = ','  REPLACE;
/* Note that the output is not sorted even though the data in table stage_saleshistory was populated by using order by. The output file should be sorted in the file system 
e.g sort -k1,4 -t',' emd586_stage_saleshistory.csv -o emd586_stage_saleshistory.csv */
/*
DROP TABLE IF EXISTS emd586.tmp_distinct_dmdunit_dfuview;
DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
drop table if exists emd586.tmp_saleshistory_daterange;
drop table if exists emd586.tmp_saleshistory_yyyymm;
DROP TABLE IF EXISTS emd586.stage_saleshistory1;
DROP TABLE IF EXISTS emd586.tmp_dim_date_fosf;
DROP TABLE IF EXISTS emd586.tmp_distinct_dmdunit_histfcst;
*/

/*DROP TABLE IF EXISTS emd586.stage_saleshistory;*/

