

DROP TABLE IF EXISTS tmp_extract_csv_for_jda;
CREATE TABLE tmp_extract_csv_for_jda
AS
SELECT dd_dmdunit "JDA - DMDUNIT",dd_loc "JDA - Location",to_char(to_date(to_char(dd_forecastdate),'YYYYMMDD'),'DD.MM.YYYY') "Forecast Date",
CT_FORECASTQUANTITY "Forecast Quantity",ct_mape "MAPE FusionOps",
CT_MAPE_BASEFORECAST "MAPE - JDA Base Forecast",
CT_MAPE_BUSINESSFORECAST "MAPE - JDA Business Forecast",
to_char(to_date(dd_reportingdate,'DD MON YYYY'),'DD.MM.YYYY') "Reporting Date",
to_char(to_date(dd_holdoutdate,'DD MON YYYY'),'DD.MM.YYYY') "Hold Out Date",
dd_forecasttype "Forecast Type",
CT_GAINCRITERIA_1 "Flag - FOPS vs Stat Forecast",
CT_GAINCRITERIA_2 "Flag - FOPS vs Mkt Forecast"
from fact_fosalesforecast
--where dd_latestreporting = 'Yes'
WHERE dd_forecastrank = 1
AND dd_reportingdate = '07 JUL 2017'
and DD_UDC_STRENGTH <> 'CHC';

select count(distinct "JDA - DMDUNIT"||"JDA - Location") from tmp_extract_csv_for_jda;

EXPORT (SELECT * FROM tmp_extract_csv_for_jda ORDER BY "JDA - DMDUNIT","JDA - Location",to_date("Forecast Date",'DD.MM.YYYY')) INTO LOCAL CSV FILE '/Users/lokeshk/DSWork/emd/forecasting/exports_to_jda/FOPS_TO_JDA_FCST_OUTLIERWITHFULLHIST_07JUL2017.csv.gz' COLUMN SEPARATOR = ',' WITH COLUMN NAMES REPLACE;

DROP TABLE IF EXISTS tmp_extract_csv_for_jda;


