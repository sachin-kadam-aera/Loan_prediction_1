open schema emd586;
/* Version 2.16 --> Added CP/SP code */
/* Changed on 26-Sep-2016 for ct_next12monthsfopsfcst chgs */
/* If there's existing data for the same reporting date, then delete such rows from fact_fosalesforecast */
/* ( Note that stage_fosalesforecast will have only 1 distinct reporting date) */
/* Ensure that reportingdate is DD MON YYYY ( in upper case) and fcstdate is in yyyymmdd (int) */

/* Temporary update */
/*UPDATE emd586.stage_fosalesforecast
set dd_reportingdate = '<Put any date you want e.g 04 Jun 2016>'*/


/*
DELETE FROM emd586.stage_fosalesforecast

/home/fusionops/ispring/db/schema_migration/bin/loadtable_exasol.sh 192.168.10.14:8563 sys exasol EMD586 prdappc3n1connection stage_fosalesforecast dd_reportingdate,dd_forecastdate,dd_partnumber,dd_level2,ct_salesquantity,ct_forecastquantity,ct_lowpi,ct_highpi,ct_mape,dd_lastdate,dd_holdoutdate,dd_forecastsample,dd_forecasttype,dd_forecastrank,dd_forecastmode,dd_companycode,ct_bias_error_rank,ct_bias_error /home/fusionops/work/lokesh/ds/emd_jda/hist/$infile ',' YYYY-MM-DD null_default skipheader_yes '\\' doublequote ISO88591
(FQA1)fusionops:/home/fusionops/work/lokesh/ds/emd_jda/hist> cp loadtable_exasol_stage_fosalesforecast.sh loadtable_exasol_stage_fosalesforecast.sh.v.1.1

--If table structure of the table and file are same then use IMPORT otherwise use loadtable_exasol.sh as shown above
*/

/*
DELETE FROM emd586.fact_fosalesforecast
WHERE TO_DATE(dd_reportingdate,'DD MON YYYY') = 
(SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') 
	from emd586.stage_fosalesforecast )
*/

/* Delete data from stage table and load from latest forecast file */

DROP TABLE IF EXISTS STAGE_FOSALESFORECAST;
CREATE TABLE STAGE_FOSALESFORECAST (
DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
DD_PARTNUMBER       VARCHAR(40)  NOT NULL ,
DD_LEVEL2           VARCHAR(40) ,
CT_SALESQUANTITY    DECIMAL(36,6),
CT_FORECASTQUANTITY DECIMAL(36,6),
CT_LOWPI            DECIMAL(36,6),
CT_HIGHPI           DECIMAL(36,6),
CT_MAPE             DECIMAL(36,6),
DD_LASTDATE         VARCHAR(50)  NOT NULL ,
DD_HOLDOUTDATE      VARCHAR(50)  NOT NULL ,
DD_FORECASTSAMPLE   VARCHAR(50)  NOT NULL ,
DD_FORECASTTYPE     VARCHAR(50)  NOT NULL ,
DD_FORECASTRANK     DECIMAL(18,0),
DD_FORECASTMODE     VARCHAR(50)  NOT NULL ,
DD_COMPANYCODE      VARCHAR(50)  NOT NULL ,
CT_BIAS_ERROR_RANK  DECIMAL(18,6),
CT_BIAS_ERROR       DECIMAL(18,6)
--DD_DMDUNIT          VARCHAR(40) ,
--DD_LOC              VARCHAR(40) ,
--DD_DMDGROUP         VARCHAR(10)
);

IMPORT INTO emd586.stage_fosalesforecast FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/EMD/forecasting/stage_fosalesforecast.csv.gz' COLUMN SEPARATOR = ',' SKIP = 1;

/* Create a de-normalized table containing data from Sales Order */
DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
CREATE TABLE emd586.tmp_sod_denorm_fcst
AS
SELECT scheddlvrdate.datevalue scheddlvrdate,scheddlvrdate.calendarmonthid, s.STSC_HIST_DMDUNIT partnumber,s.STSC_HIST_LOC plantcode,
SUM(CASE WHEN STSC_HIST_TYPE = 1 THEN 1 ELSE -1 END * s.STSC_HIST_QTY ) ct_salesquantity
FROM emdtempocc4.STSC_HIST s INNER JOIN emdtempocc4.dim_date scheddlvrdate ON scheddlvrdate.datevalue = s.STSC_HIST_STARTDATE
WHERE scheddlvrdate.companycode = 'Not Set'
AND STSC_HIST_EVENT NOT LIKE '%AUTO-CORRECT%'
AND EXISTS ( SELECT 1 FROM emdtempocc4.stsc_dfuview dfuview where dfuview.STSC_DFUVIEW_DMDUNIT = s.STSC_HIST_DMDUNIT AND dfuview.STSC_DFUVIEW_LOC = s.STSC_HIST_LOC AND dfuview.STSC_DFUVIEW_UDC_FCSTLEVEL  = '111')
AND NOT EXISTS ( SELECT 1 FROM emdtempocc4.stsc_dfuview d2 where d2.STSC_DFUVIEW_DMDUNIT = s.STSC_HIST_DMDUNIT AND d2.STSC_DFUVIEW_LOC = s.STSC_HIST_LOC AND d2.STSC_DFUVIEW_UDC_DFULIFECYCLE like 'O%')
GROUP BY scheddlvrdate.datevalue,scheddlvrdate.calendarmonthid,s.STSC_HIST_DMDUNIT,s.STSC_HIST_LOC;

/* Get all dim_partids which have atleast 18 months non-zero sales in last 2 calendar years - e.g if this is run in Apr 2016, it wil get all parts which have atleast 18 months data from Jan 2014 */
drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
create table emd586.tmp_saleshistory_grain_reqmonths
as
select distinct f.partnumber,plantcode
FROM (select distinct partnumber,plantcode,calendarmonthid FROM emd586.tmp_sod_denorm_fcst WHERE year(scheddlvrdate) >= year(current_date) - 2) f
group by f.partnumber,plantcode
having count(*) >= 18;

/* Remove all  rows from denorm WHERE less than 18 month data is available */
DELETE FROM emd586.stage_fosalesforecast f
WHERE NOT EXISTS ( SELECT 1 FROM emd586.tmp_saleshistory_grain_reqmonths t
WHERE t.partnumber = f.dd_partnumber AND t.plantcode = f.dd_level2);

drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths_2;

drop table if exists emd586.fact_fosalesforecast_temp;
create table emd586.fact_fosalesforecast_temp as
select * from emd586.fact_fosalesforecast WHERE 1=2;

alter table emd586.fact_fosalesforecast_temp add column dd_forecastdatevalue date default '1900-01-01';

delete from emd586.number_fountain m WHERE m.table_name = 'fact_fosalesforecast';

insert into emd586.number_fountain
select  'fact_fosalesforecast',
ifnull(max(d.fact_fosalesforecastid),
	ifnull((select min(s.dim_projectsourceid * s.multiplier)
			from emd586.dim_projectsource s),0))
from emd586.fact_fosalesforecast d
WHERE d.fact_fosalesforecastid <> 1;

insert into emd586.fact_fosalesforecast_temp
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup
)
select  (select ifnull(m.max_id, 0) from emd586.number_fountain m WHERE m.table_name = 'fact_fosalesforecast') 
+ row_number() over(order by dd_partnumber,dd_level2,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecastid,
ifnull((select min(dim_mdg_partid) from emd586.dim_mdg_part dp where dp.partnumber = sf.dd_partnumber),1) dim_partid,
ifnull((select min(dim_plantid) from emd586.dim_plant pl where pl.plantcode = sf.dd_level2),1) dim_plantid,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
--TO_DATE(sf.dd_reportingdate,'DD MON YYYY') dd_reportingdate, --ifnull(cast(sf.dd_reportingdate as date),'1 Jan 1900'),
upper(sf.dd_reportingdate),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mape,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
case when sf.dd_forecastdate is null then cast('1900-01-01' as date)
else cast(concat(substring(sf.dd_forecastdate,1,4) , '-' ,
substring(sf.dd_forecastdate,5,2) , '-' ,
substring(sf.dd_forecastdate,7,2) ) as date)
end dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
sf.dd_partnumber dd_dmdunit,
sf.dd_level2 dd_loc,
sf.dd_companycode dd_dmdgroup
from emd586.stage_fosalesforecast sf;

/* No plant in part for emd */
/*
UPDATE emd586.fact_fosalesforecast_temp f
SET f.dim_plantid = pl.dim_plantid,
    f.dw_update_date = current_timestamp
from emd586.dim_plant pl, EMD586.dim_mdg_part p,emd586.fact_fosalesforecast_temp f
WHERE f.dim_partid = p.dim_mdg_partid
AND p.plant = pl.plantcode
AND p.projectsourceid = 1
AND f.dim_plantid <> pl.dim_plantid*/

UPDATE emd586.fact_fosalesforecast_temp f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from emd586.dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
emd586.fact_fosalesforecast_temp f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE emd586.fact_fosalesforecast_temp f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from emd586.dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
emd586.fact_fosalesforecast_temp f
WHERE f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid;

insert into emd586.fact_fosalesforecast
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup
)
select
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup
from emd586.fact_fosalesforecast_temp;

DROP TABLE IF EXISTS emd586.tmp_maxrptdate;
CREATE TABLE emd586.tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from emd586.stage_fosalesforecast ;

/* Update future sales to NULL */
UPDATE emd586.fact_fosalesforecast f
SET ct_salesquantity = NULL
FROM emd586.dim_date d,emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_salesquantity = 0 
AND f.dim_dateidforecast = d.dim_dateid
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND d.datevalue >= to_date(f.dd_reportingdate,'YYYY-MM-DD');

/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE emd586.fact_fosalesforecast f
set ct_highpi = NULL
FROM emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_highpi = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE emd586.fact_fosalesforecast f
set ct_lowpi = NULL
FROM emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_lowpi = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

/* Format reporting date as DD MON YYYY */
UPDATE emd586.fact_fosalesforecast f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD MON YYYY')
where f.dd_reportingdate like '%-%-%';

DROP TABLE IF EXISTS emd586.tmp_maxrptdate;
CREATE TABLE emd586.tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from emd586.stage_fosalesforecast ;

/* As per discussion with Anshuman on 19th Aug 2016, do not delete these rows */
/*
delete 
from emd586.fact_fosalesforecast f
where exists ( select 1 from emd586.dim_date d 
	where f.dim_dateidforecast = d.dim_dateid
	and year(d.datevalue) >= 2019)
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from emd586.tmp_maxrptdate) 
*/


/* Additional EMD updates - custom changes for EMD - 2 Jun 2016 */
UPDATE emd586.FACT_FOSALESFORECAST f
SET f.DD_UDC_STRENGTH = d.DMDUNIT_UDC_STRENGTH,
    f.DD_UDC_TADESCR = d.DMDUNIT_UDC_TADESCR,
    f.DD_UDC_BRANDDESCR = d.DMDUNIT_UDC_BRANDDESCR,
    f.DD_UDC_STRENGTHDESCR = d.DMDUNIT_UDC_STRENGTHDESCR,
    f.DD_UDC_GPS = d.DMDUNIT_UDC_GPS,
    f.dim_dmdunitid = d.dim_dmdunitid,
    f.dd_UDC_CONTAINER = d.dmdunit_udc_container,
    f.dd_dmdunit_descr = d.dmdunit_descr
FROM emd586.dim_dmdunit d,emd586.FACT_FOSALESFORECAST f,emd586.tmp_maxrptdate r
WHERE f.DD_DMDUNIT = d.DMDUNIT_DMDUNIT and r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

UPDATE emd586.FACT_FOSALESFORECAST f
SET f.DD_UDC_COUNTRY = l.STSC_LOC_UDC_COUNTRY,
    f.DD_UDC_REGION = l.STSC_LOC_UDC_REGION,
    f.DD_UDC_MARKET = l.STSC_LOC_UDC_MARKET,
    f.dd_STSC_LOC_UDC_RESPCMG = l.STSC_LOC_UDC_RESPCMG,
    f.dim_locid = l.dim_locid
from emd586.dim_loc l, emd586.FACT_FOSALESFORECAST f, emd586.tmp_maxrptdate r
WHERE f.dd_loc = l.STSC_LOC_LOC
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

UPDATE emd586.FACT_FOSALESFORECAST f
SET f.DD_UDC_FCSTLEVEL = d.STSC_DFUVIEW_UDC_FCSTLEVEL,
    f.dd_STSC_DFUVIEW_UDC_AVGSALESPMONTH = d.STSC_DFUVIEW_UDC_AVGSALESPMONTH,
    f.dd_STSC_DFUVIEW_UDC_VOLATILITY = d.STSC_DFUVIEW_UDC_VOLATILITY,
    f.dd_STSC_DFUVIEW_UDC_SEGMENTATION = d.STSC_DFUVIEW_UDC_SEGMENTATION,
    f.dim_dfuviewid = d.dim_dfuviewid,
    f.dd_stsc_dfuview_udc_averageprice = d.stsc_dfuview_udc_averageprice,
    f.AMT_UNITSELLINGPRICE  = d.stsc_dfuview_udc_averageprice,
    f.dd_STSC_DFUVIEW_UDC_DFULIFECYCLE = d.STSC_DFUVIEW_UDC_DFULIFECYCLE
from emd586.dim_dfuview d,emd586.FACT_FOSALESFORECAST f,emd586.tmp_maxrptdate r
WHERE f.DD_DMDUNIT = d.STSC_DFUVIEW_DMDUNIT 
AND f.dd_loc = d.STSC_DFUVIEW_LOC 
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

UPDATE emd586.FACT_FOSALESFORECAST f
SET f.ct_STSC_HISTFCST_LAG = h.STSC_HISTFCST_LAG,
    f.ct_STSC_HISTFCST_BASEFCST = h.STSC_HISTFCST_BASEFCST,
    f.ct_STSC_HISTFCST_NONBASEFCST = h.STSC_HISTFCST_NONBASEFCST,
    f.ct_STSC_HISTFCST_RECONCILEDFCST = h.STSC_HISTFCST_RECONCILEDFCST,
    f.ct_STSC_HISTFCST_DUR  = h.STSC_HISTFCST_DUR,
    f.ct_stsc_histfcst_targetimpact = h.stsc_histfcst_targetimpact,
    f.ct_stsc_marketfcst_baseplusnonbaseminustargetimpact = h.stsc_histfcst_basefcst + h.stsc_histfcst_nonbasefcst - h.stsc_histfcst_targetimpact,
    f.dd_stsc_histfcst_fcstdate = h.stsc_histfcst_fcstdate,
    f.dd_stsc_histfcst_startdate = h.stsc_histfcst_startdate
FROM emdtempocc4.STSC_HISTFCST h,emd586.FACT_FOSALESFORECAST f,emd586.dim_date d, emd586.tmp_maxrptdate r
WHERE f.DD_DMDUNIT = h.STSC_HISTFCST_DMDUNIT
AND f.dd_loc = h.STSC_HISTFCST_LOC
AND f.DD_DMDGROUP = h.STSC_HISTFCST_DMDGROUP
AND year(to_date(f.dd_holdoutdate,'DD MON YYYY')) = year(h.STSC_HISTFCST_FCSTDATE)
    and month(to_date(f.dd_holdoutdate,'DD MON YYYY')) = month(h.STSC_HISTFCST_FCSTDATE)
AND f.dim_dateidforecast = d.dim_dateid
AND month(d.datevalue) = month(h.STSC_HISTFCST_STARTDATE)
    and year(d.datevalue) = year(h.STSC_HISTFCST_STARTDATE)
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY')
AND h.STSC_HISTFCST_DMDUNIT <> 'ID154911F'; /* This part has corrupt data in histfcst */

/* Filter out data per discussion between Jean Luc and Anshuman */
DELETE FROM emd586.FACT_FOSALESFORECAST where DD_UDC_FCSTLEVEL <> '111' and to_date(dd_reportingdate,'DD MON YYYY') >= '2016-05-26';


DELETE FROM emd586.FACT_FOSALESFORECAST f
where exists
   ( select 1 
       from emdtempocc4.stsc_dfuview d 
        where f.DD_DMDUNIT = d.STSC_DFUVIEW_DMDUNIT AND f.dd_loc = d.STSC_DFUVIEW_LOC and STSC_DFUVIEW_UDC_DFULIFECYCLE like 'O%');



/* Delete all rows for given part/plant/fcsttype/rptdate if any fcst is > 1million */
DROP TABLE IF EXISTS emd586.backup_fact_fosalesforecast_largefcstqty;
CREATE TABLE emd586.backup_fact_fosalesforecast_largefcstqty
AS
SELECT distinct f.dd_reportingdate,DD_DMDUNIT,dd_loc,dd_forecasttype
from emd586.fact_fosalesforecast f, emd586.tmp_maxrptdate r
where ct_forecastquantity > 20000000
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY')
AND DD_DMDUNIT <> 'FR2XM85';

DELETE FROM emd586.fact_fosalesforecast f
where exists (SELECT 1 FROM emd586.backup_fact_fosalesforecast_largefcstqty t
where t.dd_reportingdate = f.dd_reportingdate and t.DD_DMDUNIT = f.DD_DMDUNIT and t.dd_loc = f.dd_loc and t.dd_forecasttype = f.dd_forecasttype);

/* Populate No. of Days */
UPDATE emd586.FACT_FOSALESFORECAST f
SET f.dd_daysinmonth = extract(day from d.datevalue)||'D'
FROM emd586.FACT_FOSALESFORECAST f,emd586.dim_date d, emd586.tmp_maxrptdate r
WHERE f.dim_dateidforecast = d.dim_dateid
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');


DROP TABLE IF EXISTS emd586.tmp_custmapes_fosp;
CREATE TABLE emd586.tmp_custmapes_fosp
AS
SELECT f.dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype,
100 * avg(abs((ct_stsc_marketfcst_baseplusnonbaseminustargetimpact-ct_salesquantity)/ct_salesquantity)) ct_mape_businessforecast,
100 * avg(abs((ct_STSC_HISTFCST_BASEFCST-ct_salesquantity)/ct_salesquantity)) ct_mape_baseforecast
FROM emd586.fact_fosalesforecast f , emd586.tmp_maxrptdate r 
WHERE f.DD_FORECASTSAMPLE = 'Test'
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY')
GROUP BY f.dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype;

UPDATE emd586.fact_fosalesforecast f
SET f.ct_mape_businessforecast = t.ct_mape_businessforecast,
    f.ct_mape_baseforecast = t.ct_mape_baseforecast
FROM emd586.fact_fosalesforecast f,emd586.tmp_custmapes_fosp t,emd586.tmp_maxrptdate r
where f.dd_reportingdate = t.dd_reportingdate 
AND f.dd_dmdunit = t.dd_dmdunit
AND f.dd_loc = t.dd_loc
AND f.dd_forecasttype = t.dd_forecasttype
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

UPDATE fact_fosalesforecast f
SET f.dd_flag_fopsmapebetterthanmkt = 1 
FROM fact_fosalesforecast f, emd586.tmp_maxrptdate r
WHERE ct_mape < ct_mape_businessforecast
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

UPDATE fact_fosalesforecast f
SET dd_flag_fopsmapebetterthanSTAT = 1
FROM fact_fosalesforecast f, emd586.tmp_maxrptdate r
WHERE ct_mape < ct_mape_baseforecast
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

/* Gain criteria */
/*** Run this manually after the script completes ****/


/* Rerank for mult forecasts having same ranks */

DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf;
CREATE TABLE tmp_upd_fcstrank_fosf
as
select distinct f.dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype,dd_forecastrank
from fact_fosalesforecast f,emd586.tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;

select *
from tmp_upd_fcstrank_fosf
order by dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype,dd_forecastrank
limit 20;

--This should insert 0 rows as for same fcst type, there cannot be different ranks
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dd_dmdunit = t2.dd_dmdunit
and t1.dd_loc = t2.dd_loc
and t1.dd_forecasttype = t2.dd_forecasttype
and t1.dd_forecastrank <> t2.dd_forecastrank;

select *
from tmp_upd_fcstrank_fosf2
order by dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype,dd_forecastrank
limit 20;

--These are the cases with issues ( different methods, same rank )
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
CREATE TABLE tmp_upd_fcstrank_fosf2
as
select t1.*
from tmp_upd_fcstrank_fosf t1,tmp_upd_fcstrank_fosf t2
where t1.dd_reportingdate = t2.dd_reportingdate
and t1.dd_dmdunit = t2.dd_dmdunit
and t1.dd_loc = t2.dd_loc
and t1.dd_forecasttype <> t2.dd_forecasttype
and t1.dd_forecastrank = t2.dd_forecastrank;

select *
from tmp_upd_fcstrank_fosf2
order by dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype,dd_forecastrank
limit 20;

--Get all rows corresponding to these rptdate,dmdunit,loc
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf3;
CREATE TABLE tmp_upd_fcstrank_fosf3
as
select t1.*,rank() over(partition by dd_reportingdate,dd_dmdunit,dd_loc  order by dd_forecastrank,dd_forecasttype) dd_rank_new
from tmp_upd_fcstrank_fosf t1
WHERE EXISTS ( SELECT 1 FROM tmp_upd_fcstrank_fosf2 t2
    where t1.dd_reportingdate = t2.dd_reportingdate
    and t1.dd_dmdunit = t2.dd_dmdunit
    and t1.dd_loc = t2.dd_loc);

select *
from tmp_upd_fcstrank_fosf3
order by dd_reportingdate,dd_dmdunit,dd_loc,dd_forecastrank,dd_forecasttype
limit 20;

UPDATE fact_fosalesforecast f
SET f.dd_forecastrank = t.dd_rank_new
FROM fact_fosalesforecast f,tmp_upd_fcstrank_fosf3 t
where f.dd_reportingdate = t.dd_reportingdate
and f.dd_dmdunit = t.dd_dmdunit
and f.dd_loc = t.dd_loc
and f.dd_forecastrank = t.dd_forecastrank
and f.dd_forecasttype = t.dd_forecasttype;

UPDATE emd586.fact_fosalesforecast f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE emd586.fact_fosalesforecast f
SET dd_latestreporting = 'Yes'
FROM emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;


DROP TABLE IF EXISTS tmp_upd_ct_next12monthsfopsfcst;
CREATE TABLE tmp_upd_ct_next12monthsfopsfcst
as
select f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.dd_forecasttype,
d.datevalue dd_forecastdate,d.datevalue + interval '11' month dd_forecastdate_plus11,
sum(f1.ct_forecastquantity) ct_next12monthsfopsfcst
FROM fact_fosalesforecast f inner join fact_fosalesforecast f1
ON f.dd_reportingdate = f1.dd_reportingdate AND f.dd_dmdunit = f1.dd_dmdunit AND f.dd_loc = f1.dd_loc AND f.dd_forecasttype = f1.dd_forecasttype
INNER JOIN dim_date d on d.dim_dateid = f.dim_dateidforecast
INNER JOIN dim_date d1 on d1.dim_dateid = f1.dim_dateidforecast
WHERE d1.datevalue >= d.datevalue
AND d1.datevalue <= d.datevalue + interval '11' month
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
GROUP BY f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.dd_forecasttype,d.datevalue,d.datevalue + interval '11' month;

UPDATE fact_fosalesforecast f
SET f.ct_next12monthsfopsfcst = f1.ct_next12monthsfopsfcst
FROM fact_fosalesforecast f inner join dim_date d ON d.dim_dateid = f.dim_dateidforecast
    inner join tmp_upd_ct_next12monthsfopsfcst f1
ON f.dd_reportingdate = f1.dd_reportingdate AND f.dd_dmdunit = f1.dd_dmdunit AND f.dd_loc = f1.dd_loc AND f.dd_forecasttype = f1.dd_forecasttype
WHERE f1.dd_forecastdate = d.datevalue;


DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths_2;
drop table if exists emd586.fact_fosalesforecast_temp;
DROP TABLE IF EXISTS emd586.backup_fact_fosalesforecast_largefcstqty;
DROP TABLE IF EXISTS emd586.tmp_custmapes_fosp;
DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf1;
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf2;
DROP TABLE IF EXISTS tmp_upd_fcstrank_fosf3;
DROP TABLE IF EXISTS tmp_gaincritlt0;
DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape;
DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_upd;
DELETE FROM emd586.stage_fosalesforecast;

/* Prices for last 3 months before the current month */
DROP TABLE IF EXISTS emd586.tmp_upd_cogs_emd_latestdate;
CREATE TABLE emd586.tmp_upd_cogs_emd_latestdate
AS
SELECT dp.partnumber,rank() over( partition by dp.partnumber order by d.datevalue desc) sr_no,
(amt_cogsfixedplanrate_emd ) amt_cogsfixedplanrate_emd_gbl,
amt_cogsactualrate_emd,
(amt_StdUnitPrice * amt_exchangerate_gbl ) amt_StdUnitPrice_gbl
FROM emd586.fact_inventoryhistory fih inner join emd586.dim_mdg_part dp on dp.dim_mdg_partid = fih.dim_mdg_partid
INNER JOIN emd586.dim_date d on d.dim_dateid = fih.dim_dateidsnapshot AND d.datevalue >= last_day(current_date) - interval '6' month
AND (amt_cogsfixedplanrate_emd > 0 or amt_cogsactualrate_emd > 0 or amt_StdUnitPrice * amt_exchangerate_gbl > 0);
--WHERE d.datevalue >= current_date - interval '1' year;

DROP TABLE IF EXISTS emd586.tmp_upd_cogs_emd_latestdate_avg;
CREATE TABLE emd586.tmp_upd_cogs_emd_latestdate_avg
AS
SELECT partnumber,avg(amt_cogsfixedplanrate_emd_gbl) amt_cogsfixedplanrate_emd_gbl,
avg(amt_cogsactualrate_emd) amt_cogsactualrate_emd_gbl,
avg(amt_StdUnitPrice_gbl) amt_StdUnitPrice_gbl
from emd586.tmp_upd_cogs_emd_latestdate
WHERE sr_no = 1
group by partnumber;

UPDATE emd586.tmp_upd_cogs_emd_latestdate_avg
SET amt_cogsfixedplanrate_emd_gbl  = amt_cogsactualrate_emd_gbl
WHERE amt_cogsfixedplanrate_emd_gbl is null or amt_cogsfixedplanrate_emd_gbl <= 0;

UPDATE emd586.tmp_upd_cogs_emd_latestdate_avg
SET amt_cogsfixedplanrate_emd_gbl  = amt_StdUnitPrice_gbl
WHERE amt_cogsfixedplanrate_emd_gbl is null or amt_cogsfixedplanrate_emd_gbl <= 0;

UPDATE fact_fosalesforecast f
SET f.amt_cogsrate_or_stdunitprice_gbl = t.amt_cogsfixedplanrate_emd_gbl
FROM fact_fosalesforecast f,emd586.tmp_upd_cogs_emd_latestdate_avg t
WHERE f.dd_dmdunit = t.partnumber;

SELECT COUNT(DISTINCT dd_dmdunit||dd_loc) from fact_fosalesforecast f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
AND (f.amt_cogsrate_or_stdunitprice_gbl is null or f.amt_cogsrate_or_stdunitprice_gbl = 0);

select COUNT(DISTINCT dd_dmdunit||dd_loc) from fact_fosalesforecast f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r);

DROP TABLE IF EXISTS tmp_amt_sellingpriceperunit_gbl;
CREATE TABLE tmp_amt_sellingpriceperunit_gbl
AS
SELECT dp.partnumber,avg(fso.amt_UnitPrice * amt_exchangerate_gbl) amt_sellingpriceperunit_gbl_oldmethod,
avg(amt_exchangerate_gbl * amt_UnitPriceUoM/(CASE WHEN fso.ct_PriceUnit <> 0 THEN fso.ct_PriceUnit ELSE 1 END)) amt_sellingpriceperunit_gbl
FROM fact_salesorder fso inner join dim_mdg_part dp on dp.dim_mdg_partid = fso.dim_mdg_partid
INNER JOIN dim_date d on d.dim_dateid = fso.dim_dateidsocreated 
left outer join dim_currency tra on tra.dim_currencyid = fso.dim_currencyid_tra
left outer join dim_currency lcl on lcl.dim_currencyid = fso.dim_currencyid
left outer join dim_currency gbl on tra.dim_currencyid = fso.dim_currencyid_gbl
WHERE d.datevalue >= current_date - interval '1' year
AND ct_ScheduleQtySalesUnit > 0
group by dp.partnumber;

--select dp.partdescription, 
select rtrim(dp.partnumber) partnumber,pl.plantcode,ct_PriceUnit,
amt_UnitPrice,
amt_UnitPriceUoM,ct_ScheduleQtySalesUnit,d.datevalue ,amt_exchangerate,amt_exchangerate_gbl,tra.currencycode trancurr,gbl.currencycode gblcurr,lcl.currencycode localcurr
from fact_salesorder fso inner join dim_part dp on dp.dim_partid = fso.dim_partid INNER JOIN dim_date d on d.dim_dateid = fso.dim_dateidsocreated 
left outer join dim_currency tra on tra.dim_currencyid = fso.dim_currencyid_tra
left outer join dim_currency lcl on lcl.dim_currencyid = fso.dim_currencyid
left outer join dim_currency gbl on tra.dim_currencyid = fso.dim_currencyid_gbl
inner join dim_plant pl on pl.dim_plantid = fso.dim_plantid
where partnumber in ('F1213801') 
AND ct_ScheduleQtySalesUnit > 0
order by d.datevalue
limit 2;

UPDATE fact_fosalesforecast f
SET f.amt_sellingpriceperunit_gbl = t.amt_sellingpriceperunit_gbl
FROM fact_fosalesforecast f,tmp_amt_sellingpriceperunit_gbl t
WHERE f.dd_dmdunit = t.partnumber;

SELECT COUNT(DISTINCT dd_dmdunit||dd_loc) from fact_fosalesforecast f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
AND (f.amt_sellingpriceperunit_gbl is null or f.amt_sellingpriceperunit_gbl = 0);

select COUNT(DISTINCT dd_dmdunit||dd_loc) from fact_fosalesforecast f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r);


SELECT COUNT(DISTINCT dd_dmdunit||dd_loc)
FROM fact_fosalesforecast f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
AND f.amt_cogsrate_or_stdunitprice_gbl >= f.amt_sellingpriceperunit_gbl;

DROP TABLE IF EXISTS tmp_total_margin_salesytd;
CREATE TABLE tmp_total_margin_salesytd
AS
SELECT dd_reportingdate,
sum(AMT_SELLINGPRICEPERUNIT_GBL * ct_salesquantity) revenue_totalsales,
sum(amt_cogsrate_or_stdunitprice_gbl * ct_salesquantity) cogs_totalsales,
sum(AMT_SELLINGPRICEPERUNIT_GBL * (ct_salesquantity + ct_forecastquantity)) revenue_totalsales_plus_fcst,
sum(amt_cogsrate_or_stdunitprice_gbl * (ct_salesquantity + ct_forecastquantity)) cogs_totalsales_plus_fcst,
sum(AMT_SELLINGPRICEPERUNIT_GBL * (ct_salesquantity + CT_STSC_MARKETFCST_BASEPLUSNONBASEMINUSTARGETIMPACT)) revenue_totalsales_plus_jdafcst,
sum(amt_cogsrate_or_stdunitprice_gbl * (ct_salesquantity + CT_STSC_MARKETFCST_BASEPLUSNONBASEMINUSTARGETIMPACT)) cogs_totalsales_plus_jdafcst
FROM fact_fosalesforecast f inner join dim_date d on d.dim_dateid = f.dim_dateidforecast
WHERE AMT_SELLINGPRICEPERUNIT_GBL > 0 
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
AND amt_cogsrate_or_stdunitprice_gbl > 0
AND year(d.datevalue) >= 2016
GROUP BY dd_reportingdate;

UPDATE fact_fosalesforecast f
SET f.ct_marginpercent_salesytd = 100 * (t.revenue_totalsales - t.cogs_totalsales)/t.revenue_totalsales,
f.ct_marginpercent_salesplusfcst_currentyear = 100 * (t.revenue_totalsales_plus_fcst-t.cogs_totalsales_plus_fcst)/t.revenue_totalsales_plus_fcst,
f.ct_marginpercent_salesplusjdafcst_currentyear = 100 * (t.revenue_totalsales_plus_jdafcst-t.cogs_totalsales_plus_jdafcst)/t.revenue_totalsales_plus_jdafcst
FROM fact_fosalesforecast f,tmp_total_margin_salesytd t
WHERE f.dd_reportingdate = t.dd_reportingdate;


/*DROP TABLE IF EXISTS tmp_last6dates_fcst;
CREATE TABLE tmp_last6dates_fcst
AS
SELECT dd_reportingdate,
rank() over(order by to_date(dd_reportingdate,'dd mon yyyy') desc)  dd_rank
FROM (select distinct to_date(dd_reportingdate,'dd mon yyyy') dd_reportingdate  from fact_fosalesforecast);*/

/* Pick up the last reporting date from the current month plus previous 5 months */

DROP TABLE IF EXISTS tmp_last6dates_fcst;
CREATE TABLE tmp_last6dates_fcst
AS
select rank() over(order by dd_reportingdate_datefmt desc) dd_rank,to_char(dd_reportingdate_datefmt,'DD MON YYYY') dd_reportingdate_char,
dd_reportingdate_datefmt dd_reportingdate_date
FROM (select max(to_date(dd_reportingdate,'DD MON YYYY')) dd_reportingdate_datefmt,month(to_date(dd_reportingdate,'DD MON YYYY')),year(to_date(dd_reportingdate,'DD MON YYYY')) 
    from fact_fosalesforecast f where f.dd_forecastrank = 1 
    GROUP BY month(to_date(dd_reportingdate,'DD MON YYYY')),year(to_date(dd_reportingdate,'DD MON YYYY')));

/* Pick up the latest 6 reporting dates */
DELETE FROM tmp_last6dates_fcst
WHERE dd_rank > 6;

SELECT *
FROM tmp_last6dates_fcst;


/* Count the no. of points in last 6 months for each dmdunit-loc pair */
DROP TABLE IF EXISTS tmp_count_parts_6months;
CREATE TABLE tmp_count_parts_6months
AS
SELECT dd_dmdunit,dd_loc,count(*) dd_cnt
FROM (select distinct dd_dmdunit,dd_loc,dd_reportingdate 
from fact_fosalesforecast 
where dd_reportingdate in (select distinct t.dd_reportingdate_char from tmp_last6dates_fcst t)
AND CT_MAPE_BASEFORECAST is not null and CT_MAPE_BUSINESSFORECAST is not null) f
GROUP BY dd_dmdunit,dd_loc;

/* Ignore parts where less than 3 points have non null business and stat mapes */

DELETE FROM tmp_count_parts_6months
WHERE dd_cnt < 3;

DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_upd;
CREATE TABLE tmp_distinctdmdunit_loc_mape_upd
as
select distinct f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.ct_mape,DD_FLAG_FOPSMAPEBETTERTHANSTAT,DD_FLAG_FOPSMAPEBETTERTHANMKT,
CT_MAPE_BUSINESSFORECAST,CT_MAPE_BASEFORECAST,(ct_mape-CT_MAPE_BASEFORECAST) ct_gaincriteria_1,(ct_mape - CT_MAPE_BUSINESSFORECAST) ct_gaincriteria_2
from fact_fosalesforecast f inner join tmp_count_parts_6months t on t.dd_dmdunit = f.dd_dmdunit and t.dd_loc = f.dd_loc
WHERE dd_reportingdate in (select dd_reportingdate_char from tmp_last6dates_fcst)
AND EXISTS ( SELECT 1 FROM tmp_count_parts_6months tc where tc.dd_dmdunit = f.dd_dmdunit and tc.dd_loc = f.dd_loc)
AND f.dd_forecastrank = 1;

DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape;
CREATE TABLE tmp_distinctdmdunit_loc_mape
as
SELECT dd_dmdunit,dd_loc,max(ct_mape) ct_mape_max,max(ct_gaincriteria_1) max_ct_gaincriteria_1,max(ct_gaincriteria_2) max_ct_gaincriteria_2,
avg(ct_gaincriteria_1) avg_ct_gaincriteria_1,avg(ct_gaincriteria_2) avg_ct_gaincriteria_2
FROM tmp_distinctdmdunit_loc_mape_upd
GROUP BY dd_dmdunit,dd_loc;

/* Count the no. of months when gain was -ve */
DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_counts_criteria_1;
CREATE TABLE tmp_distinctdmdunit_loc_mape_counts_criteria_1
as
SELECT dd_dmdunit,dd_loc,count(*) cnt
FROM tmp_distinctdmdunit_loc_mape_upd t 
WHERE ct_gaincriteria_1 < 0
GROUP BY dd_dmdunit,dd_loc;

DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_counts_criteria_2;
CREATE TABLE tmp_distinctdmdunit_loc_mape_counts_criteria_2
as
SELECT dd_dmdunit,dd_loc,count(*) cnt
FROM tmp_distinctdmdunit_loc_mape_upd t 
WHERE ct_gaincriteria_2 < 0
GROUP BY dd_dmdunit,dd_loc;

DELETE FROM tmp_distinctdmdunit_loc_mape
WHERE ct_mape_max > 30;

UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_1 = 0,
    f.ct_gaincriteria_2 = 0
WHERE f.dd_reportingdate in (select dd_reportingdate_char from tmp_last6dates_fcst where dd_rank = 1);


/* Gain1 - Unstable not in ('Mules','Horses'). All 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_1 = t.avg_ct_gaincriteria_1
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_1 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION not in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
--AND g1.cnt = 6
AND t.max_ct_gaincriteria_1 < 0;

/* Gain2 - Unstable not in ('Mules','Horses'). All 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_2 = t.avg_ct_gaincriteria_2
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_2 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION not in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
--AND g1.cnt = 6
AND t.max_ct_gaincriteria_2 < 0;

/* Gain1 - Stable  in ('Mules','Horses'). At-least 4 out of 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_1 = t.avg_ct_gaincriteria_1
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_1 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION  in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
AND g1.cnt >= 4
--AND t.max_ct_gaincriteria_1 < 0
AND avg_ct_gaincriteria_1 < 0;

/* Gain2 - Stable  in ('Mules','Horses'). At-least 4 out of 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_2 = t.avg_ct_gaincriteria_2
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_2 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION  in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
AND g1.cnt >= 4
--AND t.max_ct_gaincriteria_2 < 0
AND avg_ct_gaincriteria_2 < 0;


DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_upd;
DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape;
DROP TABLE IF EXISTS tmp_gaincritlt0;
DROP TABLE IF EXISTS tmp_last6dates_fcst;
