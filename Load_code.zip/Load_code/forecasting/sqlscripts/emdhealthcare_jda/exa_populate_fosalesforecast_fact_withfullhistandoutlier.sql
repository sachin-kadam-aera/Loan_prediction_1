/* Prereq : Four forecast files should be present --> 
emdforecast_fullhist_with_outlier.csv.gz
emdforecast_outlier.csv.gz
emdforecast_regular.csv.gz
emdforecast_regular_with_fullhistory.csv.gz
*/

/* Change paths in import/export stmt according to the file locations */

open schema emd586;
DROP TABLE IF EXISTS STAGE_FOSALESFORECAST;
CREATE TABLE STAGE_FOSALESFORECAST (
    DD_REPORTINGDATE    VARCHAR(50)  NOT NULL ,
    DD_FORECASTDATE     DECIMAL(18,0) NOT NULL ,
    DD_PARTNUMBER       VARCHAR(40)  NOT NULL ,
    DD_LEVEL2           VARCHAR(40) ,
    CT_SALESQUANTITY    DECIMAL(36,6),
    CT_FORECASTQUANTITY DECIMAL(36,6),
    CT_LOWPI            DECIMAL(36,6),
    CT_HIGHPI           DECIMAL(36,6),
    CT_MAPE             DECIMAL(36,6),
    DD_LASTDATE         VARCHAR(50)  NOT NULL ,
    DD_HOLDOUTDATE      VARCHAR(50)  NOT NULL ,
    DD_FORECASTSAMPLE   VARCHAR(50)  NOT NULL ,
    DD_FORECASTTYPE     VARCHAR(50)  NOT NULL ,
    DD_FORECASTRANK     DECIMAL(18,0),
    DD_FORECASTMODE     VARCHAR(50)  NOT NULL ,
    DD_COMPANYCODE      VARCHAR(50)  NOT NULL ,
    CT_BIAS_ERROR_RANK  DECIMAL(18,6),
    CT_BIAS_ERROR       DECIMAL(18,6)
    --DD_DMDUNIT          VARCHAR(40) ,
--DD_LOC              VARCHAR(40) ,
--DD_DMDGROUP         VARCHAR(10)
);

/* Create STG tables for each of the 4 forecasts */
DROP TABLE IF EXISTS STAGE_FOSALESFORECAST_REGULAR;
CREATE TABLE STAGE_FOSALESFORECAST_REGULAR
AS
SELECT * FROM STAGE_FOSALESFORECAST;

DROP TABLE IF EXISTS STAGE_FOSALESFORECAST_REGULARWITHFULLHIST;
CREATE TABLE STAGE_FOSALESFORECAST_REGULARWITHFULLHIST
AS
SELECT * FROM STAGE_FOSALESFORECAST;

DROP TABLE IF EXISTS STAGE_FOSALESFORECAST_OUTLIER;
CREATE TABLE STAGE_FOSALESFORECAST_OUTLIER
AS
SELECT * FROM STAGE_FOSALESFORECAST;


DROP TABLE IF EXISTS STAGE_FOSALESFORECAST_OUTLIERWITHFULLHIST;
CREATE TABLE STAGE_FOSALESFORECAST_OUTLIERWITHFULLHIST
AS
SELECT * FROM STAGE_FOSALESFORECAST;

IMPORT INTO STAGE_FOSALESFORECAST_REGULAR FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/emd/forecasting/jul07forecasts/emdforecast_regular.csv.gz' COLUMN SEPARATOR = ',' SKIP = 1;
IMPORT INTO STAGE_FOSALESFORECAST_REGULARWITHFULLHIST FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/emd/forecasting/jul07forecasts/emdforecast_regular_with_fullhistory.csv.gz' COLUMN SEPARATOR = ',' SKIP = 1;
IMPORT INTO STAGE_FOSALESFORECAST_OUTLIER FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/emd/forecasting/jul07forecasts/emdforecast_outlier.csv.gz' COLUMN SEPARATOR = ',' SKIP = 1;
IMPORT INTO STAGE_FOSALESFORECAST_OUTLIERWITHFULLHIST FROM LOCAL CSV FILE '/Users/lokeshk/DSWork/emd/forecasting/jul07forecasts/emdforecast_fullhist_with_outlier.csv.gz' COLUMN SEPARATOR = ',' SKIP = 1;

UPDATE STAGE_FOSALESFORECAST_REGULAR
SET dd_reportingdate = '06 JUL 2017';

UPDATE STAGE_FOSALESFORECAST_REGULARWITHFULLHIST
SET dd_reportingdate = '07 JUL 2017';

UPDATE STAGE_FOSALESFORECAST_OUTLIER
SET dd_reportingdate = '08 JUL 2017';

UPDATE STAGE_FOSALESFORECAST_OUTLIERWITHFULLHIST
SET dd_reportingdate = '09 JUL 2017';

/* Rank forecast types alphabetically */
DROP TABLE IF EXISTS tmp_distinctforecasttypes;
CREATE TABLE tmp_distinctforecasttypes
AS
SELECT dd_forecasttype,rank() over(order by dd_forecasttype) dd_rank
FROM (SELECT DISTINCT dd_forecasttype FROM STAGE_FOSALESFORECAST_REGULAR);

/* In non-fullhist forecasts, keep only rank 1's */
DELETE FROM STAGE_FOSALESFORECAST_REGULAR WHERE DD_FORECASTRANK > 1;
DELETE FROM STAGE_FOSALESFORECAST_OUTLIER WHERE DD_FORECASTRANK > 1;

/* Handle duplicate rank 1's. e.g 2 forecasts having the same MAPEs */
ALTER TABLE STAGE_FOSALESFORECAST_REGULAR
ADD COLUMN dd_forecasttype_rank int;

UPDATE STAGE_FOSALESFORECAST_REGULAR s
SET s.dd_forecasttype_rank = t.dd_rank
FROM STAGE_FOSALESFORECAST_REGULAR s,tmp_distinctforecasttypes t
WHERE s.dd_forecasttype = t.dd_forecasttype;

/* For dup rank 1s, delete the one with higher dd_forecasttype_rank(e.g alphabetically) */
DELETE FROM STAGE_FOSALESFORECAST_REGULAR a
WHERE EXISTS ( SELECT 1 FROM STAGE_FOSALESFORECAST_REGULAR b 
    WHERE a.DD_PARTNUMBER = b.DD_PARTNUMBER and a.dd_level2 = b.dd_level2
    AND a.DD_FORECASTDATE = b.DD_FORECASTDATE AND a.DD_FORECASTRANK = b.DD_FORECASTRANK and a.dd_forecasttype <> b.dd_forecasttype 
    AND a.dd_forecasttype_rank > b.dd_forecasttype_rank);

/* Keep only those forecast types in full hist which have rank 1 in regular */
DELETE FROM STAGE_FOSALESFORECAST_REGULARWITHFULLHIST h
WHERE NOT EXISTS ( SELECT 1 FROM STAGE_FOSALESFORECAST_REGULAR a where a.DD_PARTNUMBER = h.dd_partnumber and a.dd_level2 = h.dd_level2 and a.dd_forecasttype = h.dd_forecasttype
AND a.DD_FORECASTDATE = h.DD_FORECASTDATE);

ALTER TABLE STAGE_FOSALESFORECAST_OUTLIER
ADD COLUMN dd_forecasttype_rank int;

UPDATE STAGE_FOSALESFORECAST_OUTLIER s
SET s.dd_forecasttype_rank = t.dd_rank
FROM STAGE_FOSALESFORECAST_OUTLIER s,tmp_distinctforecasttypes t
WHERE s.dd_forecasttype = t.dd_forecasttype;

/* For dup rank 1s, delete the one with higher dd_forecasttype_rank(e.g alphabetically) */
DELETE FROM STAGE_FOSALESFORECAST_OUTLIER a
WHERE EXISTS ( SELECT 1 FROM STAGE_FOSALESFORECAST_OUTLIER b 
    WHERE a.DD_PARTNUMBER = b.DD_PARTNUMBER and a.dd_level2 = b.dd_level2
    AND a.DD_FORECASTDATE = b.DD_FORECASTDATE AND a.DD_FORECASTRANK = b.DD_FORECASTRANK and a.dd_forecasttype <> b.dd_forecasttype 
    AND a.dd_forecasttype_rank > b.dd_forecasttype_rank);

/* Keep only those forecast types in outlier full hist which have rank 1 in outlier fcst */
DELETE FROM STAGE_FOSALESFORECAST_OUTLIERWITHFULLHIST h
WHERE NOT EXISTS ( SELECT 1 FROM STAGE_FOSALESFORECAST_OUTLIER a where a.DD_PARTNUMBER = h.dd_partnumber and a.dd_level2 = h.dd_level2 and a.dd_forecasttype = h.dd_forecasttype
AND a.DD_FORECASTDATE = h.DD_FORECASTDATE);

/* Regular fcst is better */
DROP TABLE IF EXISTS stage_bestof_regular_and_outlier;
CREATE TABLE stage_bestof_regular_and_outlier
AS
SELECT a.*,'Regular' dd_forecastregularvsoutlier
FROM STAGE_FOSALESFORECAST_REGULAR a
WHERE EXISTS ( SELECT 1 FROM STAGE_FOSALESFORECAST_OUTLIER b WHERE a.DD_PARTNUMBER = b.DD_PARTNUMBER and a.dd_level2 = b.dd_level2
AND a.DD_FORECASTDATE = b.DD_FORECASTDATE AND a.ct_mape <= b.ct_mape )
AND a.dd_forecastrank = 1;

/* No entry in outlier fcst. This means, there's no outlier */
INSERT INTO stage_bestof_regular_and_outlier
SELECT a.*,'Regular' dd_forecastregularvsoutlier
FROM STAGE_FOSALESFORECAST_REGULAR a
WHERE NOT EXISTS ( SELECT 1 FROM STAGE_FOSALESFORECAST_OUTLIER b WHERE a.DD_PARTNUMBER = b.DD_PARTNUMBER and a.dd_level2 = b.dd_level2 )
AND a.dd_forecastrank = 1;

/* Outlier forecast is better */
INSERT INTO stage_bestof_regular_and_outlier
SELECT b.*,'Outlier' dd_forecastregularvsoutlier
FROM STAGE_FOSALESFORECAST_OUTLIER b 
WHERE NOT EXISTS ( SELECT 1 FROM stage_bestof_regular_and_outlier a WHERE a.DD_PARTNUMBER = b.DD_PARTNUMBER and a.dd_level2 = b.dd_level2 )
AND b.dd_forecastrank = 1;

ALTER TABLE stage_bestof_regular_and_outlier
ADD COLUMN ct_salesquantity_orig decimal(18,4);
ALTER TABLE stage_bestof_regular_and_outlier
ADD COLUMN ct_salesquantity_outliermodified decimal(18,4);

UPDATE stage_bestof_regular_and_outlier t
SET t.ct_salesquantity_orig = s.ct_salesquantity
FROM stage_bestof_regular_and_outlier t,STAGE_FOSALESFORECAST_REGULAR s
WHERE t.DD_PARTNUMBER = s.DD_PARTNUMBER and t.dd_level2 = s.dd_level2 and t.DD_FORECASTDATE = s.DD_FORECASTDATE;

UPDATE stage_bestof_regular_and_outlier t
SET t.ct_salesquantity_outliermodified = t.ct_salesquantity
WHERE dd_forecastregularvsoutlier = 'Outlier';

UPDATE stage_bestof_regular_and_outlier
SET ct_salesquantity = ct_salesquantity_orig;

ALTER TABLE stage_bestof_regular_and_outlier
ADD COLUMN ct_forecastquantity_fullhist decimal(18,4);

UPDATE stage_bestof_regular_and_outlier t
SET t.ct_forecastquantity_fullhist = h.ct_forecastquantity
FROM stage_bestof_regular_and_outlier t,STAGE_FOSALESFORECAST_REGULARWITHFULLHIST h
WHERE t.DD_PARTNUMBER = h.DD_PARTNUMBER and t.dd_level2 = h.dd_level2
AND t.DD_FORECASTDATE = h.DD_FORECASTDATE AND t.dd_forecasttype = h.dd_forecasttype
and t.dd_forecastregularvsoutlier = 'Regular';


UPDATE stage_bestof_regular_and_outlier t
SET t.ct_forecastquantity_fullhist = h.ct_forecastquantity
FROM stage_bestof_regular_and_outlier t,STAGE_FOSALESFORECAST_OUTLIERWITHFULLHIST h
WHERE t.DD_PARTNUMBER = h.DD_PARTNUMBER and t.dd_level2 = h.dd_level2
AND t.DD_FORECASTDATE = h.DD_FORECASTDATE AND t.dd_forecasttype = h.dd_forecasttype
and t.dd_forecastregularvsoutlier = 'Outlier';

UPDATE stage_bestof_regular_and_outlier
SET ct_forecastquantity = ct_forecastquantity_fullhist;

UPDATE stage_bestof_regular_and_outlier
SET dd_reportingdate = '07 JUL 2017';

DROP TABLE IF EXISTS stage_fosalesforecast;
CREATE TABLE stage_fosalesforecast
AS
SELECT * FROM stage_bestof_regular_and_outlier;

DROP TABLE IF EXISTS emd586.tmp_maxrptdate;
CREATE TABLE emd586.tmp_maxrptdate
as
SELECT DISTINCT TO_DATE(dd_reportingdate,'DD MON YYYY') dd_reportingdate
from emd586.stage_fosalesforecast ;

DELETE FROM fact_fosalesforecast f
where TO_DATE(dd_reportingdate,'DD MON YYYY') in ( select dd_reportingdate from emd586.tmp_maxrptdate);

/* Create a de-normalized table containing data from Sales Order */
DROP TABLE IF EXISTS emd586.tmp_sod_denorm_fcst;
CREATE TABLE emd586.tmp_sod_denorm_fcst
AS
SELECT scheddlvrdate.datevalue scheddlvrdate,scheddlvrdate.calendarmonthid, s.STSC_HIST_DMDUNIT partnumber,s.STSC_HIST_LOC plantcode,
SUM(CASE WHEN STSC_HIST_TYPE = 1 THEN 1 ELSE -1 END * s.STSC_HIST_QTY ) ct_salesquantity
FROM emdtempocc4.STSC_HIST s INNER JOIN emdtempocc4.dim_date scheddlvrdate ON scheddlvrdate.datevalue = s.STSC_HIST_STARTDATE
WHERE scheddlvrdate.companycode = 'Not Set'
AND STSC_HIST_EVENT NOT LIKE '%AUTO-CORRECT%'
AND EXISTS ( SELECT 1 FROM emdtempocc4.stsc_dfuview dfuview where dfuview.STSC_DFUVIEW_DMDUNIT = s.STSC_HIST_DMDUNIT AND dfuview.STSC_DFUVIEW_LOC = s.STSC_HIST_LOC AND dfuview.STSC_DFUVIEW_UDC_FCSTLEVEL  = '111')
AND NOT EXISTS ( SELECT 1 FROM emdtempocc4.stsc_dfuview d2 where d2.STSC_DFUVIEW_DMDUNIT = s.STSC_HIST_DMDUNIT AND d2.STSC_DFUVIEW_LOC = s.STSC_HIST_LOC AND d2.STSC_DFUVIEW_UDC_DFULIFECYCLE like 'O%')
GROUP BY scheddlvrdate.datevalue,scheddlvrdate.calendarmonthid,s.STSC_HIST_DMDUNIT,s.STSC_HIST_LOC;

/* Get all dim_partids which have atleast 18 months non-zero sales in last 2 calendar years - e.g if this is run in Apr 2016, it wil get all parts which have atleast 18 months data from Jan 2014 */
drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
create table emd586.tmp_saleshistory_grain_reqmonths
as
select distinct f.partnumber,plantcode
FROM (select distinct partnumber,plantcode,calendarmonthid FROM emd586.tmp_sod_denorm_fcst WHERE year(scheddlvrdate) >= year(current_date) - 2) f
group by f.partnumber,plantcode
having count(*) >= 18;

/* Remove all  rows from denorm WHERE less than 18 month data is available */
DELETE FROM emd586.stage_fosalesforecast f
WHERE NOT EXISTS ( SELECT 1 FROM emd586.tmp_saleshistory_grain_reqmonths t
WHERE t.partnumber = f.dd_partnumber AND t.plantcode = f.dd_level2);

drop table if exists emd586.tmp_saleshistory_grain_reqmonths;
drop table if exists emd586.tmp_saleshistory_grain_reqmonths_2;

drop table if exists emd586.fact_fosalesforecast_temp;
create table emd586.fact_fosalesforecast_temp as
select * from emd586.fact_fosalesforecast WHERE 1=2;

alter table emd586.fact_fosalesforecast_temp add column dd_forecastdatevalue date default '1900-01-01';

delete from emd586.number_fountain m WHERE m.table_name = 'fact_fosalesforecast';

insert into emd586.number_fountain
select  'fact_fosalesforecast',
ifnull(max(d.fact_fosalesforecastid),
	ifnull((select min(s.dim_projectsourceid * s.multiplier)
			from emd586.dim_projectsource s),0))
from emd586.fact_fosalesforecast d
WHERE d.fact_fosalesforecastid <> 1;

insert into emd586.fact_fosalesforecast_temp
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_salesquantity_outliermodified,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup
)
select  (select ifnull(m.max_id, 0) from emd586.number_fountain m WHERE m.table_name = 'fact_fosalesforecast') 
+ row_number() over(order by dd_partnumber,dd_level2,dd_reportingdate,dd_forecastdate,dd_forecasttype) as fact_fosalesforecastid,
ifnull((select min(dim_mdg_partid) from emd586.dim_mdg_part dp where dp.partnumber = sf.dd_partnumber),1) dim_partid,
ifnull((select min(dim_plantid) from emd586.dim_plant pl where pl.plantcode = sf.dd_level2),1) dim_plantid,
ifnull(sf.dd_companycode,'Not Set') dd_companycode ,
--TO_DATE(sf.dd_reportingdate,'DD MON YYYY') dd_reportingdate, --ifnull(cast(sf.dd_reportingdate as date),'1 Jan 1900'),
upper(sf.dd_reportingdate),
1 as dim_dateidreporting,
ifnull(sf.dd_forecasttype,'Not Set'),
ifnull(sf.dd_forecastsample,'Not Set'),
ifnull(sf.dd_forecastdate,1),
1 as dim_dateidforecast,
sf.ct_salesquantity,
sf.ct_salesquantity_outliermodified,
sf.ct_forecastquantity,
sf.ct_lowpi,
sf.ct_highpi,
sf.ct_mape,
ifnull(sf.dd_forecastrank,0),
ifnull(sf.dd_holdoutdate,'1'),
ifnull(sf.dd_lastdate,'1'),
ifnull(sf.dd_forecastmode,'Not Set'),
case when sf.dd_forecastdate is null then cast('1900-01-01' as date)
else cast(concat(substring(sf.dd_forecastdate,1,4) , '-' ,
substring(sf.dd_forecastdate,5,2) , '-' ,
substring(sf.dd_forecastdate,7,2) ) as date)
end dd_forecastdatevalue,
ct_bias_error,
ct_bias_error_rank,
sf.dd_partnumber dd_dmdunit,
sf.dd_level2 dd_loc,
sf.dd_companycode dd_dmdgroup
from emd586.stage_fosalesforecast sf;

/* No plant in part for emd */
/*
UPDATE emd586.fact_fosalesforecast_temp f
SET f.dim_plantid = pl.dim_plantid,
    f.dw_update_date = current_timestamp
from emd586.dim_plant pl, EMD586.dim_mdg_part p,emd586.fact_fosalesforecast_temp f
WHERE f.dim_partid = p.dim_mdg_partid
AND p.plant = pl.plantcode
AND p.projectsourceid = 1
AND f.dim_plantid <> pl.dim_plantid*/

UPDATE emd586.fact_fosalesforecast_temp f
SET f.dim_dateidreporting = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	from emd586.dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
emd586.fact_fosalesforecast_temp f
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = d.datevalue;

UPDATE emd586.fact_fosalesforecast_temp f
SET f.dim_dateidforecast = d.dim_dateid
from (select datevalue,min(dim_dateid) dim_dateid
	        from emd586.dim_date d  where d.companycode = 'Not Set' group by datevalue)d,
emd586.fact_fosalesforecast_temp f
WHERE f.dd_forecastdatevalue = d.datevalue AND f.dim_dateidforecast <> d.dim_dateid;

insert into emd586.fact_fosalesforecast
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_salesquantity_outliermodified,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup
)
select
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dd_reportingdate,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_salesquantity_outliermodified,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_forecastrank,
dd_holdoutdate,
dd_lastdate,
dd_forecastmode,
ct_bias_error,
ct_bias_error_rank,
dd_dmdunit,
dd_loc,
dd_dmdgroup
from emd586.fact_fosalesforecast_temp;

/* Update future sales to NULL */
UPDATE emd586.fact_fosalesforecast f
SET ct_salesquantity = NULL
FROM emd586.dim_date d,emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_salesquantity = 0 
AND f.dim_dateidforecast = d.dim_dateid
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND d.datevalue >= to_date(f.dd_reportingdate,'YYYY-MM-DD');

UPDATE emd586.fact_fosalesforecast f
SET ct_salesquantity_outliermodified = NULL
FROM emd586.dim_date d,emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_salesquantity_outliermodified = 0 
AND f.dim_dateidforecast = d.dim_dateid
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND d.datevalue >= to_date(f.dd_reportingdate,'YYYY-MM-DD');


/* Update highpi and lowpi to NULL for dates before holdout date */
UPDATE emd586.fact_fosalesforecast f
set ct_highpi = NULL
FROM emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_highpi = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

UPDATE emd586.fact_fosalesforecast f
set ct_lowpi = NULL
FROM emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_lowpi = 0
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND dd_forecastsample = 'Train';

/* Format reporting date as DD MON YYYY */
UPDATE emd586.fact_fosalesforecast f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD MON YYYY')
where f.dd_reportingdate like '%-%-%';

UPDATE emd586.fact_fosalesforecast f
SET dd_latestreporting = 'No'
WHERE dd_latestreporting <> 'No';

UPDATE emd586.fact_fosalesforecast f
SET dd_latestreporting = 'Yes'
FROM emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
where TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate ;


UPDATE emd586.fact_fosalesforecast f
SET ct_salesquantity_outliermodified = ct_salesquantity
FROM emd586.fact_fosalesforecast f,emd586.tmp_maxrptdate r
WHERE ct_salesquantity_outliermodified is null
AND TO_DATE(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND ct_salesquantity is not null;

DROP TABLE IF EXISTS tmp_previous_reportingdate;
CREATE TABLE tmp_previous_reportingdate
AS
SELECT max(to_date(dd_reportingdate,'DD MON YYYY')) dd_reportingdate_date
FROM fact_fosalesforecast a
WHERE to_date(dd_reportingdate,'DD MON YYYY') <
(SELECT MAX(to_date(dd_reportingdate,'DD MON YYYY')) FROM fact_fosalesforecast);

/* Update other fields from previous std fcst */
UPDATE fact_fosalesforecast f
SET 
    f.DD_UDC_STRENGTH = f2.DD_UDC_STRENGTH,
    f.DD_UDC_TADESCR = f2.DD_UDC_TADESCR,
    f.DD_UDC_BRANDDESCR = f2.DD_UDC_BRANDDESCR,
    f.DD_UDC_STRENGTHDESCR = f2.DD_UDC_STRENGTHDESCR,
    f.DD_UDC_GPS = f2.DD_UDC_GPS,
    f.dim_dmdunitid = f2.dim_dmdunitid,
    f.dd_UDC_CONTAINER = f2.dd_UDC_CONTAINER,
    f.dd_dmdunit_descr = f2.dd_dmdunit_descr,
    f.DD_UDC_COUNTRY = f2.DD_UDC_COUNTRY,
    f.DD_UDC_REGION = f2.DD_UDC_REGION,
    f.DD_UDC_MARKET = f2.DD_UDC_MARKET,
    f.dd_STSC_LOC_UDC_RESPCMG = f2.dd_STSC_LOC_UDC_RESPCMG,
    f.dim_locid = f2.dim_locid,
    f.DD_UDC_FCSTLEVEL = f2.DD_UDC_FCSTLEVEL,
    f.dd_STSC_DFUVIEW_UDC_AVGSALESPMONTH = f2.dd_STSC_DFUVIEW_UDC_AVGSALESPMONTH,
    f.dd_STSC_DFUVIEW_UDC_VOLATILITY = f2.dd_STSC_DFUVIEW_UDC_VOLATILITY,
    f.dd_STSC_DFUVIEW_UDC_SEGMENTATION = f2.dd_STSC_DFUVIEW_UDC_SEGMENTATION,
    f.dim_dfuviewid = f2.dim_dfuviewid,
    f.dd_stsc_dfuview_udc_averageprice = f2.dd_stsc_dfuview_udc_averageprice,
    f.AMT_UNITSELLINGPRICE = f2.AMT_UNITSELLINGPRICE,
    f.dd_STSC_DFUVIEW_UDC_DFULIFECYCLE = f2.dd_STSC_DFUVIEW_UDC_DFULIFECYCLE,
    f.ct_STSC_HISTFCST_LAG = f2.ct_STSC_HISTFCST_LAG,
f.ct_STSC_HISTFCST_BASEFCST = f2.ct_STSC_HISTFCST_BASEFCST,
f.ct_STSC_HISTFCST_NONBASEFCST = f2.ct_STSC_HISTFCST_NONBASEFCST,
f.ct_STSC_HISTFCST_RECONCILEDFCST = f2.ct_STSC_HISTFCST_RECONCILEDFCST,
f.ct_STSC_HISTFCST_DUR  = f2.ct_STSC_HISTFCST_DUR,
f.ct_stsc_histfcst_targetimpact = f2.ct_stsc_histfcst_targetimpact,
f.ct_stsc_marketfcst_baseplusnonbaseminustargetimpact = f2.ct_stsc_marketfcst_baseplusnonbaseminustargetimpact,
f.dd_stsc_histfcst_fcstdate = f2.dd_stsc_histfcst_fcstdate,
f.dd_stsc_histfcst_startdate = f2.dd_stsc_histfcst_startdate,
f.amt_cogsrate_or_stdunitprice_gbl = f2.amt_cogsrate_or_stdunitprice_gbl,
f.amt_sellingpriceperunit_gbl = f2.amt_sellingpriceperunit_gbl,
f.ct_marginpercent_salesytd = f2.ct_marginpercent_salesytd,
f.ct_marginpercent_salesplusfcst_currentyear = f2.ct_marginpercent_salesplusfcst_currentyear,
f.ct_marginpercent_salesplusjdafcst_currentyear = f2.ct_marginpercent_salesplusjdafcst_currentyear

FROM fact_fosalesforecast f,fact_fosalesforecast f2,
tmp_previous_reportingdate prev, tmp_maxrptdate r
WHERE to_date(f.dd_reportingdate,'DD MON YYYY') = r.dd_reportingdate
AND to_date(f2.dd_reportingdate,'DD MON YYYY') = prev.dd_reportingdate_date
AND f.dd_dmdunit = f2.dd_dmdunit AND f.dd_loc = f2.dd_loc
AND f.dd_forecastdate = f2.dd_forecastdate
AND f.dd_forecasttype = f2.dd_forecasttype;

/* Re-calculate mapes and gains with outlier-modified-history */
DROP TABLE IF EXISTS emd586.tmp_custmapes_fosp;
CREATE TABLE emd586.tmp_custmapes_fosp
AS
SELECT f.dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype,
100 * avg(abs((ct_stsc_marketfcst_baseplusnonbaseminustargetimpact-ct_salesquantity_outliermodified)/ct_salesquantity_outliermodified)) ct_mape_businessforecast,
100 * avg(abs((ct_STSC_HISTFCST_BASEFCST-ct_salesquantity_outliermodified)/ct_salesquantity_outliermodified)) ct_mape_baseforecast
FROM emd586.fact_fosalesforecast f , emd586.tmp_maxrptdate r
WHERE f.DD_FORECASTSAMPLE = 'Test'
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY')
GROUP BY f.dd_reportingdate,dd_dmdunit,dd_loc,dd_forecasttype;

UPDATE emd586.fact_fosalesforecast f
SET f.ct_mape_businessforecast = t.ct_mape_businessforecast,
    f.ct_mape_baseforecast = t.ct_mape_baseforecast
FROM emd586.fact_fosalesforecast f,emd586.tmp_custmapes_fosp t,emd586.tmp_maxrptdate r
where f.dd_reportingdate = t.dd_reportingdate
AND f.dd_dmdunit = t.dd_dmdunit
AND f.dd_loc = t.dd_loc
AND f.dd_forecasttype = t.dd_forecasttype
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

UPDATE fact_fosalesforecast f
SET f.dd_flag_fopsmapebetterthanmkt = 1
FROM fact_fosalesforecast f, emd586.tmp_maxrptdate r
WHERE ct_mape < ct_mape_businessforecast
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

UPDATE fact_fosalesforecast f
SET dd_flag_fopsmapebetterthanSTAT = 1
FROM fact_fosalesforecast f, emd586.tmp_maxrptdate r
WHERE ct_mape < ct_mape_baseforecast
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');

/*DROP TABLE IF EXISTS tmp_last6dates_fcst;
CREATE TABLE tmp_last6dates_fcst
AS
SELECT dd_reportingdate,
rank() over(order by to_date(dd_reportingdate,'dd mon yyyy') desc)  dd_rank
FROM (select distinct to_date(dd_reportingdate,'dd mon yyyy') dd_reportingdate  from fact_fosalesforecast);*/

/* Pick up the last reporting date from the current month plus previous 5 months */
DROP TABLE IF EXISTS tmp_last6dates_fcst;
CREATE TABLE tmp_last6dates_fcst
AS
select rank() over(order by dd_reportingdate_datefmt desc) dd_rank,to_char(dd_reportingdate_datefmt,'DD MON YYYY') dd_reportingdate_char,
dd_reportingdate_datefmt dd_reportingdate_date
FROM (select max(to_date(dd_reportingdate,'DD MON YYYY')) dd_reportingdate_datefmt,month(to_date(dd_reportingdate,'DD MON YYYY')),year(to_date(dd_reportingdate,'DD MON YYYY')) 
    from fact_fosalesforecast f where f.dd_forecastrank = 1 
    GROUP BY month(to_date(dd_reportingdate,'DD MON YYYY')),year(to_date(dd_reportingdate,'DD MON YYYY')));

/* Pick up the latest 6 reporting dates */
DELETE FROM tmp_last6dates_fcst
WHERE dd_rank > 6;

SELECT *
FROM tmp_last6dates_fcst;


/* Count the no. of points in last 6 months for each dmdunit-loc pair */
DROP TABLE IF EXISTS tmp_count_parts_6months;
CREATE TABLE tmp_count_parts_6months
AS
SELECT dd_dmdunit,dd_loc,count(*) dd_cnt
FROM (select distinct dd_dmdunit,dd_loc,dd_reportingdate 
from fact_fosalesforecast 
where dd_reportingdate in (select distinct t.dd_reportingdate_char from tmp_last6dates_fcst t)
AND CT_MAPE_BASEFORECAST is not null and CT_MAPE_BUSINESSFORECAST is not null) f
GROUP BY dd_dmdunit,dd_loc;

/* Ignore parts where less than 3 points have non null business and stat mapes */

DELETE FROM tmp_count_parts_6months
WHERE dd_cnt < 3;

DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_upd;
CREATE TABLE tmp_distinctdmdunit_loc_mape_upd
as
select distinct f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.ct_mape,DD_FLAG_FOPSMAPEBETTERTHANSTAT,DD_FLAG_FOPSMAPEBETTERTHANMKT,
CT_MAPE_BUSINESSFORECAST,CT_MAPE_BASEFORECAST,(ct_mape-CT_MAPE_BASEFORECAST) ct_gaincriteria_1,(ct_mape - CT_MAPE_BUSINESSFORECAST) ct_gaincriteria_2
from fact_fosalesforecast f inner join tmp_count_parts_6months t on t.dd_dmdunit = f.dd_dmdunit and t.dd_loc = f.dd_loc
WHERE dd_reportingdate in (select dd_reportingdate_char from tmp_last6dates_fcst)
AND EXISTS ( SELECT 1 FROM tmp_count_parts_6months tc where tc.dd_dmdunit = f.dd_dmdunit and tc.dd_loc = f.dd_loc)
AND f.dd_forecastrank = 1;

DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape;
CREATE TABLE tmp_distinctdmdunit_loc_mape
as
SELECT dd_dmdunit,dd_loc,max(ct_mape) ct_mape_max,max(ct_gaincriteria_1) max_ct_gaincriteria_1,max(ct_gaincriteria_2) max_ct_gaincriteria_2,
avg(ct_gaincriteria_1) avg_ct_gaincriteria_1,avg(ct_gaincriteria_2) avg_ct_gaincriteria_2
FROM tmp_distinctdmdunit_loc_mape_upd
GROUP BY dd_dmdunit,dd_loc;

/* Count the no. of months when gain was -ve */
DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_counts_criteria_1;
CREATE TABLE tmp_distinctdmdunit_loc_mape_counts_criteria_1
as
SELECT dd_dmdunit,dd_loc,count(*) cnt
FROM tmp_distinctdmdunit_loc_mape_upd t 
WHERE ct_gaincriteria_1 < 0
GROUP BY dd_dmdunit,dd_loc;

DROP TABLE IF EXISTS tmp_distinctdmdunit_loc_mape_counts_criteria_2;
CREATE TABLE tmp_distinctdmdunit_loc_mape_counts_criteria_2
as
SELECT dd_dmdunit,dd_loc,count(*) cnt
FROM tmp_distinctdmdunit_loc_mape_upd t 
WHERE ct_gaincriteria_2 < 0
GROUP BY dd_dmdunit,dd_loc;

DELETE FROM tmp_distinctdmdunit_loc_mape
WHERE ct_mape_max > 30;

UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_1 = 0,
    f.ct_gaincriteria_2 = 0
WHERE f.dd_reportingdate in (select dd_reportingdate_char from tmp_last6dates_fcst where dd_rank = 1);


/* Gain1 - Unstable not in ('Mules','Horses'). All 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_1 = t.avg_ct_gaincriteria_1
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_1 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION not in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
--AND g1.cnt = 6
AND t.max_ct_gaincriteria_1 < 0;

/* Gain2 - Unstable not in ('Mules','Horses'). All 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_2 = t.avg_ct_gaincriteria_2
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_2 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION not in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
--AND g1.cnt = 6
AND t.max_ct_gaincriteria_2 < 0;

/* Gain1 - Stable  in ('Mules','Horses'). At-least 4 out of 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_1 = t.avg_ct_gaincriteria_1
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_1 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION  in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
AND g1.cnt >= 4
--AND t.max_ct_gaincriteria_1 < 0
AND avg_ct_gaincriteria_1 < 0;

/* Gain2 - Stable  in ('Mules','Horses'). At-least 4 out of 6 months should have gains */
UPDATE fact_fosalesforecast f
SET f.ct_gaincriteria_2 = t.avg_ct_gaincriteria_2
FROM fact_fosalesforecast f,tmp_distinctdmdunit_loc_mape t,tmp_last6dates_fcst ltdt,
emdtempocc4.STSC_DFUVIEW s, tmp_distinctdmdunit_loc_mape_counts_criteria_2 g1
WHERE f.dd_reportingdate = ltdt.dd_reportingdate_char and ltdt.dd_rank = 1
AND s.stsc_dfuview_dmdunit = f.dd_dmdunit and stsc_dfuview_loc = f.dd_loc 
AND s.STSC_DFUVIEW_UDC_SEGMENTATION  in ('Mules','Horses')
AND f.dd_dmdunit = t.dd_dmdunit  AND f.dd_loc = t.dd_loc
AND f.dd_dmdunit = g1.dd_dmdunit AND f.dd_loc = g1.dd_loc
AND g1.cnt >= 4
--AND t.max_ct_gaincriteria_2 < 0
AND avg_ct_gaincriteria_2 < 0;



UPDATE fact_fosalesforecast f
SET f.ct_forecastquantity = s.ct_forecastquantity
FROM fact_fosalesforecast f, stage_bestof_regular_and_outlier s
WHERE to_date(f.dd_reportingdate,'dd mon yyyy') = (select r.dd_reportingdate from emd586.tmp_maxrptdate r)
AND f.dd_dmdunit = s.dd_partnumber
AND f.dd_loc = s.dd_level2
AND f.dd_forecastdate = s.dd_forecastdate
AND f.dd_forecastrank = 1 and s.dd_forecastrank = 1
AND f.dd_forecasttype = s.dd_forecasttype
AND f.ct_forecastquantity <> s.ct_forecastquantity;



DELETE FROM emd586.FACT_FOSALESFORECAST 
where DD_UDC_FCSTLEVEL <> '111' 
and to_date(dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from tmp_maxrptdate);


DELETE FROM emd586.FACT_FOSALESFORECAST f
WHERE to_date(dd_reportingdate,'DD MON YYYY') = (select dd_reportingdate from tmp_maxrptdate)
and exists
   ( select 1
       from emdtempocc4.stsc_dfuview d
        where f.DD_DMDUNIT = d.STSC_DFUVIEW_DMDUNIT 
        AND f.dd_loc = d.STSC_DFUVIEW_LOC 
        and STSC_DFUVIEW_UDC_DFULIFECYCLE like 'O%');
        
        
/* Delete all rows for given part/plant/fcsttype/rptdate if any fcst is > 1million */
DROP TABLE IF EXISTS emd586.backup_fact_fosalesforecast_largefcstqty;
CREATE TABLE emd586.backup_fact_fosalesforecast_largefcstqty
AS
SELECT distinct f.dd_reportingdate,DD_DMDUNIT,dd_loc,dd_forecasttype
from emd586.fact_fosalesforecast f, emd586.tmp_maxrptdate r
where ct_forecastquantity > 20000000
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY')
AND DD_DMDUNIT <> 'FR2XM85';

DELETE FROM emd586.fact_fosalesforecast f
where exists (SELECT 1 FROM emd586.backup_fact_fosalesforecast_largefcstqty t
where t.dd_reportingdate = f.dd_reportingdate and t.DD_DMDUNIT = f.DD_DMDUNIT and t.dd_loc = f.dd_loc and t.dd_forecasttype = f.dd_forecasttype);

/* Populate No. of Days */
UPDATE emd586.FACT_FOSALESFORECAST f
SET f.dd_daysinmonth = extract(day from d.datevalue)||'D'
FROM emd586.FACT_FOSALESFORECAST f,emd586.dim_date d, emd586.tmp_maxrptdate r
WHERE f.dim_dateidforecast = d.dim_dateid
AND r.dd_reportingdate = TO_DATE(f.dd_reportingdate,'DD MON YYYY');


DROP TABLE IF EXISTS tmp_upd_ct_next12monthsfopsfcst;
CREATE TABLE tmp_upd_ct_next12monthsfopsfcst
as
select f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.dd_forecasttype,
d.datevalue dd_forecastdate,d.datevalue + interval '11' month dd_forecastdate_plus11,
sum(f1.ct_forecastquantity) ct_next12monthsfopsfcst
FROM fact_fosalesforecast f inner join fact_fosalesforecast f1
ON f.dd_reportingdate = f1.dd_reportingdate AND f.dd_dmdunit = f1.dd_dmdunit AND f.dd_loc = f1.dd_loc AND f.dd_forecasttype = f1.dd_forecasttype
INNER JOIN dim_date d on d.dim_dateid = f.dim_dateidforecast
INNER JOIN dim_date d1 on d1.dim_dateid = f1.dim_dateidforecast
WHERE d1.datevalue >= d.datevalue
AND d1.datevalue <= d.datevalue + interval '11' month
AND to_date(f.dd_reportingdate,'DD MON YYYY') = (SELECT DISTINCT r.dd_reportingdate from emd586.tmp_maxrptdate r)
GROUP BY f.dd_reportingdate,f.dd_dmdunit,f.dd_loc,f.dd_forecasttype,d.datevalue,d.datevalue + interval '11' month;

UPDATE fact_fosalesforecast f
SET f.ct_next12monthsfopsfcst = f1.ct_next12monthsfopsfcst
FROM fact_fosalesforecast f inner join dim_date d ON d.dim_dateid = f.dim_dateidforecast
    inner join tmp_upd_ct_next12monthsfopsfcst f1
ON f.dd_reportingdate = f1.dd_reportingdate AND f.dd_dmdunit = f1.dd_dmdunit AND f.dd_loc = f1.dd_loc AND f.dd_forecasttype = f1.dd_forecasttype
WHERE f1.dd_forecastdate = d.datevalue;

