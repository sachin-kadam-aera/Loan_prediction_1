
/* This is the main SQL script for sales forecast subject area */
/* This has 3 sections */
/* 1. Export Sales/Billing Data to a flatfile using vw_bi_export_historical_sales_data_mahindra.sql. Output Flatfile name: stage_saleshistory_mgbmr.txt */
/* 2. Run the forecast_wrapper.sh which will take the output of step 1 as input and generate another csv - this csv will also have the forecasted columns */
/*	Input: stage_saleshistory_mgbmr.txt. Output: sales_forecast_bm2.txt */
/* 3. Populate the fact_salesforecast fact so that data is available in the Forecasting Dashboard */
/*	Input: sales_forecast_bm2.txt	*/


/******************************************************************************************************/
/*******************************STEP 1 Export Sales/Billing Data to a flatfile ************************/
/*****************************Call vw_bi_export_historical_sales_data.sql******************************/
/******************************************************************************************************/

/* Get the Min and Max Dates For Creating a List of Year Month Periods */
drop table if exists tmp_saleshistory_daterange;
create table tmp_saleshistory_daterange as
select max(bd.datevalue) maxdate, min(bd.datevalue) mindate
from fact_billing fb, dim_billingdocumenttype bdt, dim_salesdivision sd,
dim_salesorg so, dim_distributionchannel ddc, dim_part p, dim_documentcategory dc,
dim_company comp , dim_date bd, dim_customer c
where fb.dim_Documenttypeid = bdt.dim_billingdocumenttypeid and bdt.Type in
('ZF1', 'ZMRT', 'ZRE', 'XM01', 'XM02', 'ZPRW', 'ZTF', 'ZST', 'ZSR','ZUT','ZUTR','ZF3', 'XM05','ZI','ZIR')
and fb.dim_salesorgid = so.dim_salesorgid and so.SalesOrgCode = 'F041'
and fb.Dim_DistributionChannelId = ddc.Dim_DistributionChannelid and ddc.DistributionChannelCode = '01'
and fb.dim_salesdivisionid = sd.dim_salesdivisionid and sd.DivisionCode in ('01')
and fb.dim_partid = p.dim_partid
and fb.dim_customerid = c.dim_customerid
and fb.dim_documentcategoryid = dc.dim_documentcategoryid
and fb.dim_companyid = comp.dim_companyid
and fb.dim_dateidbilling = bd.dim_dateid
and fb.dim_dateidbilling <> 1
and bd.datevalue > '2012-03-01';

/* Get all Year Month Periods based on Min and Max Dates */
drop table if exists tmp_saleshistory_yyyymm;
create table tmp_saleshistory_yyyymm as
select calendaryear, calendarmonthnumber, calendarmonthid, datevalue
from dim_date, tmp_saleshistory_daterange
where datevalue between mindate and maxdate
and dayofmonth = 1
and companycode = '7001'
and datevalue >= '2012-04-01'
order by datevalue;

/* Get all Material Group, Business Manager, Region Combinations for Division 01 */
drop table if exists tmp_saleshistory_ppallperiods;
create table tmp_saleshistory_ppallperiods as
select  distinct ifnull(p.materialgroup,'Not Set') as dd_materialgroup,
		ifnull(c.businessmanager_mahindra,'Not Set') as dd_businessmanager,
		ifnull(c.region,'Not Set') as dd_region,
		ifnull(bd.companycode,'Not Set') as dd_companycode
from fact_billing fb, dim_billingdocumenttype bdt, dim_salesdivision sd,
dim_salesorg so, dim_distributionchannel ddc, dim_part p, dim_documentcategory dc,
dim_company comp , dim_date bd, dim_customer c
where fb.dim_Documenttypeid = bdt.dim_billingdocumenttypeid and bdt.Type in
('ZF1', 'ZMRT', 'ZRE', 'XM01', 'XM02', 'ZPRW', 'ZTF', 'ZST', 'ZSR','ZUT','ZUTR','ZF3', 'XM05','ZI','ZIR')
and fb.dim_salesorgid = so.dim_salesorgid and so.SalesOrgCode = 'F041'
and fb.Dim_DistributionChannelId = ddc.Dim_DistributionChannelid and ddc.DistributionChannelCode = '01'
and fb.dim_salesdivisionid = sd.dim_salesdivisionid and sd.DivisionCode in ('01')
and fb.dim_partid = p.dim_partid
and fb.dim_customerid = c.dim_customerid
and fb.dim_documentcategoryid = dc.dim_documentcategoryid
and fb.dim_companyid = comp.dim_companyid
and fb.dim_dateidbilling = bd.dim_dateid
and fb.dim_dateidbilling <> 1
and bd.datevalue >= '2012-04-01';


/* Create a Material Group, Business Manager, Region record for each Year Month period so that we have all consecutuve months */
drop table if exists tmp_saleshistory_allperiods;
create table tmp_saleshistory_allperiods as
select  dd_materialgroup, dd_businessmanager, dd_region, dd_companycode,
		r.dim_dateid,
		d.calendaryear, d.calendarmonthnumber, d.calendarmonthid, d.datevalue
from tmp_saleshistory_yyyymm d, tmp_saleshistory_ppallperiods f, dim_date r
where r.datevalue = d.datevalue
and r.companycode = f.dd_companycode;


/* Select Parts which have Sales Quantities for more than or equal to 36 periods  */
/* This step is not required as Mahindra has low volume and we will include all parts in division 01 */

/* Get the Sales Quantities for Historical Periods  */
drop table if exists tmp_saleshistory_preallperiods;
create table tmp_saleshistory_preallperiods as
select  ifnull(p.materialgroup,'Not Set') as dd_materialgroup,
		ifnull(c.businessmanager_mahindra,'Not Set') as dd_businessmanager,
		ifnull(c.region,'Not Set') as dd_region,
		ifnull(bd.companycode,'Not Set') as dd_companycode,
		bd.calendaryear, bd.calendarmonthnumber, bd.calendarmonthid,
		sum((case when dc.DocumentCategory in ('N','O') then -1*fb.ct_BillingQtySalesUOM
				  else fb.ct_BillingQtySalesUOM END)) as ct_salesquantity
from fact_billing fb, dim_billingdocumenttype bdt, dim_salesdivision sd,
dim_salesorg so, dim_distributionchannel ddc, dim_part p, dim_documentcategory dc,
dim_company comp , dim_date bd, dim_customer c
where fb.dim_Documenttypeid = bdt.dim_billingdocumenttypeid and bdt.Type in
('ZF1', 'ZMRT', 'ZRE', 'XM01', 'XM02', 'ZPRW', 'ZTF', 'ZST', 'ZSR','ZUT','ZUTR','ZF3', 'XM05','ZI','ZIR')
and fb.dim_salesorgid = so.dim_salesorgid and so.SalesOrgCode = 'F041'
and fb.Dim_DistributionChannelId = ddc.Dim_DistributionChannelid and ddc.DistributionChannelCode = '01'
and fb.dim_salesdivisionid = sd.dim_salesdivisionid and sd.DivisionCode in ('01')
and fb.dim_partid = p.dim_partid
and fb.dim_customerid = c.dim_customerid
and fb.dim_documentcategoryid = dc.dim_documentcategoryid
and fb.dim_companyid = comp.dim_companyid
and fb.dim_dateidbilling = bd.dim_dateid
and fb.dim_dateidbilling <> 1
and bd.datevalue >= '2012-04-01'
group by ifnull(p.materialgroup,'Not Set'),
		ifnull(c.businessmanager_mahindra,'Not Set'),
		ifnull(c.region,'Not Set'),
		ifnull(bd.companycode,'Not Set'),
		bd.calendaryear, bd.calendarmonthnumber, bd.calendarmonthid;



/* Get the Sales Quantity, if historical sales delivered is not available then put zero */
drop table if exists tmp_saleshistory_allperiodsqty;
create table tmp_saleshistory_allperiodsqty as
select  a.dd_materialgroup, a.dd_businessmanager, a.dd_region, a.dd_companycode,
		a.dim_dateid, a.calendaryear, a.calendarmonthnumber, a.calendarmonthid, a.datevalue,
		case when f.ct_salesquantity is not null then f.ct_salesquantity else 0 end ct_salesquantity,
		case when f.ct_salesquantity is not null then 'Actual' else 'Filler' end dd_salesquantityflag
from tmp_saleshistory_allperiods a left outer join tmp_saleshistory_preallperiods f
on a.dd_materialgroup = f.dd_materialgroup and a.dd_businessmanager = f.dd_businessmanager and a.dd_region = f.dd_region and
a.dd_companycode = f.dd_companycode and a.calendarmonthid = f.calendarmonthid;

/* final stage - getting ready for export */
drop table if exists stage_saleshistory_mgbmr;
create table stage_saleshistory_mgbmr as
select 	dd_materialgroup, dd_businessmanager, dd_region, dd_companycode, calendarmonthid as dd_yyyymm, ct_salesquantity, dd_salesquantityflag
from tmp_saleshistory_allperiodsqty;

DELETE FROM stage_fosalesforecast;

\i /db/schema_migration/bin/forecast_wrapper.sh ;

drop table if exists fact_fosalesforecast_temp;
create table fact_fosalesforecast_temp as
select * from fact_fosalesforecast where 1=2;

alter table fact_fosalesforecast_temp add column dd_reportingdatevalue ansidate not null default '1900-01-01';
alter table fact_fosalesforecast_temp add column dd_forecastdatevalue ansidate not null default '1900-01-01';


delete from number_fountain m where m.table_name = 'fact_fosalesforecast';

insert into number_fountain
select 	'fact_fosalesforecast',
	ifnull(max(d.fact_fosalesforecastid),
	ifnull((select s.dim_projectsourceid * s.multiplier from dim_projectsource s),0))
from fact_fosalesforecast d
where d.fact_fosalesforecastid <> 1;

insert into fact_fosalesforecast_temp
(
        fact_fosalesforecastid,
        dim_partid,
        dim_plantid,
        dd_companycode,
        dd_reportingdate,
        dim_dateidreporting,
        dd_forecasttype,
        dd_forecastsample,
        dd_forecastdate,
        dim_dateidforecast,
        ct_salesquantity,
        ct_forecastquantity,
        ct_mape,
        dd_forecastrank,
        dd_holdoutdate,
        dd_lastdate,
        dd_forecastmode,
        dd_forecastgrainattrone,
        dd_forecastgrainattrtwo,
        dd_forecastgrainattrthree,
        dd_forecastgrain,
		dd_reportingdatevalue,
		dd_forecastdatevalue
)
select 	(select ifnull(m.max_id, 0) from number_fountain m where m.table_name = 'fact_fosalesforecast')
         + row_number() over() as fact_fosalesforecastid,
        1 as dim_partid,
        1 as dim_plantid,
        ifnull(dd_companycode,'Not Set') as dd_companycode,
		ifnull(sf.dd_reportingdate,1),
		1 as dim_dateidreporting,
        ifnull(sf.dd_forecasttype,'Not Set'),
        ifnull(sf.dd_forecastsample,'Not Set'),
		ifnull(sf.dd_forecastdate,1),
		1 as dim_dateidforecast,
		ifnull(sf.ct_salesquantity,0),
		ifnull(sf.ct_forecastquantity,0),
		ifnull(sf.ct_mape,0),
		ifnull(sf.dd_forecastrank,0),
		ifnull(sf.dd_holdoutdate,1),
		ifnull(sf.dd_lastdate,1),
		ifnull(sf.dd_forecastmode,'Not Set'),
        ifnull(dd_forecastgrainattrone,'Not Set'),
        ifnull(dd_forecastgrainattrtwo,'Not Set'),
        ifnull(dd_forecastgrainattrthree,'Not Set'),
        ifnull(dd_forecastgrain,'Not Set'),
		case when sf.dd_reportingdate is null then cast('1900-01-01' as ansidate)
		     else cast(concat(substring(sf.dd_reportingdate,1,4) , '-' ,
							  substring(sf.dd_reportingdate,5,2) , '-' ,
							  substring(sf.dd_reportingdate,7,2) ) as ansidate)
		end dd_reportingdatevalue,
		case when sf.dd_forecastdate is null then cast('1900-01-01' as ansidate)
		     else cast(concat(substring(sf.dd_forecastdate,1,4) , '-' ,
							  substring(sf.dd_forecastdate,5,2) , '-' ,
							  substring(sf.dd_forecastdate,7,2) ) as ansidate)
		end dd_forecastdatevalue
from stage_fosalesforecast sf;

delete from number_fountain m where m.table_name = 'fact_fosalesforecast';



update fact_fosalesforecast_temp f
from dim_date d
set f.dim_dateidreporting = d.dim_dateid,
    f.dw_update_date = current_timestamp
where 	f.dd_companycode = d.companycode and
		f.dd_reportingdatevalue = d.datevalue and
		f.dim_dateidreporting <> d.dim_dateid;

update fact_fosalesforecast_temp f
from dim_date d
set f.dim_dateidforecast = d.dim_dateid,
    f.dw_update_date = current_timestamp
where 	f.dd_companycode = d.companycode and
		f.dd_forecastdatevalue = d.datevalue and
		f.dim_dateidforecast <> d.dim_dateid;


/* Delete data from fact table if the reporting date already exists */
DROP TABLE IF EXISTS tmp_dd_reportingdate;
create table tmp_dd_reportingdate as
select distinct dd_reportingdate from fact_fosalesforecast_temp;

delete from fact_fosalesforecast where dd_reportingdate in (select date_format(cast(varchar(dd_reportingdate,8) as date),'%d %b %Y') from tmp_dd_reportingdate);

/* insert new data into the fact table */
insert into fact_fosalesforecast
(
        fact_fosalesforecastid,
        dim_partid,
        dim_plantid,
        dd_companycode,
        dd_reportingdate,
        dim_dateidreporting,
        dd_forecasttype,
        dd_forecastsample,
        dd_forecastdate,
        dim_dateidforecast,
        ct_salesquantity,
        ct_forecastquantity,
        ct_mape,
        dd_forecastrank,
        dd_holdoutdate,
        dd_lastdate,
        dd_forecastmode,
        dw_insert_date,
        dw_update_date,
        dim_projectsourceid,
        dd_latestreporting,
        ct_forecastquantity_customer,
        dd_forecastgrainattrone,
        dd_forecastgrainattrtwo,
        dd_forecastgrainattrthree,
        dd_forecastgrainattrfour,
        dd_forecastgrainattrfive,
        dd_forecastgrain
)
select
        fact_fosalesforecastid,
        dim_partid,
        dim_plantid,
        dd_companycode,
        date_format(cast(varchar(dd_reportingdate,8) as date),'%d %b %Y') dd_reportingdate,
        dim_dateidreporting,
        dd_forecasttype,
        dd_forecastsample,
	dd_forecastdate,
        /*cast(varchar(dd_forecastdate,8) as date) dd_forecastdate,*/
        dim_dateidforecast,
        ct_salesquantity,
        ct_forecastquantity,
        ct_mape,
        dd_forecastrank,
        /*dd_holdoutdate,*/
        date_format(cast(varchar(dd_holdoutdate,8) as date),'%d %b %Y') dd_holdoutdate,
        date_format(cast(varchar(dd_lastdate,8) as date),'%d %b %Y') dd_lastdate,
        dd_forecastmode,
        dw_insert_date,
        dw_update_date,
        dim_projectsourceid,
        dd_latestreporting,
        ct_forecastquantity_customer,
        dd_forecastgrainattrone,
        dd_forecastgrainattrtwo,
        dd_forecastgrainattrthree,
        dd_forecastgrainattrfour,
        dd_forecastgrainattrfive,
        dd_forecastgrain
from fact_fosalesforecast_temp;

/* update the dd_latestreporting flag */
update fact_fosalesforecast f
set dd_latestreporting = 'No';

update fact_fosalesforecast f
from dim_date d,
	( select max(d.datevalue) datevalue
	  from fact_fosalesforecast f, dim_date d
	  where f.dim_dateidreporting = d.dim_dateid ) m
set dd_latestreporting = 'Yes'
where f.dim_dateidreporting = d.dim_dateid and m.datevalue = d.datevalue;


UPDATE fact_fosalesforecast
SET dd_forecasttype = 'Trend Monthly Seasonality - Mult'
WHERE dd_forecasttype = 'Trend_MonthlySeasonality_Mult';

UPDATE fact_fosalesforecast
SET dd_forecasttype = 'Trend Monthly Seasonality'
WHERE dd_forecasttype = 'Trend_MonthlySeasonality';


UPDATE fact_fosalesforecast
SET dd_forecastgrain = 'Business Manager'
WHERE dd_forecastgrain = 'Business_Manager';



DROP TABLE IF EXISTS tmp_upd_fcfrombnr;
CREATE TABLE tmp_upd_fcfrombnr
AS
SELECT DISTINCT month(d.datevalue) mon_brdate,year(d.datevalue) yr_brdate,br.dd_monthlysalesforecast
from fact_billingandretail br,dim_date d
WHERE br.dim_dateid = d.dim_dateid;



DROP TABLE IF EXISTS tmp_upd_fcfrombnr_vendor;
CREATE TABLE tmp_upd_fcfrombnr_vendor
AS
SELECT DISTINCT month(d.datevalue) mon_brdate,year(d.datevalue) yr_brdate,br.dd_monthlysalesforecast,s.suppliername,SUM(br.dd_vendorsalesforecast)
from fact_billingandretail br,dim_date d,dim_supplierbillingretail s
WHERE br.dim_dateid = d.dim_dateid
AND br.dim_supplierbillingretailid = s.dim_supplierbillingretailid
GROUP BY month(d.datevalue),year(d.datevalue),br.dd_monthlysalesforecast,s.suppliername;

SELECT * FROM tmp_upd_fcfrombnr
order by yr_brdate,mon_brdate;


UPDATE fact_fosalesforecast f
FROM tmp_upd_fcfrombnr br,  dim_date df
SET f.ct_monthlysalesforecast_frombandr = br.dd_monthlysalesforecast
WHERE f.dim_dateidforecast = df.dim_dateid AND f.dd_latestreporting = 'Yes'
AND ( (mon_brdate = month(df.datevalue) + 1 AND yr_brdate = year(df.datevalue))
OR (mon_brdate = 1 AND month(df.datevalue) = 12 AND yr_brdate = year(df.datevalue) + 1));

UPDATE fact_fosalesforecast f
SET f.ct_monthlysalesforecast_frombandr = null
WHERE f.ct_monthlysalesforecast_frombandr = 0;


/* Update no of dealearships from stg_dealershipbybm which was populated from csv on 6th Aug. Refer DS-36 */

UPDATE fact_fosalesforecast f
SET f.ct_no_of_dealerships = NULL
WHERE f.dd_latestreporting = 'Yes';

UPDATE fact_fosalesforecast f
FROM stg_dealershipbybm s,dim_date df
SET f.ct_no_of_dealerships = s.TotalDealerships
WHERE f.dim_dateidforecast = df.dim_dateid
AND f.dd_forecastgrainattrone = s.BusinessManager AND f.dd_latestreporting = 'Yes'
AND ( (s.month = month(df.datevalue) + 1 AND s.year = year(df.datevalue))
OR (s.month = 1 AND month(df.datevalue) = 12 AND s.year = year(df.datevalue) + 1));

DROP TABLE IF EXISTS tmp_maxdt_dealercnt1;
CREATE TABLE tmp_maxdt_dealercnt1
AS
SELECT f.dd_forecastgrainattrone,max(df.datevalue) lastavailablecntdate
FROM fact_fosalesforecast f,dim_date df
WHERE f.dim_dateidforecast = df.dim_dateid AND f.dd_latestreporting = 'Yes'
AND ifnull(f.ct_no_of_dealerships,0) <> 0
GROUP BY f.dd_forecastgrainattrone;


DROP TABLE IF EXISTS tmp_maxdt_dealercnt;
CREATE TABLE tmp_maxdt_dealercnt
AS
SELECT DISTINCT f.dd_forecastgrainattrone,f.lastavailablecntdate,f2.ct_no_of_dealerships
FROM tmp_maxdt_dealercnt1 f,fact_fosalesforecast f2,dim_date df
WHERE f.dd_forecastgrainattrone = f2.dd_forecastgrainattrone AND f2.dd_latestreporting = 'Yes'
AND f2.dim_dateidforecast = df.dim_dateid
AND f.lastavailablecntdate = df.datevalue;

UPDATE fact_fosalesforecast f
FROM tmp_maxdt_dealercnt f2,dim_date df
SET f.ct_no_of_dealerships = f2.ct_no_of_dealerships
WHERE f.dd_forecastgrainattrone = f2.dd_forecastgrainattrone AND f.dd_latestreporting = 'Yes'
AND f.dim_dateidforecast = df.dim_dateid
AND df.datevalue > f2.lastavailablecntdate;


DROP TABLE IF EXISTS tmp_maxdt_dealercnt;
DROP TABLE IF EXISTS tmp_maxdt_dealercnt1;

/* Add additional qty for future assuming 3 dealearships per month and 25 new sales per dealership */

/* For Forecast dates bewteen July 2015 and Mar 2016, forecast additional 75 sales each month assuming 3 dealerships per month */

DELETE FROM fact_fosalesforecast f
WHERE dd_forecastgrainattrone = 'NEW'
AND f.dd_latestreporting = 'Yes';

INSERT INTO fact_fosalesforecast
(
fact_fosalesforecastid,
dim_partid,
dim_plantid,
dd_companycode,
dim_dateidreporting,
dd_forecasttype,
dd_forecastsample,
dd_forecastdate,
dim_dateidforecast,
ct_salesquantity,
ct_forecastquantity,
ct_mape,
dd_forecastrank,
dd_forecastmode,
dw_insert_date,
dw_update_date,
dim_projectsourceid,
dd_latestreporting,
ct_forecastquantity_customer,
dd_forecastgrainattrone,
dd_forecastgrainattrtwo,
dd_forecastgrainattrthree,
dd_forecastgrainattrfour,
dd_forecastgrainattrfive,
dd_forecastgrain,
tmp_dd_reportingdate,
tmp_dd_holdoutdate,
tmp_dd_lastdate,
dd_reportingdate,
dd_holdoutdate,
dd_lastdate,
ct_monthlysalesforecast_frombandr,
ct_vendorsalesforecast_frombandr,
ct_no_of_dealerships

)
SELECT
(SELECT MAX(fact_fosalesforecastid) from fact_fosalesforecast) + row_number() over() fact_fosalesforecastid,
t.*
FROM
(SELECT DISTINCT
1 dim_partid,
1 dim_plantid,
f.dd_companycode,
f.dim_dateidreporting,
f.dd_forecasttype,
f.dd_forecastsample,
f.dd_forecastdate,
f.dim_dateidforecast,
0 ct_salesquantity,
/*CASE WHEN month(d.datevalue) > 6 THEN ((month(d.datevalue) - 6 ) * 75 ) else (month(d.datevalue) * 75 ) + 450 END ct_forecastquantity,*/
75 ct_forecastquantity,
/*CASE    WHEN year(d.datevalue) = 2015 and month(d.datevalue) > 6 THEN 75
        WHEN year(d.datevalue) = 2016 AND month(d.datevalue) <= 3 THEN 75
        ELSE 0
END ct_forecastquantity,*/
0 ct_mape,
1 dd_forecastrank, /* Use forecast rank of 0 otherwise rows will be duplicated if ranks change for forecast types */	
dd_forecastmode,
timestamp(local_timestamp) dw_insert_date,
timestamp(local_timestamp) dw_update_date,
dim_projectsourceid,
dd_latestreporting,
0 ct_forecastquantity_customer,
'NEW' dd_forecastgrainattrone,
dd_forecastgrainattrtwo,
dd_forecastgrainattrthree,
dd_forecastgrainattrfour,
dd_forecastgrainattrfive,
dd_forecastgrain,
tmp_dd_reportingdate,
tmp_dd_holdoutdate,
tmp_dd_lastdate,
dd_reportingdate,
dd_holdoutdate,
dd_lastdate,
0 ct_monthlysalesforecast_frombandr,
0 ct_vendorsalesforecast_frombandr,
CASE    WHEN year(d.datevalue) = 2015 and month(d.datevalue) > 6 THEN ((month(d.datevalue) - 6 ) * 3 )
        WHEN year(d.datevalue) = 2016 AND month(d.datevalue) <= 3 THEN (month(d.datevalue) * 3 ) + 18
        WHEN year(d.datevalue) >= 2016 AND month(d.datevalue) >= 4 THEN 27
        WHEN year(d.datevalue) >= 2017 THEN 27
        ELSE 0
END ct_no_of_dealerships
/*CASE 	WHEN year(d.datevalue) = 2015 and month(d.datevalue) > 6 THEN ((month(d.datevalue) - 6 ) * 3 ) 
	WHEN year(d.datevalue) = 2016 AND month(d.datevalue) <= 3 THEN (month(d.datevalue) * 3 ) + 18 
	ELSE 27 
END ct_no_of_dealerships*/
/*3 ct_no_of_dealerships*/
FROM fact_fosalesforecast f, dim_date d
WHERE f.dim_dateidforecast = d.dim_dateid
AND f.dd_latestreporting = 'Yes') t;
/*AND month(d.datevalue) >= month(current_date) - 1 ) t*/
/*AND d.datevalue <= '31 Mar 2016') t*/

/* For NEW BM, update the forecasts for Apr 2016 onwards with forecast from Mar 2016 */
/*
UPDATE fact_fosalesforecast f
FROM fact_fosalesforecast f2, dim_date d1, dim_date d2
SET f.ct_forecastquantity = f2.ct_forecastquantity
WHERE f.dd_forecastgrainattrone = 'NEW'
AND f2.dd_forecastgrainattrone = 'NEW'
AND f.dim_dateidforecast = d1.dim_dateid AND f2.dim_dateidforecast = d2.dim_dateid
AND f.dd_reportingdate = f2.dd_reportingdate AND f.dim_dateidreporting = f2.dim_dateidreporting
AND f.dd_forecastgrain = f2.dd_forecastgrain
AND f.dd_forecasttype = f2.dd_forecasttype
AND f.dd_forecastmode = f2.dd_forecastmode
AND d1.datevalue >= '1 Apr 2016'
AND d2.datevalue = '1 Mar 2016'*/

/* Update no of dealership for all BMs (other than NEW which is created internally to assign unknown count in future) */
UPDATE fact_fosalesforecast f
FROM stg_dealershipbybm s,dim_date df
SET f.ct_no_of_dealerships = s.TotalDealerships
WHERE f.dim_dateidforecast = df.dim_dateid AND f.dd_latestreporting = 'Yes'
AND f.dd_forecastgrainattrone = s.BusinessManager
AND ( (s.month = month(df.datevalue) + 1 AND s.year = year(df.datevalue))
OR (s.month = 1 AND month(df.datevalue) = 12 AND s.year = year(df.datevalue) + 1));


/* Get the max date for which dealership count is non-zero */

DROP TABLE IF EXISTS tmp_maxdt_dealercnt1;
CREATE TABLE tmp_maxdt_dealercnt1
AS
SELECT f.dd_forecastgrainattrone,max(df.datevalue) lastavailablecntdate
FROM fact_fosalesforecast f,dim_date df
WHERE f.dim_dateidforecast = df.dim_dateid AND f.dd_latestreporting = 'Yes'
AND f.ct_no_of_dealerships <> 0
GROUP BY f.dd_forecastgrainattrone;


DROP TABLE IF EXISTS tmp_maxdt_dealercnt;
CREATE TABLE tmp_maxdt_dealercnt
AS
SELECT DISTINCT f.dd_forecastgrainattrone,f.lastavailablecntdate,f2.ct_no_of_dealerships
FROM tmp_maxdt_dealercnt1 f,fact_fosalesforecast f2,dim_date df
WHERE f.dd_forecastgrainattrone = f2.dd_forecastgrainattrone AND f2.dd_latestreporting = 'Yes'
AND f2.dim_dateidforecast = df.dim_dateid
AND f.lastavailablecntdate = df.datevalue;

/* For dates greater than the max date found above, update the dealership count with the count on the max date */

UPDATE fact_fosalesforecast f
FROM tmp_maxdt_dealercnt f2,dim_date df
SET f.ct_no_of_dealerships = f2.ct_no_of_dealerships
WHERE f.dd_forecastgrainattrone = f2.dd_forecastgrainattrone AND f.dd_latestreporting = 'Yes'
AND f.dim_dateidforecast = df.dim_dateid
AND df.datevalue > f2.lastavailablecntdate;


/* Update country */

UPDATE fact_fosalesforecast f
SET dd_countrybusinessmanager = 'US' WHERE f.dd_latestreporting = 'Yes';


UPDATE fact_fosalesforecast f
SET dd_countrybusinessmanager = 'CANADA' 
WHERE upper(f.dd_forecastgrainattrone) in ('GREG','POTTER')
AND f.dd_latestreporting = 'Yes';


UPDATE fact_fosalesforecast f
FROM fact_fosalesforecast fprev, dim_date d, dim_date dprev
SET f.ct_salesquantity_previousmonth = fprev.ct_salesquantity,
	f.ct_forecastquantity_previousmonth = fprev.ct_forecastquantity
WHERE f.dim_dateidreporting = fprev.dim_dateidreporting
AND f.dd_forecastgrainattrone = fprev.dd_forecastgrainattrone AND f.dd_latestreporting = 'Yes' 
AND f.dd_forecasttype = fprev.dd_forecasttype AND fprev.dd_latestreporting = 'Yes'
AND f.dim_dateidforecast = d.dim_dateid
AND fprev.dim_dateidforecast = dprev.dim_dateid
AND ((year(d.datevalue) = year(dprev.datevalue) AND month(d.datevalue) = month(dprev.datevalue) + 1)
OR (year(d.datevalue) = year(dprev.datevalue) + 1 AND month(d.datevalue) = 1 AND month(dprev.datevalue) = 12 ));


DROP TABLE IF EXISTS tmp_stg_googletrends_mah_jd_monthly;
CREATE TABLE tmp_stg_googletrends_mah_jd_monthly
as
select yyyy,mm,sum(interest_mahindra) interest_mahindra_monthly,sum(interest_johndeere) interest_johndeere_monthly
FROM stg_googletrends_mah_jd
group by yyyy,mm;


UPDATE fact_fosalesforecast f
FROM tmp_stg_googletrends_mah_jd_monthly t,dim_date df
SET f.ct_googletrendsinterest_mahindra = t.interest_mahindra_monthly * 100,
	f.ct_googletrendsinterest_competetitor_johndeere = t.interest_johndeere_monthly * 100
WHERE f.dim_dateidforecast = df.dim_dateid AND f.dd_latestreporting = 'Yes'
AND ( (t.mm = month(df.datevalue) + 1 AND t.yyyy = year(df.datevalue))
OR (t.mm = 1 AND month(df.datevalue) = 12 AND t.yyyy = year(df.datevalue) + 1));


