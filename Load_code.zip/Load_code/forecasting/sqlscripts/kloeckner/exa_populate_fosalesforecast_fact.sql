DROP TABLE IF EXISTS STAGE_FOSALESFORECAST;
CREATE TABLE STAGE_FOSALESFORECAST 
(
    DD_REPORTINGDATE          VARCHAR(100) UTF8,
    DD_FORECASTDATE           VARCHAR(100) UTF8,
    DIM_PARTID                VARCHAR(100) UTF8,
    DD_LEVEL2                 VARCHAR(100) UTF8,
    CT_SALESQUANTITY          DECIMAL(18,6),
    CT_FORECASTQUANTITY       DECIMAL(18,6),
    CT_LOWPI                  DECIMAL(18,6),
    CT_HIGHPI                 DECIMAL(18,6),
    CT_MAPE                   DECIMAL(18,6),
    DD_LASTDATE               VARCHAR(100) UTF8,
    DD_HOLDOUTDATE            VARCHAR(100) UTF8,
    DD_FORECASTSAMPLE         VARCHAR(100) UTF8,
    DD_FORECASTTYPE           VARCHAR(100) UTF8,
    DD_FORECASTRANK           VARCHAR(100) UTF8,
    DD_FORECASTMODE           VARCHAR(100) UTF8,
    DD_COMPANYCODE            VARCHAR(100) UTF8,
    CT_BIAS_ERROR_RANK        VARCHAR(100) UTF8,
    CT_BIAS_ERROR             VARCHAR(100) UTF8,
    CT_CUSTOMERFORECAST_10MMA DECIMAL(18,8),
    CT_CUSTMAPE_10MMA         DECIMAL(18,8)
);

import into stage_fosalesforecast
from local csv file
'<path>'
column separator = ','
skip = 1
reject limit 0;

insert into fact_fosalesforecast
(
fact_fosalesforecastid,
dd_reportingdate,
dd_forecastdate,
dd_partnumber,
dd_level2,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_lastdate,
dd_holdoutdate,
dd_forecastsample,
dd_forecasttype,
dd_forecastrank,
dd_forecastmode,
dd_companycode,
ct_bias_error_rank,
ct_bias_error,
ct_customerforecast_10mma,
ct_custmape_10mma
)
select (select max(fact_fosalesforecastid) from fact_fosalesforecast) + row_number() over(order by '') fact_fosalesforecastid,
dd_reportingdate,
dd_forecastdate,
dim_partid,
dd_level2,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_lastdate,
dd_holdoutdate,
dd_forecastsample,
dd_forecasttype,
dd_forecastrank,
dd_forecastmode,
dd_companycode,
ct_bias_error_rank,
ct_bias_error,
ct_customerforecast_10mma,
ct_custmape_10mma
from stage_fosalesforecast;

UPDATE fact_fosalesforecast f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD Mon YYYY')
where f.dd_reportingdate like '%-%-%';


