DROP TABLE IF EXISTS stage_fosteelpriceforecast;
create table stage_fosteelpriceforecast
(
dd_reportingdate varchar(100),
dd_forecastdate varchar(100),
dim_partid varchar(100),
dd_level2 varchar(100),
ct_salesquantity decimal(18,8),
ct_forecastquantity decimal(18,8),
ct_lowpi decimal(18,8),
ct_highpi decimal(18,8),
ct_mape decimal(18,8),
dd_lastdate varchar(100),
dd_holdoutdate varchar(100),
dd_forecastsample varchar(100),
dd_forecasttype varchar(100),
dd_forecastrank varchar(100),
dd_forecastmode varchar(100),
dd_companycode varchar(100),
ct_bias_error_rank decimal(18,8),
ct_bias_error decimal(18,8),
dd_forecastapproach varchar(100),
ct_customerforecast_3mma decimal(18,8),
ct_custmape_3mma decimal(18,8),
ct_customerforecast_12mma decimal(18,8),
ct_custmape_12mma  decimal(18,8));

import into stage_fosteelpriceforecast
from local csv file
'<path>'
column separator = ','
skip = 1
reject limit 0;

insert into fact_fosteelpriceforecast
(
fact_fosteelpriceforecastid,
dd_reportingdate,
dd_forecastdate,
dd_partnumber,
dd_level2,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_lastdate,
dd_holdoutdate,
dd_forecastsample,
dd_forecasttype,
dd_forecastrank,
dd_forecastmode,
dd_companycode,
ct_bias_error_rank,
ct_bias_error,
dd_forecastapproach,
ct_customerforecast_3mma,
ct_custmape_3mma,
ct_customerforecast_12mma,
ct_custmape_12mma
)
select (select max(fact_fosteelpriceforecastid) from fact_fosteelpriceforecast) 
+ row_number() over(order by '') fact_fosteelpriceforecastid,
dd_reportingdate,
dd_forecastdate,
dim_partid,
dd_level2,
ct_salesquantity,
ct_forecastquantity,
ct_lowpi,
ct_highpi,
ct_mape,
dd_lastdate,
dd_holdoutdate,
dd_forecastsample,
dd_forecasttype,
dd_forecastrank,
dd_forecastmode,
dd_companycode,
dd_bias_error_rank,
dd_bias_error,
dd_forecastapproach,
ct_customerforecast_3mma,
ct_custmape_3mma,
ct_customerforecast_12mma,
ct_custmape_12mma
from stage_fosteelpriceforecast;

UPDATE fact_fosteelpriceforecast f
set f.dd_reportingdate = to_char(to_date(f.dd_reportingdate,'YYYY-MM-DD') , 'DD Mon YYYY')
where f.dd_reportingdate like '%-%-%';



