#!/bin/sh
set -x

file1=$1

dest=${file1}.withcolumnsadded.csv

head -1 $file1 | sed 's/dim_partid/dd_commodity,dd_commodityname,dd_productcode,dd_productdescription,dd_gradecode,dd_gradedescription,dd_surfacecode,dd_surfacedescription,dd_width,dd_length,dd_item/' > hdr.$$

grep -v dd_reportingdate $file1|sed 's/|/,/g' > xyz.csv1.$$;cat hdr.$$ xyz.csv1.$$ > $dest

rm -f xyz.csv1.$$ hdr.$$i
