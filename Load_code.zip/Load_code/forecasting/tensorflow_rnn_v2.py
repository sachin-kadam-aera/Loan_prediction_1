# -*- coding: utf-8 -*-
"""
Created on Fri Apr 21 11:54:46 2017

@author: vikranthole
"""

import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.python.framework import dtypes
from tensorflow.contrib import learn
import logging
from forecast_error import forecast_error, get_confidence_interval
import forecast_config
from split_forecast_input import split_forecast_input
#logging.basicConfig(level=logging.INFO)




def rnn_data(data, time_steps, labels=False):
    """
    creates new data frame based on previous observation
      * example:
        l = [1, 2, 3, 4, 5]
        time_steps = 2
        -> labels == False [[1, 2], [2, 3], [3, 4]]
        -> labels == True [2, 3, 4, 5]
    """
    rnn_df = []
    for i in range(len(data) - time_steps):
        if labels:
            try:
                rnn_df.append(data.iloc[i + time_steps].as_matrix())
            except AttributeError:
                rnn_df.append(data.iloc[i + time_steps])
        else:
            data_ = data.iloc[i: i + time_steps].as_matrix()
            rnn_df.append(data_ if len(data_.shape) > 1 else [[i] for i in data_])
    return np.array(rnn_df)





def prepare_data(data, time_steps, labels=False):
    """
    Given the number of `time_steps` and some data,
    prepares training, validation and test data for an lstm cell.
    """
    
    return rnn_data(data, time_steps, labels=labels)


def load_csvdata(rawdata, time_steps, seperate=False):
    data = rawdata
    if not isinstance(data, pd.DataFrame):
        data = pd.DataFrame(data)
    train_x = prepare_data(data['a'] if seperate else data, time_steps)
    train_y = prepare_data(data['b'] if seperate else data, time_steps, labels=True)
    return dict(train=train_x), dict(train=train_y)

def lstm_model(time_steps, rnn_layers, dense_layers=None):
    """
    Creates a deep model based on:
        * stacked lstm cells
        * an optional dense layers
    :param time_steps: the number of time steps the model will be looking at.
    :param rnn_layers: list of int or dict
                         * list of int: the steps used to instantiate the `BasicLSTMCell` cell
                         * list of dict: [{steps: int, keep_prob: int}, ...]
    :param dense_layers: list of nodes for each layer
    :return: the model definition
    """

    def lstm_cells(layers):
        if isinstance(layers[0], dict):
            return [tf.nn.rnn_cell.DropoutWrapper(tf.nn.rnn_cell.BasicLSTMCell(layer['steps'],
                                                                               state_is_tuple=True),
                                                  layer['keep_prob'])
                    if layer.get('keep_prob') else tf.nn.rnn_cell.BasicLSTMCell(layer['steps'],
                                                                                state_is_tuple=True)
                    for layer in layers]
        return [tf.nn.rnn_cell.BasicLSTMCell(steps, state_is_tuple=True) for steps in layers]

    def dnn_layers(input_layers, layers):
        if layers and isinstance(layers, dict):
            return learn.ops.dnn(input_layers,
                                 layers['layers'],
                                 activation=layers.get('activation'),
                                 dropout=layers.get('dropout'))
        elif layers:
            return learn.ops.dnn(input_layers, layers)
        else:
            return input_layers

    def _lstm_model(X, y):
        stacked_lstm = tf.nn.rnn_cell.MultiRNNCell(lstm_cells(rnn_layers), state_is_tuple=True)
        x_ = learn.ops.split_squeeze(1, time_steps, X)
        output, layers = tf.nn.rnn(stacked_lstm, x_, dtype=dtypes.float32)
        output = dnn_layers(output[-1], dense_layers)
        return learn.models.linear_regression(output, y)

    return _lstm_model
    
def gettesetdata(testdata,testlist):
	#print type(testlist)
	#print testlist
	testlist.extend(testlist[-1:])
	#print "testlist,data len",len(testlist),len(testdata)
	testlist = list(np.hstack((np.array(testlist), np.zeros(len(testdata)-len(testlist)) + np.nan)))
	#print len(testdata['Sales']),len(testlist)
	testdata['Sales'] = testlist
	return testdata.dropna()
    
    
def get_forecast_nnet_lstm_tf(data1, UIN, Comop, last_date, holdout_date, horizon_in_months):
    if len(data1[data1.YYYYMM < holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']):  # this ensures min. 2 year of data for forecasting
        print UIN, "insufficient historical data"
        return
    data2,X,Y,Xtest,Ytest = split_forecast_input(data1,UIN,Comop,holdout_date,last_date,horizon_in_months)
    total_data_len = len(data2)
    data11,X11,Y11,Xtest11,Ytest11 = split_forecast_input(data1,UIN,Comop,holdout_date,last_date,total_data_len*12+1)
    data3 = data11[~(data11.YYYYMM ==0)]
    #print "Total len", total_data_len*12+1
    Ytest1 = Ytest
    train_data = data1[data1.YYYYMM<holdout_date]
    train_data = train_data[['Sales','YYYYMM']]
    train_sales = list(train_data.Sales)
    
    train_data = train_data.set_index(['YYYYMM'])
    LOG_DIR = './ops_logs'
    TIMESTEPS = 12
    RNN_LAYERS = [{'steps': TIMESTEPS}]
    DENSE_LAYERS = [10, 10]
    TRAINING_STEPS = 100
        

    try:
    	
        X, Y = load_csvdata(train_data, TIMESTEPS, seperate=False)
    
        
        
        regressor = learn.TensorFlowEstimator(model_fn=lstm_model(TIMESTEPS, RNN_LAYERS, DENSE_LAYERS), 
                                              n_classes=0,
                                              verbose=1,  
                                              steps=TRAINING_STEPS, 
                                              optimizer='Adagrad',
                                              learning_rate=0.01)
        
    
        
        X['train'], Y['train'] = X['train'].astype(np.float32).copy(), Y['train'].astype(np.float32).copy()
        
        
        regressor.fit(X['train'], Y['train'])#, monitors=[validation_monitor], logdir=LOG_DIR)
        
        temp_predicted = []
        for test_index in range(total_data_len):
        	#print "index",test_index
        	if test_index==0:
        		train_sales = train_sales
        	else:
        		#print "Before",type(train_sales),type(temp_predicted)
        		train_sales.append(temp_predicted[-1])
        		#print "After",type(train_sales)
        	#print train_sales
        	test_data  = gettesetdata(data3,train_sales)[['Sales','YYYYMM']]
        	test_data = test_data.set_index(['YYYYMM'])
        	Xtest,Ytest = load_csvdata(test_data, TIMESTEPS, seperate=False)
        	Xtest['train'], Ytest['train'] = Xtest['train'].astype(np.float32).copy(), Ytest['train'].astype(np.float32).copy()
        	predicted = regressor.predict(Xtest['train'])  
        	#print "Pre train",len(predicted),len(Xtest['train'])
        	temp_predicted.append(list(predicted)[-1])    
        	if total_data_len < len(Xtest['train']):
        		break
        
        
        #print "Predicted", predicted
        Y_pred1 = pd.DataFrame(predicted)
        
        Y_pred1.columns = ['Forecast']
        Y_pred1[Y_pred1.Forecast < 0] = 0
        Y_pred1["Forecast"] =Y_pred1.Forecast.fillna(0)
        
        
         
        Y_compare = forecast_error(data2, Ytest1, Y_pred1, holdout_date, last_date)
    
        # Printing MAPE to confirm correct results during development
    
        print "TF Neural Net -LSTM: UIN =", UIN, "Comop=", Comop, "MAPE =", Y_compare.APE.mean(), "Bias= ", \
        Y_compare.Bias_Error.iloc[1]
    
        # Return full dataset with
        # Columns for Forecast, MAPE and Forecast_Type
    
        Y_return = pd.DataFrame(data2).join(Y_pred1)
    
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['MAPE'] = Y_compare.APE.mean()  # This is a single number
        Y_return['Forecast_Type'] = 'TF Neural Net -LSTM'
        return Y_return

    except ValueError as e:
        print UIN, "ValueError in TF Neural Net -LSTM Step", e
        return
    except Exception as e:
        print "Exception in TF Neural Net -LSTM step:  ", e
        return
