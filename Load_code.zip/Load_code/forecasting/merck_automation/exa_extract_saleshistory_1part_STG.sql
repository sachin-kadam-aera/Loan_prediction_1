
open schema MERCK;


EXPORT (SELECT * FROM merck.saleshistory_fromprd_dfsubjarea 
where DD_PARTNUMBER = '000002' ORDER BY DD_PARTNUMBER,COMOP,COMPANYCODE,YYYYMM)  
INTO LOCAL CSV FILE '/home/fusionops/forecast/datascience/forecasting/data/merck/mah_saleshistory_from_STG_dfsubjarea.csv.gz' COLUMN SEPARATOR = ','
Replace ;

