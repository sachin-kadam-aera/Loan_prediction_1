
cd /home/phole/forecastAutomation/merck/
java -jar /opt/EXAplus/EXAplus-5.0.17/exaplus.jar -u "sys" -p "exasol" -c "jdbc:exa:10.102.1.11..15:8563" -f  "exa_extract_saleshistory_1part_STG.sql"
cd /home/fusionops/forecast/datascience/forecasting/
rm forecast.ini
cd /home/phole/forecastAutomation/merck/
python ./exa_forcastini.py $1 $2

python ./main_mah.py 1> mah_test_Apr_HO_201801_to_201803.log 2>mah_test_Apr_HO_201801_to_201803.err 

cd /home/phole/forecastAutomation/merck/
./post_process_mah.sh mah_test_forecast_auto22May18_merck.csv $3




