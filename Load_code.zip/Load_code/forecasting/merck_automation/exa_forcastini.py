#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Mon May 14 15:45:37 2018

@author: priyankahole
"""


import pandas as pd
import sys

filename1 ="mah_saleshistory_from_STG_dfsubjarea.csv.gz" #sys.argv[1]
print filename1
holdout_date = sys.argv[1]
last_date = sys.argv[2]
#data = pd.read_csv(filename1,converters={u'dim_partid': lambda x: str(x),u'dd_level2': lambda x: str(x)})
#data = pd .read_csv('/home/fusionops/forecasting/data/merck/mah_saleshistory_from_STG_dfsubjarea.csv.gz',names = ['dim_partid','dd_level2','comp','dd_forecastdate','sales'] ,converters={u'dim_partid': lambda x: str(x),u'dd_level2': lambda x: str(x)})
#last_date = max(data['dd_forecastdate'])
#holdout_date = max_date - 3
import datetime
#dt = datetime.datetime.now().strftime ("%d%b%y")

f = open("/home/fusionops/forecast/datascience/forecasting/forecast.ini","w") 

f.write("[RunScript]")
f.write("\n")
f.write("run_type:1")
f.write("\n")
f.write("company:merck")
f.write("\n")
f.write("input_file:"+filename1)
f.write("\n") 
f.write("output_file:mah_test_forecast_auto_merck.csv")
f.write("\n") 
f.write("holdout_date:"+holdout_date)#%holdout_date
f.write("\n") 
f.write("last_date:"+last_date)#%last_date
f.write("\n") 
f.write("demand_capping:1000000000")
f.write("\n")
f.write("num_process:45")
f.write("\n")
f.write("input_columns:UIN,Comop,CompanyCode,YYYYMM,Sales")
f.write("\n")
f.write("separator:,")
f.write("\n")
f.write("min_training_period:12")
f.write("\n")
f.write("horizon_period:59")
f.write("\n")
f.write("time_frequency:Monthly")
f.write("\n") 
f.close()

 



