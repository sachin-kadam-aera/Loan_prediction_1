#!/bin/bash
echo "First arg: $1"


cd /home/fusionops/forecast/datascience/forecasting/result/merck/
rm merck_forecast_HO_3_5yrhorizon.csv.gz
rm merck_forecast_HO_6_5yrhorizon.csv.gz

filename1=$1
months=$2

cd /home/phole/forecastAutomation/merck/
python post_process_mah.py $filename1 $months
cd /home/fusionops/forecast/datascience/forecasting/result/merck/
gzip merck_forecast_HO_3_5yrhorizon.csv
gzip merck_forecast_HO_6_5yrhorizon.csv
java -jar /opt/EXAplus/EXAplus-5.0.17/exaplus.jar -u "sys" -p "exasol" -c "jdbc:exa:10.102.1.11..15:8563" -f  "/home/phole/forecastAutomation/merck/populate_forecast_mah_3MHO.sql" 
