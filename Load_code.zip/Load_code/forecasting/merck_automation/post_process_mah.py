#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue May 22 11:00:31 2018

@author: priyankahole
"""

import pandas as pd
import sys

filename1 = sys.argv[1]
print filename1
filename = "/home/fusionops/forecast/datascience/forecasting/result/merck/"+filename1
res_path = "/home/fusionops/forecast/datascience/forecasting/result/merck/"
months = sys.argv[2]
data = pd.read_csv(filename,converters={u'dim_partid': lambda x: str(x),u'dd_level2': lambda x: str(x)})
    
data[['c1','c2','c3','c4','c5']] = data['dd_level2'].str.split('|',expand=True)
    
    
data = data[[u'dd_reportingdate', u'dd_forecastdate', u'dim_partid','c1','c2','c3','c4','c5',u'ct_salesquantity', u'ct_forecastquantity', u'ct_lowpi', u'ct_highpi',u'ct_mape', u'dd_lastdate', u'dd_holdoutdate', u'dd_forecastsample',u'dd_forecasttype', u'dd_forecastrank', u'dd_forecastmode',u'dd_companycode', u'dd_bias_error_rank', u'dd_bias_error']]
#data[u'dd_reportingdate'] = '07 Apr 2018'
    
data.columns = ['DD_REPORTINGDATE','DD_FORECASTDATE','DD_PARTNUMBER','DD_SALES_COCD','DD_REPORTING_COMPANY_CODE','DD_HEI_CODE','DD_COUNTRY_DESTINATION_CODE','DD_MARKET_GROUPING','CT_SALESQUANTITY','CT_FORECASTQUANTITY','CT_LOWPI','CT_HIGHPI','CT_MAPE','DD_LASTDATE','DD_HOLDOUTDATE','DD_FORECASTSAMPLE','DD_FORECASTTYPE','DD_FORECASTRANK','DD_FORECASTMODE','DD_COMPANYCODE','CT_BIAS_ERROR_RANK','CT_BIAS_ERROR']       
    
    
data.to_csv(res_path+'merck_forecast_HO_3_5yrhorizon.csv',index=False)
my_df = pd.DataFrame(columns=['DD_REPORTINGDATE','DD_FORECASTDATE','DD_PARTNUMBER','DD_SALES_COCD','DD_REPORTING_COMPANY_CODE','DD_HEI_CODE','DD_COUNTRY_DESTINATION_CODE','DD_MARKET_GROUPING','CT_SALESQUANTITY','CT_FORECASTQUANTITY','CT_LOWPI','CT_HIGHPI','CT_MAPE','DD_LASTDATE','DD_HOLDOUTDATE','DD_FORECASTSAMPLE','DD_FORECASTTYPE','DD_FORECASTRANK','DD_FORECASTMODE','DD_COMPANYCODE','CT_BIAS_ERROR_RANK','CT_BIAS_ERROR'])
my_df.to_csv(res_path+'merck_forecast_HO_6_5yrhorizon.csv',index=False)
       
