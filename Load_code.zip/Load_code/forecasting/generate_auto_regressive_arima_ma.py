# -*- coding: utf-8 -*-
"""
Created by Shravan Shetty
Generates non seasonal ARMA model. Calculates best AR value depending on the AIC
value of the model.
"""

import pandas as pd
import statsmodels.api as sm
import numpy as np
from numpy import linalg
from split_forecast_input import split_forecast_input
from forecast_error import forecast_error, get_confidence_interval
import forecast_config


# Update forecast configuration parameter
conf_read_input = forecast_config.getConfig('RunScript')
time_frequency = conf_read_input['time_frequency']

def get_forecast_auto_regressive_ma(data1,UIN,Comop,last_date,holdout_date,horizon_in_months):
    if len(data1[data1.YYYYMMDD<holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']): # this ensures min. 2 year of data for forecasting
        print UIN, "insufficient historical data"
        return
    try:
        #horizon_in_months = 4
        #Prepare Training and Test dataset
        data2,X,Y,Xtest,Ytest = split_forecast_input(data1,UIN,Comop,holdout_date,last_date,horizon_in_months)
        if time_frequency == "Monthly":
            date_format='%Y%m%d'
        elif time_frequency == "Weekly":
            date_format='%Y%m%d'
        else:
            date_format='%Y%m%d'
    
        Y.index = pd.to_datetime(data2.YYYYMMDD[:len(Y)], format=date_format)
       ## Optimzed Auto regressor for ARMA models
    
        Y['Sales'] = Y['Sales'].astype(np.float)
        #Model building: Finding the best AR
    
        minModel = sm.tsa.ARMA(Y, (0,0)).fit(disp=False)
        for d in range(0,3):
            for p in range(0,3):
                try:
                    arma_mod = sm.tsa.ARMA(Y, (p, d)).fit(disp=False)
                    if arma_mod.aic < minModel.aic:
                        minModel = arma_mod
                except Exception:
                    pass
        #Forecasting
        Ytest.index=pd.to_datetime(data2.YYYYMMDD,format=date_format)
        Y_pred1 = minModel.fittedvalues.append(pd.DataFrame(minModel.forecast(len(Ytest)-len(Y))[0]))
        Y_pred1.index=Ytest.index=range(0,len(Ytest))
        Y_pred1.columns = ['Forecast']
        Y_pred1.Forecast = Y_pred1.Forecast.apply(lambda x: max(1,x))

        ## Get the forecast error (APE)
        Y_compare= forecast_error(data2,Ytest,Y_pred1,holdout_date,last_date)

        # Printing MAPE to confirm correct results during development
        print "ARMA- AIC: UIN =", UIN, "Comop=",Comop, "MAPE =",Y_compare.APE.mean(), "Bias= ", \
        Y_compare.Bias_Error.iloc[1]

        # Return full dataset with
        # Columns for Forecast, MAPE and Forecast_Type
        Y_return = pd.DataFrame(data2).join(Y_pred1)
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['MAPE'] = Y_compare.APE.mean() # This is a single number
        Y_return['Forecast_Type'] = 'ARMA'
        return Y_return
    except ValueError:
        print UIN, "ValueError in ARMA Step"
        return
    except linalg.LinAlgError:
        print UIN, "SVD Error: Did not Converge in ARMA step"
        return
    except Exception as e:
        print "Exception in ARMA step:  ", e
        return
    

