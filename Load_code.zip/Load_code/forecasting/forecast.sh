# Usage:
# First argument is 0 for pre-compute and 1 for on-demand
# Second argument is Company code which is the customer
# Third argument is input file
# Fourth argument is outfile
# Fifth argument is last_date
# sixth argument is holdout_date
# seventh argument is grain

# python main.py $1 $2 $3 $4 $5 $6
#../../data/history/all_sales.txt 

# For avoiding typing all parameters during testing, I am using the following below:
mkdir logs;
python main.py \
1 \
Mahindra \
stage_saleshistory_mgbmr.txt \
sales_forecast_bm2.txt \
201507 \
201504 \
Business_Manager
