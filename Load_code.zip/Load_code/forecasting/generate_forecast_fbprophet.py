#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 13 10:51:51 2018

@author: vikranthole
"""

import pandas as pd
from pyper import R
from forecast_error import forecast_error, get_confidence_interval
import forecast_config
from fbprophet import Prophet
import pandas as pd
import numpy as np
from split_forecast_input import split_forecast_input
from datetime import datetime

import forecast_config

conf_read_input = forecast_config.getConfig('RunScript')
time_frequency = conf_read_input['time_frequency']

def diff_month(d1, d2):
    from datetime import datetime
    d1 = datetime.strptime(d1, "%Y%m%d")
    d2 = datetime.strptime(d2, "%Y%m%d")
    return abs((d2.year - d1.year)*12 + d2.month - d1.month)

def diff_weeks(d1, d2):
    from datetime import datetime
    d1 = datetime.strptime(d1, "%Y%m%d")
    d2 = datetime.strptime(d2, "%Y%m%d")
    delta = d2- d1
    return delta.days


def generate_prophet(data1,UIN,Comop,last_date,holdout_date,horizon_in_months):

    if len(data1[data1.YYYYMMDD<holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']):
        print UIN, "insufficient historical data"
        return
    # Prepare Training and Test dataset
    try:
        data2, X, Y, Xtest, Ytest = split_forecast_input(data1,UIN,Comop,holdout_date,last_date,horizon_in_months)

        train_data = data1[data1.YYYYMMDD<holdout_date]
        train_data = train_data[['Sales','YYYYMMDD']]
        test_months = diff_month(str(holdout_date),str(last_date))
        train_data['YYYYMMDD'] = pd.to_datetime(train_data['YYYYMMDD'],format='%Y%m%d')
        train_data = train_data.rename(columns={'Sales': 'y', 'YYYYMMDD': 'ds'})
        test_weeks =diff_weeks(str(holdout_date),str(last_date))/7+1

        m = Prophet()
#        print train_data
        m.fit(train_data)

        if time_frequency == "Monthly":
            future = m.make_future_dataframe(periods=int(horizon_in_months + test_months),freq='M')
        elif time_frequency == "Weekly":
            future = m.make_future_dataframe(periods=int(horizon_in_months + test_weeks),freq='W')
        else:
            future = m.make_future_dataframe(periods=int(horizon_in_months + test_months),freq='M')      
        
        
        
        
        
        

        Y_pred1 = pd.DataFrame(m.predict(future)['yhat'])
        Y_pred1.columns = ['Forecast']
        Y_pred1.Forecast = Y_pred1.Forecast.apply(lambda x: max(1, x))


        Y_compare = forecast_error(data2,Ytest,Y_pred1,holdout_date,last_date)

        # Printing MAPE to confirm correct results during development

        print "Prophet CV: UIN =", UIN, "Comop=",Comop, "MAPE =",Y_compare.APE.mean(),"Bias= ",Y_compare.Bias_Error.iloc[1]

        # Returns full dataset with
        # Columns for Forecast, MAPE and Forecast_Type

        Y_return = pd.DataFrame(data2).join(Y_pred1)
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['MAPE'] = Y_compare.APE.mean() # This is a single number
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['Forecast_Type'] = 'Prophet'
        return Y_return

    except ValueError:
        print UIN, "ValueError in Prophet Step"
        return

    except Exception as e:
        print "Exception in Prophet step:  ", e
        return
