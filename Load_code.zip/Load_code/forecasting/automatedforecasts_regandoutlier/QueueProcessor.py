__author__ = 'sshetty'

from multiprocessing import Process, Queue, Value, Lock


class Counter(object):
    """
    Useful for keeping tracks of functions which are completed
    """
    def __init__(self, initval=0):
        self.val = Value('i', initval)
        self.lock = Lock()

    def increment(self):
        with self.lock:
            self.val.value += 1

    def value(self):
        with self.lock:
            return self.val.value

class MultiProcessQueue:
    """
    Performs Multiprocessing on each tasks inside queue.
    Useful when a single method needs to be invoked from a outer for loop on multiple CPUs.
    Lifecycle should be:
    Enqueue ->Execute -> Dequeue ->Stop
    """

    def __init__(self, num_process=2):
        """
        Define number of process to run each queue.
        :param num_process: Default=2
        :return:
        """
        self.task_queue = Queue()
        self.done_queue = Queue()
        self.NUM_PROCESS = num_process
        self.qsize = 0

    def enqueue(self, func, args):
        self.task_queue.put((func, args))
        self.qsize += 1

    def dequeue(self):
        return self.done_queue.get()

    def worker(self, input, output, counter):
        """
        Define worker to execute each tasks
        :param input: Input queue that stores a method to invoke
        :param output: Output queue that stores the output of method
        :return:
        """
        # Read from the queue
        for item in iter(input.get, 'STOP'):
            if isinstance(item, str):
                break
            func, args = item
            result = func(args)
            output.put(result)
            counter.increment()
            print "-"*20
            print "Completed {0}/{1} parts".format(counter.value(), self.qsize)
            print "-" * 20

    def execute(self, worker=None):
        """
        Executes MultiProcessingQueue with the worker.
        :param worker: Default: uses inside worker or can be customized.
        :return: None
        """

        worker = self.worker if worker is None else worker
        counter = Counter(0)
        # Take minimum process to prevent system hangup
        for process in xrange(min(self.qsize,self.NUM_PROCESS)):
            # Stopper inot the queue
            self.task_queue.put("STOP")
            Process(target=worker, args=(self.task_queue, self.done_queue, counter)).start()
