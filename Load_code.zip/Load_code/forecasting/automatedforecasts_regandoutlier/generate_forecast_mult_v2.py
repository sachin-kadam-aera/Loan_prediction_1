# -*- coding: utf-8 -*-
"""
Created by Shravan Shetty
Generate log-linear/multiplicative forecast based on seasonality and trend 
(level = intercept)
pending insert holdout date
"""

import pandas as pd
import numpy as np
from numpy import linalg
from time import time
from sklearn.linear_model import LinearRegression
from split_forecast_input import split_forecast_input
from create_seasonality_var import create_seasonality_var
from forecast_error import forecast_error, get_confidence_interval
import forecast_config


def get_forecast_mult_v2(data1,UIN,Comop,last_date,holdout_date,horizon_in_months):
# this ensures min. 2 year of data for forecasting
    if len(data1[data1.YYYYMM<holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']):
        print UIN, "insufficient historical data"
        return
    #horizon_in_months = 24
    #Prepare Training and Test dataset
    data2,X,Y,Xtest,Ytest =split_forecast_input(data1,UIN,Comop,holdout_date,
                                                last_date,horizon_in_months)

    #Prepare for Mulitplicative Linear Regression    
    X = create_seasonality_var(X)
    Xtest = create_seasonality_var(Xtest)

    Y=np.log(pd.DataFrame(Y.Sales))
    X['t'] = X.index
    Xtest['t'] = Xtest.index

    # Create linear regression object
    regr = LinearRegression()

    # Train the model using the training setss
    try:
        regr.fit(X,Y)
        Y_pred1 = pd.DataFrame(regr.predict(Xtest))
        Y_pred1.columns = ['Forecast']
        Y_pred1.Forecast = Y_pred1.Forecast.apply(lambda x: max(1,np.exp(x)))

        Y_compare = forecast_error(data2,Ytest,Y_pred1,holdout_date,last_date)

        # Printing MAPE to confirm correct results during development

        print "Linear regression-Log Linear: UIN =", UIN, "Comop=",Comop, "MAPE =",Y_compare.APE.mean(),"Bias= ",Y_compare.Bias_Error.iloc[1]

        # Return full dataset with
        # Columns for Forecast, MAPE and Forecast_Type

        Y_return = pd.DataFrame(data2).join(Y_pred1)
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['MAPE'] = Y_compare.APE.mean() # This is a single number
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['Forecast_Type'] = 'Trend Seasonality - Log Linear'

    except ValueError:
        print UIN, "ValueError in Log Linear Regression Step"
        return
    except linalg.LinAlgError:
        print UIN, "SVD Error: Did not Converge in Log Linear Regression step"
        return
    except Exception as e:
        print "Exception in Log Linear Regression step:  ", e
        return
    return Y_return
