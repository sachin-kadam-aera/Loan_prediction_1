# -*- coding: utf-8 -*-
"""
Created by Shravan Shetty
Generate log-linear/multiplicative forecast based on seasonality and trend
(level = intercept)
pending insert holdout date
"""

import pandas as pd
import numpy as np
from numpy import linalg
from sklearn.linear_model import LinearRegression
from split_forecast_input import split_forecast_input
from create_seasonality_var import create_seasonality_var
from forecast_error import forecast_error, get_confidence_interval
from scipy import stats
import forecast_config


def data_transform(data,pow):
    """
    Performs data transformation according to the power given.
    Handles log and exp seperately.
    :param data:
    :param pow:
    :return: float
    """
    if pow == 'log':
        return np.log(1+data)
    elif pow == 'exp':
        return np.exp(data)-1
    # return np.sign(data) * np.abs(data)**pow
    # Should not consider negative values in the output.
    return np.abs(data)**pow


def get_forecast_mult_box_cox(data1,UIN,Comop,last_date,holdout_date,horizon_in_months):
    # this ensures min. 2 year of data for forecasting
    if len(data1[data1.YYYYMM<holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']):
        print UIN, "insufficient historical data"
        return
    #horizon_in_months = 24
    # Prepare Training and Test dataset
    data2,X,Y,Xtest,Ytest =split_forecast_input(data1,UIN,Comop,holdout_date,last_date,horizon_in_months)

    # Prepare for Mulitplicative Linear Regression
    X = create_seasonality_var(X)
    Xtest = create_seasonality_var(Xtest)
    tmp,trans_power=stats.boxcox(Y.Sales)
    trans_power = "log" if trans_power==0 else trans_power
    Y.Sales=data_transform(Y.Sales, trans_power)

    # Performing log log transformation to avoid garbage values
    X['t'] = data_transform(X.index.to_series()+1, trans_power)
    Xtest['t'] = data_transform(Xtest.index.to_series()+1, trans_power)
        
    # Create linear regression object
    regr = LinearRegression()
    
    # Train the model using the training setss
    try:
        regr.fit(X,Y)
        Y_pred1 = pd.DataFrame(data_transform(np.abs(regr.predict(Xtest)), (1/trans_power)))
        # Box-cox returns inf value sometimes, so filling it with previous values
        Y_pred1= Y_pred1.replace([np.inf, -np.inf], np.nan).fillna(method="pad")
        Y_pred1.columns = ['Forecast']


        Y_compare = forecast_error(data2,Ytest,Y_pred1,holdout_date,last_date)

        # Printing MAPE to confirm correct results during development

        print "Linear regression -Box Cox: UIN =", UIN, "Comop=",Comop, "MAPE =",Y_compare.APE.mean(),"Bias= ",Y_compare.Bias_Error.iloc[1]

        # Return full dataset with
        # Columns for Forecast, MAPE and Forecast_Type

        Y_return = pd.DataFrame(data2).join(Y_pred1)
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['MAPE'] = Y_compare.APE.mean() # This is a single number
        Y_return['Forecast_Type'] = 'Trend Seasonality - Box-Cox'

    except ValueError:
        print UIN, "ValueError in Linear Regression-Box cox Step"
        return
    except linalg.LinAlgError:
        print UIN, "SVD Error: Did not Converge in Linear Regression-Box Cox step"
        return
    except Exception as e:
        print "Exception in Linear Regression - Box cox step:  ", e
        return
    return Y_return
