# -*- coding: utf-8 -*-
"""
Created by Anshuman Lall
Reads sales data and generate forecast
"""
import pandas as pd
from numpy import linalg
from sklearn.linear_model import MultiTaskLassoCV
from sklearn.cross_validation import PredefinedSplit
from split_forecast_input import split_forecast_input
from create_seasonality_var import create_seasonality_var
from forecast_error import forecast_error,get_confidence_interval
import forecast_config


def get_forecast_LassoCV(data1,UIN,Comop,last_date,holdout_date,horizon_in_months):
    if len(data1[data1.YYYYMM<holdout_date]) < int(forecast_config.getConfig("RunScript")['min_training_period']): # this ensures min. 2 year of data for forecasting
        print UIN, "insufficient historical data"
        return
    #horizon_in_months = 24
    #Prepare Training and Test dataset
    data2,X,Y,Xtest,Ytest = split_forecast_input(data1,UIN,Comop,holdout_date,last_date,horizon_in_months)

    #Prepare for (Additive) Linear Regression    
    X = create_seasonality_var(X)
    Xtest = create_seasonality_var(Xtest)
    X['t'] = X.index
    Xtest['t'] = Xtest.index
    # Create a cross validation object
    from sklearn import cross_validation
    # Simple K-Fold cross validation. 10 folds.
    cv = cross_validation.KFold(len(X), n_folds=10)
    # Create Lasso Lars
    regr = MultiTaskLassoCV(n_jobs=1, cv=cv, random_state=55)
    # Train the model using the training sets
    try:
        regr.fit(X,Y)
        Y_pred1 = pd.DataFrame(regr.predict(Xtest))
        Y_pred1.columns = ['Forecast']
        Y_pred1.Forecast = Y_pred1.Forecast.apply(lambda x: max(1, x))
        Y_compare = forecast_error(data2,Ytest,Y_pred1,holdout_date,last_date)

        # Printing MAPE to confirm correct results during development

        print "Multi Lasso CV: UIN =", UIN, "Comop=",Comop, "MAPE =",Y_compare.APE.mean(),"Bias= ",Y_compare.Bias_Error.iloc[1]

        # Returns full dataset with
        # Columns for Forecast, MAPE and Forecast_Type

        Y_return = pd.DataFrame(data2).join(Y_pred1)
        # Calculate Root mean squared error
        Y_return = get_confidence_interval(Y_return, holdout_date)
        Y_return['MAPE'] = Y_compare.APE.mean() # This is a single number
        Y_return['Bias_Error'] = Y_compare.Bias_Error.iloc[1]
        Y_return['Forecast_Type'] = 'Lasso- Cross Validation'

    except ValueError:
        print UIN, "ValueError in Lasso Step"
        return
    except linalg.LinAlgError:
        print UIN, "SVD Error: Did not Converge in Lasso step"
        return
    except Exception as e:
        print "Exception in Lasso step:  ", e
        return


    return Y_return
