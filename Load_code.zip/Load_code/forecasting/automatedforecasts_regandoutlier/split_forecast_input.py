import pandas as pd
import numpy as np
import forecast_config




# Update forecast configuration parameter
conf_read_input = forecast_config.getConfig('RunScript')
time_frequency = conf_read_input['time_frequency']

def split_forecast_input(data1, UIN, Comop, holdout_date, last_date, horizon_in_months):
    def get_horizon_months(last_date, horizon_in_months):
        month = last_date % 100
        year = int(last_date / 100)
        # print year, month
        m_column = pd.DataFrame([])
        year_column = pd.DataFrame([])
        for i in range(0, horizon_in_months + 1):
            j = (i + month) % 12
            k = year + int((i + month) / 12)
            if j == 0:
                j = 12
                k = k - 1
            m_column = m_column.append(pd.DataFrame([j]))
            year_column = year_column.append(pd.DataFrame([k * 100 + j]))
           
    
        m_column.columns = ['Month']
        m_column = m_column.reset_index().drop('index', 1)
        year_column.columns = ['YYYYMM']
        year_column = year_column.reset_index().drop('index', 1)
        return m_column, year_column
 
    def get_horizon_weeks(last_date, horizon_in_months):
        month = last_date % 100
        year = int(last_date / 100)
        # print year, month
        m_column = pd.DataFrame([])
        year_column = pd.DataFrame([])
        for i in range(0, horizon_in_months + 1):
            j = (i + month) % 53
            k = year + int((i + month) / 53)
            if j == 0:
                j = 53
                k = k - 1
            m_column = m_column.append(pd.DataFrame([j]))
            year_column = year_column.append(pd.DataFrame([k * 100 + j]))
            
     
       
        m_column.columns = ['Month']
        m_column = m_column.reset_index().drop('index', 1)
        year_column.columns = ['YYYYMM']
        year_column = year_column.reset_index().drop('index', 1)
        return m_column, year_column    
    

    # Prepare Training Dataset
    train = data1[data1.YYYYMM < holdout_date]
    X = train.drop('Sales', 1).drop('UIN', 1).drop('Comop', 1).drop('YYYYMM', 1)
    Y = pd.DataFrame(train.Sales)

    # Add forecast horizon 
    test = data1  # used for both insample and holdout calculations
    if time_frequency=='Weekly':
        month_column, year_column = get_horizon_weeks(last_date, horizon_in_months)
    elif time_frequency=='Monthly':
        month_column, year_column = get_horizon_months(last_date, horizon_in_months)
    horizon_rows = month_column.join(year_column)
    horizon_rows['UIN'] = UIN
    horizon_rows['Comop'] = Comop
    horizon_rows['Sales'] = np.nan
    test = test.append(horizon_rows).reset_index().drop('index', 1)
    # print test


    # Prepare Test Dataset which contains horizon also 
    # but testing will be done in holdout only.
    Xtest = test.drop('Sales', 1).drop('UIN', 1).drop('Comop', 1).drop('YYYYMM', 1)
    Ytest = pd.DataFrame(test.Sales)

    # For new variables, fill NAs in test data according to the last value in training data.
    Xtest = Xtest.fillna(method='ffill')
    # print Ytest
   # print test, X, Y, Xtest, Ytest
    return test, X, Y, Xtest, Ytest

