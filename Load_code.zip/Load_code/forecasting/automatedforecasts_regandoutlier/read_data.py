# -*- coding: utf-8 -*-
"""
Created by Anshuman Lall
Reads sales data and generate forecast
"""

import pandas as pd
import numpy as np
import forecast_config


def read_data(input_file):
    # Get the configuration information
    conf_read_input = forecast_config.getConfig('RunScript')
    input_columns = conf_read_input['input_columns']

    # IMPORT HISTORICAL SALES DATA
    data = pd.read_csv(input_file, sep=conf_read_input["separator"], low_memory=False, header=None, \
                       names=input_columns.split(','), \
                       dtype={'UIN': np.str, 'CompanyCode': np.str})
    data['Month'] = data.YYYYMM.apply(lambda x: x - (x / 100) * 100)
    data.Sales = data.Sales.apply(lambda x: max(1, x))
    return data
