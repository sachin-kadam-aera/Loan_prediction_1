rm()
library(data.table)
library(gdata)
library(readxl)
library(forecast)

# path where all excel files are stored --> 
setwd("/Users/kalyanikulkarni/Desktop/Zoetis/Zoetis_04_26_18/Raw_data_12_Periods/All_Raw_Files")

file_names = c("Raw data 2016-03.xlsx","Raw data 2016-04.xlsx","Raw data 2016-05.xlsx","Raw data 2016-06.xlsx",
               "Raw data 2016-07.xlsx","Raw data 2016-08.xlsx","Raw data 2016-09.xlsx","Raw data 2016-10.xlsx","Raw data 2016-11.xlsx","Raw data 2016-12.xlsx",
               "Raw data 2017-01.xlsx","Raw data 2017-02.xlsx","Raw data 2017-03.xlsx","Raw data 2017-04.xlsx",
               "Raw data 2017-05.xlsx","Raw data 2017-06.xlsx")
col_names = c("Market_Cluster_DP","Sales_Org","Sales_Org_APO","Business_Area_APO","Market","Product","Product_Descr","Month_Starting","Sales", "X__1","X__2")

elapsed_months <- function(end_date, start_date) {
  ed <- as.POSIXlt(end_date)
  sd <- as.POSIXlt(start_date)
  12 * (ed$year - sd$year) + (ed$mon - sd$mon)
}


# Reading the csv in which Selected number of parts are written
Zoetis_6k_parts = as.data.table(read.csv("/Users/kalyanikulkarni/Desktop/Zoetis/Zoetis_04_26_18/Zoetis_6k_parts_V2.csv"))
Zoetis_6k_parts[,grain:=  paste(Product,Business_Area_APO,sep="_")]
Zoetis_6k_parts[,temp:=1]
Zoetis_6k_parts =Zoetis_6k_parts[, c("grain","Sales_Org_APO","temp")]

FCST_input1_all = c()
length(file_names)
i=1
for (i in 1:16){
  filename = file_names[i]
  print(filename)

  Raw1 = read_excel(filename, sheet = "Sheet0")
  
  
  Raw1 = as.data.table(Raw1)
  
  colnames(Raw1) <- col_names
  Raw1 = Raw1[,-c("X__1","X__2")]
  Raw1[,grain:= paste(Product,Business_Area_APO,sep="_")]
  Raw1[,grain3:= paste(Product,Business_Area_APO,Sales_Org_APO,sep="_")]
  Raw1[,grain2:= "abc"]
  
  Raw1[,Month_Starting:= as.character(Month_Starting)]
  Raw1[,Calendar_Month:= paste(substr(Month_Starting,1,4),substr(Month_Starting,6,7),sep="")]
  last_month = as.numeric(Raw1[nrow(Raw1),"Calendar_Month"])
  Raw1[,Calendar_Month_date:= as.Date(paste0(Calendar_Month, '01'), format='%Y%m%d')]
  
  Raw1 = merge(Raw1,Zoetis_6k_parts,all.y = TRUE,by=c("grain","Sales_Org_APO"))
  

  
  
  FCST_input = Raw1[,c("grain","Sales_Org_APO","grain2","Calendar_Month","Sales")]

  FCST_input <-  FCST_input[,list(Sales = sum(Sales)),
                            by = c("grain","Sales_Org_APO","grain2","Calendar_Month")]
  
  
  
  FCST_input[,Calendar_Month_date:= as.Date(paste0(Calendar_Month, '01'), format='%Y%m%d')]
  
  FCST_input[,Calendar_Month:=as.integer(Calendar_Month)]
  
  FCST_input = FCST_input[ order( FCST_input[,1], FCST_input[,2] ,FCST_input[,4]),  ]
  
  #print(nrow(FCST_input))
  print(length(unique(FCST_input$grain)))
  filename = gsub(" ", "_", filename) 
  filename = paste( strsplit(filename, ".xlsx"), "_6k_Top10.csv", sep= "")
  
  print(filename)
  
  
  FCST_input_summary <- FCST_input[,list(cnt = .N,
                                         st = min(Calendar_Month_date),
                                         end = max(Calendar_Month_date),
                                         sum_sales = sum(Sales)),
                                   by = c("grain","Sales_Org_APO")]


  FCST_input1_all = rbind(FCST_input1_all,FCST_input)
  #write.table(FCST_input1,filename,sep = ",", row.names = FALSE,col.names = FALSE)
  
  #rm(list(FCST_input1,Raw1,FCST_input,FCST_input_summary,temp_new,FCST_input1))
  
}

FCST_input1_all = unique(FCST_input1_all)
FCST_input1_all = FCST_input1_all[ order( FCST_input1_all[,1], FCST_input1_all[,2] ,FCST_input1_all[,4]),  ]



FCST_input1  = c()

st = min(FCST_input$Calendar_Month_date) ; end =  max(FCST_input$Calendar_Month_date) 
Calendar_Month_date = seq(st,end, by = "month")

for(j in 1:nrow(FCST_input_summary))
{
  if(j %% 100 == 0){print(j)}
  
  grain_temp =as.character( FCST_input_summary[j,"grain"]) ; 
  Sales_Org_APO_temp = as.character( FCST_input_summary[j,"Sales_Org_APO"])
  temp = FCST_input1_all[grain == grain_temp & Sales_Org_APO == Sales_Org_APO_temp, ]
  sales_temp = temp$Sales ; months_temp = temp$Calendar_Month_date
  Sales = c()
  for(k in 1:length(Calendar_Month_date))
  { ind =   which(months_temp == Calendar_Month_date[k])
  if(length(ind) == 0) {Sales = c(Sales,0)}else {Sales = c(Sales,sales_temp[ind])}
  }
  temp_new = as.data.table(Sales) ; temp_new$Calendar_Month_date = as.Date(Calendar_Month_date,format= '%Y%m%d')
  temp_new$grain = grain_temp ; temp_new$Sales_Org_APO = Sales_Org_APO_temp; temp_new$grain2 = "abc"
  temp_new[,Calendar_Month := paste(substr(as.character(Calendar_Month_date),1,4), substr(as.character(Calendar_Month_date),6,7),sep="")]
  temp_new = temp_new[ order( temp_new[,4], temp_new[,3] ,temp_new[,6]),  ]
  temp_new = temp_new[,-c("Calendar_Month_date")]
  
  FCST_input1 = rbind(FCST_input1,temp_new )
}

FCST_input1 = FCST_input1[,c("grain","Sales_Org_APO","grain2","Calendar_Month","Sales")]
FCST_input1 = FCST_input1[ order( FCST_input1[,1], FCST_input1[,2] ,FCST_input1[,4]),  ]

FCST_input1_summary <- FCST_input1[,list(cnt = .N,
                                       sum_sales = sum(Sales)),
                                 by = c("grain","Sales_Org_APO")]


write.table(FCST_input1,"Zoetis_Combined_History.csv", row.names = FALSE,col.names = FALSE)


