import pandas as pd

def create_seasonality_var(X):
    # just_dummies = pd.get_dummies(X['Month'], prefix='m')
    # X=X.join(just_dummies)
    #print X
    #X=X.reset_index()
    #X=X.drop('index',1).drop('Month',1)
    # X=X.drop('Month',1)
    catg_cols = list(X.select_dtypes(include=['object']).columns) + ['Month']
    return pd.get_dummies(X, columns=catg_cols)
