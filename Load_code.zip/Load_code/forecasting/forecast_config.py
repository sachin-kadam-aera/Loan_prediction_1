__author__ = 'sshetty'
import ConfigParser
_CONFIG_FILENAME='forecast.ini'
Config = ConfigParser.ConfigParser()
Config.read(_CONFIG_FILENAME)

config_dict = {}
def loadConfig(section='RunScript'):
    global config_dict
    options = Config.options(section)
    for option in options:
        try:
            config_dict[option] = Config.get(section, option)
            if config_dict[option] == -1:
                raise Exception
        except:
            print("Exception on %s!" % option)
            config_dict[option] = None
    return config_dict

def getConfig(section='RunScript'):
    """
    Get the data from Config file in the Sections. For sections please view <b>forecast.ini</b> file.
    :param section: INI file is divided into sections. Pass which section the data is needed from.
    :return: Dictionary related to the section
    """
    global config_dict
    if len(config_dict)==0:
        config_dict = loadConfig(section)
    return config_dict

def setConfig( config_name, config_value=None, section='RunScript'):
    """
    Set the configuration dictionary
    """
    global config_dict
    config_dict[config_name] = config_value
    return config_dict

