#!/bin/sh

if [ $# -ne 3 ]
then
	echo "Enter CustomerName, DBserver and Forecastingserver2 name as parameters. Stopping here"
	exit 2
fi

cust=$1
dbserver=$2
fcstserver_2=$3

#Get reportingdate,holdoutdate,lastdate from mysql configuration
reportingdate=
holdoutdate=
lastdate=


#Create customer directory if it does not exist already ( on both forecasting servers )
mkdir -p /home/forecasting/data/$cust
ssh fusionops@${fcstserver_2} "mkdir -p /home/forecasting/data/$cust"


#ssh to the db server and extract the sales history data. Copy that data to forecast server
ssh fusionops@${dbserver} "mkdir -p /home/fusionops/ispring/scripts/ds/flatfiles/$cust; /home/fusionops/ispring/db/schema_migration/bin/VWbcp.sh $cust stage_saleshistory ALL ',' /home/fusionops/ispring/scripts/ds/flatfiles/$cust"

if [ $? -ne 0 ]
then
	echo "Error in ssh to ${dbserver}. Please check"
	exit 3
fi

scp fusionops@dbserver:/home/fusionops/ispring/scripts/ds/flatfiles/${cust}/stage_saleshistory.txt /home/forecasting/data/${cust}

if [ $? -ne 0 ]
then
	echo "Error in copying stage_saleshistory.txt from ${dbserver}. Please check"
	exit 4
fi


#Split the files in 2 parts. Copy the 2nd part to fcstserver_2

python /home/forecasting/chunk_data.py /home/forecasting/data/${cust}/stage_saleshistory.txt

scp /home/forecasting/data/${cust}/stage_saleshistory_part1.csv fusionops@${fcstserver_2}:/home/forecasting/data/${cust}/stage_saleshistory_part1.csv


# Run the forecasts on both servers simultaneously
fcstcmd1="cd /home/forecasting;nohup python main.py --run_type=1 --company=$cust --input_file=stage_saleshistory_part0.csv --output_file=stage_fosalesforecast_${reportingdate}_1.txt --holdout_date=${holdoutdate} --last_date=${lastdate} --demand_capping=1000000 --num_process=35 --input_columns=UIN,Comop,CompanyCode,YYYYMM,Sales --separator=, --min_training_period=12 --horizon_period=12 1>logs/${cust}_${reportingdate}.log 2>logs/${cust}_${reportingdate}.err &"
fcstcmd2="cd /home/forecasting;nohup python main.py --run_type=1 --company=$cust --input_file=stage_saleshistory_part1.csv --output_file=stage_fosalesforecast_${reportingdate}_2.txt --holdout_date=${holdoutdate} --last_date=${lastdate} --demand_capping=1000000 --num_process=35 --input_columns=UIN,Comop,CompanyCode,YYYYMM,Sales --separator=, --min_training_period=12 --horizon_period=12 1>logs/${cust}_${reportingdate}.log 2>logs/${cust}_${reportingdate}.err &"

$fcstcmd
ssh fusionops@${fcstserver_2} "$fcstcmd"


#Check whether the forecasts are complete and merge the files if complete
while true
do
	if ssh ${fcstserver_2} stat /home/forecasting/result/${cust}/stage_fosalesforecast_${reportingdate}_2* \> /dev/null 2\>\&1
        then
                    scp fusionops@${fcstserver_2}:/home/forecasting/result/${cust}/stage_fosalesforecast_${reportingdate}_2* /home/forecasting/result/${cust}/
		    if [ -f /home/forecasting/result/${cust}/stage_fosalesforecast_${reportingdate}_1* ]
		    then
			cat /home/forecasting/result/${cust}/stage_fosalesforecast_${reportingdate}_1* /home/forecasting/result/${cust}/stage_fosalesforecast_${reportingdate}_2* | grep -v dd_reportingdate > /home/forecasting/result/${cust}/stage_fosalesforecast_${reportingdate}_combined.csv 
			break
	            else
			echo "Forecast file has not been created yet. Wait for 15 min and check again"
		    fi
        else
                    echo "Forecast file has not been created yet on ${fcstserver_2}. Wait for 15 min and check again"
        fi
sleep 900

done



#scp to db server and load into fact table
scp /home/forecasting/result/${cust}/stage_fosalesforecast_${reportingdate}_combined.csv fusionops@${dbserver}:/home/fusionops/ispring/scripts/ds/flatfiles/$cust

dataloadcmd="vwload -u ${cust} --fdelim "," -CISO88591 -E -n '\N' -a dd_reportingdate,dd_forecastdate,dim_partid,dd_level2,ct_salesquantity,ct_forecastquantity,ct_lowpi,ct_highpi,ct_mape,dd_lastdate,dd_holdoutdate,dd_forecastsample,dd_forecasttype,dd_forecastrank,dd_forecastmode,dd_companycode,dd_bias_error_rank,dd_bias_error -B off --table ${cust}.stage_fosalesforecast fusionops /home/fusionops/ispring/scripts/ds/flatfiles/${cust}/stage_fosalesforecast_${reportingdate}_combined.csv"

ssh fusionops@${dbserver} "$dataloadcmd"


