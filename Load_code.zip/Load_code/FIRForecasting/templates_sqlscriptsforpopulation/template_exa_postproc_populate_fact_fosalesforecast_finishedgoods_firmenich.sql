open schema firmenich2c1;

/* Capture Raw Sales History */
DROP TABLE IF EXISTS tmp_fg_rawsaleshist;
CREATE TABLE tmp_fg_rawsaleshist
AS
SELECT f.dd_material_number dd_MaterialNo, d.SOLD_TO_PARTY dd_SoldToParty, to_char(d.CREATION_DATE,'YYYYMM') dd_forecastdate_yyyymm,
sum(f.ct_actual_invoiced_quantity_in_kg) ct_salesquantity_orig_monthly
FROM fact_lui_billing_doc_item_dummy_euro f inner join dim_lui_billing_doc_header_dummy_euro d
ON d.dim_lui_billing_doc_header_dummy_euroid = f.dim_billing_doc_header_euroid
GROUP BY f.dd_material_number, d.SOLD_TO_PARTY, to_char(d.CREATION_DATE,'YYYYMM');


/* Pick up job ID and reporting dates as parameters */
DROP TABLE IF EXISTS tmp_currentrunparam;
CREATE TABLE tmp_currentrunparam
AS
SELECT 'acd60f79efb443f0b5f8de7bb010077c' dd_jobid,
CAST('2020-11-01' as date) dd_reportingdate,  
CAST(NULL as date) dd_reportingdate_firmenichterminology,
CAST(NULL AS VARCHAR(10)) dd_yyyymm_lag1,
CAST(NULL AS VARCHAR(10)) dd_yyyymm_lag2,
CAST(NULL AS VARCHAR(10)) dd_yyyymm_lag3;

UPDATE tmp_currentrunparam
SET dd_reportingdate_firmenichterminology = dd_reportingdate - INTERVAL '1' DAY;


UPDATE tmp_currentrunparam
SET dd_yyyymm_lag1 = to_char(dd_reportingdate ),
dd_yyyymm_lag2 = to_char(dd_reportingdate + interval '1' month,'YYYYMM'),
dd_yyyymm_lag3 = to_char(dd_reportingdate + interval '2' month,'YYYYMM');


/* Get Cortex data for given job id into tmp table */

/* Part 1: Cortex data for current job */
DROP TABLE IF EXISTS tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA;
CREATE TABLE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
AS
SELECT 
c.dd_reportingdate,
f.DD_JOBID, f.DD_GRAIN1, 
f.dd_grain2, 
f.DD_FORECASTALGORITHM, f.DD_FORECASTRANK,
f.DD_FORECASTDATE, f.DD_ACTUALDATEVALUE DD_FORECASTDATE_YYYYMM,
f.CT_SALESQUANTITY, 
CAST(0 AS DECIMAL(18,4)) ct_salesquantity_raw,
f.CT_FORECASTQUANTITY, f.CT_RANKINGMODE_FORECASTQUANTITY,
cast(0 as decimal(10,2)) ct_mae_rankingmode,
d.dd_holdout_date dd_endoftrainingoutperiod,
d.dd_last_date dd_endofholdoutperiod,
CASE WHEN f.DD_ACTUALDATEVALUE <= d.dd_holdout_date THEN 'Train'
WHEN f.DD_ACTUALDATEVALUE <= d.dd_last_date THEN 'Test'
ELSE 'Horizon'
END dd_forecastsample
FROM FACT_FORECASTOUTPUT_CORTEX_DATA f 
INNER JOIN dim_jobmetadata_cortex_data d
ON d.dd_jobid = f.dd_jobid, tmp_currentrunparam c
WHERE d.dd_jobid = c.dd_jobid
AND dd_forecastalgorithm in ('FittestARIMA','FALL_BACK_NAIVE','AUTO_ARIMA','SIMPLE_EXPO_SMOOTHING','TBATS','THETAM') 
AND f.DD_ACTUALDATEVALUE <> 'None';

/* SoldToParty should be 10 char. Cortex is removing leading 0's due to a bug. Add leading 0's so that it matches the input grains*/
UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET dd_grain2 = lpad(f.dd_grain2,10,'0');

/* Cleanup useless grains */
DELETE FROM tmp_fg_rawsaleshist s
WHERE dd_soldtoparty = 'Not Set'
OR dd_MaterialNo = 'Not Set';

/* Update raw sales - useful for analysis & backdated runs */
UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.ct_salesquantity_raw = s.ct_salesquantity_orig_monthly
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f, tmp_fg_rawsaleshist s
WHERE f.dd_grain1 = s.dd_MaterialNo
AND lpad(f.dd_grain2,10,'0') = lpad(s.dd_SoldToParty,10,'0')
AND f.DD_FORECASTDATE_YYYYMM = s.DD_FORECASTDATE_YYYYMM;

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.ct_salesquantity = f.ct_salesquantity_raw
WHERE f.dd_forecastsample = 'Horizon';

/* Cleanup algorithms that have problems in output */
DROP TABLE IF EXISTS tmp_sanitychecks_sales;
CREATE TABLE tmp_sanitychecks_sales
AS
SELECT dd_grain1, dd_grain2, 
DD_FORECASTALGORITHM,
min(DD_FORECASTDATE) min_DD_FORECASTDATE,
max(DD_FORECASTDATE) max_DD_FORECASTDATE,
--DD_FORECASTDATE, DD_FORECASTDATE_YYYYMM, dd_endofholdoutperiod,
count(*) cnt,
sum(CT_SALESQUANTITY) sum_ct_salesquantity,
avg(CT_SALESQUANTITY) avg_ct_salesquantity,
median(CT_SALESQUANTITY) median_ct_salesquantity,
min(CT_SALESQUANTITY) min_ct_salesquantity,
max(CT_SALESQUANTITY) max_ct_salesquantity,
stddev(CT_SALESQUANTITY) stdev_ct_salesquantity,
stddev(CT_SALESQUANTITY)/case when avg(CT_SALESQUANTITY) <= 0 THEN 1 ELSE avg(CT_SALESQUANTITY) END cov_ct_salesquantity
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastdate >= to_date(dd_endofholdoutperiod, 'YYYYMM') - INTERVAL '11' MONTH
AND dd_forecastdate <= to_date(dd_endofholdoutperiod, 'YYYYMM')
GROUP BY dd_grain1, dd_grain2, DD_FORECASTALGORITHM;


DROP TABLE IF EXISTS tmp_sanitychecks_fcst;
CREATE TABLE tmp_sanitychecks_fcst
AS
SELECT dd_grain1, dd_grain2, 
DD_FORECASTALGORITHM,
min(DD_FORECASTDATE) min_DD_FORECASTDATE,
max(DD_FORECASTDATE) max_DD_FORECASTDATE,
count(*) cnt,
sum(ct_forecastquantity) sum_ct_forecastquantity,
avg(ct_forecastquantity) avg_ct_forecastquantity,
median(ct_forecastquantity) median_ct_forecastquantity,
min(ct_forecastquantity) min_ct_forecastquantity,
max(ct_forecastquantity) max_ct_forecastquantity,
stddev(ct_forecastquantity) stdev_ct_forecastquantity,
stddev(ct_forecastquantity)/case when avg(ct_forecastquantity) <= 0 THEN 1 ELSE avg(ct_forecastquantity) END cov_ct_forecastquantity
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastdate >= to_date(dd_endofholdoutperiod, 'YYYYMM') + INTERVAL '1' MONTH
AND dd_forecastdate <= to_date(dd_endofholdoutperiod, 'YYYYMM') + INTERVAL '12' MONTH
GROUP BY dd_grain1, dd_grain2, DD_FORECASTALGORITHM;


/* Find exceptions */
DROP TABLE IF EXISTS tmp_forecastmethod_exceptions;
CREATE TABLE tmp_forecastmethod_exceptions
AS
SELECT f.dd_grain1, f.dd_grain2, f.dd_forecastalgorithm, f.avg_ct_forecastquantity, 
f.max_ct_forecastquantity, 
s.median_ct_salesquantity,
s.avg_ct_salesquantity, s.max_ct_salesquantity
FROM tmp_sanitychecks_fcst f, tmp_sanitychecks_sales s
WHERE f.dd_grain1 = s.dd_grain1
AND f.dd_grain2 = s.dd_grain2
AND f.dd_forecastalgorithm = s.dd_forecastalgorithm
AND (
f.avg_ct_forecastquantity > 1.5 * s.avg_ct_salesquantity
OR 
(s.median_ct_salesquantity <= 0));

DELETE FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
WHERE EXISTS ( SELECT 1 FROM tmp_forecastmethod_exceptions e
WHERE f.dd_grain1 = e.dd_grain1
AND f.dd_grain2 = e.dd_grain2
AND f.dd_forecastalgorithm = e.dd_forecastalgorithm)
AND f.dd_forecastalgorithm NOT IN ('FALL_BACK_NAIVE');


/* Prepare data for ensemble */
/* 3MA */
DROP TABLE IF EXISTS tmp_naive_3MAand6MA;
CREATE TABLE tmp_naive_3MAand6MA
AS
SELECT dd_grain1, dd_grain2, 
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endoftrainingoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endoftrainingoutperiod,'YYYYMM') - INTERVAL '3' MONTH
THEN ct_salesquantity ELSE NULL END) ct_3ma_ranking,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endofholdoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endofholdoutperiod,'YYYYMM') - INTERVAL '3' MONTH
THEN ct_salesquantity ELSE NULL END) ct_3ma_final,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endoftrainingoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endoftrainingoutperiod,'YYYYMM') - INTERVAL '6' MONTH
THEN ct_salesquantity ELSE NULL END) ct_6ma_ranking,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endofholdoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endofholdoutperiod,'YYYYMM') - INTERVAL '6' MONTH
THEN ct_salesquantity ELSE NULL END) ct_6ma_final
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastalgorithm = 'FALL_BACK_NAIVE'
GROUP BY 1,2;


DROP TABLE IF EXISTS tmp_6MA_newmethod;
CREATE TABLE tmp_6MA_newmethod
AS
SELECT *
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastalgorithm = 'FALL_BACK_NAIVE';

UPDATE tmp_6MA_newmethod m
SET 
m.DD_FORECASTALGORITHM = '6MA',
m.ct_rankingmode_forecastquantity = n.ct_6ma_ranking,
m.ct_forecastquantity = n.ct_6ma_final
FROM tmp_6MA_newmethod m, tmp_naive_3MAand6MA n
WHERE m.dd_grain1 = n.dd_grain1
AND m.dd_grain2 = n.dd_grain2;

INSERT INTO tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
SELECT *
FROM tmp_6MA_newmethod m;


DROP TABLE IF EXISTS tmp_distinctgrains_currentforecast;
CREATE TABLE tmp_distinctgrains_currentforecast
AS
SELECT dd_grain1, 
dd_grain2, 
count(distinct DD_FORECASTALGORITHM) ct_algocount,
min(DD_FORECASTDATE) mindate, 
max(DD_FORECASTDATE) maxdate
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
GROUP BY dd_grain1, dd_grain2;


/* Cleanup */

/* Part 2: Ranking */
/* Rank by MAE, then by Bias, then by RMSE and then by Algo Name */
DROP TABLE IF EXISTS tmp_rankforecast;
CREATE TABLE tmp_rankforecast
AS
SELECT dd_grain1, 
dd_grain2,
DD_FORECASTALGORITHM, 
sum(ct_salesquantity) ct_salesquantity,
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_mae,
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_bias,
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))) ct_rmse,
RANK() OVER(PARTITION BY dd_grain1, dd_grain2 ORDER BY
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))),
DD_FORECASTALGORITHM) dd_forecastranknew
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastsample = 'Test'
AND dd_forecastalgorithm <> 'FALL_BACK_NAIVE'
GROUP BY 1,2,3;


DROP TABLE IF EXISTS tmp_distinctgrains_rankedfcst;
CREATE TABLE tmp_distinctgrains_rankedfcst
AS
SELECT distinct dd_grain1, dd_grain2
FROM tmp_rankforecast;

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = -1;

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = t.dd_forecastranknew,
f.ct_mae_rankingmode = t.ct_mae
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f, tmp_rankforecast t
WHERE f.dd_grain1 = t.dd_grain1
AND f.dd_grain2 = t.dd_grain2
AND f.dd_forecastalgorithm = t.dd_forecastalgorithm;


/* Grains that don't have any other algorithm should use Naive */
UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = 1
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
WHERE f.dd_forecastalgorithm = 'FALL_BACK_NAIVE'
AND NOT EXISTS ( SELECT 1 FROM tmp_distinctgrains_rankedfcst t
WHERE t.dd_grain1 = f.dd_grain1
AND t.dd_grain2 = f.dd_grain2);


/* Populate fact_finalfinishgoodforecastoutput, which is used by the CE team */

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
SET ct_salesquantity = 0
WHERE ct_salesquantity IS NULL;

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
SET ct_salesquantity = 0.001
WHERE ct_salesquantity = 0;

DROP TABLE IF EXISTS tmp_cumulativesales_fg;
CREATE TABLE tmp_cumulativesales_fg
AS
SELECT dd_reportingdate, dd_grain1, DD_grain2, sum(ct_salesquantity) sumsales,
STDDEV(ct_salesquantity) ct_stdev,
AVG(ct_salesquantity) ct_avgsales,
STDDEV(ct_salesquantity)/CASE WHEN AVG(ct_salesquantity) = 0 THEN 1 ELSE AVG(ct_salesquantity) END ct_cov  --To ensure there's no 0 in denominator
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE DD_FORECASTDATE >= to_date(DD_REPORTINGDATE) - INTERVAL '12' MONTH
AND DD_FORECASTDATE <= DD_REPORTINGDATE
GROUP BY dd_reportingdate, dd_grain1, DD_grain2;


DROP TABLE IF EXISTS tmp_orderedsales_fg;
CREATE TABLE tmp_orderedsales_fg
AS
SELECT f.dd_reportingdate, f.dd_grain1, f.DD_grain2,f.sumsales,
SUM(f.sumsales) OVER(PARTITION BY f.dd_reportingdate ORDER BY f.sumsales DESC) cumulative_qty,
rank() OVER(PARTITION BY f.dd_reportingdate ORDER BY f.sumsales DESC) dd_rank,
t.totalsalesforreportingdate,
SUM(f.sumsales) OVER(PARTITION BY f.dd_reportingdate ORDER BY f.sumsales DESC)/t.totalsalesforreportingdate ct_contribution,
cast('C' as varchar(1)) dd_abc,
cast('Z' as varchar(1)) dd_xyz,
cast('CZ' as varchar(2)) dd_segment
FROM tmp_cumulativesales_fg f,
(select DD_REPORTINGDATE, sum(sumsales) totalsalesforreportingdate
FROM tmp_cumulativesales_fg GROUP BY 1) t
WHERE f.dd_reportingdate = t.dd_reportingdate;

UPDATE tmp_orderedsales_fg t1
SET t1.dd_abc = CASE WHEN ct_contribution <= 0.8 THEN 'A'
											   WHEN ct_contribution <= 0.95 THEN 'B'
										ELSE 'C' END;

UPDATE tmp_orderedsales_fg t1
SET t1.dd_xyz =  CASE WHEN t2.ct_cov < 0.5 THEN 'X'
                     WHEN t2.ct_cov < 1.5 THEN 'Y'
                     ELSE 'Z' END
FROM tmp_orderedsales_fg t1,tmp_cumulativesales_fg t2
WHERE t1.dd_reportingdate = t2.dd_reportingdate
AND t1.dd_grain1 = t2.dd_grain1
AND t1.DD_grain2 = t2.DD_grain2;



UPDATE tmp_orderedsales_fg
SET dd_segment = dd_abc || dd_xyz;

DROP TABLE IF EXISTS tmp_finalfinishgoodforecastoutput;
CREATE TABLE tmp_finalfinishgoodforecastoutput
AS
SELECT
f.dd_grain1  || '-' || f.DD_grain2  dd_grain,
t.dd_segment,
f.ct_forecastquantity,
f.ct_salesquantity,
f.dd_forecastdate_yyyymm dd_actualdatevalue,
f.dd_reportingdate dd_snapshotdate,
abs(f.ct_forecastquantity - f.ct_salesquantity) ct_abserror,
f.ct_forecastquantity - f.ct_salesquantity ct_error_bias,
MONTHS_BETWEEN(f.dd_forecastdate, f.dd_reportingdate) dd_lag,
100 * abs(f.ct_forecastquantity - f.ct_salesquantity) / f.ct_salesquantity ct_mape,
100 - (100 * abs(f.ct_forecastquantity - f.ct_salesquantity) / f.ct_salesquantity) ct_accuracy,
100 * (f.ct_forecastquantity - f.ct_salesquantity) / f.ct_salesquantity ct_bias,
f.dd_jobid
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
INNER JOIN tmp_orderedsales_fg t
ON f.dd_reportingdate = t.dd_reportingdate
AND f.dd_grain1 = t.dd_grain1
AND f.DD_grain2 = t.DD_grain2
WHERE dd_forecastrank = 1
;


update tmp_finalfinishgoodforecastoutput
set ct_mape =
case when ct_mape > 100 then 100 else ct_mape end ;

update tmp_finalfinishgoodforecastoutput
set ct_accuracy =
case when ct_accuracy < 0 then 0 else ct_accuracy end ;

UPDATE fact_finalfinishgoodforecastoutput
SET DD_LATEST_FLAG = 'N';


DELETE * FROM fact_finalfinishgoodforecastoutput
where dd_jobid in (select distinct dd_jobid from tmp_finalfinishgoodforecastoutput);


insert into fact_finalfinishgoodforecastoutput
(
fact_finalfinishgoodforecastoutputID,
DD_GRAIN,
DD_SEGMENT,
CT_FORECASTQUANTITY,
CT_SALESQUANTITY,
DD_ACTUALDATEVALUE,
DD_SNAPSHOTDATE,
CT_ABSERROR,
CT_ERROR_BIAS,
DD_LAG,
CT_MAPE,
CT_ACCURACY,
CT_BIAS,
dd_current_snapshot,
DD_LATEST_FLAG,
dd_jobid
)
select
(
select
ifnull(max(fact_finalfinishgoodforecastoutputID), 0)
from fact_finalfinishgoodforecastoutput m) + row_number()
over(order by '') as fact_finalfinishgoodforecastoutputID,
DD_GRAIN,
DD_SEGMENT,
CT_FORECASTQUANTITY,
CT_SALESQUANTITY,
DD_ACTUALDATEVALUE,
--DD_SNAPSHOTDATE,
cp.dd_reportingdate_firmenichterminology,
CT_ABSERROR,
CT_ERROR_BIAS,
DD_LAG,
CT_MAPE,
CT_ACCURACY,
CT_BIAS,
to_char(to_date(current_date,'YYYY-MM-DD'),'DD MON YYYY'),
'Y',f.dd_jobid
from tmp_finalfinishgoodforecastoutput f
INNER JOIN tmp_currentrunparam cp
ON f.dd_jobid = cp.dd_jobid;


/* Recalculate lags */
DROP TABLE IF EXISTS tmp_recalculatelag_asperfirmenichdefinition;
CREATE TABLE tmp_recalculatelag_asperfirmenichdefinition
AS
SELECT DISTINCT dd_snapshotdate, dd_actualdatevalue, 
MONTHS_BETWEEN(to_date(dd_actualdatevalue,'YYYYMM'),to_date(to_char(dd_snapshotdate,'YYYYMM'),'YYYYMM')) dd_lagnew
FROM fact_finalfinishgoodforecastoutput;


UPDATE fact_finalfinishgoodforecastoutput f
SET f.dd_lag = t.dd_lagnew
FROM fact_finalfinishgoodforecastoutput f, tmp_recalculatelag_asperfirmenichdefinition t
WHERE f.dd_snapshotdate = t.dd_snapshotdate
AND f.dd_actualdatevalue = t.dd_actualdatevalue;


