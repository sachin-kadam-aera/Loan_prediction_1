open schema firmenich2c1;


/* Preproc RM */
/*
DROP TABLE IF EXISTS tmp_raw_and_outliertreatedsales_monthly;
CREATE TABLE tmp_raw_and_outliertreatedsales_monthly
AS
SELECT rtrim(dd_partnumber)||'-'||rtrim(dd_plantcode) dd_grain1, f.*
FROM FACT_RAWMATERIALCONSUMPTION_PREPROCESSED f;
*/


/* All snapshots with job ids */
/*
--1 Jun: c398341ff4b54a1194c67dfc19f67a0f (Use for Jul-2019 validation)
--1 Jul: eb6b4d3fbfff43d5a63f88be39a51942 (Use for Aug-2019 validation)
--1 Aug: cfb0f5ed2b0c4f07a10e906104eddeea (Use for Sep-2019 validation)
--1 Sep: 7e12fd5a0dc64865b3cbddf749d5dad9 (Use for Oct-2019 validation)
--1 Oct: 150a61c9ddfc4969a0b06671c1b22cb2 (Use for Nov-2019 validation)
--1 Nov: c97deb9bfe524299867044ca0b9ebb71 (Use for Dec-2019 validation)
--1 Dec: db1e955630be495a9d97bf8c4f8231f8 (Use for Jan-2020 validation)
--1 Jan: c3225234a9a447ee8c8550a42b5913db (Use for Feb-2020 validation)
--1 Feb: 88711dfdac134a3e912ecd35f26bbfb8 (Use for Mar-2020 validation)
--1 Mar: 613e5ae807574e43a5ab5223acda548d (Use for Apr-2020 valiation)
--1 Apr: 2e45228c80354077acc0f275acc5fd0b (Use for May-2020 valiation)
--1 May: 1b3c692131ee4018a22b37ee22fd3017 (Use for Jun-2020 valiation)
--1 Jun: 8afaf3a4d3a14937934a205734b5b55a (Use for Jul-2020 valiation)

*/

/* New runs 18 Mar 2021 */
/*
Job 1 - 2c82b447aeed4fea8dad4de7cc760e4d - Oct-2019 Snapshot
Job 2 - 0aafb5c968d64a76aaee83af52b0317a - Nov-2019 Snapshot
Job 3 - 92c8406d9108462582631432001dedb2 - Dec-2019 Snapshot
Job 4 - 312d6332ecaf47cd831db80be9d5013a - Jan-2020 Snapshot
Job 5 - 7ac3a552644a43b79995a0a5ff613729 - Feb-2020 Snapshot
Job 6 - 195ea2ed410143b5932d3aba9a1e1783 - Mar-2020 Snapshot
*/

/* Pick up any one run from above */
DROP TABLE IF EXISTS tmp_currentrunparam;
CREATE TABLE tmp_currentrunparam
AS
SELECT '195ea2ed410143b5932d3aba9a1e1783' dd_jobid,
CAST('2020-03-01' as date) dd_reportingdate,  
CAST(NULL AS VARCHAR(10)) dd_yyyymm_lag1,
CAST(NULL AS VARCHAR(10)) dd_yyyymm_lag2,
CAST(NULL AS VARCHAR(10)) dd_yyyymm_lag3;

UPDATE tmp_currentrunparam
SET dd_yyyymm_lag1 = to_char(dd_reportingdate ),
dd_yyyymm_lag2 = to_char(dd_reportingdate + interval '1' month,'YYYYMM'),
dd_yyyymm_lag3 = to_char(dd_reportingdate + interval '2' month,'YYYYMM');

/*
SELECT *
FROM dim_jobmetadata_cortex_data
ORDER BY dd_job_created desc
limit 10;

SELECT *
FROM FACT_FORECASTOUTPUT_CORTEX_DATA
limit 10;

SELECT DISTINCT dd_jobid, dd_job_created
FROM dim_jobmetadata_cortex_data;

SELECT DISTINCT dd_jobid
FROM FACT_FORECASTOUTPUT_CORTEX_DATA;

*/

/* Get Cortex data for given job id into tmp table */

/* Part 1: Cortex data for current job */
DROP TABLE IF EXISTS tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA;
CREATE TABLE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
AS
SELECT 
c.dd_reportingdate,
f.DD_JOBID, f.DD_GRAIN1, 
f.dd_grain2, 
f.DD_FORECASTALGORITHM, f.DD_FORECASTRANK,
f.DD_FORECASTDATE, f.DD_ACTUALDATEVALUE DD_FORECASTDATE_YYYYMM,
f.CT_SALESQUANTITY, f.CT_FORECASTQUANTITY, f.CT_RANKINGMODE_FORECASTQUANTITY,
cast(0 as decimal(10,2)) ct_mae_rankingmode,
d.dd_holdout_date dd_endoftrainingoutperiod,
d.dd_last_date dd_endofholdoutperiod,
CASE WHEN f.DD_ACTUALDATEVALUE <= d.dd_holdout_date THEN 'Train'
WHEN f.DD_ACTUALDATEVALUE <= d.dd_last_date THEN 'Test'
ELSE 'Horizon'
END dd_forecastsample
FROM FACT_FORECASTOUTPUT_CORTEX_DATA f 
INNER JOIN dim_jobmetadata_cortex_data d
ON d.dd_jobid = f.dd_jobid, tmp_currentrunparam c
WHERE d.dd_jobid = c.dd_jobid
AND dd_forecastalgorithm in ('FittestARIMA','FALL_BACK_NAIVE','AUTO_ARIMA','SIMPLE_EXPO_SMOOTHING')
AND f.DD_ACTUALDATEVALUE <> 'None';

/*
SELECT DISTINCT dd_forecastdate_yyyymm
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA;

SELECT *
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
LIMIT 10;

SELECT *
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE DD_FORECASTDATE_YYYYMM = 'None';
*/

/* Prepare data for ensemble */
/* 3MA */
DROP TABLE IF EXISTS tmp_naive_3MAand6MA;
CREATE TABLE tmp_naive_3MAand6MA
AS
SELECT dd_grain1, dd_grain2, 
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endoftrainingoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endoftrainingoutperiod,'YYYYMM') - INTERVAL '3' MONTH
THEN ct_salesquantity ELSE NULL END) ct_3ma_ranking,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endofholdoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endofholdoutperiod,'YYYYMM') - INTERVAL '3' MONTH
THEN ct_salesquantity ELSE NULL END) ct_3ma_final,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endoftrainingoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endoftrainingoutperiod,'YYYYMM') - INTERVAL '6' MONTH
THEN ct_salesquantity ELSE NULL END) ct_6ma_ranking,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endofholdoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endofholdoutperiod,'YYYYMM') - INTERVAL '6' MONTH
THEN ct_salesquantity ELSE NULL END) ct_6ma_final
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastalgorithm = 'FALL_BACK_NAIVE'
GROUP BY 1,2;

/*
DROP TABLE IF EXISTS tmp_3MA_newmethod;
CREATE TABLE tmp_3MA_newmethod
AS
SELECT *
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastalgorithm = 'FALL_BACK_NAIVE';

UPDATE tmp_3MA_newmethod m
SET 
m.DD_FORECASTALGORITHM = '3MA',
m.ct_rankingmode_forecastquantity = n.ct_3ma_ranking,
m.ct_forecastquantity = n.ct_3ma_final
FROM tmp_3MA_newmethod m, tmp_naive_3MAand6MA n
WHERE m.dd_grain1 = n.dd_grain1;
*/
/*
INSERT INTO tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
SELECT *
FROM tmp_3MA_newmethod m;
*/

DROP TABLE IF EXISTS tmp_6MA_newmethod;
CREATE TABLE tmp_6MA_newmethod
AS
SELECT *
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastalgorithm = 'FALL_BACK_NAIVE';

UPDATE tmp_6MA_newmethod m
SET 
m.DD_FORECASTALGORITHM = '6MA',
m.ct_rankingmode_forecastquantity = n.ct_6ma_ranking,
m.ct_forecastquantity = n.ct_6ma_final
FROM tmp_6MA_newmethod m, tmp_naive_3MAand6MA n
WHERE m.dd_grain1 = n.dd_grain1
AND m.dd_grain2 = n.dd_grain2;

INSERT INTO tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
SELECT *
FROM tmp_6MA_newmethod m;

/*
SELECT *
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
ORDER BY dd_grain1, dd_forecastalgorithm, dd_forecastdate
LIMIT 100;
*/

DROP TABLE IF EXISTS tmp_distinctgrains_currentforecast;
CREATE TABLE tmp_distinctgrains_currentforecast
AS
SELECT dd_grain1, 
dd_grain2, 
count(distinct DD_FORECASTALGORITHM) ct_algocount,
min(DD_FORECASTDATE) mindate, 
max(DD_FORECASTDATE) maxdate
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
GROUP BY dd_grain1, dd_grain2;

/*
select *
from tmp_distinctgrains_currentforecast
LIMIT 10;
*/

/* Cleanup */
/*
DROP TABLE IF EXISTS tmp_ranking_vs_finalforecast;
CREATE TABLE tmp_ranking_vs_finalforecast
AS
SELECT dd_grain1, dd_forecastalgorithm, 
avg(ct_salesquantity) ct_salesquantity_avg, 
avg(ct_forecastquantity) ct_forecastquantity_avg, 
avg(ct_rankingmode_forecastquantity) ct_rankingmade_forecastquantity_avg,
avg(ct_forecastquantity)/case when avg(ct_rankingmode_forecastquantity) = 0 THEN 1 ELSE avg(ct_rankingmode_forecastquantity) END ratio_final_ranking
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastsample = 'Test'
GROUP BY dd_grain1, dd_forecastalgorithm;
*/

/*
DELETE FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA t
WHERE EXISTS ( SELECT 1 FROM tmp_ranking_vs_finalforecast t1
WHERE t.dd_grain1 = t1.dd_grain1
AND t.dd_forecastalgorithm = t1.dd_forecastalgorithm
AND (t1.ratio_final_ranking < 0.9 OR t1.ratio_final_ranking > 1.1));
*/


/* Part 2: Ranking */
/* Rank by MAE, then by Bias, then by RMSE and then by Algo Name */
DROP TABLE IF EXISTS tmp_rankforecast;
CREATE TABLE tmp_rankforecast
AS
SELECT dd_grain1, 
dd_grain2,
DD_FORECASTALGORITHM, 
sum(ct_salesquantity) ct_salesquantity,
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_mae,
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_bias,
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))) ct_rmse,
RANK() OVER(PARTITION BY dd_grain1, dd_grain2 ORDER BY
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))),
DD_FORECASTALGORITHM) dd_forecastranknew
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastsample = 'Test'
AND dd_forecastalgorithm <> 'FALL_BACK_NAIVE'
GROUP BY 1,2,3;

/*
SELECT COUNT(*)
FROM tmp_rankforecast
WHERE dd_forecastranknew = 1;
*/

DROP TABLE IF EXISTS tmp_distinctgrains_rankedfcst;
CREATE TABLE tmp_distinctgrains_rankedfcst
AS
SELECT distinct dd_grain1, dd_grain2
FROM tmp_rankforecast;

/*
SELECT distinct dd_forecastalgorithm
FROM tmp_rankforecast
ORDER BY 1,2
LIMIT 10;

SELECT COUNT(DISTINCT dd_grain1)
FROM tmp_rankforecast
LIMIT 10;
*/

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = -1;

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = t.dd_forecastranknew,
f.ct_mae_rankingmode = t.ct_mae
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f, tmp_rankforecast t
WHERE f.dd_grain1 = t.dd_grain1
AND f.dd_grain2 = t.dd_grain2
AND f.dd_forecastalgorithm = t.dd_forecastalgorithm;

/*
SELECT COUNT(DISTINCT dd_grain1)
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
WHERE dd_forecastrank = 1
LIMIT 10;
*/

/* Grains that don't have any other algorithm should use Naive */
UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = 1
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
WHERE f.dd_forecastalgorithm = 'FALL_BACK_NAIVE'
AND NOT EXISTS ( SELECT 1 FROM tmp_distinctgrains_rankedfcst t
WHERE t.dd_grain1 = f.dd_grain1
AND t.dd_grain2 = f.dd_grain2);

/* 
SELECT COUNT(DISTINCT dd_grain1 || dd_forecastdate_yyyymm)
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
WHERE dd_forecastrank = 1
LIMIT 10;
*/


/* Part 3: Raw Sales and Outlier-Treated Sales */
/*
SELECT *
FROM FACT_RAWMATERIALCONSUMPTION_PREPROCESSED
WHERE dd_calendarmonthid_yyyymm = '202007';
*/

/*
SELECT *
FROM tmp_raw_and_outliertreatedsales_monthly
LIMIT 10;
*/

/*
SELECT *
FROM fact_lui_hist_rm_cd_unified_euro
LIMIT 10;
*/
/*
DROP TABLE IF EXISTS tmp_rawmaterialconsumptionhistory;
CREATE TABLE tmp_rawmaterialconsumptionhistory
AS
SELECT RTRIM(dd_raw_material_aera) || '-' || RTRIM(DD_PLANT) dd_grain1,
SUBSTR(to_char(dd_posting_date),1,4)||SUBSTR(to_char(dd_posting_date),6,2) dd_calendarmonthid_yyyymm,
DD_RAW_MATERIAL_AERA dd_rawmaterial,
dd_plant,
SUM(ct_quantity) ct_consumptionquantity_orig
FROM fact_lui_hist_rm_cd_unified_euro
WHERE DD_RAW_MATERIAL_AERA not like 'P%'
GROUP BY 1,2,3,4;
*/


/* Part 4: Customer Forecast */
/*
DROP TABLE IF EXISTS tmp_customerforecast;
CREATE TABLE tmp_customerforecast
AS
SELECT RTRIM(dd_fg_aera) || '-' || RTRIM(dd_apo_location)  dd_grain1, substr(dd_calendar_year_month,1,4)||substr(dd_calendar_year_month,6,2) dd_forecastdate_yyyymm,
to_date(dd_snapshot_date,'YYYY-MM') dd_snapshotdate,
substr(dd_snapshot_date,1,4)||substr(dd_snapshot_date,6,2) dd_snapshotdate_yyyymm,
ct_final_forecast_quantity,
ct_statistical_forecast_quantity,
ct_total_dep_dmd_lag_quantity
FROM fact_lui_baseline_forecast f, tmp_currentrunparam c
WHERE replace(dd_calendar_year_month,'-','') = c.dd_yyyymm_lag2
AND EXISTS ( SELECT 1 FROM tmp_distinctgrains_currentforecast t
WHERE t.dd_grain1 = RTRIM(dd_fg_aera) || '-' || RTRIM(dd_apo_location));
*/

DROP TABLE IF EXISTS tmp_customerforecast;
CREATE TABLE tmp_customerforecast
AS
SELECT 
dd_grain1, dd_grain2, dd_reportingdate dd_snapshotdate,to_char(dd_reportingdate, 'YYYYMM') dd_snapshotdate_YYYYMM, 
dd_forecastdate_YYYYMM,
ct_forecastquantity ct_final_forecast_quantity,
ct_forecastquantity ct_statistical_forecast_quantity
FROM tmp_6MA_newmethod;




/*
SELECT *
FROM tmp_customerforecast
LIMIT 10;
*/

/* Measure accuracy */
DROP TABLE IF EXISTS tmp_accuracy_pergrain;
CREATE TABLE tmp_accuracy_pergrain
AS
SELECT DISTINCT f.dd_grain1, dd_grain2, 
f.dd_forecastalgorithm,
f.dd_forecastdate,
f.dd_forecastdate_yyyymm,
f.ct_mae_rankingmode,
CAST(0 AS DECIMAL(10,2)) ct_salesquantity,
CT_FORECASTQUANTITY ct_forecastquantity_cortex,
CAST(0 AS DECIMAL(10,2)) ct_forecastquantity_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_forecastquantity_cust_final,
CAST(0 AS DECIMAL(10,2)) ct_abserror_cortex,
CAST(0 AS DECIMAL(10,2)) ct_abserror_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_abserror_cust_final,
CAST(0 AS DECIMAL(10,2)) ct_bias_cortex,
CAST(0 AS DECIMAL(10,2)) ct_bias_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_bias_cust_final,
CAST(0 AS DECIMAL(10,2)) ct_ape_cortex,
CAST(0 AS DECIMAL(10,2)) ct_ape_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_ape_cust_final,
'N' dd_existsinsales,
'N' dd_existsincustfcst
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f, tmp_currentrunparam c
WHERE f.dd_forecastdate_yyyymm = c.dd_yyyymm_lag2
AND f.dd_forecastrank = 1;

/*
SELECT dd_forecastdate_yyyymm, COUNT(DISTINCT dd_grain1||dd_grain2)
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastrank = 1
GROUP BY 1
ORDER BY 1;

SELECT *
FROM tmp_currentrunparam;
*/


/* Should return 0 rows */
/*
SELECT dd_grain1, COUNT(*)
FROM tmp_accuracy_pergrain
GROUP BY 1
HAVING COUNT(*) > 1;
*/
/*
select *
from tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_grain1 = 'RM 6297-BE00'
AND dd_forecastrank = 1
AND dd_forecastsample = 'Test';
*/
/*
SELECT *
FROM FACT_RAWMATERIALCONSUMPTION_PREPROCESSED
LIMIT 10;

SELECT *
FROM tmp_accuracy_pergrain
LIMIT 10;
*/

UPDATE tmp_accuracy_pergrain f
SET f.ct_salesquantity = s.ct_consumptionquantity_orig,
dd_existsinsales = 'Y'
FROM tmp_accuracy_pergrain f, FACT_RAWMATERIALCONSUMPTION_PREPROCESSED s --tmp_rawmaterialconsumptionhistory s --tmp_raw_and_outliertreatedsales_monthly s
WHERE f.dd_grain1 = s.dd_plantcode
AND f.dd_grain2 = s.dd_partnumber
AND f.dd_forecastdate_yyyymm = s.dd_calendarmonthid_yyyymm;

/*
SELECT *
FROM tmp_accuracy_pergrain f
limit 10;
select *
from tmp_raw_and_outliertreatedsales_monthly s
limit 10;
*/

UPDATE tmp_accuracy_pergrain f
SET f.ct_forecastquantity_cust_stat = c.ct_statistical_forecast_quantity,
f.ct_forecastquantity_cust_final = c.ct_final_forecast_quantity,
dd_existsincustfcst = 'Y'
FROM tmp_accuracy_pergrain f, tmp_customerforecast c
WHERE f.dd_grain1 = c.dd_grain1
AND f.dd_grain2 = c.dd_grain2
AND f.dd_forecastdate_yyyymm = c.dd_forecastdate_yyyymm;

UPDATE tmp_accuracy_pergrain f
SET ct_salesquantity = 0.1
WHERE (ct_salesquantity = 0
OR ct_salesquantity IS NULL);

DELETE FROM tmp_accuracy_pergrain
WHERE (dd_existsinsales = 'N'
OR dd_existsincustfcst = 'N');


UPDATE tmp_accuracy_pergrain
SET ct_abserror_cortex = abs(ct_forecastquantity_cortex - ct_salesquantity),
ct_abserror_cust_stat = abs(ct_forecastquantity_cust_stat - ct_salesquantity),
ct_abserror_cust_final = abs(ct_forecastquantity_cust_final - ct_salesquantity),
ct_bias_cortex = (ct_forecastquantity_cortex - ct_salesquantity),
ct_bias_cust_stat = (ct_forecastquantity_cust_stat - ct_salesquantity),
ct_bias_cust_final = (ct_forecastquantity_cust_final - ct_salesquantity),
ct_ape_cortex = 100 * abs(ct_forecastquantity_cortex - ct_salesquantity)/ct_salesquantity,
ct_ape_cust_stat = 100 * abs(ct_forecastquantity_cust_stat - ct_salesquantity)/ct_salesquantity,
ct_ape_cust_final = 100 * abs(ct_forecastquantity_cust_final - ct_salesquantity)/ct_salesquantity;


SELECT 100 * ROUND(SUM(ct_abserror_cortex)/SUM(ct_salesquantity),3) WtAE_Cortex,
100 * ROUND(SUM(ct_abserror_cust_stat)/SUM(ct_salesquantity),3) WtAE_CustStat,
100 * ROUND(SUM(ct_abserror_cust_final)/SUM(ct_salesquantity),3) WtAE_CustFinal,
100 * ROUND(SUM(ct_bias_cortex)/SUM(ct_salesquantity),3) WtBias_Cortex,
100 * ROUND(SUM(ct_bias_cust_stat)/SUM(ct_salesquantity),3) WtBias_CustStat,
100 * ROUND(SUM(ct_bias_cust_final)/SUM(ct_salesquantity),3) WtBias_CustFinal,
SUM(CASE WHEN ct_abserror_cortex <= ct_abserror_cust_stat THEN 1 ELSE 0 END) cnt_aerabetterthanstat,
SUM(CASE WHEN ct_abserror_cortex <= ct_abserror_cust_final THEN 1 ELSE 0 END) cnt_aerabetterthanfinal,
sum(1) cnt_total
FROM tmp_accuracy_pergrain;


/*
DROP TABLE IF EXISTS fact_finalrawmaterialforecast_monthly;
CREATE TABLE fact_finalrawmaterialforecast_monthly
AS
SELECT 
CAST(0 AS INT) fact_finalrawmaterialforecast_monthlyID,
dd_reportingdate, dd_grain1, dd_grain2, dd_forecastalgorithm, dd_forecastrank, 
dd_forecastdate, dd_forecastdate_yyyymm, dd_forecastsample,
ct_salesquantity, ct_forecastquantity
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE 1=2;

ALTER TABLE fact_finalrawmaterialforecast_monthly
ADD COLUMN dd_partnumber varchar(20);

ALTER TABLE fact_finalrawmaterialforecast_monthly
ADD COLUMN dd_plantcode varchar(20);

UPDATE fact_finalrawmaterialforecast_monthly
SET dd_partnumber = dd_grain2,
dd_plantcode = dd_grain1;

select *
from fact_finalrawmaterialforecast_monthly
limit 10;
*/



DELETE FROM fact_finalrawmaterialforecast_monthly
WHERE dd_reportingdate in (SELECT DISTINCT dd_reportingdate FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA);

INSERT INTO fact_finalrawmaterialforecast_monthly
(fact_finalrawmaterialforecast_monthlyid, 
dd_reportingdate, dd_plantcode, dd_partnumber, dd_forecastalgorithm, dd_forecastrank, 
dd_forecastdate, dd_forecastdate_yyyymm, dd_forecastsample,
ct_salesquantity, ct_forecastquantity)
SELECT 
(SELECT MAX(IFNULL(fact_finalrawmaterialforecast_monthlyid,0)) FROM fact_finalrawmaterialforecast_monthly)
+ row_number() over(order by dd_reportingdate, dd_grain1, dd_grain2, dd_forecastalgorithm, dd_forecastdate) fact_finalsalesforecast_weeklyid,
dd_reportingdate, dd_grain1, dd_grain2, dd_forecastalgorithm, dd_forecastrank, 
dd_forecastdate, dd_forecastdate_yyyymm, dd_forecastsample,
ct_salesquantity, ct_forecastquantity
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastrank = 1;

/*
SELECT *
FROM tmp_accuracy_pergrain
ORDER BY ct_abserror_cortex DESC
LIMIT 10;
*/

/* Individual examples */

/*
SELECT dd_reportingdate, f.dd_grain1, dd_forecastrank, dd_forecastalgorithm, dd_forecastdate, 
ct_salesquantity, ct_rankingmode_forecastquantity rankfcst, ct_forecastquantity,
dd_forecastsample,
s.ct_consumptionquantity_orig
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f, tmp_raw_and_outliertreatedsales_monthly s
WHERE f.dd_grain1 = 'RM 12272-BE00'
AND f.dd_forecastdate >= '2018-11-01'
AND f.dd_forecastdate <= '2020-06-01'
AND f.dd_grain1 = s.dd_grain1
AND f.dd_forecastdate_yyyymm = s.dd_calendarmonthid_yyyymm
ORDER BY f.dd_grain1, dd_forecastrank, dd_forecastalgorithm, dd_forecastdate;
*/

/*
EXPORT 
(SELECT dd_reportingdate, dd_plantcode, dd_partnumber, dd_forecastalgorithm, 
dd_forecastdate, dd_forecastdate_yyyymm, dd_forecastsample,
ct_salesquantity, ct_forecastquantity
FROM fact_finalrawmaterialforecast_monthly 
WHERE dd_forecastdate_yyyymm >= '201901'
ORDER BY dd_grain1, dd_grain2)
INTO LOCAL CSV FILE '/Users/lokeshkamani/DSWork/poc_customer/0-firmenich/data/rawmaterialforecastoutput_6snapshots.csv.gz'
COLUMN SEPARATOR = ','
WITH COLUMN NAMES
REPLACE;
*/


/******************************************************************************************************************************************/
/* Final Export for CE/Skills Team */
UPDATE fact_finalrawmaterialforecast_monthly 
SET ct_salesquantity = 0
WHERE ct_salesquantity IS NULL;

UPDATE fact_finalrawmaterialforecast_monthly 
SET ct_salesquantity = 0.001 
WHERE ct_salesquantity = 0;

/*
SELECT *
FROM fact_finalrawmaterialforecast_monthly 
LIMIT 10;
*/


DROP TABLE IF EXISTS tmp_cumulativesales;
CREATE TABLE tmp_cumulativesales
AS
SELECT dd_reportingdate, dd_partnumber, dd_plantcode, sum(ct_salesquantity) sumsales,
STDDEV(ct_salesquantity) ct_stdev,
AVG(ct_salesquantity) ct_avgsales,
STDDEV(ct_salesquantity)/CASE WHEN AVG(ct_salesquantity) = 0 THEN 1 ELSE AVG(ct_salesquantity) END ct_cov  --To ensure there's no 0 in denominator
FROM fact_finalrawmaterialforecast_monthly 
WHERE DD_FORECASTDATE >= DD_REPORTINGDATE - INTERVAL '12' MONTH
AND DD_FORECASTDATE <= DD_REPORTINGDATE 
GROUP BY dd_reportingdate, dd_partnumber, dd_plantcode;

DROP TABLE IF EXISTS tmp_orderedsales;
CREATE TABLE tmp_orderedsales
AS
SELECT f.dd_reportingdate, f.dd_partnumber, f.dd_plantcode,f.sumsales,
SUM(f.sumsales) OVER(PARTITION BY f.dd_reportingdate ORDER BY f.sumsales DESC) cumulative_qty,
rank() OVER(PARTITION BY f.dd_reportingdate ORDER BY f.sumsales DESC) dd_rank,
t.totalsalesforreportingdate,
SUM(f.sumsales) OVER(PARTITION BY f.dd_reportingdate ORDER BY f.sumsales DESC)/t.totalsalesforreportingdate ct_contribution,
cast('C' as varchar(1)) dd_abc,
cast('Z' as varchar(1)) dd_xyz,
cast('CZ' as varchar(2)) dd_segment
FROM tmp_cumulativesales f,
(select DD_REPORTINGDATE, sum(sumsales) totalsalesforreportingdate
FROM tmp_cumulativesales GROUP BY 1) t
WHERE f.dd_reportingdate = t.dd_reportingdate;

/* Update segment */
UPDATE tmp_orderedsales t1
SET t1.dd_abc = CASE WHEN ct_contribution <= 0.8 THEN 'A' 
											   WHEN ct_contribution <= 0.95 THEN 'B'
										ELSE 'C' END;

UPDATE tmp_orderedsales t1
SET t1.dd_xyz = CASE WHEN t2.ct_cov < 0.5 THEN 'X'
                     WHEN t2.ct_cov < 1.5 THEN 'Y'
                     ELSE 'Z' END
FROM tmp_orderedsales t1,tmp_cumulativesales t2
WHERE t1.dd_reportingdate = t2.dd_reportingdate
AND t1.dd_partnumber = t2.dd_partnumber
AND t1.dd_plantcode = t2.dd_plantcode;

UPDATE tmp_orderedsales
SET dd_segment = dd_abc || dd_xyz;

SELECT dd_reportingdate, dd_segment, count(*)
FROM tmp_orderedsales
GROUP BY 1,2
ORDER BY dd_reportingdate, dd_segment;

DROP TABLE IF EXISTS tmp_finalrawmaterialforecastoutput;
CREATE TABLE tmp_finalrawmaterialforecastoutput
AS
SELECT 
f.dd_partnumber || '-' || f.dd_plantcode dd_grain, 
t.dd_segment,
f.ct_forecastquantity,
f.ct_salesquantity,
f.dd_forecastdate_yyyymm dd_actualdatevalue,
f.dd_reportingdate dd_snapshotdate,
abs(f.ct_forecastquantity - f.ct_salesquantity) ct_abserror,
f.ct_forecastquantity - f.ct_salesquantity ct_error_bias,
MONTHS_BETWEEN(f.dd_forecastdate, f.dd_reportingdate) dd_lag,
100 * abs(f.ct_forecastquantity - f.ct_salesquantity) / f.ct_salesquantity ct_mape,
100 - (100 * abs(f.ct_forecastquantity - f.ct_salesquantity) / f.ct_salesquantity) ct_accuracy,
100 * (f.ct_forecastquantity - f.ct_salesquantity) / f.ct_salesquantity ct_bias
FROM fact_finalrawmaterialforecast_monthly f
INNER JOIN tmp_orderedsales t
ON f.dd_reportingdate = t.dd_reportingdate
AND f.dd_partnumber = t.dd_partnumber
AND f.dd_plantcode = t.dd_plantcode;

SELECT max(dd_actualdatevalue)
FROM tmp_finalrawmaterialforecastoutput;


