#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 15 12:40:55 2021

@author: aman
"""

import pandas as pd
import numpy as np
import requests
import sys
import time
import os
from src.utility.utils import utility


ds_server_flag = 1

if __name__ == '__main__':

            #############################################################################
    #1.Read system arguments from skill
    if ds_server_flag == 1:
        program_start_time = time.time()
        job_id = sys.argv[1]
        token_ip = sys.argv[2]
        storage_flag = sys.argv[3]
        rm_forecast_api_name = sys.argv[4]
        data_path = sys.argv[5] #/efs/datascience/Firmenich2C1/data/
        env_url_ip = sys.argv[6] #https://insightqd.aeratechnology.com/ispring/client/v2/reports/
        
        
    if ds_server_flag == 0:
        program_start_time = time.time()
        job_id = '100'
        token_ip = '6aca154203427e6d9d0c76543fe0d05f'
        storage_flag = 'true'
        rm_forecast_api_name = 'RMConsumptionhistorywithfiltersforDS'
        data_path = '/Users/aman/Downloads'
        env_url_ip = 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'
        
        
    # Initialize Path
    util = utility(data_path)
    logsPath = util.get_logs_path(job_id)
    print(logsPath)   
    
        
    # Utility functions
    def fetch_records(envUrl,api_name,token,rowStart,pageSize):
        headers = {'Authorization':token,'Host':'insightqd.aeratechnology.com'}
        url = envUrl+api_name
        params={'rowStart':rowStart,'pageSize':pageSize}
        response = requests.get(url,headers=headers,params=params)
        if response.status_code == 200:
            return pd.DataFrame(response.json()['data'])
        else:
            return 'empty_chunk'
    def read_report(envUrl,api_name,token,pageSize):
        data_chunks = []
        for i in range(0,100000):
            print('Reading Chunk - '+str(i))
            rowStart = i*pageSize
            chunk = fetch_records(envUrl,api_name,token,rowStart,pageSize)
            if not isinstance(chunk,pd.DataFrame):
                print('No Data fetched from API')
                return 'empty_data'
            else:
                data_chunks.append(chunk)
                if len(chunk) < pageSize:
                    return pd.concat(data_chunks)
    
    consumption = read_report(env_url_ip,rm_forecast_api_name,token_ip,pageSize = 50000)   

 ##### Storage Flag = 1   
    if storage_flag == 'true':
        storage_time = time.time()
        input_files_path = util.get_input_path(job_id)
        consumption.to_csv(os.path.join(input_files_path,"{}.csv".format(rm_forecast_api_name)),index=False)
        print("Input stored as csv for later debugging")

       
################## Code ################3##    
    consumption = consumption.rename(columns = {'____sum__quantity_kg': 'Agg_Sum'}, inplace = False)
    consumption['GRAIN_VALUE'] = consumption['material_number'].astype('str') + ' - ' + consumption['plant'].astype('str')
    consumption_group1 = consumption.groupby(['GRAIN_VALUE']).agg({'Agg_Sum':'sum'}).reset_index()
    consumption_group1 = consumption_group1.rename(columns = {'Agg_Sum': 'Summation'}, inplace = False)
    consumption_group2 = consumption.groupby(['GRAIN_VALUE'])['Agg_Sum'].std() / consumption.groupby(['GRAIN_VALUE'])['Agg_Sum'].mean()
    merge1 = pd.merge(right = consumption_group1, how = 'outer', left = consumption_group2, on=['GRAIN_VALUE'])
    merge1 = merge1.rename(columns = {'Agg_Sum': 'CoV'}, inplace = False)

    merge1 = merge1.sort_values(by=['Summation'], ascending=[False])
    
    merge1['cum_percent'] = 100*(merge1.Summation.cumsum() / merge1.Summation.sum()) 
    
    conditions = [
        (merge1['cum_percent'] <= 80) & (merge1['CoV'] <= .5),
        (merge1['cum_percent'] <= 80) & ((merge1['CoV'] > .5)&(merge1['CoV'] <= 1.5)),
        (merge1['cum_percent'] <= 80) & ((merge1['CoV'] > 1.5)),

        ((merge1['cum_percent'] > 80)&(merge1['cum_percent'] <= 95)) & (merge1['CoV'] <= .5),
        ((merge1['cum_percent'] > 80)&(merge1['cum_percent'] <= 95))  & ((merge1['CoV'] > .5)&(merge1['CoV'] <= 1.5)),
        ((merge1['cum_percent'] > 80)&(merge1['cum_percent'] <= 95))  & ((merge1['CoV'] > 1.5)),

    
        (merge1['cum_percent'] > 95) & (merge1['CoV'] <= .5),
        (merge1['cum_percent'] > 95) & ((merge1['CoV'] > .5)&(merge1['CoV'] <= 1.5)),
        (merge1['cum_percent'] > 95) & ((merge1['CoV'] > 1.5)),
        ]
    values = ['AX', 'AY', 'AZ', 'BX', 'BY', 'BZ', 'CX', 'CY','CZ']
    merge1['Segment'] = np.select(conditions, values)
    merge1 = merge1.drop(['CoV', 'Summation','cum_percent'], axis=1)

    

# Save the output to output folder
    output_file_path = util.get_output_path(job_id)   
    merge1.to_csv(os.path.join(output_file_path,'ABC_XYZ_Segment.csv'),index=False)

                
    
    