import pandas as pd
import numpy as np
import requests
import sys
import time
import os
from src.utility.utils import utility

'''
python3 preprocess_fgforecast_univariate.py test123 8aea8d8e78225e096479fb77bcc7b33d true CombinedRMConsumptionandFGProductionhistorywithfiltersforDS '/efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting/' 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'
'''


ds_server_flag = 1


if __name__ == '__main__':

    #############################################################################
    #1.Read system arguments from skill
    if ds_server_flag == 1:
        program_start_time = time.time()
        job_id = sys.argv[1]
        token_ip = sys.argv[2]
        storage_flag = sys.argv[3]
        fg_forecast_api_name = sys.argv[4]
        data_path = sys.argv[5] #/efs/datascience/Firmenich2C1/data/
        env_url_ip = sys.argv[6] #https://insightqd.aeratechnology.com/ispring/client/v2/reports/

    if ds_server_flag == 0:
        program_start_time = time.time()
        job_id = 'test'
        token_ip = '36d1c304291c16d7198595271a685223'
        storage_flag = 'true'
        fg_forecast_api_name = 'RMConsumptionhistorywithfiltersforDS'
        data_path = '/Users/sandeepdhankhar/Downloads/Preprocessing'
        env_url_ip = 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'


    # Initialize Path
    util = utility(data_path)
    logsPath = util.get_logs_path(job_id)
    print(logsPath)

    # Utility functions
    def fetch_records(envUrl,api_name,token,rowStart,pageSize):
        headers = {'Authorization':token,'Host':'insightqd.aeratechnology.com'}
        url = envUrl+api_name
        params={'rowStart':rowStart,'pageSize':pageSize}
        response = requests.get(url,headers=headers,params=params)
        if response.status_code == 200:
            return pd.DataFrame(response.json()['data'])
        else:
            return 'empty_chunk'
    def read_report(envUrl,api_name,token,pageSize):
        data_chunks = []
        for i in range(0,100000):
            print('Reading Chunk - '+str(i))
            rowStart = i*pageSize
            chunk = fetch_records(envUrl,api_name,token,rowStart,pageSize)
            if not isinstance(chunk,pd.DataFrame):
                print('No Data fetched from API')
                return 'empty_data'
            else:
                data_chunks.append(chunk)
                if len(chunk) < pageSize:
                    return pd.concat(data_chunks)

    prelim = read_report(env_url_ip,fg_forecast_api_name,token_ip,pageSize = 50000)

    ##### Storage Flag = 1
    if storage_flag == 'true':
        storage_time = time.time()
        input_files_path = util.get_input_path(job_id)
        prelim.to_csv(os.path.join(input_files_path,"{}.csv".format(fg_forecast_api_name)),index=False)
        print("Input stored as csv for later debugging")

    ################## Code ##################
    prelim = prelim.rename(columns = {'actual_invoiced_quantity_in_kg': 'Quantity (inKg)'}, inplace = False)
    prelim['GRAIN_VALUE'] = prelim['material_number'].astype('str') + ' - ' + prelim['customer_number'].astype('str')
    prelim['year_month'] = prelim['year_month'].astype('str')
# Remove grains which has total sum of sales zero
    sales_sum = prelim.groupby(['GRAIN_VALUE'])['Quantity (inKg)'].agg('sum').reset_index()
    only_zero_grains = list(sales_sum[sales_sum['Quantity (inKg)'] == 0]['GRAIN_VALUE'])
    only_zero_grain = prelim[prelim['GRAIN_VALUE'].isin(only_zero_grains)]
    only_zero_grain = only_zero_grain[['year_month','GRAIN_VALUE','Quantity (inKg)','business_unit','material_number','customer_number']]
    only_zero_grain['Updated Sales Qty After Outlier Treatment'] = 0
    prelim = prelim[~prelim['GRAIN_VALUE'].isin(only_zero_grains)].reset_index(drop=True)
# End 
    prelim['Year'] = prelim['year_month'].str.slice(0, 4)

    prelim_bu = prelim.filter(['GRAIN_VALUE','business_unit','material_number','customer_number'], axis=1)
    prelim_bu = prelim_bu.drop_duplicates()

    prelim = prelim.groupby(['year_month', 'GRAIN_VALUE','business_unit'])['Quantity (inKg)'].agg('sum').reset_index()




    prelim =  prelim.set_index(
        ['year_month', 'GRAIN_VALUE']
    ).unstack(
        fill_value=0
    ).stack().sort_index(level=1).reset_index()
# To remove leading zero of months
    prelim = prelim[prelim.groupby('GRAIN_VALUE')['Quantity (inKg)'].cumsum().gt(0)]



    prelim['Mean(Last 12 months)'] = prelim.groupby('GRAIN_VALUE')['Quantity (inKg)'].rolling(12).mean().reset_index(0,drop=True)

    prelim['SD(Last 12 months)'] = prelim.groupby('GRAIN_VALUE')['Quantity (inKg)'].rolling(12).std().reset_index(0,drop=True)
    prelim['2.5 SD'] = 2.5*prelim['SD(Last 12 months)']
    prelim['Lower Bound'] = prelim['Mean(Last 12 months)']  - prelim['2.5 SD']
    prelim['Upper Bound'] = prelim['Mean(Last 12 months)']  + prelim['2.5 SD']
    prelim['Median(Last 6 months)'] = prelim.groupby('GRAIN_VALUE')['Quantity (inKg)'].rolling(6).median().reset_index(0,drop=True)


    prelim['Outlier'] = ''
    prelim['Outlier'] = np.where(((prelim['Quantity (inKg)'] < prelim['Lower Bound']) | (prelim['Quantity (inKg)'] > prelim['Upper Bound']))
                                 , 'True', 'False')

    prelim['Updated Sales Qty After Outlier Treatment'] = np.where((prelim['Outlier'] == 'True')  , prelim['Median(Last 6 months)'], prelim['Quantity (inKg)'])



    prelim_upd = prelim.filter(['year_month','GRAIN_VALUE','Updated Sales Qty After Outlier Treatment','Quantity (inKg)'], axis=1)
    prelim_upd = prelim_upd.merge(prelim_bu, on='GRAIN_VALUE')
#   Takes back those grains which was removed due to 0 sales
    prelim_upd = pd.concat([prelim_upd,only_zero_grain], axis = 0).reset_index(drop=True)
    prelim_upd['Updated Sales Qty After Outlier Treatment'] = prelim_upd['Updated Sales Qty After Outlier Treatment'].fillna(0)
    print('Total grain count -', len(prelim_upd['GRAIN_VALUE'].drop_duplicates()))

    print('Total sales after - ', sum(prelim_upd['Updated Sales Qty After Outlier Treatment']))
    print('Total sales before - ', sum(prelim_upd['Quantity (inKg)']))
    print("Input stored as csv for later debugging")
    # Save the output to output folder
    output_file_path = util.get_output_path(job_id)
    prelim_upd.to_csv(os.path.join(output_file_path,'FG_Updated_timeSeries.csv'),index=False)