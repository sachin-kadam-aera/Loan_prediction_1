"""
Created on Sat Mar 20 13:06:19 2021

@author: sandeepdhankhar
"""
############################## Import packages ##############################

import os
import time
import sys
import warnings
import datetime
import pandas as pd
from dateutil.relativedelta import relativedelta

from src.utility.utils import utility
from src.utility.LoggerConfig import Logger
from src.preProcessing.multivariate_lag0_prep import get_lag0_corr_data

warnings.filterwarnings('ignore')

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

if __name__ == '__main__':

    #############################################################################
    #1.Read system arguments from skill
    if ds_server_flag == 1:
        program_start_time = time.time()
        job_id = sys.argv[1]
        token = sys.argv[2]
        storage_flag = sys.argv[3]
        rm_report_api_name = sys.argv[4]
        fg_report_api_name = sys.argv[5]
        bom_report_api_name = sys.argv[6]
        data_path = sys.argv[7] #/efs/datascience/MarsC46/data
        env_url = sys.argv[8] #https://insightqd.aeratechnology.com/ispring/client/v2/reports/

        print('Job_Id:',job_id)
        print('token:',token)
        print('storage_flag:',storage_flag)
        print('Raw Material API:',rm_report_api_name)
        print('Finished Goods API:',fg_report_api_name)
        print('BOM API',bom_report_api_name)

    if ds_server_flag == 0:
        program_start_time = time.time()
        job_id = '22Mar2021'
        token = '36218f55118e51239ba0396044253fe4'
        storage_flag = 'false'
        rm_report_api_name = 'RMConsumptionhistorywithfiltersforDS'
        fg_report_api_name = 'CombinedRMConsumptionandFGProductionhistorywithfiltersforDS'
        bom_report_api_name = 'BillofMaterialwithfiltersforDS'
        data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/11 Project Firmenich/Multivariate Prodn/Data'
        env_url = 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'

    # Initialize Path
    util = utility(data_path)
    logsPath = util.get_logs_path(job_id)
    print(logsPath)

    #############################################################################
    #2. Use the API names to call the read_report function and retrieve 3 dataframes

    # To read the data offline, use the below code
    '''
    raw_materials = pd.read_csv(os.path.join(data_path,job_id,'input','1 raw materials data.csv'), dtype = {'dfu':str,'location':str})
    finished_goods = pd.read_csv(os.path.join(data_path,job_id,'input','2 finished goods data.csv'), dtype = {'dfu':str,'location':str})
    bom = pd.read_csv(os.path.join(data_path,job_id,'input','3 bom data.csv'), dtype = {'dfu':str,'location':str})
    '''
    api_read_start = time.time()

    raw_materials = util.read_report(env_url,rm_report_api_name,token,100000)
    if not isinstance(raw_materials,pd.DataFrame):
        Logger(job_id,logsPath).logr.error('Incorrect Response from API {0}. Response Code: {1}'.format(rm_report_api_name,raw_materials))
        sys.exit()

    finished_goods = util.read_report(env_url,fg_report_api_name,token,100000)
    print(finished_goods.head())
    if not isinstance(finished_goods,pd.DataFrame):
        Logger(job_id,logsPath).logr.error('Incorrect Response from API {0}. Response Code: {1}'.format(fg_report_api_name,finished_goods))
        sys.exit()

    bom = util.read_report(env_url,bom_report_api_name,token,100000)
    if not isinstance(bom,pd.DataFrame):
        Logger(job_id,logsPath).logr.error('Incorrect Response from API {0}. Response Code: {1}'.format(bom_report_api_name,bom))
        sys.exit()

    Logger(job_id,logsPath).logr.info("Read Data from APIs in {} seconds".format(round(time.time() - api_read_start, 2)))
    #'''
    #3. If the storage flag is true, save the files in the input file directory for later use
    if storage_flag == 'true':
        storage_time = time.time()
        input_files_path = util.get_input_path(job_id)
        raw_materials.to_csv(os.path.join(input_files_path,"{}.csv".format('1 raw materials data')),index=False)
        finished_goods.to_csv(os.path.join(input_files_path,"{}.csv".format('2 finished goods data')),index=False)
        bom.to_csv(os.path.join(input_files_path,"{}.csv".format('3 bom data')),index=False)
        print("Input stored as csv for later debugging")
        Logger(job_id,logsPath).logr.info("Stored input data in {} seconds".format(round(time.time() - storage_time, 2)))

    #4. Prepare data for Correlation analysis

    #4.0 Getting Snapshot date
    snapshot_date = datetime.date.today()
    snapshot_ym = int(snapshot_date.strftime('%Y%m'))

    # Getting future periods
    #ending_period = datetime.date(2021,12,31)
    ending_period = snapshot_date + relativedelta(months=12) #12 months in future
    future_periods = pd.date_range(snapshot_date, end=ending_period, freq='M')
    future_periods = future_periods.strftime('%Y%m').astype(int)

    #4.1 Keeping required rows and columns
    raw_materials = raw_materials[['material_number','plant','year_month','____sum__quantity_kg']]
    finished_goods = finished_goods[['material_number','plant','year_month','actual_invoiced_quantity_in_kg']]
    bom = bom[['bom_component','material_number','plant']]

    raw_materials = raw_materials[raw_materials['year_month'] < snapshot_ym]
    finished_goods = finished_goods[finished_goods['year_month'] < snapshot_ym]


    #4.2 Renaming cols
    raw_materials.columns = ['Raw_Material','Plant','YearMonth','RM_consumption']
    finished_goods.columns = ['Finished_Material','Plant','YearMonth','FG_consumption']
    bom.columns = ['Raw_Material','Finished_Material','Plant']

    #4.3 Rolling the data
    raw_materials = raw_materials.groupby(['Raw_Material','Plant','YearMonth']).agg(RM_consumption = ('RM_consumption','sum')).reset_index()
    finished_goods = finished_goods.groupby(['Finished_Material','Plant','YearMonth']).agg(FG_consumption = ('FG_consumption','sum')).reset_index()
    bom = bom.drop_duplicates()

    #4.4 Changing data types
    raw_materials['Raw_Material'] = raw_materials['Raw_Material'].astype(str)
    finished_goods['Finished_Material'] = finished_goods['Finished_Material'].astype(str)

    #4.4 Creating custom cols
    raw_materials['RM_Grain'] = raw_materials['Raw_Material'] + '-' +raw_materials['Plant']
    finished_goods['FG_Grain'] = finished_goods['Finished_Material'] + '-' +finished_goods['Plant']
    bom['RM_Grain'] = bom['Raw_Material'] + '-' +bom['Plant']
    bom['FG_Grain'] = bom['Finished_Material'] + '-' +bom['Plant']

    #4.5 Keeping FG grains with 80% volume portfolio
    latest_12_months = sorted(finished_goods['YearMonth'].unique(),reverse=True)[0:11]
    sales_latest_12_months = finished_goods[finished_goods['YearMonth'].isin(latest_12_months)]
    total_sales = sum(sales_latest_12_months['FG_consumption'])
    sales_share = sales_latest_12_months.groupby(['FG_Grain']).agg(PercentShare = ('FG_consumption',
                                                                                   lambda x: round(x.sum()*100/total_sales,2))).reset_index()
    sales_share.sort_values(by = ['PercentShare'],ascending=False,inplace = True)
    sales_share['CumulativeShare'] = sales_share['PercentShare'].cumsum()
    top_grains = sales_share['FG_Grain'][sales_share['CumulativeShare'] < 80]
    finished_goods = finished_goods[finished_goods['FG_Grain'].isin(top_grains)]

    print("{}% FG grains constitute of 80% volume share in finished goods".format(round(len(top_grains)*100/len(sales_share),2)))

    #4.6 Keeping FG grains with less than 25% intermittency
    finished_goods['Value0'] = finished_goods['FG_consumption'] == 0
    fg_intermitency = finished_goods.groupby('FG_Grain').agg(Intermittency_percent = ('Value0','mean')).reset_index()
    low_intermitency_fg = fg_intermitency['FG_Grain'][fg_intermitency['Intermittency_percent']<=0.25]
    finished_goods = finished_goods[finished_goods['FG_Grain'].isin(low_intermitency_fg)]
    print('{} FG grains in finished good selected out of {}'.format(len(low_intermitency_fg),len(fg_intermitency)))

    #4.7 Keeping RM grains with 80% volume portfolio
    latest_12_months = sorted(raw_materials['YearMonth'].unique(),reverse=True)[0:11]
    sales_latest_12_months = raw_materials[raw_materials['YearMonth'].isin(latest_12_months)]
    total_sales = sum(sales_latest_12_months['RM_consumption'])
    sales_share = sales_latest_12_months.groupby(['RM_Grain']).agg(PercentShare = ('RM_consumption',
                                                                                   lambda x: round(x.sum()*100/total_sales,2))).reset_index()
    sales_share.sort_values(by = ['PercentShare'],ascending=False,inplace = True)
    sales_share['CumulativeShare'] = sales_share['PercentShare'].cumsum()
    top_grains = sales_share['RM_Grain'][sales_share['CumulativeShare'] < 80]
    raw_materials = raw_materials[raw_materials['RM_Grain'].isin(top_grains)]

    print("{}% RM grains constitute of 80% volume share in raw materials".format(round(len(top_grains)*100/len(sales_share),2)))

    #4.8 Keeping FG grains with less than 25% intermittency
    raw_materials['Value0'] = raw_materials['RM_consumption'] == 0
    rm_intermitency = raw_materials.groupby('RM_Grain').agg(Intermittency_percent = ('Value0','mean')).reset_index()
    low_intermitency_rm = rm_intermitency['RM_Grain'][rm_intermitency['Intermittency_percent']<=0.25]
    raw_materials = raw_materials[raw_materials['RM_Grain'].isin(low_intermitency_rm)]
    print('{} RM grains in raw materials selected out of {}'.format(len(low_intermitency_rm),len(rm_intermitency)))

    #5. Perform correlation analysis

    #5.1 Lag0
    multivar_prep_lag0 = get_lag0_corr_data(raw_materials,finished_goods,bom,future_periods)

    #6. Save the output to output folder
    output_file_path = util.get_output_path(job_id)
    multivar_prep_lag0.to_csv(os.path.join(output_file_path,'Multivariate_ip_for_cortex.csv'),index=False, na_rep='')
    Logger(job_id,logsPath).logr.info("Multivariate script finished")


