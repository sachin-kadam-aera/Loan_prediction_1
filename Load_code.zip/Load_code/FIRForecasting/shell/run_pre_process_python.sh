#!/bin/bash
echo 'Connected forecast01 (UAT-IRL).......'
folder_name=$1
token=$2
storage_flag=$3
webservice_name_rm=$4
folder_path=$5
webservice_api=$6
webservice_name_fg=$7
webservice_name_bom=$8
HOST=$9

echo pre-processiing outliertreatment py scripts Start for RM webservice..

export PATH=/opt/anaconda3/bin/:$PATH
cd /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting
python preprocess_rmforecast_univariate.py $folder_name $token $storage_flag $webservice_name_rm $folder_path $webservice_api

echo RM outliertreatment preprocessing python shell script finished ..

echo pre-processiing XYZ-ABC_Segment.py scripts Start for RM webservice..

export PATH=/opt/anaconda3/bin/:$PATH
cd /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting
python XYZ-ABC_Segment.py $folder_name $token $storage_flag $webservice_name_rm $folder_path $webservice_api

echo RM XYZ-ABC_Segment.py python shell script finished ..

echo multivariate preprocessing python shell script ..
export PATH=/opt/anaconda3/bin/:$PATH
cd /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting
python multivariate_data_prep.py  $folder_name $token $storage_flag $webservice_name_rm $webservice_name_fg $webservice_name_bom $folder_path $webservice_api
echo Multivariate preprocessing python shell script finished..
