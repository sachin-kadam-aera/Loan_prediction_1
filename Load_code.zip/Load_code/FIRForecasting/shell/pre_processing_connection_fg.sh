#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on..
folder_name=$1
token=$2
storage_flag=$3
folder_path=$4
webservice_api=$5
webservice_name_fg=$6
HOST=$7

echo "folder_name "$folder_name
echo "token: "$token
echo "storage_flag: "$storage_flag
echo "folder_path: "$folder_path
echo "webservice_api: "$webservice_api
echo "webservice_name_fg: "$webservice_name_fg
echo "HOST: "$HOST

echo "This script call Forecast01 (UAT-IRL) shell script"
ssh -o StrictHostKeyChecking=no fusionops@$HOST /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting/shell/run_pre_process_python_fg.sh $folder_name $token $storage_flag $folder_path $webservice_api $webservice_name_fg
