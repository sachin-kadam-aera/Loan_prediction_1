#!/bin/bash
set -o errexit

USER1=$(whoami)
echo -e "\e[31;43m***** User trying to run is $USER1 *****\e[0m"

echo SSH passed to target server, moving on..
folder_name=$1
token=$2
storage_flag=$3
webservice_name_rm=$4
folder_path=$5
webservice_api=$6
webservice_name_fg=$7
webservice_name_bom=$8
HOST=$9

echo "folder_name "$folder_name
echo "token: "$token
echo "storage_flag: "$storage_flag
echo "webservice_name_rm: "$webservice_name_rm
echo "folder_path: "$folder_path
echo "webservice_api: "$webservice_api
echo "webservice_name_fg: "$webservice_name_fg
echo "webservice_name_bom: "$webservice_name_bom

echo "HOST: "$HOST

echo "This script call Forecast01 (UAT-IRL) shell script"
ssh -o StrictHostKeyChecking=no fusionops@$HOST /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting/shell/run_pre_process_python.sh $folder_name $token $storage_flag $webservice_name_rm $folder_path $webservice_api $webservice_name_fg $webservice_name_bom $HOST