#!/bin/bash
echo 'Connected forecast01 (UAT-IRL).......'
folder_name=$1
token=$2
storage_flag=$3
folder_path=$4
webservice_api=$5
webservice_name_fg=$6

echo FG outliertreatment preprocessing python shell script starting ..
export PATH=/opt/anaconda3/bin/:$PATH
cd /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting
python preprocess_fgforecast_univariate.py $folder_name $token $storage_flag $webservice_name_fg $folder_path $webservice_api


echo FG outliertreatment preprocessing python shell script finished ..
