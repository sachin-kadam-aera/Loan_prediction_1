#!/bin/sh
# Creating backup of final file
cd /efs/datascience/Firmenich2C1/data/

bkpdirname=`date +%Y_%m`
archivedirname=`date +%Y_%m_%d%M%S`

echo 'Backing up forecast files to /efs/datascience/Firmenich2C1/data/'${bkpdirname}
if [ -d $bkpdirname ]
then
echo "Moving existing backup dir to archive /efs/datascience/Firmenich2C1/data/$archivedirname"
mv ${bkpdirname} $archivedirname
fi
mkdir ${bkpdirname}
echo 'Backup directory name: '
echo ${bkpdirname}

cp -p /efs/datascience/Firmenich2C1/data/tmp_accuracy_pergrain.csv.gz /efs/datascience/Firmenich2C1/data/${bkpdirname}
chmod 755 -R /efs/datascience/Firmenich2C1/data/${bkpdirname}
rm /efs/datascience/Firmenich2C1/data/tmp_accuracy_pergrain.csv.gz
echo 'Backup finished..'
