echo 'Allocation Run Start...'
cd /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting/
# Run
python3 multivariate_data_prep.py $1 $2 $3 $4 $5 $6 $7 $8
echo 'Allocation Run Completed...'