#!/bin/bash
HOST='10.110.6.149'
echo 'Host IP :'$HOST



status=$(ssh -o BatchMode=yes -o ConnectTimeout=5 fusionops@$HOST echo ok 2>&1)
if [[ $status == ok ]]; then
        echo SSH passed to target server, moving on...
        ssh -o StrictHostKeyChecking=no fusionops@$HOST '/efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting/src/integration/run_python_script_segment.sh' $1 $2 $3 $4 $5 $6 2>&1

elif [[ $status == "Permission denied"* ]] ; then
    echo I am unable to communicate to target host $HOST
fi
echo 'completed.....'
