echo 'Allocation Run Start...'
cd /efs/datascience/aera-datascience/deploy/ds_services/FirmenichForecasting/
# Run
python3 RM-Univariate.py $1 $2 $3 $4 $5 $6 
echo 'Allocation Run Completed...'