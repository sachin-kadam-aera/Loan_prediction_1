/*  select only those grain data for which data are not present in Multivariate table */
drop table if exists tmp_FIROUTLIER_TREATED_SALES_HISTORY;
create table tmp_FIROUTLIER_TREATED_SALES_HISTORY
as
select * from FACT_FIROUTLIER_TREATED_SALES_HISTORY
where DD_LATESTREPORTING_FLAG = 'Y' and DD_MATERIAL_TYPE = 'RM'
and DD_RAW_MATERIAL||dd_PLANT not in
									(select distinct DD_RAW_MATERIAL||dd_PLANT from FACT_FIRMENISH_MULTIVARIATE_SALES
									 where DD_LATESTREPORTING_FLAG = 'Y');

/*  Insert Univariate tmp table data into existing multivariate sales */

INSERT INTO FACT_FIRMENISH_MULTIVARIATE_SALES
(
fact_firmenish_multivariate_salesID,
DD_RAW_MATERIAL,
DD_PLANT,
DD_YEAR_MONTH,
CT_RM_CONSUMPTION,
DD_LATESTREPORTING_FLAG,
DD_SNAPSHOTDATE,
dd_is_mulv_sales,
CT_FG_CONSUMPTION,
DD_MONTH,
DD_QUARTER
)
SELECT
(
select
ifnull(max(fact_firmenish_multivariate_salesID), 0)
from fact_firmenish_multivariate_sales m) + row_number()
over(order by '') as fact_firmenish_multivariate_salesID,
DD_RAW_MATERIAL,
DD_PLANT,
DD_YEAR_MONTH,
CT_OUTLIER_SALES,
'Y',
DD_SNAPSHOTDATE,
'N',0,0,0
FROM
     tmp_FIROUTLIER_TREATED_SALES_HISTORY;
     
/*  Delete all entries where future date is present */

delete * from  FACT_FIRMENISH_MULTIVARIATE_SALES
where DD_YEAR_MONTH >= select to_char(to_date(current_date,'YYYY-MM-DD'),'YYYYMM');