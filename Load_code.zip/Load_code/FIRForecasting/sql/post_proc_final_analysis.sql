/* Table tmp_currentrunparam will be passed from skill which contains lastest job id and reporting date */

UPDATE tmp_currentrunparam
SET dd_yyyymm_lag2 = to_char(dd_reportingdate + interval '1' month,'YYYYMM');

/* Part 1: Cortex data for current job */
DROP TABLE IF EXISTS tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA;
CREATE TABLE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
AS
SELECT
c.dd_reportingdate,
f.DD_JOBID, f.DD_GRAIN1, f.DD_FORECASTALGORITHM, f.DD_FORECASTRANK,
f.DD_FORECASTDATE, f.DD_ACTUALDATEVALUE DD_FORECASTDATE_YYYYMM,
f.CT_SALESQUANTITY, f.CT_FORECASTQUANTITY, f.CT_RANKINGMODE_FORECASTQUANTITY,
cast(0 as decimal(10,2)) ct_mae_rankingmode,
d.dd_holdout_date dd_endoftrainingoutperiod,
d.dd_last_date dd_endofholdoutperiod,
CASE WHEN f.DD_ACTUALDATEVALUE <= d.dd_holdout_date THEN 'Train'
WHEN f.DD_ACTUALDATEVALUE <= d.dd_last_date THEN 'Test'
ELSE 'Horizon'
END dd_forecastsample
FROM FACT_FORECASTOUTPUT_CORTEX_DATA f
INNER JOIN dim_jobmetadata_cortex_data d
ON d.dd_jobid = f.dd_jobid, tmp_currentrunparam c
WHERE d.dd_jobid = c.dd_jobid
AND dd_forecastalgorithm in ('FittestARIMA','FALL_BACK_NAIVE','AUTO_ARIMA','SIMPLE_EXPO_SMOOTHING')
AND f.DD_ACTUALDATEVALUE <> 'None';

/* 3MA */

DROP TABLE IF EXISTS tmp_naive_3MAand6MA;
CREATE TABLE tmp_naive_3MAand6MA
AS
SELECT dd_grain1,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endoftrainingoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endoftrainingoutperiod,'YYYYMM') - INTERVAL '3' MONTH
THEN ct_salesquantity ELSE NULL END) ct_3ma_ranking,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endofholdoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endofholdoutperiod,'YYYYMM') - INTERVAL '3' MONTH
THEN ct_salesquantity ELSE NULL END) ct_3ma_final,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endoftrainingoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endoftrainingoutperiod,'YYYYMM') - INTERVAL '6' MONTH
THEN ct_salesquantity ELSE NULL END) ct_6ma_ranking,
AVG(CASE WHEN to_date(dd_forecastdate_yyyymm,'YYYYMM') <= to_date(dd_endofholdoutperiod,'YYYYMM')
AND to_date(dd_forecastdate_yyyymm,'YYYYMM') > to_date(dd_endofholdoutperiod,'YYYYMM') - INTERVAL '6' MONTH
THEN ct_salesquantity ELSE NULL END) ct_6ma_final
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastalgorithm = 'FALL_BACK_NAIVE'
GROUP BY 1;

DROP TABLE IF EXISTS tmp_6MA_newmethod;
CREATE TABLE tmp_6MA_newmethod
AS
SELECT *
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastalgorithm = 'FALL_BACK_NAIVE';

UPDATE tmp_6MA_newmethod m
SET
m.DD_FORECASTALGORITHM = '6MA',
m.ct_rankingmode_forecastquantity = n.ct_6ma_ranking,
m.ct_forecastquantity = n.ct_6ma_final
FROM tmp_6MA_newmethod m, tmp_naive_3MAand6MA n
WHERE m.dd_grain1 = n.dd_grain1;

INSERT INTO tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
SELECT *
FROM tmp_6MA_newmethod m;

DROP TABLE IF EXISTS tmp_distinctgrains_currentforecast;
CREATE TABLE tmp_distinctgrains_currentforecast
AS
SELECT dd_grain1, count(distinct DD_FORECASTALGORITHM) ct_algocount,
min(DD_FORECASTDATE) mindate,
max(DD_FORECASTDATE) maxdate
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
GROUP BY dd_grain1;

/* Rank by MAE, then by Bias, then by RMSE and then by Algo Name */
DROP TABLE IF EXISTS tmp_rankforecast;
CREATE TABLE tmp_rankforecast
AS
SELECT dd_grain1, DD_FORECASTALGORITHM,
sum(ct_salesquantity) ct_salesquantity,
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_mae,
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)) ct_bias,
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))) ct_rmse,
RANK() OVER(PARTITION BY dd_grain1 ORDER BY
avg(abs(CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
avg((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity)),
SQRT(AVG(POWER((CT_RANKINGMODE_FORECASTQUANTITY - ct_salesquantity),2))),
DD_FORECASTALGORITHM) dd_forecastranknew
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA
WHERE dd_forecastsample = 'Test'
AND dd_forecastalgorithm <> 'FALL_BACK_NAIVE'
GROUP BY 1,2;


DROP TABLE IF EXISTS tmp_distinctgrains_rankedfcst;
CREATE TABLE tmp_distinctgrains_rankedfcst
AS
SELECT distinct dd_grain1
FROM tmp_rankforecast;


UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = -1;

UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = t.dd_forecastranknew,
f.ct_mae_rankingmode = t.ct_mae
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f, tmp_rankforecast t
WHERE f.dd_grain1 = t.dd_grain1
AND f.dd_forecastalgorithm = t.dd_forecastalgorithm;

/* Grains that don't have any other algorithm should use Naive */
UPDATE tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
SET f.dd_forecastrank = 1
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f
WHERE f.dd_forecastalgorithm = 'FALL_BACK_NAIVE'
AND NOT EXISTS ( SELECT 1 FROM tmp_distinctgrains_rankedfcst t
WHERE t.dd_grain1 = f.dd_grain1);

/* Part 4: Customer Forecast */
DROP TABLE IF EXISTS tmp_customerforecast;
CREATE TABLE tmp_customerforecast
AS
SELECT RTRIM(dd_fg_aera) || '-' || RTRIM(dd_apo_location)  dd_grain1, substr(dd_calendar_year_month,1,4)||substr(dd_calendar_year_month,6,2) dd_forecastdate_yyyymm,
to_date(dd_snapshot_date,'YYYY-MM') dd_snapshotdate,
substr(dd_snapshot_date,1,4)||substr(dd_snapshot_date,6,2) dd_snapshotdate_yyyymm,
ct_final_forecast_quantity,
ct_statistical_forecast_quantity,
ct_total_dep_dmd_lag_quantity
FROM fact_lui_baseline_forecast f, tmp_currentrunparam c
WHERE replace(dd_calendar_year_month,'-','') = c.dd_yyyymm_lag2
AND EXISTS ( SELECT 1 FROM tmp_distinctgrains_currentforecast t
WHERE t.dd_grain1 = RTRIM(dd_fg_aera) || '-' || RTRIM(dd_apo_location));


/* Measure accuracy */
DROP TABLE IF EXISTS tmp_accuracy_pergrain;
CREATE TABLE tmp_accuracy_pergrain
AS
SELECT DISTINCT f.dd_grain1,
f.dd_forecastalgorithm,
f.dd_forecastdate,
f.dd_forecastdate_yyyymm,
f.ct_mae_rankingmode,
CAST(0 AS DECIMAL(10,2)) ct_salesquantity,
CT_FORECASTQUANTITY ct_forecastquantity_cortex,
CAST(0 AS DECIMAL(10,2)) ct_forecastquantity_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_forecastquantity_cust_final,
CAST(0 AS DECIMAL(10,2)) ct_abserror_cortex,
CAST(0 AS DECIMAL(10,2)) ct_abserror_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_abserror_cust_final,
CAST(0 AS DECIMAL(10,2)) ct_bias_cortex,
CAST(0 AS DECIMAL(10,2)) ct_bias_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_bias_cust_final,
CAST(0 AS DECIMAL(10,2)) ct_ape_cortex,
CAST(0 AS DECIMAL(10,2)) ct_ape_cust_stat,
CAST(0 AS DECIMAL(10,2)) ct_ape_cust_final,
'N' dd_existsinsales,
'N' dd_existsincustfcst
FROM tmp_currentjob_FACT_FORECASTOUTPUT_CORTEX_DATA f, tmp_currentrunparam c
WHERE f.dd_forecastdate_yyyymm = c.dd_yyyymm_lag2
AND f.dd_forecastrank = 1;


UPDATE tmp_accuracy_pergrain f
SET f.ct_salesquantity = s.ct_consumptionquantity_orig,
dd_existsinsales = 'Y'
FROM tmp_accuracy_pergrain f, tmp_rawmaterialconsumptionhistory s --tmp_raw_and_outliertreatedsales_monthly s
WHERE f.dd_grain1 = s.dd_grain1
AND f.dd_forecastdate_yyyymm = s.dd_calendarmonthid_yyyymm;

UPDATE tmp_accuracy_pergrain f
SET f.ct_forecastquantity_cust_stat = c.ct_statistical_forecast_quantity,
f.ct_forecastquantity_cust_final = c.ct_final_forecast_quantity,
dd_existsincustfcst = 'Y'
FROM tmp_accuracy_pergrain f, tmp_customerforecast c
WHERE f.dd_grain1 = c.dd_grain1
AND f.dd_forecastdate_yyyymm = c.dd_forecastdate_yyyymm;

UPDATE tmp_accuracy_pergrain f
SET ct_salesquantity = 0.1
WHERE (ct_salesquantity = 0
OR ct_salesquantity IS NULL);

DELETE FROM tmp_accuracy_pergrain
WHERE (dd_existsinsales = 'N'
OR dd_existsincustfcst = 'N');


UPDATE tmp_accuracy_pergrain
SET ct_abserror_cortex = abs(ct_forecastquantity_cortex - ct_salesquantity),
ct_abserror_cust_stat = abs(ct_forecastquantity_cust_stat - ct_salesquantity),
ct_abserror_cust_final = abs(ct_forecastquantity_cust_final - ct_salesquantity),
ct_bias_cortex = (ct_forecastquantity_cortex - ct_salesquantity),
ct_bias_cust_stat = (ct_forecastquantity_cust_stat - ct_salesquantity),
ct_bias_cust_final = (ct_forecastquantity_cust_final - ct_salesquantity),
ct_ape_cortex = 100 * abs(ct_forecastquantity_cortex - ct_salesquantity)/ct_salesquantity,
ct_ape_cust_stat = 100 * abs(ct_forecastquantity_cust_stat - ct_salesquantity)/ct_salesquantity,
ct_ape_cust_final = 100 * abs(ct_forecastquantity_cust_final - ct_salesquantity)/ct_salesquantity;


SELECT 100 * ROUND(SUM(ct_abserror_cortex)/SUM(ct_salesquantity),3) WtAE_Cortex,
100 * ROUND(SUM(ct_abserror_cust_stat)/SUM(ct_salesquantity),3) WtAE_CustStat,
100 * ROUND(SUM(ct_abserror_cust_final)/SUM(ct_salesquantity),3) WtAE_CustFinal,
100 * ROUND(SUM(ct_bias_cortex)/SUM(ct_salesquantity),3) WtBias_Cortex,
100 * ROUND(SUM(ct_bias_cust_stat)/SUM(ct_salesquantity),3) WtBias_CustStat,
100 * ROUND(SUM(ct_bias_cust_final)/SUM(ct_salesquantity),3) WtBias_CustFinal,
SUM(CASE WHEN ct_abserror_cortex <= ct_abserror_cust_stat THEN 1 ELSE 0 END) cnt_aerabetterthanstat,
SUM(CASE WHEN ct_abserror_cortex <= ct_abserror_cust_final THEN 1 ELSE 0 END) cnt_aerabetterthanfinal,
sum(1) cnt_total
FROM tmp_accuracy_pergrain;

EXPORT tmp_accuracy_pergrain
INTO LOCAL CSV FILE '/efs/datascience/Firmenich2C1/data/tmp_accuracy_pergrain.csv.gz'
COLUMN SEPARATOR = ','
WITH COLUMN NAMES
REPLACE;
