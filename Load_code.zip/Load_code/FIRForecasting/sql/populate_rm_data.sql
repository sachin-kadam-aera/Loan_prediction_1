/*  Script to load outlier treated sales data into fact table */

/* Drop and create tmp table every time */
drop table if exists  tmp_firoutlier_treated_sales_history_RM;
create table tmp_firoutlier_treated_sales_history_RM
(
year_month varchar(10),
grain_value varchar(100),
outlier_sales decimal(18,4),
sales decimal(18,4),
business_unit varchar(100),
material_number varchar(100),
plant varchar (100)
);

/* import outlier treated sales data into tmp table */
import into tmp_firoutlier_treated_sales_history_RM
(
year_month,
grain_value,
outlier_sales,
sales ,
business_unit,
material_number,
plant
)
from local CSV file '/efs/datascience/Firmenich2C1/data/auto_forecast_firmenish/output/RM_Updated_timeSeries.csv'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

/* Set N to old reporting flag */
update fact_firoutlier_treated_sales_history
set dd_latestreporting_flag = 'N'
where DD_MATERIAL_TYPE = 'RM';

DELETE * FROM fact_firoutlier_treated_sales_history
WHERE DD_SNAPSHOTDATE IN (to_char(to_date(current_date,'YYYY-MM-DD'),'DD MON YYYY'));


/* Insert latest data from tmp to fact table with lastest reporting flag */
insert into fact_firoutlier_treated_sales_history
(
fact_firoutlier_treated_sales_historyID,
dd_year_month,
dd_grain_value,
ct_outlier_sales,
ct_sales ,
dd_business_unit,
dd_raw_material,
dd_plant,
dd_latestreporting_flag,
DD_MATERIAL_TYPE,
DD_SNAPSHOTDATE
)
select
(
select
ifnull(max(fact_firoutlier_treated_sales_historyID), 0)
from fact_firoutlier_treated_sales_history m) + row_number()
over(order by '') as fact_firoutlier_treated_sales_historyID,
year_month, grain_value , outlier_sales, sales, business_unit,
material_number,
plant,'Y','RM', to_char(to_date(current_date,'YYYY-MM-DD'),'DD MON YYYY') 
from tmp_firoutlier_treated_sales_history_RM;