/* Script to load outlier treated sales data into fact table */

drop table if exists tmp_firmenish_multivariate_sales ;
create table tmp_firmenish_multivariate_sales
(
dd_raw_material varchar(50),
dd_plant varchar(20),
dd_year_month varchar(10),
ct_rm_consumption decimal(18,4),
dd_rm_grains varchar(100),
dd_fg_grain varchar(100),
ct_fg_consumption decimal(18,4),
dd_month varchar(10),
dd_quarter varchar(10)
) ;

/* import outlier treated sales data into tmp table */
import into tmp_firmenish_multivariate_sales
(
dd_raw_material,
dd_plant ,
dd_year_month ,
ct_rm_consumption,
dd_rm_grains ,
dd_fg_grain ,
ct_fg_consumption ,
dd_month ,
dd_quarter
)
from local CSV file '/efs/datascience/Firmenich2C1/data/auto_forecast_firmenish/output/Multivariate_ip_for_cortex.csv'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;

update fact_firmenish_multivariate_sales
set dd_latestreporting_flag = 'N';

/* Insert latest data from tmp to fact table with laster reporting flag */
insert into fact_firmenish_multivariate_sales
(
fact_firmenish_multivariate_salesID,
dd_raw_material,
dd_plant ,
dd_year_month ,
ct_rm_consumption,
dd_rm_grains ,
dd_fg_grain ,
ct_fg_consumption ,
dd_month ,
dd_quarter,
dd_latestreporting_flag,
DD_SNAPSHOTDATE,
dd_is_mulv_sales
)
select
(
select
ifnull(max(fact_firmenish_multivariate_salesID), 0)
from fact_firmenish_multivariate_sales m) + row_number()
over(order by '') as fact_firmenish_multivariate_salesID,
dd_raw_material,
dd_plant ,
dd_year_month ,
ct_rm_consumption,
dd_rm_grains ,
dd_fg_grain ,
ct_fg_consumption ,
dd_month ,
dd_quarter, 'Y',to_char(to_date(current_date,'YYYY-MM-DD'),'DD MON YYYY'),'Y'
from tmp_firmenish_multivariate_sales;
