
/* 
DROP TABLE IF EXISTS tmp_currentsnapshotdate
CREATE TABLE tmp_currentsnapshotdate
AS
SELECT '2020-11-30' dd_snapshotdate_endofmonth,
TO_CHAR(to_date('2020-11-30','YYYY-MM-DD'), 'DD MON YYYY') dd_snapshotdate_monyyyy,
TO_DATE('2020-11-30','YYYY-MM-DD') + INTERVAL '1' DAY - INTERVAL '1' MONTH dd_forecastdate_lag0,
TO_DATE('2020-11-30','YYYY-MM-DD') + INTERVAL '1' DAY dd_forecastdate_lag1,
TO_DATE('2020-11-30','YYYY-MM-DD') + INTERVAL '1' DAY + INTERVAL '1' MONTH dd_forecastdate_lag2,
TO_DATE('2020-11-30','YYYY-MM-DD') + INTERVAL '1' DAY + INTERVAL '2' MONTH dd_forecastdate_lag3
*/

DROP TABLE IF EXISTS tmp_rawmaterial_rawdatainput;
CREATE TABLE tmp_rawmaterial_rawdatainput
(
dd_snapshotdate_endofmonth date,
dd_forecastdate_lag0 date,
dd_materialno varchar(20),
dd_plant varchar(20),
dd_postingdate_yearmonth varchar(20),
dd_PostingDate_dateformat date,
ct_salesquantity decimal(18,2),
dd_business_unit varchar(20)
);


INSERT INTO tmp_rawmaterial_rawdatainput
(dd_materialno, dd_plant, dd_postingdate_yearmonth, ct_salesquantity) 
SELECT f.DD_MATERIALNO DD_MATERIALNO, f.DD_PLANT DD_PLANT, d.CALENDARMONTHID dd_forecastdate_yyyymm,
sum(f.CT_QUANTITY)  ct_salesquantity_orig_monthly
from fact_lui_good_movement_order_euro_dummy f
INNER JOIN DIM_SIMPLE_DATE d
ON f.DD_POST_DATE_DOC = d.datevalue
INNER JOIN dim_lui_material_location_euro d_ml
ON f.dim_material_locationid = d_ml.dim_lui_material_location_euroid
WHERE d_ml.FLAG_BUSINESS_UNIT IN ('Flavour','Perfume')
AND d_ml.FLAG_MATERIAL_TYPE = 'RM'
AND d_ml.FLAG_IN_SCOPE = 'YES'
AND f.DD_MOVEMENT_TYPE_IM IN ('261','262','Not Set')
group by f.DD_MATERIALNO, f.DD_PLANT,  d.CALENDARMONTHID ;



UPDATE tmp_rawmaterial_rawdatainput t
SET t.dd_PostingDate_dateformat = to_date(dd_postingdate_yearmonth,'YYYYMM'),
t.dd_snapshotdate_endofmonth = curr.dd_snapshotdate_endofmonth,
t.dd_forecastdate_lag0 = curr.dd_forecastdate_lag0
FROM tmp_rawmaterial_rawdatainput t, tmp_currentsnapshotdate curr;

UPDATE tmp_rawmaterial_rawdatainput t
SET t.dd_business_unit = dim.flag_business_unit
FROM tmp_rawmaterial_rawdatainput t, dim_lui_material_location_euro dim 
WHERE t.dd_materialno = dim.partnumber AND t.dd_plant = dim.plant;

/* Get distinct YYYYMM */
/* Start from the min non-zero sales date for all grains. End at dd_snapshotdate_endofmonth */
DROP TABLE IF EXISTS tmp_distinctmonths_date;
CREATE TABLE tmp_distinctmonths_date
AS
SELECT DISTINCT calendarmonthid,
CASt(NULL AS DATE) datevalue 
FROM dim_simple_date d , tmp_currentsnapshotdate curr
WHERE d.datevalue >= (SELECT min(dd_PostingDate_dateformat) FROM tmp_rawmaterial_rawdatainput WHERE ct_salesquantity > 0)
AND d.datevalue <= curr.dd_snapshotdate_endofmonth;

UPDATE tmp_distinctmonths_date
SET datevalue = to_date(to_char(calendarmonthid),'YYYYMM');

/* For each grain, first aggregate data by month */
DROP TABLE IF EXISTS tmp_rmconsumption_bymonth;
CREATE TABLE tmp_rmconsumption_bymonth
AS
SELECT dd_materialno, dd_plant, dd_business_unit, d.datevalue, 
SUM(t.ct_salesquantity) ct_salesquantity,
CAST('N' as CHAR(1)) dd_outlierflag,
CAST(NULL as DECIMAL(18,2)) ct_salesquantity_lowerbound,
CAST(NULL as DECIMAL(18,2)) ct_salesquantity_upperbound,
CAST(NULL as DECIMAL(18,2)) ct_salesquantity_rollingmedian_6m,
CAST(NULL as DECIMAL(18,2)) ct_salesquantity_outliertreated
FROM tmp_rawmaterial_rawdatainput t inner join tmp_distinctmonths_date d on t.dd_PostingDate_YearMonth = d.calendarmonthid
WHERE t.ct_salesquantity > 0
GROUP BY 1,2,3, 4;


/* For each grain, get the min date. Maxdate is whats present in tmp_currentsnapshotdate */
DROP TABLE IF EXISTS tmp_minmaxdatespergrain;
CREATE TABLE tmp_minmaxdatespergrain
AS
SELECT dd_materialno, dd_plant, dd_business_unit, min(datevalue) mindate,
curr.dd_forecastdate_lag0 maxdate
FROM tmp_rmconsumption_bymonth t , tmp_currentsnapshotdate curr
WHERE ct_salesquantity > 0
GROUP BY 1,2,3, curr.dd_forecastdate_lag0;

/* Imputed Values */
DROP TABLE IF EXISTS tmp_rmconsumption_impute;
CREATE TABLE tmp_rmconsumption_impute
AS
SELECT dd_materialno, dd_plant,dd_business_unit, d.DateValue, 0 ct_salesquantity
FROM ( SELECT DISTINCT dd_materialno, dd_plant, dd_business_unit FROM tmp_rmconsumption_bymonth) t,
tmp_distinctmonths_date d;

DELETE FROM tmp_rmconsumption_impute i
WHERE EXISTS ( SELECT 1 FROM tmp_minmaxdatespergrain t
WHERE i.dd_materialno = t.dd_materialno
AND i.dd_plant = t.dd_plant
AND i.dd_business_unit = t.dd_business_unit
AND (i.datevalue < t.mindate OR i.datevalue > t.maxdate));

/* tmp_rmconsumption_bymonth has all grains with imputation. Clean data. No leading 0's. All grains have last data point as snapshot month */
INSERT INTO tmp_rmconsumption_bymonth
(dd_materialno, dd_plant, dd_business_unit, DateValue, ct_salesquantity)
SELECT DISTINCT dd_materialno, dd_plant, dd_business_unit, DateValue, ct_salesquantity
FROM tmp_rmconsumption_impute i
WHERE NOT EXISTS ( SELECT 1 FROM tmp_rmconsumption_bymonth t
WHERE t.dd_materialno = i.dd_materialno
AND t.dd_plant = i.dd_plant
AND t.dd_business_unit = i.dd_business_unit
AND t.DateValue = i.DateValue);

/* Outlier treatment - needs to be done before getting top grains. There are large outliers */
DROP TABLE IF EXISTS tmp_cov_last12months;
CREATE TABLE tmp_cov_last12months
AS
SELECT t.dd_materialno, t.dd_plant, t.dd_business_unit,
avg(ct_salesquantity) avg_sales_12m,
stddev(ct_salesquantity) sd_sales_12m,
stddev(ct_salesquantity)/CASE WHEN avg(ct_salesquantity) > 0 THEN avg(ct_salesquantity) ELSE 1 END ct_cov_12m
FROM tmp_rmconsumption_bymonth t, tmp_currentsnapshotdate curr
WHERE t.datevalue >= curr.dd_forecastdate_lag0 - INTERVAL '11' MONTH
GROUP BY 1,2,3;   --For 31-Jan snapshot, this is from 1 Feb


UPDATE tmp_rmconsumption_bymonth t
SET t.ct_salesquantity_lowerbound = CASE WHEN c.avg_sales_12m - 2 * c.sd_sales_12m > 0 THEN t.ct_salesquantity - 2 * c.sd_sales_12m ELSE 0 END,
t.ct_salesquantity_upperbound = c.avg_sales_12m + 2 * c.sd_sales_12m
FROM tmp_rmconsumption_bymonth t, tmp_cov_last12months c
WHERE t.dd_materialno = c.dd_materialno
AND t.dd_plant = c.dd_plant
AND t.dd_business_unit = c.dd_business_unit;

UPDATE tmp_rmconsumption_bymonth
SET dd_outlierflag = 'N';

UPDATE tmp_rmconsumption_bymonth
SET dd_outlierflag = 'Y'
WHERE (ct_salesquantity < ct_salesquantity_lowerbound
OR ct_salesquantity > ct_salesquantity_upperbound);

/* Rolling median of previous 6 months */
DROP TABLE IF EXISTS tmp_rolling_median_6m;
CREATE TABLE tmp_rolling_median_6m
AS
SELECT t1.dd_materialno, t1.dd_plant, t1.dd_business_unit, t1.datevalue, t1.ct_salesquantity,
avg(t1.ct_salesquantity) over(ORDER BY t1.datevalue rows between 7 preceding and 1 preceding) ct_salesrollingavg,
MEDIAN(t2.ct_salesquantity) ct_salesrollingmedian,
avg(t2.ct_salesquantity) ct_salesrollingavg_method2
FROM tmp_rmconsumption_bymonth t1 
		INNER JOIN tmp_rmconsumption_bymonth t2
		ON  t1.dd_materialno = t2.dd_materialno
		AND t1.dd_plant = t2.dd_plant
WHERE t2.datevalue < t1.datevalue 
AND t2.datevalue > t1.datevalue - INTERVAL '7' MONTH
GROUP BY 1,2,3,4,5
ORDER BY 1,2,3,4,5;

UPDATE tmp_rmconsumption_bymonth t
SET t.ct_salesquantity_rollingmedian_6m = rollmed.ct_salesrollingmedian
FROM tmp_rmconsumption_bymonth t, tmp_rolling_median_6m rollmed
WHERE t.dd_materialno = rollmed.dd_materialno
AND t.dd_plant = rollmed.dd_plant
AND t.dd_business_unit = rollmed.dd_business_unit
AND t.datevalue = rollmed.datevalue;

UPDATE tmp_rmconsumption_bymonth
SET ct_salesquantity_outliertreated = CASE WHEN dd_outlierflag = 'Y' THEN ct_salesquantity_rollingmedian_6m END;

UPDATE tmp_rmconsumption_bymonth
SET ct_salesquantity_outliertreated = ct_salesquantity
WHERE ct_salesquantity_outliertreated IS NULL;

DROP TABLE IF EXISTS tmp_cov_last12months_afteroutliertreatment;
CREATE TABLE tmp_cov_last12months_afteroutliertreatment
AS
SELECT t.dd_materialno, t.dd_plant, t.dd_business_unit,
avg(ct_salesquantity_outliertreated) avg_sales_12m,
stddev(ct_salesquantity_outliertreated) sd_sales_12m,
stddev(ct_salesquantity_outliertreated)/CASE WHEN avg(ct_salesquantity_outliertreated) > 0 THEN avg(ct_salesquantity_outliertreated) ELSE 1 END   ct_cov_12m
FROM tmp_rmconsumption_bymonth t, tmp_currentsnapshotdate curr
WHERE t.datevalue >= curr.dd_forecastdate_lag0 - INTERVAL '11' MONTH
GROUP BY 1,2,3;   --For 31-Jan snapshot, this is from 1 Feb


/* Find grains that contribute to the top 99% in 2020 */
DROP TABLE IF EXISTS tmp_aggsales_24months;
CREATE TABLE tmp_aggsales_24months
AS
SELECT dd_plant, dd_business_unit, SUM(ct_salesquantity_outliertreated) sum_qtybydd_plant
FROM tmp_rmconsumption_bymonth f, tmp_currentsnapshotdate curr
WHERE DATEVALUE >= curr.dd_forecastdate_lag0 - INTERVAL '11' MONTH
AND DATEVALUE <= curr.dd_forecastdate_lag0 
GROUP BY 1,2;

DROP TABLE IF EXISTS tmp_aggsalesbygrain_24months;
CREATE TABLE tmp_aggsalesbygrain_24months
AS
SELECT dd_plant, dd_materialno, dd_business_unit, SUM(ct_salesquantity_outliertreated) sum_qtybydd_plant,
RANK() over(partition by dd_plant, dd_business_unit ORDER BY SUM(ct_salesquantity_outliertreated) desc) dd_rank
FROM tmp_rmconsumption_bymonth f, tmp_currentsnapshotdate curr
WHERE DATEVALUE >= curr.dd_forecastdate_lag0 - INTERVAL '11' MONTH
AND DATEVALUE <= curr.dd_forecastdate_lag0 
GROUP BY 1,2,3;

DROP TABLE IF EXISTS tmp_cumulativesales;
CREATE TABLE tmp_cumulativesales
as
SELECT s.dd_plant, s.dd_materialno, s.dd_business_unit,  s.dd_rank, SUM(s.sum_qtybydd_plant) over(partition by s.dd_plant, s.dd_business_unit ORDER BY s.dd_rank) cumulative_qty,
SUM(s.sum_qtybydd_plant) over(partition by s.dd_plant, s.dd_business_unit ORDER BY s.dd_rank)/t.sum_qtybydd_plant ct_cumulativeshare,
t.sum_qtybydd_plant totalconsumptionbydd_plant
FROM tmp_aggsalesbygrain_24months s, tmp_aggsales_24months t
WHERE s.dd_plant = t.dd_plant
AND s.dd_business_unit = t.dd_business_unit
ORDER BY  s.dd_plant, s.dd_business_unit, s.dd_rank, t.sum_qtybydd_plant totalconsumptionbydd_plant;

DROP TABLE IF EXISTS fact_preprochistory_exceptiongrains;
CREATE TABLE fact_preprochistory_exceptiongrains
AS
SELECT DISTINCT 
t.dd_materialno, t.dd_plant, t.dd_business_unit,
'E0' dd_exceptioncode, 
CAST('Contribution in last 12m less than 1%' AS VARCHAR(50)) dd_exceptiondescription
FROM tmp_rmconsumption_bymonth t
WHERE EXISTS ( SELECT 1 FROM tmp_cumulativesales c 
WHERE c.dd_plant = t.dd_plant
AND c.dd_materialno = t.dd_materialno
AND c.dd_business_unit = t.dd_business_unit
AND c.ct_cumulativeshare > 0.99);

DROP TABLE IF EXISTS tmp_rmconsumption_bymonth_topgrains;
CREATE TABLE tmp_rmconsumption_bymonth_topgrains
AS
SELECT t.*
FROM tmp_rmconsumption_bymonth t
WHERE NOT EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains c 
WHERE c.dd_plant = t.dd_plant
AND c.dd_materialno = t.dd_materialno
AND c.dd_business_unit = t.dd_business_unit
AND c.dd_exceptioncode = 'E0');

INSERT INTO fact_preprochistory_exceptiongrains
SELECT DISTINCT 
t.dd_materialno, t.dd_plant, t.dd_business_unit,
'E1' dd_exceptioncode, 
CAST('Less than 18 datapoints in history' AS VARCHAR(50)) dd_exceptiondescription
FROM tmp_rmconsumption_bymonth_topgrains t, ( SELECT dd_materialno, dd_plant,dd_business_unit, count(*) cnt
FROM tmp_rmconsumption_bymonth_topgrains GROUP BY 1, 2, 3) c
WHERE c.dd_materialno = t.dd_materialno
AND c.dd_plant = t.dd_plant
AND c.dd_business_unit = t.dd_business_unit
AND c.cnt <= 17;

DELETE FROM tmp_rmconsumption_bymonth_topgrains t
WHERE EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains f
WHERE f.dd_materialno = t.dd_materialno
AND f.dd_plant = t.dd_plant
AND f.dd_business_unit = t.dd_business_unit
AND f.dd_exceptioncode = 'E1');

DROP TABLE IF EXISTS tmp_last3m_zeros;
CREATE TABLE tmp_last3m_zeros
AS
SELECT t.dd_materialno, t.dd_plant, t.dd_business_unit, curr.dd_forecastdate_lag0 - INTERVAL '3' MONTH dd_thresholddate3m  --For Jan-End snapshot, this is Oct, Nov, Dec, Jan
FROM tmp_rmconsumption_bymonth_topgrains t, tmp_currentsnapshotdate curr
WHERE t.datevalue >= curr.dd_forecastdate_lag0 - INTERVAL '3' MONTH
GROUP BY 1,2,3, 4
HAVING SUM(ct_salesquantity) <= 0;

INSERT INTO fact_preprochistory_exceptiongrains 
SELECT DISTINCT 
t.dd_materialno, t.dd_plant, t.dd_business_unit,
'E2' dd_exceptioncode, 
CAST('Last 4m are zero' AS VARCHAR(50)) dd_exceptiondescription
FROM tmp_last3m_zeros t
WHERE NOT EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains f
WHERE f.dd_materialno = t.dd_materialno
AND f.dd_plant = t.dd_plant
AND f.dd_business_unit = t.dd_business_unit);

DELETE FROM tmp_rmconsumption_bymonth_topgrains t
WHERE EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains f
WHERE f.dd_materialno = t.dd_materialno
AND f.dd_plant = t.dd_plant
AND f.dd_business_unit = t.dd_business_unit
AND f.dd_exceptioncode = 'E2');


DROP TABLE IF EXISTS tmp_intermittency;
CREATE TABLE tmp_intermittency
AS
SELECT t.dd_materialno, t.dd_plant, t.dd_business_unit,
SUM(CASE WHEN ct_salesquantity = 0 THEN 0 ELSE 1 END) count_nonzero,
COUNT(*) count_total,
SUM(CASE WHEN ct_salesquantity = 0 THEN 0 ELSE 1 END)/COUNT(*) ct_fraction_nonzero
FROM tmp_rmconsumption_bymonth_topgrains t
GROUP BY 1,2,3;

INSERT INTO fact_preprochistory_exceptiongrains 
SELECT DISTINCT 
t.dd_materialno, t.dd_plant, t.dd_business_unit,
'E3' dd_exceptioncode, 
CAST('Highly Intermittent - More than 30% points are 0s' AS VARCHAR(50)) dd_exceptiondescription
FROM tmp_intermittency t
WHERE ct_fraction_nonzero <= 0.7
AND NOT EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains f
WHERE f.dd_materialno = t.dd_materialno
AND f.dd_plant = t.dd_plant
AND f.dd_business_unit = t.dd_business_unit);

DELETE FROM tmp_rmconsumption_bymonth_topgrains t
WHERE EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains f
WHERE f.dd_materialno = t.dd_materialno
AND f.dd_plant = t.dd_plant
AND f.dd_business_unit = t.dd_business_unit
AND f.dd_exceptioncode = 'E3');

/* Capture moderately intermittent grains, but don't remove them from forecasts */
INSERT INTO fact_preprochistory_exceptiongrains 
SELECT DISTINCT 
t.dd_materialno, t.dd_plant,t.dd_business_unit,
'W1' dd_exceptioncode, 
CAST('Moderately Intermittent - More than 20% 0s' AS VARCHAR(50)) dd_exceptiondescription
FROM tmp_intermittency t
WHERE ct_fraction_nonzero <= 0.8
AND NOT EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains f
WHERE f.dd_materialno = t.dd_materialno
AND f.dd_plant = t.dd_plant
AND f.dd_business_unit = t.dd_business_unit);


DROP TABLE IF EXISTS tmp_cov_last12months_afteroutliertreatment_topgrains;
CREATE TABLE tmp_cov_last12months_afteroutliertreatment_topgrains
AS
SELECT t.dd_materialno, t.dd_plant,t.dd_business_unit,
avg(ct_salesquantity_outliertreated) avg_sales_12m,
stddev(ct_salesquantity_outliertreated) sd_sales_12m,
stddev(ct_salesquantity_outliertreated)/avg(ct_salesquantity_outliertreated) ct_cov_12m
FROM tmp_rmconsumption_bymonth_topgrains t, tmp_currentsnapshotdate curr
WHERE t.datevalue >= curr.dd_forecastdate_lag0 - INTERVAL '11' MONTH
GROUP BY 1,2,3;   --For 31-Jan snapshot, this is from 1 Feb


INSERT INTO fact_preprochistory_exceptiongrains 
SELECT DISTINCT 
t.dd_materialno, t.dd_plant,t.dd_business_unit,
'W2' dd_exceptioncode, 
CAST('High CoV > 1.5 After Outlier Treatment' AS VARCHAR(50)) dd_exceptiondescription
FROM tmp_cov_last12months_afteroutliertreatment_topgrains t
WHERE ct_cov_12m > 1.5
AND NOT EXISTS ( SELECT 1 FROM fact_preprochistory_exceptiongrains f
WHERE f.dd_materialno = t.dd_materialno
AND f.dd_plant = t.dd_plant
AND f.dd_business_unit = t.dd_business_unit);


UPDATE fact_firoutlier_treated_sales_history
SET dd_latestreporting_flag = 'N'
WHERE DD_MATERIAL_TYPE = 'RM';

DELETE FROM fact_firoutlier_treated_sales_history f
WHERE EXISTS (SELECT 1 FROM tmp_currentsnapshotdate curr
WHERE curr.dd_snapshotdate_monyyyy = f.dd_snapshotdate)
AND DD_MATERIAL_TYPE = 'RM';

insert into fact_firoutlier_treated_sales_history
(
fact_firoutlier_treated_sales_historyID,
dd_raw_material,
dd_plant,
dd_business_unit,
dd_year_month,
dd_forecastdate_dateformat,
dd_grain_value,
ct_sales ,
ct_outlier_sales,
dd_latestreporting_flag,
DD_MATERIAL_TYPE,
DD_SNAPSHOTDATE
)
SELECT
(
select
ifnull(max(fact_firoutlier_treated_sales_historyID), 0)
FROM fact_firoutlier_treated_sales_history m) + row_number()
over(ORDER BY '') as fact_firoutlier_treated_sales_historyID,
dd_materialno,
dd_plant,
dd_business_unit,
to_char(datevalue, 'YYYYMM') dd_year_month, 
datevalue, 
dd_materialno || ' - ' || dd_plant dd_grain_value, 
ct_salesquantity,
ct_salesquantity_outliertreated,
'Y' dd_latestreporting_flag,
'RM' DD_MATERIAL_TYPE, 
curr.dd_snapshotdate_monyyyy
FROM tmp_rmconsumption_bymonth_topgrains t, tmp_currentsnapshotdate curr;


