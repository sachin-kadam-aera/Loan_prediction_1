/* This file used to populate xyz abc segmentation data into fact table */
drop table if exists  tmp_fir_xyz_abc_segment;

/* Creating tmp table */
create table tmp_fir_xyz_abc_segment
(
grain_value varchar(100),
segment varchar(5)
);

/* Importing server csv data into tmp table */
import into tmp_fir_xyz_abc_segment
(
grain_value,
segment
)
from local CSV file '/efs/datascience/Firmenich2C1/data/auto_forecast_firmenish/output/ABC_XYZ_Segment.csv'
ENCODING = 'UTF-8'
ROW SEPARATOR = 'LF'
COLUMN SEPARATOR = ','
COLUMN DELIMITER = '"'
SKIP = 1
REJECT LIMIT 0;


/* Kept old data with N flag */
update fact_fir_xyz_abc_segment
set dd_latestreporting_flag = 'N';

DELETE * FROM fact_fir_xyz_abc_segment
WHERE DD_SNAPSHOTDATE IN (to_char(to_date(current_date,'YYYY-MM-DD'),'DD MON YYYY'));

/* Inserting latest data with lastest flag */

insert into fact_fir_xyz_abc_segment
(
fact_fir_xyz_abc_segmentID,
dd_grain_value,
dd_segment,
dd_latestreporting_flag,
DD_SNAPSHOTDATE
)
select
(
select
ifnull(max(fact_fir_xyz_abc_segmentID), 0)
from fact_fir_xyz_abc_segment m) + row_number()
over(order by '') as fact_fir_xyz_abc_segmentID,
grain_value ,segment, 'Y',to_char(to_date(current_date,'YYYY-MM-DD'),'DD MON YYYY')
from tmp_fir_xyz_abc_segment;
