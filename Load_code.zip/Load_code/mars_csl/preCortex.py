'''
## Steps to run this script via terminal
Pass 8 input parameters, namely - 
    job_id - unique for each run
    token - token string to access the UAT/PROD enviornment
    storage_flag - true/false  to save input data
    dc_forecast_api_name - webservice name DC Forecast
    dc_actuals_api_name - webservice name DC Actuals
    prodn_actuals_api_name - webservice name Production Actuals
    data_path - data storage path
    env_url - UAT/PROD enviornment link

# Sample command
python3 preCortex.py 'job_id' 'token' 'storage_flag' 'dc_forecast_api_name' 'dc_actuals_api_name' 'prodn_actuals_api_name' 'data_path' 'env_url'

# Command to run on Local System
python3 preCortex.py 09Mar2021 c5e912026a346b79981235917dc66911 true dc_forecast dc_actuals production_actuals '/Users/sandeepdhankhar/OneDrive - Aera Technology/8 Project Mars/Data/' 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'

# Command to run on UAT-IRL server
python3 preCortex.py 14Dec2020 b7721454579e551882b584ac5a0a8d33 true dc_forecast dc_actuals production_actuals '/efs/datascience/MarsC46/data/' 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'
'''

import sys
import time
import os
import pickle
import pandas as pd
from src.preProcessing.DataHandling import DataHandler
from src.preProcessing.DataValidation import DataValidation
from src.utility.utils import utility
from src.utility.LoggerConfig import Logger

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

if __name__ == '__main__':
    
    #############################################################################
    #1.Read system arguments from skill
    if ds_server_flag == 1:
        program_start_time = time.time()
        job_id = sys.argv[1]
        token = sys.argv[2]
        storage_flag = sys.argv[3]
        dc_forecast_api_name = sys.argv[4]
        dc_actuals_api_name = sys.argv[5]
        prodn_actuals_api_name = sys.argv[6]
        data_path = sys.argv[7] #/efs/datascience/MarsC46/data
        env_url = sys.argv[8] #https://insightqd.aeratechnology.com/ispring/client/v2/reports/
        host = sys.argv[9] #insightqd.aeratechnology.com
        
        print('Job_Id:',job_id)
        print('token:',token)
        print('storage_flag:',storage_flag)
        print('DC Forecast API:',dc_forecast_api_name)
        print('DC Actuals API:',dc_actuals_api_name)
        print('Production Actuals API',prodn_actuals_api_name)
        
    if ds_server_flag == 0:
        program_start_time = time.time()
        job_id = '8Apr2021'
        token = 'c7fce0f08df688be06ba2f2fb99cdd31'
        storage_flag = 'false'
        dc_forecast_api_name = 'dc_forecast'
        dc_actuals_api_name = 'dc_actuals'
        prodn_actuals_api_name = 'production_actuals'
        data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/8 Project Mars/Data/'
        env_url = 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'
        host = 'insightqd.aeratechnology.com'
        
    # Initialize Path
    util = utility(data_path)
    logsPath = util.get_logs_path(job_id)
    print(logsPath)
        
    #############################################################################
    #2. Use the API names to call the read_report function and retrieve 3 dataframes
    
    # To read the data offline, use the below code
    '''
    dc_forecast = pd.read_csv(os.path.join(data_path,job_id,'input','dc_forecast.csv'), dtype = {'dfu':str,'location':str})
    dc_actuals = pd.read_csv(os.path.join(data_path,job_id,'input','dc_actuals.csv'), dtype = {'dfu':str,'location':str})
    prodn_actuals = pd.read_csv(os.path.join(data_path,job_id,'input','production_actuals.csv'), dtype = {'dfu':str,'location':str})    
    '''
    api_read_start = time.time()
    
    dc_forecast = util.read_report(env_url,dc_forecast_api_name,token,100000,host)
    if not isinstance(dc_forecast,pd.DataFrame):
        Logger(job_id,logsPath).logr.error('Incorrect Response from API {0}. Response Code: {1}'.format(dc_forecast_api_name,dc_forecast))
        sys.exit()
    
    dc_actuals = util.read_report(env_url,dc_actuals_api_name,token,100000,host)
    if not isinstance(dc_actuals,pd.DataFrame):
        Logger(job_id,logsPath).logr.error('Incorrect Response from API {0}. Response Code: {1}'.format(dc_actuals_api_name,dc_actuals))
        sys.exit()
        
    prodn_actuals = util.read_report(env_url,prodn_actuals_api_name,token,100000,host)
    if not isinstance(prodn_actuals,pd.DataFrame):
        Logger(job_id,logsPath).logr.error('Incorrect Response from API {0}. Response Code: {1}'.format(prodn_actuals_api_name,prodn_actuals))
        sys.exit()
    
    Logger(job_id,logsPath).logr.info("Read Data from APIs in {} seconds".format(round(time.time() - api_read_start, 2)))
    #'''
    #############################################################################
    
    #############################################################################
    #3. If the storage flag is true, save the files in the input file directory for later use
    if storage_flag == 'true':
        storage_time = time.time()
        input_files_path = util.get_input_path(job_id)
        dc_forecast.to_csv(os.path.join(input_files_path,"{}.csv".format(dc_forecast_api_name)),index=False)
        dc_actuals.to_csv(os.path.join(input_files_path,"{}.csv".format(dc_actuals_api_name)),index=False)
        prodn_actuals.to_csv(os.path.join(input_files_path,"{}.csv".format(prodn_actuals_api_name)),index=False)
        print("Input stored as csv for later debugging")
        Logger(job_id,logsPath).logr.info("Stored input data in {} seconds".format(round(time.time() - storage_time, 2)))
    #############################################################################
    
    #############################################################################
    #4. Pass the dataframe to the validation checks
    #'''
    validation_time = time.time()
    validation = DataValidation(job_id,logsPath,dc_forecast,dc_actuals,prodn_actuals)
    del validation
    Logger(job_id,logsPath).logr.info("Validated data in {} seconds".format(round(time.time() - validation_time, 2)))    
    #'''
    #############################################################################
    
    #############################################################################
    #5. Pass the dataframes to the DataHandler Object, then save the output
    preprocess_time = time.time()
    preProcessing = DataHandler(job_id,logsPath,dc_forecast,dc_actuals,prodn_actuals)
    # Save the output to output folder
    output_file_path = util.get_output_path(job_id)
    #with open(os.path.join(output_file_path,'_postCortex_ip_line_maping.dat'), "wb") as f: pickle.dump(preProcessing.line_maping, f)
    #with open(os.path.join(output_file_path,'_postCortex_ip_ats_pred.dat'), "wb") as f: pickle.dump(preProcessing.ats_predn, f)
    with open(os.path.join(output_file_path,'_postCortex_ip_mars_fcst_accuracy.dat'), "wb") as f: pickle.dump(preProcessing.mars_forecast_accuracy, f)
    with open(os.path.join(output_file_path,'_postCortex_ip_mars_actual_sales.dat'), "wb") as f: pickle.dump(preProcessing.mars_actual_sales, f)
    preProcessing.forecast_snapshot.to_csv(os.path.join(output_file_path,'_mars_forecast_test_period.csv'),index=False)
    preProcessing.cortex_ip.to_csv(os.path.join(output_file_path,'1_cortexDateInput.csv'),index=False)
    preProcessing.dc_summary.to_csv(os.path.join(output_file_path,'2_dc_summary.csv'),index=False)
    preProcessing.prodn_summary.to_csv(os.path.join(output_file_path,'3_prodn_summary.csv'),index=False)
    preProcessing.bias_csl_corr.to_csv(os.path.join(output_file_path,'4_bias_csl_corr.csv'),index=False)
    preProcessing.cortex_dc_sales_ip.to_csv(os.path.join(output_file_path,'5_cortex_dc_sales_ip.csv'),index=False)
    preProcessing.ats_csl_corr.to_csv(os.path.join(output_file_path,'6_ats_csl_corr.csv'),index=False)
    #preProcessing.cortex_ats_ip.to_csv(os.path.join(output_file_path,'7_cortex_ats_ip.csv'),index=False)
    preProcessing.ats_predn.to_csv(os.path.join(output_file_path,'9_Final_Prodn_Forecast.csv'),index=False)

    Logger(job_id,logsPath).logr.info("Preprocessed data in {} seconds".format(round(time.time() - preprocess_time, 2)))
    #############################################################################
    
    def glimpse(df):    
        Data_Type = df.dtypes
        Missing_Values = df.isnull().sum()
        Unique_Values = df.nunique()    
        df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
        df_out.columns = ['Data Type','Missing Values','Unique Values']
        return df_out
    
    
    
    
    
    
    
    
    
    
    
    
    
    
        
        
    