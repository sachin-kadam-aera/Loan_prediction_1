rm(list = ls())


library(data.table)
library(lubridate)
library(forecast)

data_folder = '09Mar2021'
data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/8 Project Mars/Data/'

########################## Read Data ##########################
prodn_actuals = fread(paste(data_path,data_folder,'input','production_actuals.csv',sep='/'))
cortex_date_ip = fread(paste(data_path,data_folder,'output','1_cortexDateInput.csv',sep='/'))

########################## Pre-processing ##########################

#1. Roll to Line level
prodn_actuals[,ats := actual_production_in_ea*100/scheduled_production_in_ea]
prodn_actuals = prodn_actuals[!(is.infinite(ats) | is.na(ats))]  # remove Inf/NA values
prodn_actuals = prodn_actuals[ats>20] # keep ats values of above 20
prodn_actuals[,ats := ifelse(ats > 100, 100, ats)] # limit ats to 100
prodn_actuals = prodn_actuals[,.(ats = mean(ats), scheduled_production_in_ea = sum(scheduled_production_in_ea),
                                 actual_production_in_ea = sum(actual_production_in_ea)),by=.(line,date)]

#2.Keep only those lines where number of data points are more than 16.
num_dpts_per_line = prodn_actuals[,.(n_data_pts = .N), by = .(line)]
num_dpts_per_line = num_dpts_per_line[n_data_pts > 16]
prodn_actuals = prodn_actuals[line %in% num_dpts_per_line$line]
prodn_actuals = prodn_actuals[order(line,date)]

#3. Split into train and test
holdout_date = cortex_date_ip[Type == 'HoldOut',Date]
last_date = cortex_date_ip[Type == 'LastDate',Date]
horizon_date = cortex_date_ip[Type == 'HorizonDate',Date]

prodn_actuals = prodn_actuals[date <= last_date]
train = prodn_actuals[,head(.SD,-8),by=.(line)]
test = prodn_actuals[,tail(.SD,8),by=.(line)]
test[,Period := seq(1,8),by=.(line)]

#train = prodn_actuals[date <= holdout_date]
#test = prodn_actuals[date > holdout_date]

#4. 8-period moving average
last_8_period = train[,tail(.SD,8),by=.(line)]
ma_predn = last_8_period[,.(ma_predn = mean(ats)),by=.(line)]

#5. Most Likely outcome based on training period
mle = function(singleLine){
  d = density(singleLine$ats)
  idx = which.max(d$y)
  mle = d$x[idx]
  return(mle)
}

most_likely_outcome = train[,.(mle_predn = mle(.SD)),by=.(line)]

#6. Mars prediction of 100


#7. Regression prediction
singleLine = train[line == 'SLO MINSTRELS']

linear_coef = function(singleLine){
  lm_model = lm(ats~scheduled_production_in_ea,data=singleLine)
  intercept = lm_model$coefficients[1]
  coef = lm_model$coefficients[2]
  out = data.table(intercept,coef)
  return(out)
}

linear_model_coef = train[,linear_coef(.SD),by=.(line)]

#8. Time Series prediction
ses_predn = function(singleLine){
  fcast <- holt(singleLine$ats,h=8)
  out = data.table(Period = seq(1,8), ts_predn = as.numeric(fcast$mean))
  return(out)
}

ts_outcome = train[,ses_predn(.SD),by=.(line)]

#9. Comparison
test = merge(test,most_likely_outcome)
test[,mle_abs_dev := abs(ats - mle_predn)]

test = merge(test,ma_predn)
test[,ma_abs_dev := abs(ats - ma_predn)]

test = merge(test,linear_model_coef)
test[,lm_predn := coef*scheduled_production_in_ea + intercept]
test[,lm_predn := ifelse(lm_predn>100,100,lm_predn)]
test[,lm_abs_dev := abs(ats - lm_predn)]

test = merge(test,ts_outcome,by=c('line','Period'))
test[,ts_abs_dev := abs(ats - ts_predn)]

test_avg_error = test[,.(mle_avg_error = mean(mle_abs_dev), ma_avg_error = mean(ma_abs_dev), 
                         lm_avg_error = mean(lm_abs_dev), ts_avg_error = mean(ts_abs_dev)),by=.(line)]

test_avg_error[,Best_method := colnames(test_avg_error[,.(mle_avg_error,ma_avg_error,lm_avg_error)])[apply(test_avg_error[,.(mle_avg_error,ma_avg_error,lm_avg_error)],1,which.min)]]
test_avg_error[,Best_method_error := pmin(mle_avg_error,ma_avg_error,lm_avg_error)]

test = merge(test,test_avg_error)

test = test[,.(line,date,ats,scheduled_production_in_ea,actual_production_in_ea,
               mle_predn,mle_abs_dev,ma_predn,ma_abs_dev,lm_predn,lm_abs_dev,ts_predn,ts_abs_dev,
               mle_avg_error,ma_avg_error,lm_avg_error,ts_avg_error,Best_method,Best_method_error)]



#10. Merge train and test
combined = rbind(train,test,fill=T)
combined = combined[order(line, date)]


#write.csv(combined,paste(data_path,data_folder,'output','line_level_comparison_v2.csv',sep='/'),row.names = F,na='')









