import sys
import traceback
import pandas as pd
from src.utility.LoggerConfig import Logger
from datetime import date, datetime, timedelta
from src.utility.LoggerConfig import Logger

class DataFormat:
    def __init__(self,job_id,logsPath,dc_forecast_op,mars_fcst_accuracy,mars_actual_sales,cortex_date_ip):
        '''
        Parameters
        ----------
        job_id : string
            Unique Job ID for each run
        logsPath : string
            Path where logs are written 
        dc_forecast_op : pandas dataframe
            Time series output from CORTEX at DC level (Sales Qty)
        prodn_forecast_op : pandas dataframe
            Time series output from CORTEX at Production level (ATS)

        Returns
        -------
        dc_final_forecast : pandas dataframe
            Time series output in a required format at DC level
        prodn_final_forecast : pandas dataframe
            Time series output in a required format at Production level
        '''
        self.job_id = job_id
        self.logsPath = logsPath
        self.dc_forecast_op = dc_forecast_op
        #self.prodn_forecast_op = prodn_forecast_op
        #self.line_maping = line_maping
        #self.ats_predn = ats_predn
        self.mars_fcst_accuracy = mars_fcst_accuracy
        self.mars_actual_sales = mars_actual_sales
        self.cortex_date_ip = cortex_date_ip
        
        try:
            self.reevaluate_error_metric()
            self.cortex_yearweek_bug_workaround()
            self.cortex_dc_forecast = self.format_dc_forecast()
            #self.cortex_prodn_forecast = self.format_prodn_forecast()
            self.dc_final_forecast = self.select_best_dc_forecast()
            #self.prodn_final_forecast = self.select_best_prodn_forecast()
            
        except Exception as e:
            Logger(job_id,logsPath).logr.error("Data Formatting Issue: {}".format(e))
            print(traceback.print_exc())
            sys.exit()
            
    #############################################################################        
    
    #1. Main functions go here
    def reevaluate_error_metric(self):
        holdOut = self.cortex_date_ip.loc[self.cortex_date_ip['Type'] == 'HoldOut','YearWeek'].iloc[0]
        lastDate = self.cortex_date_ip.loc[self.cortex_date_ip['Type'] == 'LastDate','YearWeek'].iloc[0]
        # Find accuracy
        self.dc_forecast_op['actual_date_value'] = self.dc_forecast_op['actual_date_value'].astype(int)
        cortex_test_period_predn = self.dc_forecast_op.loc[(self.dc_forecast_op['actual_date_value'] > holdOut) & (self.dc_forecast_op['actual_date_value'] <= lastDate),
                                                  ['grain-1','grain-2','actual_date_value','ranking_mode_forecast_qty']].fillna(0)
        cortex_test_period_predn['grain-1'] = cortex_test_period_predn['grain-1'].astype(float).astype(int).astype(str)
        cortex_fcst_accuracy = cortex_test_period_predn.merge(self.mars_actual_sales,left_on = ['grain-1','grain-2','actual_date_value'], right_on = ['dfu','location','YearWeek'])
        cortex_fcst_accuracy['Abs_error'] = abs(cortex_fcst_accuracy.ranking_mode_forecast_qty - cortex_fcst_accuracy.actuals)
        cortex_fcst_accuracy = cortex_fcst_accuracy.groupby(['dfu','location']).agg(ranking_metric_value = ('Abs_error','mean')).reset_index()
        # Update the accuracy metric
        colsToKeep = self.dc_forecast_op.columns
        self.dc_forecast_op['dfu'] = self.dc_forecast_op['grain-1'].astype(float).astype(int).astype(str)
        self.dc_forecast_op['location'] = self.dc_forecast_op['grain-2']
        self.dc_forecast_op.drop(columns = ['ranking_metric_value'],inplace=True)
        self.dc_forecast_op = self.dc_forecast_op.merge(cortex_fcst_accuracy,on = ['dfu','location'])
        return self.dc_forecast_op[colsToKeep]
    
    def cortex_yearweek_bug_workaround(self):
        self.dc_forecast_op['actual_date_value'] = self.dc_forecast_op['actual_date_value'].apply(self.do_yearweek_workaround)
        #self.prodn_forecast_op['actual_date_value'] = self.prodn_forecast_op['actual_date_value'].apply(self.do_yearweek_workaround)
        return 
    
    def format_dc_forecast(self):
        final_forecast_op = self.discard_exponential_forecast(self.dc_forecast_op)
        final_forecast_op = self.keep_required_cols(final_forecast_op)
        final_forecast_op = self.convert_column_dtype(final_forecast_op)
        final_forecast_op = self.keep_future_weeks(final_forecast_op)
        final_forecast_op = self.create_future_week(final_forecast_op)
        final_forecast_op = self.cortex_bug_dual_op_correction(final_forecast_op)
        #final_forecast_op = self.cortex_bug_week_correction(final_forecast_op)
        final_forecast_op = self.dc_forecast_col_formating(final_forecast_op)
        final_forecast_op['DFU'] = final_forecast_op['DFU'].astype(float).astype(int).astype(str)
        return final_forecast_op
    
    def format_prodn_forecast(self):
        final_forecast_op = self.keep_required_cols(self.prodn_forecast_op)
        final_forecast_op = self.convert_column_dtype(final_forecast_op)
        final_forecast_op = self.keep_future_weeks(final_forecast_op)
        final_forecast_op = self.create_future_week(final_forecast_op)
        final_forecast_op = self.cortex_bug_dual_op_correction(final_forecast_op)
        #final_forecast_op = self.cortex_bug_week_correction(final_forecast_op)
        final_forecast_op = self.convert_to_dfu_location(final_forecast_op)
        final_forecast_op = self.prodn_forecast_col_formating(final_forecast_op)
        final_forecast_op = self.cap_ats_values(final_forecast_op)
        return final_forecast_op
    
    def select_best_dc_forecast(self):
        dc_final_forecast = self.cortex_dc_forecast.merge(self.mars_fcst_accuracy, left_on =['DFU','Location'],
                                      right_on=['dfu','location'], how = 'left')
        # Keep grains if cortex forecast error metric is less than Mars forecast error metric
        dc_final_forecast['Aera_Wins'] = dc_final_forecast['Forecast Model Error'] < dc_final_forecast['Mean_Abs_Dev']
        self.log_improvement(dc_final_forecast)
        dc_final_forecast = dc_final_forecast[dc_final_forecast['Aera_Wins'] == True]
        dc_final_forecast = dc_final_forecast[['DFU','Location','DS Run Date','Forecast Week','Forecast DS model','Forecast Model Error','Cortex Future Forecast (Eaches)','Cortex Min Forecast (Eaches) - 95% CI','Cortex Max Forecast (Eaches) - 95% CI']]
        return dc_final_forecast
    
    def select_best_prodn_forecast(self):
        most_likely_ats = self.ats_predn['most_likely_predn']
        mars_ats = self.ats_predn['mars_predn']
        linreg_ats = self.ats_predn['linreg_predn']
        moving_avg_ats = self.ats_predn['moving_avg_predn']
        #avg_predn_dfu_level = self.ats_predn['avg_predn_dfu_level']
        #cortex_ats = self.cortex_prodn_forecast
        # Concat
        all_methods_ats = pd.concat([most_likely_ats,mars_ats,linreg_ats,moving_avg_ats]).reset_index(drop=True)
        all_methods_ats['DS Run Date'] = pd.to_datetime(all_methods_ats['DS Run Date'],format='%Y-%m-%d')
        all_methods_ats['ATS Week'] = pd.to_datetime(all_methods_ats['ATS Week'],format='%Y-%m-%d')
        # Best ATS model
        best_ats = all_methods_ats.loc[all_methods_ats.groupby(['DFU','Location','ATS Week'])['ATS Model Error'].idxmin()]
        return best_ats
    
    #############################################################################        
    
    #############################################################################        
    #2. Support functions go here
    
    def discard_exponential_forecast(self,data):
        # Max sales historically        
        max_sales_in_history = data.groupby(['grain-1','grain-2']).agg(max_sales_qty = ('sales_quantity','max')).reset_index()
        # Max forecast in future
        lastDate = self.cortex_date_ip.loc[self.cortex_date_ip['Type'] == 'LastDate','YearWeek'].iloc[0]
        forecast = data[data['actual_date_value'] >= lastDate]
        max_sales_in_forecast = forecast.groupby(['grain-1','grain-2']).agg(max_forecast_qty = ('forecast_quantity','max')).reset_index()        
        # Discard grains whose max_sales_history/max_forecast_future is higher than 2 --> exponential forecast
        max_forecast_to_max_history_idx = max_sales_in_history.merge(max_sales_in_forecast,on=['grain-1','grain-2'])
        max_forecast_to_max_history_idx['Max_forecast_to_max_history'] = max_forecast_to_max_history_idx['max_forecast_qty']/max_forecast_to_max_history_idx['max_sales_qty']
        max_forecast_to_max_history_idx['Exponential_Forecast_Flag'] = max_forecast_to_max_history_idx['Max_forecast_to_max_history'].apply(lambda x: 1 if x > 2 else 0) 
        dc_forecast = data.merge(max_forecast_to_max_history_idx,on=['grain-1','grain-2'])
        dc_forecast = dc_forecast[dc_forecast['Exponential_Forecast_Flag'] == 0]
        # Log
        grains_dropped_due_to_expo_forecast = max_forecast_to_max_history_idx['Exponential_Forecast_Flag'].sum()
        Logger(self.job_id,self.logsPath).logr.info("Data post-processing - Dropped {} grains due to exponential forecast".format(grains_dropped_due_to_expo_forecast))
        return dc_forecast
    
    def keep_required_cols(self,data):
        data = data[['grain-1','grain-2','reporting_date','actual_date_value','forecast_algorithm','ranking_metric_value','forecast_quantity']]
        return data[~data['ranking_metric_value'].isna()]
    
    def convert_column_dtype(self,data):
        data['reporting_date'] = pd.to_datetime(data['reporting_date'],format='%Y-%m-%d', errors='ignore')
        data['actual_date_value'] = data['actual_date_value'].astype(int)
        return data
    
    def keep_future_weeks(self,data):
        last_training_week = self.get_last_training_week()
        return data[data['actual_date_value'] > last_training_week]
    
    def create_future_week(self,data):
        data['actual_date_value'] = data['actual_date_value'].apply(lambda d: datetime.strptime(str(d)+'1', '%Y%W%w') - timedelta(days=1))
        return data
    
    def cortex_bug_dual_op_correction(self,data):
        # Robust code - to be done later
        select_first_algo = data.groupby(['grain-1','grain-2'])['forecast_algorithm'].first().reset_index()
        data = select_first_algo.merge(data,how='inner')
        return data
    
    def cortex_bug_week_correction(self,data):
        # Robust code - to be done later
        data = data.sort_values(by=['grain-1','grain-2','actual_date_value'])
        unique_dates = pd.Series(data['actual_date_value'].unique())
        all_group = []
        for name,group in data.groupby(['grain-1','grain-2']):
            group = group[:-1].reset_index(drop=True)
            group.loc[:,'actual_date_value'] = unique_dates
            all_group.append(group)
        return pd.concat(all_group,ignore_index=True)

    def dc_forecast_col_formating(self,data):
        data.columns = ['DFU','Location','Forecast DS model','DS Run Date','Forecast Week','Forecast Model Error','Cortex Future Forecast (Eaches)']
        data = data[['DFU','Location','DS Run Date','Forecast Week','Forecast DS model','Forecast Model Error','Cortex Future Forecast (Eaches)']]
        data['Cortex Min Forecast (Eaches) - 95% CI'] = data['Cortex Future Forecast (Eaches)']	
        data['Cortex Max Forecast (Eaches) - 95% CI'] = data['Cortex Future Forecast (Eaches)']	
        data['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        return data
    
    def convert_date_to_datetime(self,dateObj):
         return datetime(dateObj.year, dateObj.month, dateObj.day)
     
    def get_previous_week_date(self):
        today = date.today()
        offset = (today.weekday() - 6) % 7 #Sunday -> 6
        last_sunday = today - timedelta(days=offset)
        previous_week_start_date = last_sunday - timedelta(days=7)
        previous_week_start_date = self.convert_date_to_datetime(previous_week_start_date)
        print(previous_week_start_date)
        return previous_week_start_date
    
    def get_year_week(self,dateSeries):
        yearSeries = dateSeries.apply(lambda x: x.strftime("%Y")).astype(str)
        weekSeries = dateSeries.apply(lambda x: x.strftime("%U")).astype(str)  #week starting Sunday - same as Mars
        yearWeek = yearSeries + weekSeries
        return yearWeek.astype(int)
    
    def get_last_training_week(self):
        previous_week_start_date = self.get_previous_week_date()
        last_training_yearweek = self.get_year_week(pd.Series(previous_week_start_date)).iloc[0]
        return last_training_yearweek
    
    
    def convert_to_dfu_location(self,data):
        dfu_location_forecast = self.line_maping.merge(data,left_on='line',right_on='grain-1',how='inner')
        dfu_location_forecast = dfu_location_forecast[['dfu','location','reporting_date','actual_date_value','forecast_algorithm','ranking_metric_value','forecast_quantity']]
        return dfu_location_forecast
    
    def prodn_forecast_col_formating(self,data):
        data.columns = ['DFU','Location','DS Run Date','ATS Week','ATS DS model','ATS Model Error','Cortex Future ATS']
        data['Cortex Min ATS - 95% CI'] = data['Cortex Future ATS']	
        data['Cortex Max ATS - 95% CI'] = data['Cortex Future ATS']	
        data['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        return data
    
    def cap_ats(self,ats):
        if ats > 100:
            return 100
        elif ats < 1:
            return 1
        else:
            return ats
    
    def cap_ats_values(self,data):
        data['Cortex Future ATS'] = data['Cortex Future ATS'].apply(self.cap_ats)
        data['Cortex Min ATS - 95% CI'] = data['Cortex Min ATS - 95% CI'].apply(self.cap_ats)
        data['Cortex Max ATS - 95% CI'] = data['Cortex Max ATS - 95% CI'].apply(self.cap_ats)
        return data
    
    def log_improvement(self,dc_final_forecast):
        data = dc_final_forecast[['dfu','location','Aera_Wins']].drop_duplicates()
        aera_wins = data['Aera_Wins'].sum()
        total_grains = len(data)
        percent_better = int(aera_wins*100/total_grains)
        Logger(self.job_id,self.logsPath).logr.info("Data post-processing - Aera DC forecast is better on {}/{} grains. Approximately, {} percent.".format(aera_wins,total_grains,percent_better))
        return
    
    def do_yearweek_workaround(self,yearweek):
        if yearweek == 202053:
            return 202101
        elif yearweek > 202053:
            return yearweek+1
        else:
            return yearweek

        
    
    
    
    
    
    
    
    

