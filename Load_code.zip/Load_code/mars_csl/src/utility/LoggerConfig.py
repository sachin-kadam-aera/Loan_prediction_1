import logging
import logging.config
import os
import os.path
from logging.handlers import TimedRotatingFileHandler
import numpy as np
import pandas as pd
"""
AIM: This config file sets the configuration for logger config.
Here we add:
1. format of message which we want in logs
2. Level of message, we set it to debug level meaning that we will get all the messages at and above debug level
3. Add the handlers, we have added 3 handlers:
  a. console (print logs on console which will be removed later
  b. file, add logs to a local file
"""
class Singleton(type):
    def __init__(cls,name,bases,dic):
        super(Singleton,cls).__init__(name,bases,dic)
        cls.instance=None
    def __call__(cls,*args,**kw):
        if cls.instance is None:
            cls.instance=super(Singleton,cls).__call__(*args,**kw)
        return cls.instance

class Logger(metaclass=Singleton):
    def __init__(self,job_id,logsPath):
        log_filename = 'log_file.csv'
        log_path = logsPath
        log_filepath = os.path.join(log_path,log_filename)
        if not os.path.isfile(log_filepath):
            #Initialize the Log File
            init_log_headers = pd.DataFrame(columns = ['Job_Id','Level','Timestamp',\
                                                        'File','Function','Line',\
                                                        'GIC','CPG','LC','Message'])
            init_log_headers.to_csv(log_filepath,index = False)
            os.chmod(log_filepath, 0o777)

        LOGGING_CONFIG = {
            'version': 1,
            'disable_existing_loggers': False,
            'formatters': {
                'standard': {
                    'format': '%(job_id)s,%(levelname)s,%(asctime)s,%(module)s,%(funcName)s(),%(lineno)d,%(gic)s,%(cpg)s,%(lc)s,%(message)s',
                    'datefmt' : '%Y/%m/%d %H:%M:%S'
                },
                'console_stan': {
                    'format': '%(levelname)s,%(asctime)s,%(message)s',
                    'datefmt' : '%Y/%m/%d %H:%M:%S'
                }
            },
            'handlers': {
                'console': {
                    'level': "INFO",
                    'formatter': "console_stan",
                    'class': 'logging.StreamHandler',
                },
                'file': {
                    'level': "INFO",
                    'formatter': "standard",
                    'class': 'logging.FileHandler',
                    'filename': log_filepath,
                    'mode': 'a',
                    'encoding' : None,
                    'delay' : False
                },

            },
            'loggers': {
                '': {
                    'handlers': ['file','console'],
                    'level': "INFO",
                    'propagate': False
                },
            },
        }

        # if run_env == "local":
        #     #LOGGING_CONFIG["loggers"]['']["handlers"]=['console', 'file']
        #     LOGGING_CONFIG["loggers"]['']["handlers"]=['console']

        logging.config.dictConfig(LOGGING_CONFIG)
        old_factory = logging.getLogRecordFactory()
        def record_factory(*args, **kwargs):
            record = old_factory(*args, **kwargs)
            record.job_id = job_id
            record.gic = ''
            record.cpg = ''
            record.lc = ''
            if(record.args):
                record.gic = record.args.get('gic','')
                record.cpg = record.args.get('cpg','')
                record.lc = record.args.get('lc','')
            return record
        logging.setLogRecordFactory(record_factory)


        self.logr = logging.getLogger('root')
        #self.logr = logging.LoggerAdapter(self.logr, extra)
        #handler = TimedRotatingFileHandler(log_filepath, when="midnight", interval=1)
        #handler.suffix = "%Y%m%d"
