import os
import pandas as pd
import requests

class utility:
    def __init__(self,data_path):
        self.path = data_path
    
    def get_data_path(self):
        #init_path = os.path.dirname(os.path.abspath(__file__))
        #data_path = os.path.join(init_path,'Data')
        data_path = self.path
        try:
            os.makedirs(data_path)
        except:
            pass
        return data_path
    
    def get_logs_path(self,job_id):
        data_path = self.get_data_path()
        logs_files_path = os.path.join(data_path,job_id,'logs')
        try:
            os.makedirs(logs_files_path)
        except:
            pass
        return logs_files_path
    
    def get_output_path(self,job_id):
        data_path = self.get_data_path()
        output_files_path = os.path.join(data_path,job_id,'output')
        #Create the output directory if necessary
        try:
            os.makedirs(output_files_path)
        except:
            pass
        return output_files_path
    
    def get_cortex_output_path(self,job_id):
        data_path = self.get_data_path()
        cortex_output_files_path = os.path.join(data_path,job_id,'cortex_output')
        #Create the output directory if necessary
        try:
            os.makedirs(cortex_output_files_path)
        except:
            pass
        return cortex_output_files_path
    
    def get_input_path(self,job_id):
        data_path = self.get_data_path()
        input_files_path = os.path.join(data_path,job_id,'input')
        try:
            os.makedirs(input_files_path)
        except:
            pass
        return input_files_path
    
    def create_job_directory(self,job_id):
        data_path = self.get_data_path()
        job_path = os.path.join(data_path,job_id)
        try:
            os.makedirs(job_path)
        except:
            pass
        return
    
    def fetch_records(self,envUrl,api_name,token,rowStart,pageSize,host):
        headers = {'Authorization':token,'Host':host}
        url = envUrl+api_name
        params={'rowStart':rowStart,'pageSize':pageSize}
        response = requests.get(url,headers=headers,params=params)
        if response.status_code == 200:
            return pd.DataFrame(response.json()['data'])
        else:
            return 'empty_chunk'
    
    def read_report(self,envUrl,api_name,token,pageSize,host):
        data_chunks = []
        for i in range(0,100000):
            print('Reading Chunk - '+str(i))
            rowStart = i*pageSize
            chunk = self.fetch_records(envUrl,api_name,token,rowStart,pageSize,host)
            if not isinstance(chunk,pd.DataFrame):
                print('No Data fetched from API')
                return 'empty_data'
            else:
                data_chunks.append(chunk)
                if len(chunk) < pageSize:
                    return pd.concat(data_chunks)

