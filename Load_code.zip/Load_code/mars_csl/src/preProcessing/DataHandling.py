import pandas as pd
import traceback
from src.utility.LoggerConfig import Logger
import sys
from datetime import date, datetime, timedelta
from scipy.stats import linregress
import numpy as np
import matplotlib.pyplot as plt
import os
from sklearn.neighbors import KernelDensity

class DataHandler:
    def __init__(self,job_id,logsPath,dc_forecast,dc_actuals,prodn_actuals):
        '''
        Parameters
        ----------
        job_id : string
            Unique Job ID for each run
        logsPath : string
            Path where logs are written 
        dc_forecast : pandas dataframe
            Sales quantity forecast at DFU-Location level
        dc_actuals : pandas dataframe
            Actual sales quantity and CSL at DFU-Location level
        prodn_actuals : pandas dataframe
            ATS and CSL at DFU Production level

        Returns
        -------
        cortex_ip : pandas dataframe
            Dataframe specifying hold-out,test and horizon date inputs for Cortex forecasting.
        bias_csl_corr : pandas dataframe
            Lagged bias v/s CSL correlation
        cortex_ip_sales_qty : pandas dataframe
            Sales Qty pre-processed data at DFU-DC level
        ats_csl_corr : pandas dataframe
            ATS v/s CSL correlation
        cortex_ip_ats : pandas dataframe
            ATS pre-processed data at DFU-Production level
        dfu_dc_data_summary : pandas dataframe
            Log file at DFU-DC level - summarises the missing snapshots
        dfu_prod_data_summary : pandas dataframe
            Log file at DFU-Production level - summarises the missing snapshots
        '''
        self.job_id = job_id
        self.logsPath = logsPath
        self.dc_forecast = dc_forecast
        self.dc_actuals = dc_actuals
        self.prodn_actuals = prodn_actuals
        self.dc_location_allowed = {'GB40','GB47','GB73'}
        self.test_weeks = 8
        self.horizon_weeks = 12
        
        try:
            self.pre_Processing()
            self.dc_summary = self.get_dfu_dc_data_summary()
            self.prodn_summary = self.get_dfu_prod_data_summary()
            self.make_data_continuous()
            self.bias_csl_corr = self.get_bias_csl_corr()
            self.cortex_dc_sales_ip = self.cortex_ip_sales_qty()
            self.ats_csl_corr = self.get_ats_csl_corr()
            self.ats_ip = self.get_cortex_ats_ip()
            self.line_maping = self.get_line_maping()
            self.ats_predn = self.run_ats_predn_methods() #dataframe
            self.cortex_yearweek_bug_workaround()
            
            # For accuracy comparison - Mars VS Aera
            self.forecast_snapshot = self.mars_forecast_snapshot()
            self.mars_forecast_accuracy = self.get_mars_forecast_accuracy_on_test_period()
            self.mars_actual_sales = self.get_mars_actual_sales()
            
        except Exception as e:
            Logger(job_id,logsPath).logr.error("Data Processing Issue: {}".format(e))
            print(traceback.print_exc())
            sys.exit()
    
    #############################################################################        
    #1. Main functions go here
    def pre_Processing(self):
        self.rename_column()
        self.convert_to_datetime()
        self.filter_unknown_data()
        self.future_prodn = self.get_scheduled_prodn_in_future()
        self.keep_historical_data()
        self.keep_top_dfus_data()
        self.get_cortex_date_input()
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('pre_Processing()'))
        return None
    
    def get_dfu_dc_data_summary(self):
        dc_forecast_summary = self.get_snapshot_summary(self.dc_forecast,['dfu','location'],'_forecast')
        dc_actuals_summary = self.get_snapshot_summary(self.dc_actuals,['dfu','location'],'_actuals')
        dc_summary = dc_forecast_summary.merge(dc_actuals_summary, on=['dfu','location'])
        dc_summary = dc_summary[['dfu','location','FirstSnapshot_forecast','LastSnapshot_forecast','NumberOfSnapshotsMissing_forecast','FirstSnapshot_actuals','LastSnapshot_actuals','NumberOfSnapshotsMissing_actuals']]
        dc_summary.columns = ['DFU','Location','First_Snapshot_Forecast','Last_Snapshot_Forecast','Num_of_Missing_Snapshots_Forecast','First_Snapshot_Actuals','Last_Snapshot_Actuals','Num_of_Missing_Snapshots_Actuals']
        dc_summary.fillna('NA',inplace=True)
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('get_dfu_dc_data_summary()'))
        return dc_summary
    
    def get_dfu_prod_data_summary(self):
        prodn_summary = self.get_snapshot_summary(self.prodn_actuals,['dfu','location'],'_prodn')
        prodn_summary = prodn_summary[['dfu','location','FirstSnapshot_prodn','LastSnapshot_prodn','NumberOfSnapshotsMissing_prodn']]
        prodn_summary.columns = ['DFU','Location','First_Snapshot_Production','Last_Snapshot_Production','Num_of_Missing_Snapshots_Production']
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('get_dfu_prod_data_summary()'))
        return prodn_summary
    
    def make_data_continuous(self):
        # DC Forecast
        forecast_with_all_lag = self.insert_missing_lag_forecast()
        self.dc_forecast_complete = self.insert_missing_time_periods_forecsat(forecast_with_all_lag)
        # DC Actuals
        self.dc_actuals_complete = self.insert_missing_time_periods_actuals(self.dc_actuals)
        # Prod Actuals
        #self.prodn_actuals_complete = self.insert_missing_time_periods_prodn(self.prodn_actuals)
        self.prodn_actuals_complete = self.prodn_actuals
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('make_data_continuous()'))
        return None
    
    def get_bias_csl_corr(self):
        # Calculating Bias for each lag
        bias_vs_csl_dc_level = self.dc_forecast_complete.merge(self.dc_actuals_complete,how='inner',on=['dfu','location','Week_Start_Date'])
        bias_vs_csl_dc_level = self.create_bias_cols(bias_vs_csl_dc_level)
        # Finding the most significant correlation
        corr_with_pvalue = bias_vs_csl_dc_level.groupby(['dfu','location']).apply(self.get_correlation_with_significance_level).reset_index()
        self.best_significant = corr_with_pvalue.groupby(['dfu','location']).apply(lambda x: x[x['P-Value'] == min(x['P-Value'])]).reset_index(drop = True)
        corr_bias_csl = self.format_correlation_table(corr_with_pvalue)
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('get_bias_csl_corr()'))
        return corr_bias_csl
    
    def cortex_ip_sales_qty(self):
        self.dc_actuals_complete['YearWeek'] = self.get_year_week(self.dc_actuals_complete['Week_Start_Date'])
        # Outlier Treatment - 2MAD / IQR
        self.dc_actuals_treated = self.dc_actuals_complete.groupby(['dfu','location']).apply(self.mad_outlier_treatment,'actuals').reset_index(drop=True)
        self.dc_actuals_treated = self.dc_actuals_treated.groupby(['dfu','location']).apply(self.iqr_outlier_treatment,'actuals').reset_index(drop=True)
        # Format - choosing 2MAD treated sales
        cortex_sales_ip = self.dc_actuals_treated[['Week_Start_Date','dfu','location','actuals_MAD','YearWeek']]
        cortex_sales_ip.columns = ['DD_STARTDATE','DD_DFU','DD_LOCATION','CT_SALES_HISTORY_EACHES','YearWeek']
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('cortex_ip_sales_qty()'))
        return cortex_sales_ip
    
    def get_ats_csl_corr(self):
        # Calculate ATS
        self.prodn_actuals_complete['ats'] = self.prodn_actuals_complete['actual_production_in_ea']*100/self.prodn_actuals_complete['scheduled_production_in_ea']
        # Remove rows with inf and nan
        self.prodn_actuals_complete = self.prodn_actuals_complete[~((self.prodn_actuals_complete['ats'].isnull()) | (np.isinf(self.prodn_actuals_complete['ats'])))]
        '''
        # replace Inf by 0 (case when actual != 0 but scheduled = 0)
        self.prodn_actuals_complete['ats'][np.isinf(self.prodn_actuals_complete['ats'])] = 0
        # replace NaN by latest available ATS 
        self.prodn_actuals_complete ['ats'] = self.prodn_actuals_complete.groupby(['dfu','location'])['ats'].fillna(method='ffill')
        self.prodn_actuals_complete ['ats'] = self.prodn_actuals_complete.groupby(['dfu','location'])['ats'].fillna(method='bfill')
        '''
        # Remove data before 31st Dec 2019 => incorrect data
        self.prodn_actuals_complete = self.prodn_actuals_complete[self.prodn_actuals_complete['Week_Start_Date'] >= datetime(2019, 12, 31)]
        '''
        # Outlier Treatment - 2MAD / IQR
        self.prodn_actuals_complete = self.prodn_actuals_complete.groupby(['dfu','location']).apply(self.mad_outlier_treatment,'ats').reset_index(drop=True)
        self.prodn_actuals_complete = self.prodn_actuals_complete.groupby(['dfu','location']).apply(self.iqr_outlier_treatment,'ats').reset_index(drop=True)
        '''
        # Get ATS-CSL Correlation
        self.ats_csl_corr_with_pvalue = self.prodn_actuals_complete.groupby(['dfu','location']).apply(self.get_ats_csl_correlation,'ats').reset_index()
        ats_csl_corr = self.format_ats_csl_corr_table()
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('get_ats_csl_corr()'))
        return ats_csl_corr
    
    def get_cortex_ats_ip(self):
        prodn_dfu_lvl = self.prodn_actuals_complete
        # Cap ATS
        prodn_dfu_lvl['ats'] = prodn_dfu_lvl['ats'].apply(self.cap_ats)
        prodn_dfu_lvl['scheduled_production_in_ea'] = prodn_dfu_lvl['actual_production_in_ea']*100/prodn_dfu_lvl['ats']
        # Don't consider ATS below 20
        prodn_dfu_lvl = prodn_dfu_lvl[prodn_dfu_lvl['ats'] > 20]
        
        # Line level ATS
        prodn_line_level = prodn_dfu_lvl.groupby(['line','Week_Start_Date']).agg(actual_production_in_ea = ('actual_production_in_ea','sum'),
                                                                            scheduled_production_in_ea = ('scheduled_production_in_ea','sum'),
                                                                            ats = ('ats','mean')).reset_index()        
        # Get in required format
        prodn_line_level['YearWeek'] = self.get_year_week(prodn_line_level['Week_Start_Date'])
        
        '''
        prodn_line_level_ip = prodn_line_level[['Week_Start_Date','line','line','actual_production_in_ea','scheduled_production_in_ea','ats','YearWeek']]
        prodn_line_level_ip.columns = ['DD_STARTDATE','DD_DFU','DD_LOCATION','CT_ACTUAL_PRODUCTION_EACHES','CT_SCHEDULED_PRODUCTION_EACHES','ATS','YearWeek']
        prodn_line_level_cortex_ip = prodn_line_level_ip
        
        #self.cap_ats_and_recalculate_scheduled_prodn()
        prodn_line_level = self.prodn_actuals_complete.groupby(['line','Week_Start_Date']).agg(actual_production_in_ea = ('actual_production_in_ea','sum'),
                                                                            scheduled_production_in_ea = ('scheduled_production_in_ea','sum')).reset_index()        
        # Calculate ATS
        prodn_line_level['ats'] = prodn_line_level['actual_production_in_ea']*100/prodn_line_level['scheduled_production_in_ea']        
        # replace Inf by 0 (case when actual != 0 but scheduled = 0)
        prodn_line_level['ats'][np.isinf(prodn_line_level['ats'])] = 0
        # replace NaN by latest available ATS 
        prodn_line_level['ats'] = prodn_line_level.groupby(['line'])['ats'].fillna(method='ffill')
        prodn_line_level['ats'] = prodn_line_level.groupby(['line'])['ats'].fillna(method='bfill')
        # cap ats
        prodn_line_level['ats'] = prodn_line_level['ats'].apply(self.cap_ats)
        prodn_line_level['scheduled_production_in_ea'] = prodn_line_level['actual_production_in_ea']*100/prodn_line_level['ats']
        
        prodn_line_level = prodn_line_level.groupby('line').apply(self.mad_outlier_treatment,'ats').reset_index(drop=True)
        prodn_line_level = prodn_line_level.groupby('line').apply(self.iqr_outlier_treatment,'ats').reset_index(drop=True)
        prodn_line_level['YearWeek'] = self.get_year_week(prodn_line_level['Week_Start_Date'])
        #prodn_line_level.to_csv(os.path.join(self.logsPath,'_line_level_ats_capped.csv'),index=False)
        
        # Get in required format
        prodn_line_level_ip = prodn_line_level[['Week_Start_Date','line','line','actual_production_in_ea','scheduled_production_in_ea','ats_IQR','YearWeek']]
        prodn_line_level_ip.columns = ['DD_STARTDATE','DD_DFU','DD_LOCATION','CT_ACTUAL_PRODUCTION_EACHES','CT_SCHEDULED_PRODUCTION_EACHES','ATS','YearWeek']
        
        prodn_line_level_cortex_ip = prodn_line_level[['Week_Start_Date','line','line','actual_production_in_ea','scheduled_production_in_ea','ats_IQR','YearWeek']]
        prodn_line_level_cortex_ip.columns = ['DD_STARTDATE','DD_DFU','DD_LOCATION','CT_ACTUAL_PRODUCTION_EACHES','CT_SCHEDULED_PRODUCTION_EACHES','ATS','YearWeek']
        '''
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('get_cortex_ats_ip()'))
        return (prodn_line_level)
    
    def get_line_maping(self):
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('get_line_maping()'))
        return self.prodn_actuals[['dfu','location','line']].drop_duplicates()
    
    def run_ats_predn_methods(self):   
        line_level_ats = self.ats_ip
        line_level_ats = line_level_ats.sort_values(by=['line','Week_Start_Date'])
        
        # Keep only those lines where number of data points are more than 16
        num_of_data_pts = line_level_ats.groupby('line').agg(Data_pts = ('Week_Start_Date','count')).reset_index()
        line_level_ats = line_level_ats.merge(num_of_data_pts,on='line')
        line_level_ats_pts_less_than_16 = line_level_ats[line_level_ats['Data_pts'] <= 16]
        line_level_ats = line_level_ats[line_level_ats['Data_pts'] > 16]
        line_level_ats = line_level_ats.reset_index()
        
        # Prediction when data points are less than 16
        line_level_ats_pts_less_than_16 = line_level_ats_pts_less_than_16.groupby('line').tail(8).reset_index()
        ats_predn_new_lines = line_level_ats_pts_less_than_16.groupby('line').agg(Prediction = ('ats','mean')).reset_index()
        ats_predn_new_lines = ats_predn_new_lines.merge(self.future_prodn,on='line')
        ats_predn_new_lines['Method'] = '8 period moving average'
        ats_predn_new_lines['Mean_Abs_Dev'] = 0
        
        # Split into train and test
        test = line_level_ats.groupby('line').tail(8)
        train = line_level_ats[~(line_level_ats.index.isin(test.index))]
        
        # 8-period moving average
        latest_8_period_training = train.groupby('line').tail(8)
        ma_train_predn = latest_8_period_training.groupby('line').agg(Mvg_avg_predn = ('ats','mean')).reset_index()
        test_predn = test.merge(ma_train_predn,on=['line'])
        test_predn['Abs_Dev'] = abs(test_predn['ats'] - test_predn['Mvg_avg_predn'])
        ma_test_predn = test_predn.groupby('line').agg(Prediction = ('ats','mean'),
                                                       Mean_Abs_Dev = ('Abs_Dev','mean')).reset_index()
        ma_future_predns = self.future_prodn.merge(ma_test_predn,on='line')
        ma_future_predns['Method'] = '8 period moving average'
        
        # Most Likely outcome based on training period
        mle_predn = train.groupby('line').agg(Mle_predn = ('ats',self.get_max_density_outcome)).reset_index()
        test_predn = test.merge(mle_predn,on=['line'])
        test_predn['Abs_Dev'] = abs(test_predn['ats'] - test_predn['Mle_predn'])
        mle_test_predn = test_predn.groupby('line').agg(Prediction = ('Mle_predn','mean'),
                                                       Mean_Abs_Dev = ('Abs_Dev','mean')).reset_index()
        mle_future_predns = self.future_prodn.merge(mle_test_predn,on='line')
        mle_future_predns['Method'] = 'Most probable outcome'
        
        # Regression prediction
        reg_parameters = train.groupby('line').apply(self.run_linreg_on_ats).reset_index()
        test_predn = test.merge(reg_parameters,on=['line'])
        test_predn['Predicted_ATS'] = test_predn['Slope']*test_predn['scheduled_production_in_ea'] + test_predn['Intercept']
        test_predn['Abs_Dev'] = abs(test_predn['ats'] - test_predn['Predicted_ATS'])
        test_accuracy = test_predn.groupby(['line']).agg(Mean_Abs_Dev = ('Abs_Dev','mean')).reset_index()
        reg_parameters = reg_parameters.merge(test_accuracy)
        linreg_predn = self.future_prodn.merge(reg_parameters[['line','Slope','Intercept','Mean_Abs_Dev']],left_on='line',right_on='line')
        linreg_predn['Prediction'] = linreg_predn['scheduled_production_in_ea']*linreg_predn['Slope'] + linreg_predn['Intercept']
        linreg_predn['Method'] = 'Linear regression'
        linreg_predn = linreg_predn[['line','Week_Start_Date','scheduled_production_in_ea',
                                     'Prediction','Mean_Abs_Dev','Method']]
        
        # Comparison
        all_methods = pd.concat([ma_future_predns,mle_future_predns,linreg_predn]).reset_index(drop=True)
        best_ats = all_methods.loc[all_methods.groupby(['line','Week_Start_Date'])['Mean_Abs_Dev'].idxmin()]
        best_ats = pd.concat([best_ats,ats_predn_new_lines])
        final_ats_predn = self.line_maping.merge(best_ats,on='line').reset_index(drop=True)
        final_ats_predn['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        final_ats_predn = final_ats_predn[['dfu','location','DS Run Date','Week_Start_Date','Method','Mean_Abs_Dev','Prediction']]
        final_ats_predn.columns = ['DFU','Location','DS Run Date','ATS Week','ATS DS model','ATS Model Error','Cortex Future ATS']
        final_ats_predn['Cortex Min ATS - 95% CI'] = final_ats_predn['Cortex Future ATS']
        final_ats_predn['Cortex Max ATS - 95% CI'] = final_ats_predn['Cortex Future ATS']
        
        final_ats_predn['DS Run Date'] = pd.to_datetime(final_ats_predn['DS Run Date'],format='%Y-%m-%d')
        final_ats_predn['ATS Week'] = pd.to_datetime(final_ats_predn['ATS Week'],format='%Y-%m-%d')

        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('run_ats_predn_methods()'))
        return final_ats_predn
    
    def mars_forecast_snapshot(self):
        snapshotDate = self.cortex_ip[self.cortex_ip['Type'] == 'HoldOut']['Date'].iloc[0] + timedelta(days = 7)
        forecast_snapshot = self.dc_forecast_complete[self.dc_forecast_complete['Week_Start_Date'] == snapshotDate]
        forecast_snapshot = forecast_snapshot[['dfu','location'] + ['Lag_'+str(x) for x in range(self.test_weeks)]]
        forecast_snapshot = pd.melt(forecast_snapshot,id_vars =['dfu','location'],var_name='lag',value_name='mars_forecast')
        forecast_snapshot['lag_int'] = forecast_snapshot['lag'].apply(lambda x : x[4:]).astype(int)
        forecast_snapshot['forecast_week'] = forecast_snapshot['lag_int'].apply(lambda x: snapshotDate + timedelta(days=7*x))
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('mars_forecast_snapshot()'))
        return forecast_snapshot[['dfu','location','forecast_week','mars_forecast']]
    
    def get_mars_forecast_accuracy_on_test_period(self):
        mars_fcst_acc_on_test_period = self.forecast_snapshot.merge(self.dc_actuals, right_on = ['dfu','location','Week_Start_Date'],left_on = ['dfu','location','forecast_week'])
        mars_fcst_acc_on_test_period['Abs_Deviation'] = abs(mars_fcst_acc_on_test_period['actuals'] - mars_fcst_acc_on_test_period['mars_forecast'])
        mars_fcst_acc_on_test_period = mars_fcst_acc_on_test_period.groupby(['dfu','location']).agg(Mean_Abs_Dev = ('Abs_Deviation','mean')).reset_index()
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - {} executed".format('get_mars_forecast_accuracy_on_test_period()'))
        return mars_fcst_acc_on_test_period
    
    def cortex_yearweek_bug_workaround(self):
        self.cortex_ip['YearWeek'] = self.cortex_ip['YearWeek'].apply(self.do_yearweek_workaround)
        self.cortex_dc_sales_ip['YearWeek'] = self.cortex_dc_sales_ip['YearWeek'].apply(self.do_yearweek_workaround)
        #self.cortex_ats_ip['YearWeek'] = self.cortex_ats_ip['YearWeek'].apply(self.do_yearweek_workaround)
        self.dc_actuals_treated['YearWeek'] = self.dc_actuals_treated['YearWeek'].apply(self.do_yearweek_workaround)
        return
    
    def get_mars_actual_sales(self):
        historical_sales = self.dc_actuals_treated[['dfu','location','YearWeek','actuals']]
        return historical_sales
        
    #############################################################################        
    
    #############################################################################        
    #2. Support functions go here
    def glimpse(self,df):    
        Data_Type = df.dtypes
        Missing_Values = df.isnull().sum()
        Unique_Values = df.nunique()    
        df_out = pd.concat([Data_Type,Missing_Values,Unique_Values],axis = 1)
        df_out.columns = ['Data Type','Missing Values','Unique Values']
        return df_out
    
    def rename_column(self):
        self.dc_forecast.rename(columns = {'forecast_week':'Week_Start_Date'}, inplace = True)
        self.dc_actuals.rename(columns = {'week':'Week_Start_Date'}, inplace = True)
        self.prodn_actuals.rename(columns = {'date':'Week_Start_Date'}, inplace = True)
        print('Data pre-processing - Column rename finished')
        return
    
    def convert_to_datetime(self):
        self.dc_forecast['Week_Start_Date'] = pd.to_datetime(self.dc_forecast['Week_Start_Date'],format='%Y-%m-%d')
        self.dc_actuals['Week_Start_Date'] = pd.to_datetime(self.dc_actuals['Week_Start_Date'],format='%Y-%m-%d')
        self.prodn_actuals['Week_Start_Date'] = pd.to_datetime(self.prodn_actuals['Week_Start_Date'],format='%Y-%m-%d')
        print('Data pre-processing - Conversion to datetime finished')
        return 
    
    def filter_unknown_data(self):
        self.dc_forecast = self.dc_forecast[~((self.dc_forecast['dfu'] == "Not Set") | (self.dc_forecast['location'] == "not_available"))]
        self.dc_actuals = self.dc_actuals[~((self.dc_actuals['dfu'] == "Not Set") | (self.dc_actuals['location'] == "not_available"))]
        self.prodn_actuals = self.prodn_actuals[~((self.prodn_actuals['dfu'] == "Not Set") | (self.prodn_actuals['location'] == "not_available") | (self.prodn_actuals['line'] == "Not Set"))]
        self.dc_actuals = self.dc_actuals[self.dc_actuals['location'].isin(self.dc_location_allowed)]
        return
    
    def convert_date_to_datetime(self,dateObj):
         return datetime(dateObj.year, dateObj.month, dateObj.day)
    
    def get_previous_week_date(self):
        today = date.today()
        offset = (today.weekday() - 6) % 7 #Sunday -> 6
        last_sunday = today - timedelta(days=offset)
        previous_week_start_date = last_sunday - timedelta(days=7)
        previous_week_start_date = self.convert_date_to_datetime(previous_week_start_date)
        print(previous_week_start_date)
        return previous_week_start_date
    
    def get_cortex_date_input(self):
        last_date = self.get_previous_week_date()
        holdout_date = last_date - timedelta(days=7*self.test_weeks) #8 weeks test data
        horizon_date = last_date + timedelta(days=7*self.horizon_weeks) #12 weeks in future
        date_series = pd.Series([holdout_date,last_date,horizon_date])
        self.cortex_ip = pd.DataFrame({'Type': ['HoldOut','LastDate','HorizonDate'],
                                       'YearWeek': list(self.get_year_week(date_series)),
                                       'Date':[holdout_date,last_date,horizon_date]})
        print('Data pre-processing - Cortex date input created')        
        return None
    
    def get_year_week(self,dateSeries):
        yearSeries = dateSeries.apply(lambda x: x.strftime("%Y")).astype(str)
        weekSeries = dateSeries.apply(lambda x: x.strftime("%U")).astype(str)  #week starting Sunday - same as Mars
        yearWeek = yearSeries + weekSeries
        return yearWeek.astype(int)
    
    def keep_historical_data(self):
        week_minus_one = self.get_previous_week_date()
        print('Data pre-processing - Week Minus One -> {}'.format(week_minus_one))
        print('Data pre-processing - Latest Week DC Forecast -> {}'.format(max(self.dc_forecast['Week_Start_Date'])))
        print('Data pre-processing - Latest Week DC Actuals -> {}'.format(max(self.dc_actuals['Week_Start_Date'])))
        print('Data pre-processing - Latest Week Prodn Actuals -> {}'.format(max(self.prodn_actuals['Week_Start_Date'])))

        self.dc_forecast = self.dc_forecast[self.dc_forecast['Week_Start_Date'] <= week_minus_one]
        self.dc_actuals = self.dc_actuals[self.dc_actuals['Week_Start_Date'] <= week_minus_one]
        self.prodn_actuals = self.prodn_actuals[self.prodn_actuals['Week_Start_Date'] <= week_minus_one]
        print('Data pre-processing - Historical Weeks filter applied')
        return
    
    def get_top_dfu(self):
        '''
        Top DFU constitutes 90% volume share in past 1 year
        '''
        date_now = datetime.now()
        date_year_ago = date_now - timedelta(days = 365)
        cutOff = 90
        # Calculate market share in past 1 year
        lastOneYearActual = self.dc_actuals.loc[self.dc_actuals['Week_Start_Date'] >= date_year_ago]
        aggLastOneYear = lastOneYearActual.groupby(['dfu']).agg(PercentageShare=('actuals',lambda x: round(x.sum()*100/sum(lastOneYearActual['actuals']),2))).reset_index()
        aggLastOneYear = aggLastOneYear.sort_values(by=['PercentageShare'], ascending=False).reset_index(drop=True)
        aggLastOneYear['CumulativeShare'] = aggLastOneYear['PercentageShare'].cumsum()    
        dfu_with_90_per_share = list(aggLastOneYear['dfu'][aggLastOneYear['CumulativeShare'] <=cutOff])
        # Add top DFU info in Logger
        Logger(self.job_id,self.logsPath).logr.info("Data pre-processing - Top 10 DFU volume wise => {}".format('-'.join(dfu_with_90_per_share[0:10])))
        return dfu_with_90_per_share
    
    def keep_top_dfus_data(self):
        top_dfu = self.get_top_dfu()
        self.dc_forecast  = self.dc_forecast[self.dc_forecast['dfu'].isin(top_dfu)]
        self.dc_actuals  = self.dc_actuals[self.dc_actuals['dfu'].isin(top_dfu)]
        #self.prodn_actuals  = self.prodn_actuals[self.prodn_actuals['dfu'].isin(top_dfu)]
        #self.future_prodn = self.future_prodn[self.future_prodn['dfu'].isin(top_dfu)]
        print('Data pre-processing - Top DFU filter applied')
        return
    
    def get_missing_snapshots(self,single_grain,dfu_name,location_name,suffix):
        # Snapshots present
        snapshotsPresent = set(single_grain['Week_Start_Date'])
        numOfSnapshots = len(snapshotsPresent)
        firstSnapshotDate = min(snapshotsPresent)
        lastSnapshotDate = max(snapshotsPresent)
        # Find missing snapshots date
        all_snapshots = set(pd.date_range(start = firstSnapshotDate, end = lastSnapshotDate, freq = 'W'))
        missingSnapshots = all_snapshots - snapshotsPresent
        missingSnapshots = [x.strftime('%Y-%m-%d') for x in missingSnapshots]
        # Consolidate
        summary = {'dfu':dfu_name,'location':location_name,'NumOfSnapshot'+suffix:numOfSnapshots,
                   'FirstSnapshot'+suffix:firstSnapshotDate.strftime('%Y-%m-%d'),
                   'LastSnapshot'+suffix:lastSnapshotDate.strftime('%Y-%m-%d'),
                   'MissingSnapshot'+suffix:missingSnapshots,
                   'NumberOfSnapshotsMissing'+suffix:len(missingSnapshots)
                   }
        return summary
    
    def get_snapshot_summary(self,data,group,suffix):
        grain_summary = []
        grain_groups = data.groupby(group)
        for name,group in grain_groups:
            grain_summary.append(self.get_missing_snapshots(group,name[0],name[1],suffix))
        data_summary = pd.DataFrame(grain_summary)    
        #data_summary = data_summary[data_summary['NumberOfSnapshotsMissing'] != 0]
        return data_summary
        
    def insert_missing_lag_forecast(self):
        fpivot = self.dc_forecast.pivot(index = ['dfu','location','Week_Start_Date'],columns = 'lag', values='forecast_qty')
        fpivot = fpivot.fillna(method='ffill',axis=1)
        fpivot = fpivot.fillna(method='bfill',axis=1).reset_index()
        fmelt = pd.melt(fpivot,id_vars=['dfu','location','Week_Start_Date'],var_name='lag',value_name='forecast_qty')
        fmelt['lag_week_start_date'] = [x+timedelta(days=y*7) for x,y in zip(fmelt['Week_Start_Date'],fmelt['lag'])]
        return fmelt
    
    def insert_missing_time_periods_forecsat(self,forecast):
        forecast = forecast.sort_values(by=['lag'])
        forecast['lag'] = 'Lag_'+forecast['lag'].astype(int).astype(str)
        lagCols = list(forecast['lag'].unique())
        forecast = forecast.pivot(index = ['dfu','location','Week_Start_Date'],columns = ['lag'], values = 'forecast_qty').reset_index()
        # looping over each grain
        grain_groups = forecast.groupby(['dfu','location'])
        grain_complete = []
        for name,singleGrain in grain_groups:
            # Re-index - add all time periods between start and end date
            singleGrain = singleGrain.set_index('Week_Start_Date')
            idx = pd.date_range(start = min(singleGrain.index),end = max(singleGrain.index),freq='W')
            singleGrain = singleGrain.reindex(list(idx))
            # ffill
            singleGrain = singleGrain.fillna(method='ffill')
            grain_complete.append(singleGrain)
        # re-arrange cols
        forecast_complete = pd.concat(grain_complete).reset_index()
        return forecast_complete[['dfu','location','Week_Start_Date']+lagCols]
    
    def insert_missing_time_periods_actuals(self,actuals):
        # looping over each grain
        grain_groups = actuals.groupby(['dfu','location'])
        grain_complete = []
        for name,singleGrain in grain_groups:
            # Re-index - add all time periods between start and end date
            singleGrain = singleGrain.set_index('Week_Start_Date')
            idx = pd.date_range(start = min(singleGrain.index),end = max(singleGrain.index),freq='W')
            singleGrain = singleGrain.reindex(list(idx))
            # fill na
            singleGrain[['dfu','location']] = singleGrain[['dfu','location']].fillna(method='ffill')
            singleGrain['csl'] = singleGrain['csl'].fillna(100)
            singleGrain['actuals'] = singleGrain['actuals'].fillna(0)
            grain_complete.append(singleGrain)
        # re-arrange cols
        actuals_complete = pd.concat(grain_complete).reset_index()
        return actuals_complete[['dfu','location','Week_Start_Date','actuals','csl']]
    
    def insert_missing_time_periods_prodn(self,prodn):
        # looping over each grain
        grain_groups = prodn.groupby(['dfu','location','line'])
        grain_complete = []
        for name,singleGrain in grain_groups:
            # Re-index - add all time periods between start and end date
            singleGrain = singleGrain.set_index('Week_Start_Date')
            idx = pd.date_range(start = min(singleGrain.index),end = max(singleGrain.index),freq='W')
            singleGrain = singleGrain.reindex(list(idx))
            # fill na
            singleGrain[['dfu','location','line']] = singleGrain[['dfu','location','line']].fillna(method='ffill')
            singleGrain[['actual_production_in_ea','scheduled_production_in_ea']] = singleGrain[['actual_production_in_ea','scheduled_production_in_ea']].fillna(0)
            singleGrain[['csl','ats']] = singleGrain[['csl','ats']].fillna(method = "ffill")
            grain_complete.append(singleGrain)
        # re-arrange cols
        prodn_complete = pd.concat(grain_complete).reset_index()
        return prodn_complete[['dfu','location','line','Week_Start_Date','actual_production_in_ea','scheduled_production_in_ea','csl','ats']]
    
    def create_bias_cols(self,data):
        lagCols = data.columns[data.columns.str.contains('Lag_')]
        for column in lagCols:
            data['Bias_'+column] = (data[column] - data['actuals'])/data[column]
            #data['Bias_'+column] = (data[column] - data['CT_SALES_HISTORY_EACHES'])
        return data

    def get_correlation_with_significance_level(self,x):
        try:
            bias_cols = x.columns[x.columns.str.contains('Bias_Lag')]
            BiasLag = []
            Corr = []
            Pvalue =[]
            coef =[]
            n = []
            BiasMean = []
            for col in bias_cols:
                a = x[col][~x[col].isin([np.nan, np.inf, -np.inf])]
                b = x['csl'][~x[col].isin([np.nan, np.inf, -np.inf])]
                out = linregress(a,b)
                Corr.append(out.rvalue)
                Pvalue.append(out.pvalue)
                BiasLag.append(col)
                coef.append(out.slope)
                n.append(len(a))
                BiasMean.append(a.mean())
            corr_df = pd.DataFrame({'BiasCol':BiasLag,'Correlation':Corr,'P-Value':Pvalue,'NumOfPoints':n,'Coefficient':coef,'MeanBiasVal':BiasMean})
        except:
            corr_df = pd.DataFrame(columns = ['BiasCol','Correlation','P-Value','NumOfPoints','Coefficient','MeanBiasVal'])
        return corr_df

    def format_correlation_table(self,corr_with_pvalue):
        data = corr_with_pvalue[['dfu','location','BiasCol','Correlation']]
        data.loc[:,'BiasCol'] = 'Corr_'+data.loc[:,'BiasCol'] 
        data = data.pivot(index=['dfu','location'],columns='BiasCol',values='Correlation').reset_index()
        return data
    
    def mad_outlier_treatment(self,data,col):
        d = data.copy()
        # 2MAD method
        d['ShiftedQty'] = d[col].shift(1)
        d['RollingMedian'] = d['ShiftedQty'].transform(lambda x: x.rolling(6, 1).median())
        d['AbsDeviation'] = abs(d['RollingMedian'] - d[col])
        d['MAD'] = d['AbsDeviation'].median()
        d['OutlierFlag_2MAD'] = [1 if dev > 2*mad else 0 for dev,mad in zip(d['AbsDeviation'],d['MAD'])]
        d[col+'_MAD'] = [z if x==1 else y for x,y,z in zip(d['OutlierFlag_2MAD'],d[col],d['RollingMedian'])]
        d = d.drop(['ShiftedQty','RollingMedian','AbsDeviation','MAD','OutlierFlag_2MAD'],axis=1) 
        return d

    def iqr_outlier_treatment(self,data,col):
        d = data.copy()
        q1,q3 = np.percentile(d[col],[25,75])
        IQR = q3-q1
        lower_bound = q1 - (IQR*1.5)
        upper_bound = q3 + (IQR*1.5)
        d[col+'_IQR'] = d[col]
        d[col+'_IQR'] = [lower_bound if x < lower_bound else x for x in d[col]]
        #d[col+'_IQR'] = [upper_bound if x > upper_bound else x for x in d[col]]
        return d
    
    def recalculate_ats(self,row):
            return row['actual_production_in_ea']*100/row['scheduled_production_in_ea']
    
    def get_ats_csl_correlation(self,data,ats_col):
        try:
            ats = data[ats_col]
            csl = data['csl']
            csl = csl[~ats.isin([np.nan, np.inf, -np.inf])] # Remove unwanted values
            ats = ats[~ats.isin([np.nan, np.inf, -np.inf])] # Remove unwanted values
            out = linregress(ats,csl)
            corr_df = pd.DataFrame({'Correlation':[out.rvalue],'P-Value':[out.pvalue],'NumOfPoints':[len(ats)],'Coefficient':[out.slope]})
        except:
            corr_df = pd.DataFrame(columns = ['Correlation','P-Value','NumOfPoints','Coefficient'])
        return corr_df
    
    def format_ats_csl_corr_table(self):
        ats_csl_correlation = self.ats_csl_corr_with_pvalue[['dfu','location','Correlation']]
        ats_csl_correlation.columns = ['DFU','Location','Corr_ATS']
        return ats_csl_correlation
    
    def get_max_density_outcome(self,series):
        #sns.distplot(data, hist=False)
        #plt.show()
        X = series.to_numpy().reshape(-1,1)
        kde = KernelDensity(kernel='gaussian', bandwidth=1).fit(X)
        X_plot = np.linspace(-100, 300, 1000)[:, np.newaxis]    
        log_dens = np.exp(kde.score_samples(X_plot))
        max_density_val = X_plot[np.argmax(log_dens),0]
        return max_density_val
    
    def get_most_probable_ats(self):
        #d1 = g.get_group(('105230','NL01')) #74.69
        most_likely_outcome = self.prodn_actuals_complete.groupby(['dfu','location']).agg(Most_Probable_Outcome = ('ats_IQR',self.get_max_density_outcome)).reset_index()
        return most_likely_outcome
    
    def cap_ats_and_recalculate_scheduled_prodn(self):
        self.prodn_actuals_complete['ats_capped'] = self.prodn_actuals_complete['ats_MAD'].apply(self.cap_ats)
        self.prodn_actuals_complete['scheduled_production_in_ea'] = self.prodn_actuals_complete['actual_production_in_ea']*100/self.prodn_actuals_complete['ats_capped']
        return
        
    def cap_ats(self,ats):
        if ats > 100:
            return 100
        elif ats < 1:
            return 1
        else:
            return ats
        
    def run_linreg_on_ats(self,train):
        slope, intercept, r_value, p_value, std_err = linregress(train['scheduled_production_in_ea'], train['ats'])
        op = pd.DataFrame({'Slope':slope,'Intercept':intercept}, index=[0])
        return op
    
    def get_naive_method_predn(self,train,test,horizon_period):
        ## Naive method - most probable outcome
        ats_most_likely_outcome = train.groupby(['DD_DFU','DD_LOCATION']).agg(Most_Probable_Outcome = ('ATS',self.get_max_density_outcome)).reset_index()
        naive_method_accuracy = test.merge(ats_most_likely_outcome,on = ['DD_DFU','DD_LOCATION'])
        naive_method_accuracy['Abs_Deviation'] = abs(naive_method_accuracy['ATS'] - naive_method_accuracy['Most_Probable_Outcome'])
        naive_method_accuracy = naive_method_accuracy.groupby(['DD_DFU','DD_LOCATION']).agg(Mean_Abs_Deviation = ('Abs_Deviation','mean')).reset_index()
        # Naive method prediction - Cross Join
        horizon_df = pd.DataFrame({'ATS Week':horizon_period,'Key':0})
        ats_most_likely_outcome['Key'] = 0
        naive_method_prediction = horizon_df.merge(ats_most_likely_outcome)
        naive_method_prediction = naive_method_prediction.merge(naive_method_accuracy)
        return naive_method_prediction
    
    def get_moving_average_predn(self,train,test,horizon_period,holdout_date):
        # Moving Avg prediction using 8MA - training
        last_8_ats = train[train['DD_STARTDATE'] > holdout_date - timedelta(days=7*8)]
        #last_8_ats = train.groupby(['DD_DFU','DD_LOCATION']).tail(8)
        last_8_ats = last_8_ats.groupby(['DD_DFU','DD_LOCATION']).agg(Moving_avg_predn = ('ATS','mean')).reset_index()
        moving_avg_accuracy = test.merge(last_8_ats,on = ['DD_DFU','DD_LOCATION'])
        moving_avg_accuracy['Abs_Deviation'] = abs(moving_avg_accuracy['ATS'] - moving_avg_accuracy['Moving_avg_predn'])
        moving_avg_accuracy = moving_avg_accuracy.groupby(['DD_DFU','DD_LOCATION']).agg(Mean_Abs_Deviation = ('Abs_Deviation','mean')).reset_index()
        # Moving Avg prediction using 8MA - testing
        last_8_ats = test.groupby(['DD_DFU','DD_LOCATION']).tail(8)
        last_8_ats = last_8_ats.groupby(['DD_DFU','DD_LOCATION']).agg(Moving_avg_predn = ('ATS','mean')).reset_index()
        # Moving average prediction - Cross Join
        horizon_df = pd.DataFrame({'ATS Week':horizon_period,'Key':0})
        last_8_ats['Key'] = 0
        moving_avg_predn = horizon_df.merge(last_8_ats)
        moving_avg_predn = moving_avg_predn.merge(moving_avg_accuracy)
        return moving_avg_predn
    
    def get_average_predn_at_dfu_level(self,test,holdout_date,horizon_period):
        ats_dfu_level = self.prodn_actuals_complete
        ats_dfu_level['ats'] = ats_dfu_level['ats'].apply(self.cap_ats)
        ats_dfu_level = ats_dfu_level[ats_dfu_level['ats'] > 20]
        train_dfu = ats_dfu_level[ats_dfu_level['Week_Start_Date'] <= holdout_date]
        test_dfu = ats_dfu_level[ats_dfu_level['Week_Start_Date'] > holdout_date]
        
        # Training prediction - dfu avg
        mean_ats = train_dfu.groupby(['line','Week_Start_Date']).agg(Mean_ats = ('ats','mean')).reset_index()
        mean_ats = mean_ats.sort_values(by=['line','Week_Start_Date'])
        mean_ats = mean_ats.groupby(['line']).tail(8)
        mean_ats = mean_ats.groupby(['line']).agg(Mean_ats = ('Mean_ats','mean')).reset_index()
        
        # Testing prediction - dfu avg
        mean_ats_test = test_dfu.groupby(['line','Week_Start_Date']).agg(Mean_ats = ('ats','mean')).reset_index()
        mean_ats_test = mean_ats_test.sort_values(by=['line','Week_Start_Date'])
        mean_ats_test = mean_ats_test.groupby(['line']).agg(Mean_ats = ('Mean_ats','mean')).reset_index()
          
        # Test accuracy - line level
        mean_ats_accuracy = test.merge(mean_ats,left_on = ['DD_DFU'],right_on=['line'])
        mean_ats_accuracy['Abs_Deviation'] = abs(mean_ats_accuracy['ATS'] - mean_ats_accuracy['Mean_ats'])
        mean_ats_accuracy = mean_ats_accuracy.groupby(['DD_DFU','DD_LOCATION']).agg(Mean_Abs_Deviation = ('Abs_Deviation','mean')).reset_index()
        
        # Join
        horizon_df = pd.DataFrame({'ATS Week':horizon_period,'Key':0})
        mean_ats_accuracy['Key'] = 0
        mean_ats_accuracy = horizon_df.merge(mean_ats_accuracy)
        mean_ats_predn = mean_ats_test.merge(mean_ats_accuracy,left_on='line',right_on='DD_DFU')
        
        return mean_ats_predn
    
    def format_naive_method_predn(self,naive_method_prediction):
        naive_method_prediction = naive_method_prediction.merge(self.line_maping,left_on='DD_DFU',right_on='line',how='inner')
        naive_method_prediction = naive_method_prediction[['line','dfu','location','ATS Week','Most_Probable_Outcome','Mean_Abs_Deviation']]
        naive_method_prediction['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        naive_method_prediction['ATS DS model'] = 'Most Probable Outcome'
        naive_method_prediction = naive_method_prediction[['dfu','location','DS Run Date','ATS Week','ATS DS model','Mean_Abs_Deviation','Most_Probable_Outcome']]
        naive_method_prediction.columns = ['DFU','Location','DS Run Date','ATS Week','ATS DS model','ATS Model Error','Cortex Future ATS']
        naive_method_prediction['Cortex Min ATS - 95% CI'] = naive_method_prediction['Cortex Future ATS']
        naive_method_prediction['Cortex Max ATS - 95% CI'] = naive_method_prediction['Cortex Future ATS']
        return naive_method_prediction
    
    def format_moving_avg_predn(self,moving_avg_predn):
        moving_avg_predn = moving_avg_predn.merge(self.line_maping,left_on='DD_DFU',right_on='line',how='inner')
        moving_avg_predn = moving_avg_predn[['line','dfu','location','ATS Week','Moving_avg_predn','Mean_Abs_Deviation']]
        moving_avg_predn['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        moving_avg_predn['ATS DS model'] = '8 Period Moving Average'
        moving_avg_predn = moving_avg_predn[['dfu','location','DS Run Date','ATS Week','ATS DS model','Mean_Abs_Deviation','Moving_avg_predn']]
        moving_avg_predn.columns = ['DFU','Location','DS Run Date','ATS Week','ATS DS model','ATS Model Error','Cortex Future ATS']
        moving_avg_predn['Cortex Min ATS - 95% CI'] = moving_avg_predn['Cortex Future ATS']
        moving_avg_predn['Cortex Max ATS - 95% CI'] = moving_avg_predn['Cortex Future ATS']
        return moving_avg_predn
    
    def format_avg_predn_dfu_level(self,mean_ats_predn):
        mean_ats_predn = mean_ats_predn.merge(self.line_maping,left_on='line',right_on='line',how='inner')
        mean_ats_predn = mean_ats_predn[['line','dfu','location','ATS Week','Mean_ats','Mean_Abs_Deviation']]
        mean_ats_predn['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        mean_ats_predn['ATS DS model'] = 'Avg ATS at DFU level'
        mean_ats_predn = mean_ats_predn[['dfu','location','DS Run Date','ATS Week','ATS DS model','Mean_Abs_Deviation','Mean_ats']]
        mean_ats_predn.columns = ['DFU','Location','DS Run Date','ATS Week','ATS DS model','ATS Model Error','Cortex Future ATS']
        mean_ats_predn['Cortex Min ATS - 95% CI'] = mean_ats_predn['Cortex Future ATS']
        mean_ats_predn['Cortex Max ATS - 95% CI'] = mean_ats_predn['Cortex Future ATS']
        return mean_ats_predn
    
    def get_scheduled_prodn_in_future(self):
        week_minus_one = self.get_previous_week_date()
        future_prodn = self.prodn_actuals[self.prodn_actuals['Week_Start_Date'] > week_minus_one]
        future_prodn = future_prodn[['dfu','location','line','Week_Start_Date','scheduled_production_in_ea']]        
        # Make sure we have 12 weeks of future production for each grain        
        # looping over each grain
        grain_groups = future_prodn.groupby(['dfu','location','line'])        
        grain_complete = []
        for name,singleGrain in grain_groups:
            # Re-index - add all time periods between start and end date
            singleGrain = singleGrain.set_index('Week_Start_Date')
            idx = pd.date_range(start = week_minus_one + timedelta(days=7),end = week_minus_one + timedelta(days=7*12),freq='W')
            singleGrain = singleGrain.reindex(list(idx))
            # fill na
            singleGrain[['dfu','location','line']] = singleGrain[['dfu','location','line']].fillna(method='ffill')
            singleGrain[['dfu','location','line']] = singleGrain[['dfu','location','line']].fillna(method='bfill')
            singleGrain['scheduled_production_in_ea'] = singleGrain['scheduled_production_in_ea'].fillna(0)
            grain_complete.append(singleGrain)
        future_prodn_complete = pd.concat(grain_complete).reset_index()
        future_prodn_complete = future_prodn.groupby(['line','Week_Start_Date']).agg(scheduled_production_in_ea = ('scheduled_production_in_ea','sum')).reset_index()
        return future_prodn_complete
    
    def get_mars_ats_predn(self,train,test,horizon_period):
        test['Mars_ATS'] = 100
        test['Abs_Deviation'] = abs(test['ATS'] - test['Mars_ATS'])
        mars_accuracy = test.groupby(['DD_DFU','DD_LOCATION']).agg(Mean_Abs_Deviation = ('Abs_Deviation','mean')).reset_index()
        # Mars method prediction - Cross Join
        horizon_df = pd.DataFrame({'ATS Week':horizon_period,'Key':0})
        mars_accuracy['Key'] = 0
        mars_prediction = horizon_df.merge(mars_accuracy)
        mars_prediction['Predicted_ATS'] = 100
        return mars_prediction
        
    def format_mars_ats_predn(self,mars_prediction):
        mars_prediction = mars_prediction.merge(self.line_maping,left_on='DD_DFU',right_on='line',how='inner')
        mars_prediction = mars_prediction[['line','dfu','location','ATS Week','Predicted_ATS','Mean_Abs_Deviation']]
        mars_prediction['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        mars_prediction['ATS DS model'] = 'Mars ATS of 100'
        mars_prediction = mars_prediction[['dfu','location','DS Run Date','ATS Week','ATS DS model','Mean_Abs_Deviation','Predicted_ATS']]
        mars_prediction.columns = ['DFU','Location','DS Run Date','ATS Week','ATS DS model','ATS Model Error','Cortex Future ATS']
        mars_prediction['Cortex Min ATS - 95% CI'] = mars_prediction['Cortex Future ATS']
        mars_prediction['Cortex Max ATS - 95% CI'] = mars_prediction['Cortex Future ATS']
        return mars_prediction
    
    def get_linreg_predn(self,train,test,horizon_period):
        reg_parameters = train.groupby('DD_DFU').apply(self.run_linreg_on_ats).reset_index()
        test_predn = test.merge(reg_parameters,on=['DD_DFU'])
        test_predn['Predicted_ATS'] = test_predn['Slope']*test_predn['CT_SCHEDULED_PRODUCTION_EACHES'] + test_predn['Intercept']
        test_predn['Abs_Dev'] = abs(test_predn['ATS'] - test_predn['Predicted_ATS'])
        test_accuracy = test_predn.groupby(['DD_DFU']).agg(Mean_Abs_Dev = ('Abs_Dev','mean')).reset_index()
        reg_parameters = reg_parameters.merge(test_accuracy)
        linreg_predn = self.future_prodn.merge(reg_parameters[['DD_DFU','Slope','Intercept','Mean_Abs_Dev']],left_on='line',right_on='DD_DFU')
        linreg_predn['linreg_ats'] = linreg_predn['scheduled_production_in_ea']*linreg_predn['Slope'] + linreg_predn['Intercept']
        return linreg_predn
    
    def format_linreg_predn(self,linreg_predn):
        linreg_predn['DS Run Date'] = datetime.today().strftime('%Y-%m-%d')
        linreg_predn['ATS DS model'] = 'Linear Regression'
        linreg_predn = linreg_predn[['dfu','location','DS Run Date','Week_Start_Date','ATS DS model','Mean_Abs_Dev','linreg_ats']]
        linreg_predn.columns = ['DFU','Location','DS Run Date','ATS Week','ATS DS model','ATS Model Error','Cortex Future ATS',]
        linreg_predn['ATS Week'] = linreg_predn['ATS Week'].apply(lambda x: x.strftime('%Y-%m-%d'))
        linreg_predn['Cortex Min ATS - 95% CI'] = linreg_predn['Cortex Future ATS']
        linreg_predn['Cortex Max ATS - 95% CI'] = linreg_predn['Cortex Future ATS']
        return linreg_predn
    
    def do_yearweek_workaround(self,yearweek):
        if yearweek == 202101:
            return 202053
        elif yearweek > 202101:
            return yearweek-1
        else:
            return yearweek
    
    
    
    