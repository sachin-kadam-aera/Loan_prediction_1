import os
import sys
import traceback
import pandas as pd
from src.utility.LoggerConfig import Logger
from datetime import date, datetime, timedelta

class DataValidation:
    def __init__(self,job_id,logsPath,dc_forecast,dc_actuals,prodn_actuals):

        self.job_id = job_id
        self.logsPath = logsPath
        self.dc_forecast = dc_forecast
        self.dc_actuals = dc_actuals
        self.prodn_actuals = prodn_actuals
        
        self.dataSpecification = pd.ExcelFile('data_specification/data_specs.xls')
        self.dc_forecast_spec = self.get_spec('dc_forecast')
        self.dc_actuals_spec = self.get_spec('dc_actuals')
        self.prodn_actuals_spec = self.get_spec('prodn_actuals')
        
        self.dc_location_allowed = {'GB40','GB47','GB73'}
        
        try:
            self.dc_forecast_check()
            self.dc_actuals_check()
            self.prodn_actuals_check()
            self.latest_date_check()
            self.check_lag_values()
            self.check_line_mapping()
            #self.check_locations_dc_level()
        except Exception as e:
            Logger(job_id,logsPath).logr.error("Data Validation Issue - unknown issue: {}".format(e))
            print(traceback.print_exc())
            sys.exit()
            
    #############################################################################           
    #1. Main function go here    
    def dc_forecast_check(self):
        self.column_name_check(self.dc_forecast,self.dc_forecast_spec,'dc_forecast')
        self.data_type_check(self.dc_forecast,self.dc_forecast_spec,'dc_forecast')
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - {} executed".format('dc_forecast_check()'))
        return None
    
    def dc_actuals_check(self):
        self.column_name_check(self.dc_actuals,self.dc_actuals_spec,'dc_actuals')
        self.data_type_check(self.dc_actuals,self.dc_actuals_spec,'dc_actuals')
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - {} executed".format('dc_actuals_check()'))
        return None
    
    def prodn_actuals_check(self):
        self.column_name_check(self.prodn_actuals,self.prodn_actuals_spec,'prodn_actuals')
        self.data_type_check(self.prodn_actuals,self.prodn_actuals_spec,'prodn_actuals')
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - {} executed".format('prodn_actuals_check()'))
        return None
    
    def latest_date_check(self):
        self.rename_column()
        self.convert_to_datetime()
        
        week_minus_one = self.get_previous_week_date()
        max_dc_forecast_date = max(self.dc_forecast['Week_Start_Date'])
        max_dc_actuals_date = max(self.dc_actuals['Week_Start_Date'])
        max_prodn_actuals_date = max(self.prodn_actuals['Week_Start_Date'])

        Logger(self.job_id,self.logsPath).logr.info("Data Validation - Week Minus One Date {}".format(week_minus_one))
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - Max dc_forecast date {}".format(max_dc_forecast_date))
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - Max dc_actuals date {}".format(max_dc_actuals_date))
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - Max prodn_actuals date {}".format(max_prodn_actuals_date))
        
        dc_forecast_flag = 1 if max_dc_forecast_date >= week_minus_one else 0
        dc_actuals_flag = 1 if max_dc_actuals_date >= week_minus_one else 0
        # Prodn data maximum date should be (previous week date + 12 weeks forward)
        prodn_actuals_flag = 1 if max_prodn_actuals_date == (week_minus_one + timedelta(days=7*12)) else 0
        
        if not (dc_forecast_flag*dc_actuals_flag == 1):
            Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - latest date check failed. Data is not updated with current week minus one data.")
            sys.exit()
            
        if not (prodn_actuals_flag == 1):
            Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - production date check failed. Production data is missing one or more future week.")
            sys.exit()
        
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - {} executed".format('latest_date_check()'))
        
        return
    
    def check_lag_values(self):
        if not ((len(set(self.dc_forecast['lag'])) == 17) & (len(set(range(17)) - set(self.dc_forecast['lag'])) == 0)):
            Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - lag column issue in {}. Check if a value is missing or a new value is added".format('dc_forecast'))
            sys.exit()
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - {} executed".format('check_lag_values()'))
        return
            
    def check_line_mapping(self):
        '''
        For each dfu-location, a single line mapping should exist
        '''
        maping = self.prodn_actuals[['dfu','location','line']].drop_duplicates()
        if sum(maping.groupby(['dfu','location'])['line'].agg('count') > 1) != 0:
            Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - More than 1 line maping for same dfu-location in {}".format('prodn_actuals'))
            sys.exit()
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - {} executed".format('check_line_mapping()'))
        return
    
    def check_locations_dc_level(self):
        if not ((len(set(self.dc_actuals['location'])) == len(self.dc_location_allowed)) & (len(self.dc_location_allowed - set(self.dc_actuals['location'])) == 0)):
            Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - Un-identified location in {}".format('dc_actuals'))
            sys.exit()
            
        if not ((len(set(self.dc_forecast['location'])) == len(self.dc_location_allowed)) & (len(self.dc_location_allowed - set(self.dc_forecast['location'])) == 0)):
            Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - Un-identified location in {}".format('dc_forecast'))
            sys.exit()
        
        Logger(self.job_id,self.logsPath).logr.info("Data Validation - {} executed".format('check_locations_dc_level()'))
        return
    #############################################################################           
    
    #############################################################################           
    #2. Support function go here
    def get_spec(self,sheet):
        spec = pd.read_excel(self.dataSpecification,sheet)
        return dict(zip(spec.ColumnNames,spec.DataType))
    
    def column_name_check(self,testFile,referenceFile,name):
        if not ((len(testFile.columns) == len(referenceFile.keys())) & (len(set(testFile.columns) - set(referenceFile.keys())) == 0)):
            Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - column name validation failed in {}".format(name))
            sys.exit()
        return 1
    
    def data_type_check(self,testFile,referenceFile,name):
        for col in testFile:
            if not testFile[col].dtype == referenceFile[col]:
                Logger(self.job_id,self.logsPath).logr.error("Data Validation Issue - data type validation failed in {}".format(name))
                sys.exit()
        return 1
    
    def convert_date_to_datetime(self,dateObj):
         return datetime(dateObj.year, dateObj.month, dateObj.day)
    
    def get_previous_week_date(self):
        today = date.today()
        offset = (today.weekday() - 6) % 7 #Sunday -> 6
        last_sunday = today - timedelta(days=offset)
        previous_week_start_date = last_sunday - timedelta(days=7)
        previous_week_start_date = self.convert_date_to_datetime(previous_week_start_date)
        print(previous_week_start_date)
        return previous_week_start_date
    
    def rename_column(self):
        self.dc_forecast.rename(columns = {'forecast_week':'Week_Start_Date'}, inplace = True)
        self.dc_actuals.rename(columns = {'week':'Week_Start_Date'}, inplace = True)
        self.prodn_actuals.rename(columns = {'date':'Week_Start_Date'}, inplace = True)
        print('Data Validation- Column rename finished')
        return
    
    def convert_to_datetime(self):
        self.dc_forecast['Week_Start_Date'] = pd.to_datetime(self.dc_forecast['Week_Start_Date'],format='%Y-%m-%d')
        self.dc_actuals['Week_Start_Date'] = pd.to_datetime(self.dc_actuals['Week_Start_Date'],format='%Y-%m-%d')
        self.prodn_actuals['Week_Start_Date'] = pd.to_datetime(self.prodn_actuals['Week_Start_Date'],format='%Y-%m-%d')
        print('Data Validation - Conversion to datetime finished')
        return 
    

    
    #############################################################################           
    