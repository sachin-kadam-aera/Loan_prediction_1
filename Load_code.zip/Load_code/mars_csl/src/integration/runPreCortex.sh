echo 'Allocation Run Start...'
cd /efs/datascience/aera-datascience/deploy/ds_services/Mars_CSL/
# Run
/opt/anaconda3.8/bin/python preCortex.py $1 $2 $3 $4 $5 $6 $7 $8 $9
echo 'Allocation Run Completed...'
