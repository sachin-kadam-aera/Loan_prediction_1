#!/bin/bash
HOST=${10}
echo 'Host IP :'$HOST



# status=$(ssh -o BatchMode=yes -o ConnectTimeout=5 fusionops@$HOST echo ok 2>&1)
# if [[ $status == ok ]]; then
#         echo SSH passed to target server, moving on...
#         ssh -o StrictHostKeyChecking=no fusionops@$HOST '/efs/datascience/aera-datascience/deploy/ds_services/Mars_CSL/src/integration/runPreCortex.sh' $1 $2 $3 $4 $5 $6 $7 $8 $9 2>&1
# 
# 
# elif [[ $status == "Permission denied"* ]] ; then
#     echo I am unable to communicate to target host $HOST
# fi
# echo 'completed.....'


success_response="Server is running"
status_message="success"

response=$(curl -s $HOST | cut -d '"' -f 2)
echo "Responce:"$response


if [[ "$response" == "$success_response" ]];
	then
		echo "Running Script..."
		status=$(curl -s --location --request POST $HOST --header 'Content-Type: application/json' --data-raw '{ "cmd" : "sudo -i -u fusionops /efs/datascience/aera-datascience/deploy/ds_services/Mars_CSL/src/integration/runPreCortex.sh '$1' '$2' '$3' '$4' '$5' '$6' '$7' '$8' '$9' 2>&1  "}' | jq -r '.status' )
	if [[ "$status" == "$status_message" ]];
		then
		echo "Successfully executed the script"
	else
		echo "Unable to execute the script"
	fi
else
	echo "Unable to connect to server"
fi
