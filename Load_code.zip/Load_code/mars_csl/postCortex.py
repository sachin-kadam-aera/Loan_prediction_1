import sys
import time
import os
import pickle
import pandas as pd
from src.postProcessing.DataFormating import DataFormat
from src.utility.utils import utility
from src.utility.LoggerConfig import Logger
#python postCortex.py 30Nov2020 4c23a71fd1b652aa9f03a0fcc901f100 true cortex_forecast_output cortex_forecast_output '/Users/sandeepdhankhar '/OneDrive - Aera Technology/8 Project Mars/Data/' 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'

# Idenitfy if the script is running on Local or Server. 1 = server, 0 = local machine
ds_server_flag = 1

if __name__ == '__main__':
    
    #############################################################################
    #1.Read system arguments from skill
    if ds_server_flag == 1:
        program_start_time = time.time()
        job_id = sys.argv[1]
        token = sys.argv[2]
        storage_flag = sys.argv[3]
        dc_forecast_op_api_name = sys.argv[4]
        prodn_forecast_op_api_name = sys.argv[5]
        data_path = sys.argv[6] #/efs/datascience/MarsC46/data
        env_url = sys.argv[7] #https://insightqd.aeratechnology.com/ispring/client/v2/reports/
        host = sys.argv[8] #insightqd.aeratechnology.com
        
        print('Job_Id:',job_id)
        print('token:',token)
        print('storage_flag:',storage_flag)
        print('Cortex DC API:',dc_forecast_op_api_name)
        print('Cortex Prodn API:',prodn_forecast_op_api_name)
        
    if ds_server_flag == 0:
        program_start_time = time.time()
        job_id = '30Mar2021'
        token = '700ea724839cc7990b191e033d7800bc'
        storage_flag = 'false'
        dc_forecast_op_api_name = 'dc_forecast_op_postCortex'
        prodn_forecast_op_api_name = 'prodn_forecast_op'
        data_path = '/Users/sandeepdhankhar/OneDrive - Aera Technology/8 Project Mars/Data/'
        env_url = 'https://insightqd.aeratechnology.com/ispring/client/v2/reports/'
        host = 'insightqd.aeratechnology.com'
        
    # Initialize Path
    util = utility(data_path)
    logsPath = util.get_logs_path(job_id)
    output_file_path = util.get_output_path(job_id)
    
    #2. Use the API names to call the read_report function and retrieve 3 dataframes
    '''
    dc_forecast_op = pd.read_csv(os.path.join(data_path,job_id,'cortex_output','dc_forecast_op.csv'), dtype = {'grain-1':str,'grain-2':str})
    '''
    api_read_start = time.time()
    
    dc_forecast_op = util.read_report(env_url,dc_forecast_op_api_name,token,100000,host)
    dc_forecast_op[['sales_quantity','forecast_quantity','forecast_rank','ranking_mode_forecast_qty','actual_date_value','ranking_metric_value']] = dc_forecast_op[['sales_quantity','forecast_quantity','forecast_rank','ranking_mode_forecast_qty','actual_date_value','ranking_metric_value']].apply(pd.to_numeric)
    if not isinstance(dc_forecast_op,pd.DataFrame):
        Logger(job_id,logsPath).logr.error('Incorrect Response from API {0}. Response Code: {1}'.format(dc_forecast_op_api_name,dc_forecast_op))
        sys.exit()
    
    
    Logger(job_id,logsPath).logr.info("Post Processing - Read Data from APIs in {} seconds".format(round(time.time() - api_read_start, 2)))
    #'''
    # Read the pickle files (saved using preCortex.py)
    try:
        pickle_read_time = time.time()    
        #with open(os.path.join(output_file_path,'_postCortex_ip_line_maping.dat'), "rb") as f:  line_maping = pickle.load(f)
        #with open(os.path.join(output_file_path,'_postCortex_ip_ats_pred.dat'), "rb") as f:  ats_predn = pickle.load(f)
        with open(os.path.join(output_file_path,'_postCortex_ip_mars_fcst_accuracy.dat'), "rb") as f:  mars_fcst_accuracy = pickle.load(f)    
        with open(os.path.join(output_file_path,'_postCortex_ip_mars_actual_sales.dat'), "rb") as f:  mars_actual_sales = pickle.load(f)    
        cortex_date_ip = pd.read_csv(os.path.join(output_file_path,'1_cortexDateInput.csv'))
        Logger(job_id,logsPath).logr.info("Post Processing - Read Data from pickle file in {} seconds".format(round(time.time() - pickle_read_time, 2)))
    except Exception as e:
        Logger(job_id,logsPath).logr.error("Post processing : Issue in reading pickle file. Error => {}".format(e))
        sys.exit()
    #############################################################################
    
    #############################################################################
    #3. If the storage flag is true, save the files in the input file directory for later use
    if storage_flag == 'true':
        storage_time = time.time()
        cortex_output_files_path = util.get_cortex_output_path(job_id)
        dc_forecast_op.to_csv(os.path.join(cortex_output_files_path,"{}.csv".format(dc_forecast_op_api_name)),index=False)
        print("Cortex output stored as csv for later debugging")
        Logger(job_id,logsPath).logr.info("Stored cortex output data in {} seconds".format(round(time.time() - storage_time, 2)))
    #############################################################################
    
    #############################################################################
    #4. Pass the dataframes to the DataHandler Object, then save the output
    postprocess_time = time.time()
    postProcessing = DataFormat(job_id,logsPath,dc_forecast_op,mars_fcst_accuracy,mars_actual_sales,cortex_date_ip)
    # Save the output to output folder
    postProcessing.dc_final_forecast.to_csv(os.path.join(output_file_path,'8_Final_DC_Forecast.csv'),index=False)
    #postProcessing.prodn_final_forecast.to_csv(os.path.join(output_file_path,'9_Final_Prodn_Forecast.csv'),index=False)
    Logger(job_id,logsPath).logr.info("Post processed data in {} seconds".format(round(time.time() - postprocess_time, 2)))
        
        
        
        
        
        
        
        
        
        
        
        
        