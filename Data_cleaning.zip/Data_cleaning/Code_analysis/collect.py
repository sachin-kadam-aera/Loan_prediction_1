import logging
import pandas as pd

from safety_stock.data_modelling.modelling_api import compute_safety_stock


def get_grain_compute_data(grain_safety_stock_result):
    demand_data = grain_safety_stock_result['demand_distribution']
    leadtime_data = grain_safety_stock_result['leadtime_distribution']
    target_service_levels = grain_safety_stock_result['target_service_levels']
    grain_ss_compute_time_taken = grain_safety_stock_result['grain_ss_compute_time_taken']
    grain_cols = grain_safety_stock_result['grain_cols']
    grain_defn = ''
    if isinstance(grain_cols, str):
        grain_defn = grain_cols
    elif isinstance(grain_cols, list):
        grain_defn = ','.join(grain_cols)
    grain_name = grain_safety_stock_result['jobgrain']
    grain_name = grain_name.replace('-=-', '/')
    grain_name = grain_name.split('__')
    if len(grain_name) == 1:
        grain_name.extend(['', ''])
    elif len(grain_name) == 2:
        grain_name.extend([''])
    elif len(grain_name) > 3:
        grain_name = grain_name[:3]

    error_message = str(grain_safety_stock_result['error_msg']).strip()
    grain_all_results = []
    for service_level, safety_stock_result in target_service_levels.items():
        grain_result = []
        grain_result.extend(grain_name)
        grain_result.append(grain_defn)
        grain_result.append(service_level)
        safety_stock = safety_stock_result['safetystock']
        safety_stock = max(0, safety_stock)
        ss_last_service_level = safety_stock_result['last_service_level']
        ss_simulation_count = safety_stock_result['simulation_count']
        grain_result.append(safety_stock)
        grain_result.append(demand_data['dist'])
        grain_result.append(demand_data['param'])
        grain_result.append(leadtime_data['LeadTime_Dist'])
        grain_result.append(leadtime_data['params'])
        grain_result.append(error_message)
        grain_result.append(grain_ss_compute_time_taken)
        grain_result.append(ss_last_service_level)
        grain_result.append(ss_simulation_count)
        grain_all_results.append(grain_result)

    all_data = pd.DataFrame(grain_all_results)
    all_data.columns = ['DD_GRAIN1', 'DD_GRAIN2', 'DD_GRAIN3',
                        'DD_GRAIN_DEFINITION',
                        'CT_FILLRATE',
                        'CT_SAFETYSTOCK',
                        'DD_DEMANDDISTRIBUTION',
                        'DD_DEMAND_DISTRIBUTION_PARAMS',
                        'DD_LEADTIME_DISTRIBUTION',
                        'DD_LEADTIMEDISTRIBUTION_PARAMS',
                        'DD_ERROR_MESSAGE',
                        'CT_TIMETAKEN',
                        'CT_BEST_SERVICE_LEVEL',
                        'CT_SIMULATION_COUNT']
    for col in all_data.columns:
        if col.startswith('DD_'):
            all_data[col] = all_data[col].astype(str)
        if col.startswith('CT_'):
            all_data[col] = all_data[col].astype(float)
    return all_data.to_dict(orient='records')


class GrainOrchestrator:
    def __init__(self, grain_data):
        self.grain_data = grain_data
        self.message_id = self.grain_data['message_id']
        self.task_id = self.grain_data['task_id']
        self.job_id = self.grain_data['job_id']
        self.project_id = self.grain_data['project_id']
        self.capacityPoolId = self.grain_data['capacityPoolId']
        self.service_id = self.grain_data['service_id']
        self.grain = self.grain_data['grain']
        logger_instance = logging.getLogger(__name__)
        self.logger = logging.LoggerAdapter(logger_instance, {'jobId': self.job_id})

    def get_safetystock(self):
        self.logger.info(f"Starting safety stock computation for grain: {self.grain}")
        safety_stock = compute_safety_stock(self.grain_data)
        safety_stock_results = safety_stock['result']['metadata']['modelParams']
        is_error = safety_stock_results['is_error']
        error_reason = safety_stock_results['error_reason']
        safety_stock_result = safety_stock_results['safety_stock_result']
        self.logger.info(f"Completed safety stock compuation for grain: {self.grain} Status: {is_error}")
        compute_data_result = get_grain_compute_data(safety_stock_result)
        task_response = {
            'MESSAGE_DETAILS_LOGS': {
                        "job_id": self.job_id,
                        "task_id": self.task_id,
                        "project_id": self.project_id,
                        "capacity_pool_id": self.capacityPoolId,
                        "service_id": self.service_id,
                        "document_type": "MESSAGE_DETAILS_LOGS",
                        "stream_message_list": [safety_stock_result] # list of json
                        },
            'COMPUTE_DATA': {
                "job_id": self.job_id,
                "task_id": self.task_id,
                "project_id": self.project_id,
                "capacity_pool_id": self.capacityPoolId,
                "service_id": self.service_id,
                "document_type": "COMPUTE_DATA",
                "stream_message_list": compute_data_result  # list of json
            }
        }
        return is_error, task_response


'''
grain, safety_stock {json}

original_input = {'demand_data': None, 'demand_data_time': None, 'lead_time_data': None, 'grain': ('10000361', 'US44'), 'number_of_simulations': 10, 'fill_rate_desired': [95], 'Q_value': 0.0, 'message_id': 'TESTING__10000361__US44'}
self = GrainOrchestrator(original_input)
'''
'''
df = pd.read_csv("/private/tmp/5476adcfadee48258d49f94b8a09ab6d_computational_data.csv", header = None)
required_idx = list(range(1, 201, 2))
df = df.iloc[required_idx]
import ast
all_data = []
for i in range(df.shape[0]):
    row = df.iloc[i, 4]
    row = ast.literal_eval(row.replace('\r','\\r').replace('\n','\\n'))
    all_data.append(row)

all_data_df = pd.DataFrame.from_dict(all_data)
all_data_df.to_csv("/tmp/safety_stock_output_5476adcfadee48258d49f94b8a09ab6d.csv", index=False)
'''