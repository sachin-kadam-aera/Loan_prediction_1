from abc import ABC
import logging
import time
import traceback
import pandas as pd
from utils.status_update import StatusUpdateService
from utils.cassandra_utility import stream_message_wrapper, CassandraDb
from safety_stock.utility.constant import Constant
from cortex.settings import CORTEX_CONFIG
from datetime import date
from utils.exporter_utility import ExporterUtility
from utils.db_utility import DBUtility

'''
Standard to be followed:
1. variable should be service agnostic
2. method name should be service agnostic and should be based on document type
3. Uses: it should be independently executable

'''

class ExportableDataBase(ABC):
    def __init__(self):
        pass


class ExportableData(ExportableDataBase):

    def __init__(self, job_id, project_id, service_id, job_name,**kwargs):
        self.job_id = job_id
        self.key_space = CORTEX_CONFIG['CASSANDRA-PROPERTIES']['KEY_SPACE'].upper()
        self.project_id = project_id
        self.service_id = service_id
        self.job_name = job_name
        self.exportable_documents = {}
        self.working_folder = kwargs.get("working_folder")
        pass

    def compute_data(self):
        '''
        This function gives the Compute data and returns it as a DataFrame
        '''
        export_obj = ExporterUtility(self.job_id,
                                     self.project_id,
                                     self.service_id,
                                     'COMPUTE_DATA',
                                     upload_data=False,
                                     working_folder = self.working_folder)
        export_status, compute_data = export_obj.main()
        return compute_data

    def job_summary(self):
        compute_data = self.compute_data()
        grain_cols = ['DD_GRAIN1', 'DD_GRAIN2', 'DD_GRAIN3']
        compute_data['grain'] = compute_data[grain_cols].astype(str).apply(lambda x: '__'.join(x), axis=1)

        job_summary_data = compute_data.drop_duplicates(['grain'])
        total_grains = job_summary_data['grain'].shape[0]
        job_summary_data['DD_ERROR_MESSAGE'] = job_summary_data['DD_ERROR_MESSAGE'].fillna('')
        grains_passed = sum(job_summary_data['DD_ERROR_MESSAGE'].apply(lambda x: x.strip() == ''))
        grains_failed = sum(job_summary_data['DD_ERROR_MESSAGE'].apply(lambda x: x.strip() != ''))
        grain_passed_percentage = 100.0 * grains_passed / total_grains
        grain_failed_percentage = 100.0 * grains_failed / total_grains
        return total_grains, grains_passed, grains_failed, grain_passed_percentage, grain_failed_percentage


    # def get_job_status_details(self):
    #     cass_db = CassandraDb(project_id=self.project_id, service_id=self.service_id, job_id=self.job_id)
    #     job_status_data_retrieve_query = "select * from {}.cortex_framework_jobs_status where job_id = '{}'".format(
    #         self.key_space,
    #         self.job_id,
    #     )
    #     response = cass_db.query_executor(job_status_data_retrieve_query, job_id=self.job_id, query_ops='read')
    #
    #     if not response:
    #         raise Exception("Exporter Failed! Failed to retrieve SAFETY_STOCK_JOB_STATUS!")
    #
    #     job_details = cass_db.query_data
    #     return job_details

    def get_total_execution_time(self):
        # job_details = self.get_job_status_details()
        job_details = DBUtility().get_job_status_details(self.job_id)

        job_created_time = None
        for row in job_details:
            if row.job_created is not None:
                job_created_time = row.job_created
            else:
                continue
        if job_created_time is None:
            time_taken = 0
        else:
            try:
                time_taken = (pd.Timestamp.now() - job_created_time).seconds
                time_taken = round(time_taken, 2)
            except Exception as e:
                time_taken = 0
        return time_taken

    def get_simulation_error_lags(self):
        response = DBUtility().get_documentmap_by_page(self.job_id, "MESSAGE_DETAILS_LOGS", 1)
        rows = response.result()
        if not response:
            raise Exception("Exporter Failed! Failed to retrieve ERROR LAGS DATA!")
        error_lags_df = pd.DataFrame(columns=[ "Lags","MAE", "Mean", "STD", "jobid", "jobName", "projectId", "serviceId",
                                               "Grain1", "Grain2", "Grain3", "ReportingDate"], dtype = object)
        for row0 in rows:
            error_lags_data = eval(row0.document_map["all_lag_errors"])
            g1, g2, g3 = row0.document_map["jobgrain"].split("__")
            map_result = map(
                lambda item: dict(item, jobid=self.job_id, jobName=self.job_name, projectId=self.project_id, serviceId=self.service_id,
                                  Grain1=g1, Grain2=g2, Grain3=g3, ReportingDate=date.today().strftime("%Y-%m-%d")),
                error_lags_data)
            stream_message_list = list(map_result)
            temp_error_lags_df = pd.DataFrame(stream_message_list)
            error_lags_df = error_lags_df.append(temp_error_lags_df, ignore_index = True)
        error_lags_df = error_lags_df[["Grain1", "Grain2", "Grain3", "Lags", "MAE", "Mean", "ReportingDate", "STD", "jobName",
                                       "jobid",  "projectId", "serviceId"]]
        error_lags_path = self.working_folder + "/SIMULATION_ERROR_LAGS.csv.gz"
        error_lags_df.to_csv(error_lags_path, compression='gzip', index = False)
        self.exportable_documents[Constant.SIMULATION_ERROR_LAGS] = error_lags_path
        return True

    def dataquality_dataforecastability_simulation_error_lags(self):
        startTime = time.time()
        logger_instance = logging.getLogger(__name__)
        logger = logging.LoggerAdapter(logger_instance, {'jobId': self.job_id})

        time_taken = self.get_total_execution_time()
        total_grains, grains_passed, grains_failed, grain_passed_percentage, grain_failed_percentage = self.job_summary()

        summary_message_list = {
            'DD_JOBID': self.job_id,
            'CT_TOTAL_GRAINS': total_grains,
            'CT_GRAINS_SUCCESSFUL': grains_passed,
            'CT_GRAINS_FAILED': grains_failed,
            'CT_GRAIN_SUCCESSFUL_PERCENTAGE': grain_passed_percentage,
            'CT_GRAIN_FAILED_PERCENTAGE': grain_failed_percentage,
            'CT_TIME_TAKEN': time_taken
        }

        stream_message_args = {
            "job_id": self.job_id,
            "task_id": self.job_id,
            "project_id": self.project_id,
            "capacity_pool_id": self.project_id,
            "service_id": self.service_id,
            "document_type": "DQDFDV_SUMMARY",
            "stream_message_list": [summary_message_list],
            "logger": logger
        }
        #       import pdb;pdb.set_trace()
        stream_status, stream_message = stream_message_wrapper("cassandra_insert", stream_message_args)

        simulation_error_lag_response = self.get_simulation_error_lags()

        if stream_status & simulation_error_lag_response:
            logger.info("Created the final safety stock summary successfully, now streaming data to Cassandra")
            logger.info("Time required to process the exporting safety stock summary data %s", time.time() - startTime)
            logger.info("Successfully completed exporting data")
            status = True
            ExportError = str(stream_message)
        else:
            logger.error("Failed to stream summary data to Cassandra. Reason of faliure:", str(stream_message))
            status = False
            ExportError = str(stream_message)
        return status, ExportError



    def cortex_message_details_logs(self):
        pass

    def cortex_message_level_logs(self):
        pass

    def forecast_validation(self):
        pass


# if __name__ == "__main__":
    # Step 1: Get Structured Data/ Compute Data
    # project_id = "0797FF95_4733_4F4A_880B_F474204228A1"
    # service_id = "1006"
    # job_id = "458167aadf0b48c7be17d9a38db8548c"
    # job_name = "DS_SS_RB_RUN2021-06-15-05-06"
    # key_space = "CORTEX_UAT"
    # exp = ExportableData(job_id, key_space, project_id, service_id, job_name)
    # exp.get_simulation_error_lags(job_id, job_name, project_id, service_id)