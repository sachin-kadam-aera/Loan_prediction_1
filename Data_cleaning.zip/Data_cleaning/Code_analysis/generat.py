import os
import logging
import pandas as pd
import numpy as np
from utils.common_utility import CommonUtility
from utils.constant import Constant
from safety_stock.data_ingestion import read_data
from utils.exceptions.service_exception import DirectoryNotExistsException


class GrainGenerator:
    '''
    Reads different data files, does data munging  and collate the data by grains
    '''
    def __init__(self, file_path=None, job_id=None, request_folder=None, original_input=None):
        self.input_para_data = None
        self.request_folder = request_folder
        self.job_id = job_id
        self.file_paths = file_path
        self.original_inputs = original_input
        self.ss_modeltype = None # It can be "with_demand" or "with_forecast"
        logger_instance = logging.getLogger(__name__)
        self.logger = logging.LoggerAdapter(logger_instance, {'jobId': self.job_id})
        self.logger.info("Started Producing Messages for Job Id = %s", self.job_id)
        self.load_params()
        self.logger.info("Completed loading the data params")

    def check_data_validation(self):
        # TODO Add validation tests
        return True, ''

    def get_parameter(self, param_key, param_parent_key=None, default_value=None):
        if param_parent_key is None:
            value = self.original_inputs.get(param_key)
        else:
            value = self.original_inputs.get(param_parent_key).get(param_key)
        if value is None:
            if default_value:
                value = default_value
            else:
                err_msg = f"Input value missing for {param_key}"
                self.logger.error(err_msg)
                raise Exception(err_msg)
        return value

    def load_params(self):
        # common params
        self.projectId = self.get_parameter("projectId")
        self.capacityPoolId = self.get_parameter("capacityPoolId")
        self.service_id = self.get_parameter("serviceId")
        self.isSimulated = self.get_parameter("isSimulated")
        self.accessToken = self.get_parameter("accessToken")
        self.requestEnvironment = self.get_parameter("requestEnvironment")
        self.userName = self.get_parameter("userName")
        # self.refreshToken = self.get_parameter("refreshToken")
        self.refreshToken = self.get_parameter("refreshToken", None, "defaultoken")
        # data params
        self.granularity = self.get_parameter("granularity", "dataParams")[0]
        self.approach = self.get_parameter("approach", "dataParams")
        self.threshold_dd_distribution = self.get_parameter("threshold_dd_distribution", "dataParams")
        self.threshold_lt_distribution = self.get_parameter("threshold_lt_distribution", "dataParams")
        self.grain_date_type = self.get_parameter("grain_date_type", "dataParams")
        self.demand_date_column = self.get_parameter("demand_date_column", "dataParams").upper()
        # model params
        self.number_of_simulations = self.get_parameter("number_of_simulations", "modelParams")
        self.simulation_method = "ss_simulation_model2"
        # job params
        self.job_name = self.get_parameter("jobName", "jobParams")
        self.jobId = self.get_parameter("jobId", "jobParams")
        self.user_name = self.get_parameter("user_name", "jobParams")
        self.target_service_level_filepath = self.file_paths['target_service_level']
        self.demand_history_filepath = self.file_paths['demand_history']
        self.lead_time_history_filepath = self.file_paths['lead_time_history']

        # new files
        self.forecast_snapshots_filepath = self.file_paths.get('all_forecast_snapshot')
        self.moq_filepath = self.file_paths.get('moq')

        if self.approach == "Monte Carlo Simulation With Demand History" and "Forecast" not in self.approach:
            self.ss_modeltype = "with_demand"
        else:
            self.ss_modeltype = "with_forecast"

        # update the grain columns
        self.job_grain_cols = [x.upper() for x in self.granularity]
        self.grain_info_cols = sorted(self.job_grain_cols)
        self.grain_info_cols = [x for x in self.grain_info_cols if x != "TARGET_SERVICE_LEVEL"]
        self.isTSLGrain = False
        if 'TARGET_SERVICE_LEVEL' in self.job_grain_cols:
            self.isTSLGrain = True
            self.job_grain_cols = self.grain_info_cols[:2]
            self.job_grain_cols.extend(['TARGET_SERVICE_LEVEL'])
        else:
            self.job_grain_cols = self.grain_info_cols[:3]

    def load_data(self):
        # read the files
        self.target_service_level_df = read_data.read_csv(self.target_service_level_filepath,
                                                          grain_cols=self.grain_info_cols)
        self.target_service_level_df['TARGET_SERVICE_LEVEL'] = self.target_service_level_df['TARGET_SERVICE_LEVEL']\
                                                                   .astype(float).round(4)
        self.demand_data_df = read_data.read_csv(self.demand_history_filepath,
                                                 grain_cols=self.grain_info_cols)
        self.lead_time_data_df = read_data.read_csv(self.lead_time_history_filepath,
                                                    grain_cols=self.grain_info_cols)
        if self.ss_modeltype == "with_forecast":
            self.forecast_snapshots_df = read_data.read_csv(self.forecast_snapshots_filepath,
                                                            grain_cols=self.grain_info_cols)
            self.moq_df = read_data.read_csv(self.moq_filepath,
                                             grain_cols=self.grain_info_cols)

        self.logger.info("Successfully read the data")
        self.target_service_level_df['grain'] = self.target_service_level_df[self.grain_info_cols]\
                                                    .astype(str).apply(lambda x: '__'.join(x).replace('/', '-=-'), axis=1)
        self.target_service_level_df['job_grain'] = self.target_service_level_df[self.job_grain_cols]\
                                                        .astype(str).apply(lambda x: '__'.join(x).replace('/', '-=-'), axis=1)
        self.demand_data_df['grain'] = self.demand_data_df[self.grain_info_cols]\
                                           .astype(str).apply(lambda x: '__'.join(x).replace('/', '-=-'), axis=1)
        self.lead_time_data_df['grain'] = self.lead_time_data_df[self.grain_info_cols]\
                                              .astype(str).apply(lambda x: '__'.join(x).replace('/', '-=-'), axis=1)
        # filter the grain based on target service level
        self.selected_grains = self.target_service_level_df['grain'].unique()
        self.demand_data_df = self.demand_data_df[self.demand_data_df['grain']
                                                      .isin(self.selected_grains)]
        self.lead_time_data_df = self.lead_time_data_df[self.lead_time_data_df['grain']
                                                            .isin(self.selected_grains)]
        if self.ss_modeltype == "with_forecast":
            # approach 2 params
            self.nlags = self.get_parameter("number_of_lags", "modelParams")
            self.current_weekmonth = self.get_parameter("current_weekmonth", "modelParams")
            self.forecast_date_column = self.get_parameter("forecast_snapshot_date_column", "dataParams").upper()

            self.error_metric_type = self.get_parameter("error_metric", "modelParams", "error")
            if self.error_metric_type == 'Error': self.error_metric_type = 'error'
            elif self.error_metric_type == 'Percetage Error': self.error_metric_type = 'percentage_error'

            self.forecast_snapshots_df['grain'] = self.forecast_snapshots_df[self.grain_info_cols]\
                                                      .astype(str).apply(lambda x: '__'.join(x).replace('/', '-=-'), axis=1)
            self.moq_df['grain'] = self.moq_df[self.grain_info_cols]\
                                       .astype(str).apply(lambda x: '__'.join(x).replace('/', '-=-'), axis=1)

            self.forecast_snapshot_cols = np.setdiff1d(self.forecast_snapshots_df.columns, self.grain_info_cols)
            self.forecast_snapshots_df = self.forecast_snapshots_df[self.forecast_snapshots_df['grain']
                                                                        .isin(self.selected_grains)]
            self.moq_df = self.moq_df[self.moq_df['grain'].isin(self.selected_grains)]

        # assert (self.demand_data_df.grain.nunique() > 0)
        # assert (self.lead_time_data_df.grain.nunique() > 0)
        # if self.ss_modeltype == "with_forecast":
        #     assert (self.forecast_snapshots_df.grain.nunique() > 0)
        #     assert (self.moq_df.grain.nunique() > 0)

        self.logger.info("Grain creating, and filtering is complete")

        if self.grain_date_type == "month":
            time_grain_period = pd.to_datetime(self.demand_data_df[self.demand_date_column]).dt.strftime('%Y%m')
            time_grain_period_grain = time_grain_period.values.tolist()
        elif self.grain_date_type == "week":
            time_grain_period_grain = self.demand_data_df[self.demand_date_column].astype(str).values.tolist()

        self.demand_data_df["Time_Grain"] = time_grain_period_grain
        self.logger.info("Data ingestion and data munging complete")

    def generate_all_grain_data(self):

        self.load_data()
        target_service_level_grain_data = self.target_service_level_df\
                                              .groupby('grain')["TARGET_SERVICE_LEVEL"]\
                                              .apply(max).to_dict()

        target_service_level_job_grain_data = self.target_service_level_df\
                                                  .groupby('job_grain')["TARGET_SERVICE_LEVEL"]\
                                                  .apply(max).to_dict()

        lead_time_grain_data = self.lead_time_data_df\
                                   .groupby('grain')["RLT"]\
                                   .apply(list).to_dict()

        demand_grain_data = self.demand_data_df.groupby('grain')["DEMAND"]\
                                               .apply(list).to_dict()

        demand_grain_time_data = self.demand_data_df.groupby(['grain'] + ["Time_Grain"])\
                                                    ["DEMAND"].sum().to_dict()

        demand_date_ranges = self.demand_data_df.groupby('grain')["Time_Grain"]\
                                                .agg(['min', 'max']).to_dict(orient='index')

        if self.ss_modeltype == "with_forecast":
            moq_grain_data = self.moq_df.groupby('grain')['MOQ'].apply(list).to_dict()
            forecast_snapshots_grain_data = self.forecast_snapshots_df.groupby('grain')\
                                                .apply(lambda x: x.to_json(orient='records'))
            self.simulation_method = "ss_simulation_model3"

        demand_grain_time_data_mapping = {}
        for key, value in demand_grain_time_data.items():
            grain_val, _ = key
            update_value(demand_grain_time_data_mapping, grain_val, key, value)

        self.logger.info("Completed aggregating grain data")

        all_grain_metadata = []
        for job_grain_ in target_service_level_job_grain_data:
            if self.isTSLGrain:
                grain_ = '__'.join(job_grain_.split('__')[:len(self.grain_info_cols)])
            else:
                grain_ = '__'.join(job_grain_.split('__'))
            grain_demand_dates = demand_date_ranges.get(grain_)
            demand_data = demand_grain_data.get(grain_)
            demand_data_time = demand_grain_time_data_mapping.get(grain_)
            lead_time_data = lead_time_grain_data.get(grain_)
            if self.ss_modeltype == "with_forecast":
                moq_data = moq_grain_data.get(grain_)
                forecast_data = forecast_snapshots_grain_data.get(grain_)
            else:
                moq_data = False
                forecast_data = False
            '''
            If condition to handle scenarios when the data is not available for demand and rlt data
            '''
            if demand_data is None:
                demand_data = []
                demand_data_time = {}
                start_year = ''
                start_month = ''

                end_year = ''
                end_month = ''
            else:
                start_year = str(grain_demand_dates['min'])[:4]
                start_month = str(grain_demand_dates['min'])[4:6]

                end_year = str(grain_demand_dates['max'])[:4]
                end_month = str(grain_demand_dates['max'])[4:6]

            if lead_time_data is None:
                lead_time_data = []

            grain_data = {'demand_data': demand_data,
                          'demand_data_time': demand_data_time,
                          'lead_time_data': lead_time_data,
                          "fill_rate_desired": [target_service_level_job_grain_data.get(job_grain_)],
                          'grain': grain_,
                          'jobgrain': job_grain_,
                          'user_name': self.user_name,
                          'grain_cols': self.job_grain_cols,
                          'threshold_dd_distribution': self.threshold_dd_distribution,
                          'threshold_lt_distribution': self.threshold_lt_distribution,
                          'grain_date_type': self.grain_date_type,
                          'demand_date_column': self.demand_date_column,
                          'start_month': start_month,
                          'start_year': start_year,
                          'end_month': end_month,
                          'end_year': end_year,
                          'number_of_simulations': self.number_of_simulations,
                          'job_name': self.job_name,
                          'job_id': self.job_id,
                          'project_id': self.projectId,
                          'capacityPoolId': self.capacityPoolId,
                          'service_id': self.service_id,
                          'simulation_method': self.simulation_method
                          }

            if self.ss_modeltype == "with_forecast":
                if moq_data is None:
                    grain_data['moq'] = []
                else:
                    grain_data['moq'] = moq_data
                if forecast_data is None:
                    grain_data["forecast_snapshots"] = []
                else:
                    grain_data["forecast_snapshots"] = forecast_data
                grain_data["ss_modeltype"] = self.ss_modeltype
                grain_data["nlags"] = self.nlags
                grain_data["current_weekmonth"] = self.current_weekmonth
                grain_data["forecast_date_column"] = self.forecast_date_column
                grain_data["error_metric_type"] = self.error_metric_type

            grain_data['message_id'] = self.job_id + "__" + job_grain_
            grain_data['task_id'] = grain_data['message_id']
            # save grain_data
            grain_file_path = save_file(str(grain_data), self.request_folder, grain_data['message_id'],
                                        prefix_dir="grains")
            grain_metadata = {"task_file_path": grain_file_path, "task_id": grain_data["message_id"]}
            self.logger.info(f"Successfully generate data for grain: {job_grain_}")
            all_grain_metadata.append(grain_metadata)

        # save grain_definition
        grain_def_file_name = CommonUtility().generate_uuid()
        grain_metadata_definition = save_file(self.original_inputs, self.request_folder, grain_def_file_name, prefix_dir="metadata")
        self.logger.info("Generated all grain wise data")
        return all_grain_metadata, grain_metadata_definition


def save_file(data, destination_path, unique_id, prefix_dir=None):
        """
        save_file method save the grain metadata into a file on local directory, later uploaded this file to
        remote location.
         @params:
            data:grain metadata for downstream processes or service, this is final consumable data.
            unique_id(str): metadata file name without extention.
            destination_path(str): local folder path for current job, all relevant files will got generated here only.
        @return:
            destination_file(str): local file path for current grain which contains grain metadata.
        """
        # generates filename with its absolute path
        if not os.path.exists(destination_path):
            message = Constant.DIRECTORY_NOT_FOUND_LOG % destination_path
            raise DirectoryNotExistsException(message)
        ## Create Child Dir
        destination_path = CommonUtility.concat_string(destination_path, os.path.sep, prefix_dir)
        if not os.path.exists(destination_path):
            os.makedirs(destination_path)
        destination_file = CommonUtility.concat_string(destination_path, os.path.sep, unique_id, Constant.JSON_FILE_EXT)
        CommonUtility.dumps_json_in_files(destination_file, data)
        return destination_file


def update_value(data_dict, grain_val, key, value):
    grain_data = data_dict.get(grain_val)
    if grain_data:
        grain_data[key] = value
    else:
        grain_data = {key: value}
    data_dict[grain_val] = grain_data

'''

original_input = 
of_simulations": "30"
 	},
 	"jobParams": {
 		"jobId": "0830238a03c548f3a713cbcb3941b02a",
 		"jobName": "jobname1",
 		"user_name": "nicolae.naum@aeratechnology.com"
 	},
 	"serviceId": "1006",
 	"dataParams": {
 		"granularity": [
 			["location", "material", "target_service_level"]
 		],
 		"demand_date_column": "period_end",
 		"threshold_dd_distribution": "4",
 		"threshold_lt_distribution": "10",
 		"grain_date_type": "month",
 		"dataUri": {
 			"demand_history": "DEMAND_HISTORY",
 			"lead_time_history": "RLT_HISTORY",
 			"target_service_level": "TARGET_SERVICE_LEVEL_EXTENDED",
 			"average_demand": "AVERAGE_DEMAND_HISTORY"
 		}
 	}
 }

file_path={
        "demand_history": "/Users/pradeepkumarmahato/aera/PBLOG-3256/7509522f-8d18-4594-a0a2-ac7a32565af6/demand_history.csv",
        "lead_time_history": "/Users/pradeepkumarmahato/aera/PBLOG-3256/7509522f-8d18-4594-a0a2-ac7a32565af6/rlt.csv",
        "average_demand": "/Users/pradeepkumarmahato/aera/PBLOG-3256/7509522f-8d18-4594-a0a2-ac7a32565af6/avg_demand.csv",
        "target_service_level": "/Users/pradeepkumarmahato/aera/PBLOG-3256/7509522f-8d18-4594-a0a2-ac7a32565af6/target_service_level.csv",

}
job_id=None
request_folder=None
self = GrainGenerator(file_path, job_id, request_folder, original_input)


---
original_input = {
    'projectId': '3E79211D_479A_4516_BC8C_3D67EF59868A',
    'capacityPoolId': '3E79211D_479A_4516_BC8C_3D67EF59868A',
    'accessToken': '5dfefc19e71ee2eebb138ad70a030829',
    'isSimulated': False,
    'requestEnvironment': 'dev-ds',
    'userName': 'pradeep.mahato@aeratechnology.com',
    'refreshToken': 'fe0875a3188c7db5503c0f076da64bf4',
    'data': None,
    'modelParams': {
        'number_of_simulations': '30',
        'number_of_lags': '13',
        'current_weekmonth': '202041',
        'error_metric': 'Error'
    },
    'jobParams': {
        'jobId': '1ea6efcd36c24b13942b3064b7225b07',
        'jobName': '20janjob201',
        'user_name': 'pradeep.mahato@aeratechnology.com'
    },
    'serviceId': '1006',
    'dataParams': {
        'granularity': [
            ['target_service_level', 'material']
        ],
        'approach': 'Monte Carlo Simulation With Forecast History',
        'demand_date_column': 'date',
        'forecast_snapshot_date_column': 'forecast_week',
        'threshold_dd_distribution': '10',
        'threshold_lt_distribution': '4',
        'grain_date_type': 'month',
        'dataUri': {
            'demand_history': 'SS_Actual_Sales_Demand_RB',
            'lead_time_history': 'LeadTime_History_RB',
            'target_service_level': 'Target_Service_Level_RB',
            'average_demand': 'Average_Demand_Over_RLT_RB',
            'all_forecast_snapshot': 'Forecast_Snapshot_Data_RB',
            'moq': 'Safety_Stock_MOQ_RB'
        }
    }
}

file_path = original_input['dataParams']['dataUri']
self = GrainGenerator(file_path=file_path, original_input=original_input)

self.target_service_level_filepath = "/Users/pradeepkumarmahato/aera/safetystock_rb/sample_data/97_prod_grainsTargetServiceLevel.csv"
self.demand_history_filepath = "/Users/pradeepkumarmahato/aera/safetystock_rb/sample_data/actual_sales_97_Grains_yw.csv"
self.average_demand_filepath = "/Users/pradeepkumarmahato/aera/safetystock_rb/sample_data/average_demand_over_lt.csv"
self.lead_time_history_filepath ="/Users/pradeepkumarmahato/aera/safetystock_rb/sample_data/RLT_weekly.csv"
self.forecast_snapshots_filepath = "/Users/pradeepkumarmahato/aera/safetystock_rb/sample_data/Combined_Forecast.csv"
self.moq_filepath = "/Users/pradeepkumarmahato/aera/safetystock_rb/sample_data/moq.csv"

'''