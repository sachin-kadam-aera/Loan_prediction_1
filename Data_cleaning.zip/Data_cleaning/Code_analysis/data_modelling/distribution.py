import numpy as np
import pandas as pd
import scipy.stats as st
import random
import math
random.seed(1024)
np.random.seed(1024)
from safety_stock.utility.datetimeseries import create_datetime_series


def check_nonzero(a):
    return [v for v in a if v != 0]


def get_distribution(data, dist_names=["norm", "uniform", "poisson"]):  # "exponnorm"
    '''
    vineet
    '''
    dist_results = []
    params = {}
    poisson = 1
    for dist_name in dist_names:
        if dist_name == "poisson":
            poisson_data = data[data > 0]
            if len(poisson_data) == 0: continue
            mu, n = poisson_data.mean(), len(poisson_data)
            opp_rolls_actual = poisson_data
            opp_rolls_expected = np.random.poisson(mu, n)
            sum_multiple = (np.sum(opp_rolls_actual) / np.sum(opp_rolls_expected))
            opp_rolls_expected_updated = []
            for i in opp_rolls_expected:
                opp_rolls_expected_updated.append(i * sum_multiple)
            res = st.chisquare(opp_rolls_actual, opp_rolls_expected_updated)
            poisson = res.pvalue
        else:
            dist = getattr(st, dist_name)
            param = dist.fit(data)
            params[dist_name] = param
            # Applying the Kolmogorov-Smirnov test
            D, p = st.kstest(data, dist_name, args=param)
            # print("p value for "+dist_name+" = "+str(p))
            dist_results.append((dist_name, p))

    best_dist, best_p = (max(dist_results, key=lambda item: item[1]))
    # store the name of the best fit and its p value

    if poisson < 0.001:
        if best_p < 0.1:
            best_dist = "poisson"
            best_p = poisson
            params["poisson"] = (mu, n)

    # print("Best fitting distribution: "+str(best_dist))
    # print("Best p value: "+ str(best_p))
    # print("Parameters for the best fit: "+ str(params[best_dist]))
    if pd.isnull(best_p): best_p = ''
    return best_dist, best_p, params[best_dist]


def get_demand_distribution(grain_data):
    try:
        answer_dict = {}
        answer_dict['param'] = ""
        answer_dict['dist'] = ""
        answer_dict['p_value'] = ""
        error_msg = ''

        start_month = grain_data["start_month"]
        start_year = grain_data["start_year"]
        end_month = grain_data["end_month"]
        end_year = grain_data["end_year"]
        time_grain = grain_data["grain_date_type"]
        col_time_grain = grain_data["demand_date_column"]

        th_demand = int(grain_data["threshold_dd_distribution"])

        alpha = grain_data['demand_data']
        alpha2 = grain_data['demand_data_time']
        a = grain_data['grain']

        if alpha is None or alpha2 is None:
            raise Exception("No Demand Data ")
        elif len(alpha) == 0:
            raise Exception("No Demand Data ")
        elif sum(alpha) == 0:
            raise Exception("All Demand values are zero")

        TS = create_datetime_series(start_month, start_year, end_month, end_year, time_grain=time_grain)

        p_values = []
        flag_normal = []
        demand_prod_series = {}
        params_list = []

        demand_s = [0] * len(TS)


        # TODO: legacy code, will change later
        for index in range(len(TS)):
            k_alpha = tuple([a] + [TS[index]])
            if k_alpha in alpha2:
                demand_s[index] = alpha2[k_alpha]

        if len(check_nonzero(demand_s)) > th_demand:
            dist, p_value, params = get_distribution(np.array(check_nonzero(demand_s)))
            p_values.append(p_value)
            demand_prod_series[a] = demand_s
            flag_normal.append(dist)
            # print("in data", a)
            params_list.append(params)
            answer_dict['param'] = params
            answer_dict['dist'] = dist
            answer_dict['demand_data'] = check_nonzero(demand_s)
            answer_dict['p_value'] = p_value
            error_msg = ''
        else:
            error_msg = 'Demand Distribution Error: Less than the threshold'

        answer_dict['demand_data'] = check_nonzero(demand_s)
    except Exception as e:
        error_msg += f" \n Demand Distribution Error: {str(e)}"

    answer_dict['error_msg'] = error_msg
    return answer_dict


def get_demand_distribution_ss_v2(grain_data, demand_s):
    try:
        answer_dict = {}
        answer_dict['param'] = ""
        answer_dict['dist'] = ""
        answer_dict['p_value'] = ""
        error_msg = ''
        p_values = []
        flag_normal = []
        params_list = []
        th_demand = int(grain_data["threshold_dd_distribution"])

        if demand_s is None:
            raise Exception("No Demand Data ")

        if len((demand_s)) > th_demand:
            dist, p_value, params = get_distribution(np.array((demand_s)))
            p_values.append(p_value)
            flag_normal.append(dist)
            params_list.append(params)
            answer_dict['param'] = params
            answer_dict['dist'] = dist
            answer_dict['demand_data'] = demand_s
            answer_dict['p_value'] = p_value
            error_msg = ''
        else:
            error_msg = 'Demand Distribution Error: Less than the threshold'

        answer_dict['demand_data'] = (demand_s)
    except Exception as e:
        error_msg += f" \n Demand Distribution Error: {str(e)}"

    answer_dict['error_msg'] = error_msg
    return answer_dict


def get_leadtime_distribution(grain_data):
    try:
        answer_dict = {}
        answer_dict['p_value'] = ''
        answer_dict['LeadTime_Dist'] = ''
        answer_dict['params'] = ''
        answer_dict['leadtime_data'] = []
        error_msg = ''
        Th_LT = int(grain_data["threshold_lt_distribution"])
        alpha = grain_data['lead_time_data']
        if alpha is None:
            raise Exception("No Lead time Data")
        elif len(alpha) == 0:
            raise Exception("No Lead time Data")
        elif sum(alpha) == 0:
            raise Exception("All lead time values are zero")
        p_value = []
        distribution = []
        params = []
        length_data = []
        pr = grain_data['grain']

        ###########
        # Removing outliers
        x_vals = np.asarray(alpha)
        Q1 = np.quantile(x_vals, 0.25)
        Q3 = np.quantile(x_vals, 0.75)
        IQR = Q3 - Q1  # IQR is interquartile range.
        alpha = list(x_vals[(x_vals >= Q1 - 1.5 * IQR) & (x_vals <= Q3 + 1.5 * IQR)])
        ############

        if len(alpha) >= Th_LT:
            a, b, c = get_distribution(np.array(alpha))
            p_value.append(b)
            distribution.append(a)
            params.append(c)
            length_data.append(len(alpha))
            answer_dict['p_value'] = b
            answer_dict['LeadTime_Dist'] = a
            answer_dict['params'] = c
            answer_dict['leadtime_data'] = alpha
            error_msg = ''
        else:
            error_msg = 'Leadtime Distribution Error: Less than the threshold'
    except Exception as e:
        error_msg += f'\n Leadtime Distribution Error: {str(e)}'

    answer_dict['error_msg'] = error_msg
    return answer_dict


def distribution_adjustment(datetime_type):
    if datetime_type == 'month':
        return 30.0
    elif datetime_type == 'week':
        return 7.0
    else:
        return 1.0


def update_demand_distribution(dict_demand, grain_date_type):
    distribution_correction = distribution_adjustment(grain_date_type)
    params = list(dict_demand['param'])

    if dict_demand['dist'] == 'norm':
        params[0] = params[0] / distribution_correction
        params[1] = params[1] / math.sqrt(distribution_correction)
    elif dict_demand['dist'] == 'exponnorm':
        params[1] = params[1] / distribution_correction
        params[2] = params[2] / math.sqrt(distribution_correction)
    elif dict_demand['dist'] == 'poisson':
        params[0] = params[0] / distribution_correction
    elif dict_demand['dist'] == 'uniform':
        old_params = dict_demand['param']
        data = dict_demand['demand_data']
        data = [x / distribution_correction for x in data]
        params = get_distribution(data, ['uniform'])
        new_params = params[2]
        if params[0] is None or params[1] is None:
            new_params = old_params
        params = new_params

    dict_demand['param'] = tuple(params)