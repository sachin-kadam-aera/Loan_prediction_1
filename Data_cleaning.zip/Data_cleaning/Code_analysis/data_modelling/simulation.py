import warnings
warnings.filterwarnings('ignore')
import random
import time
import math
import numpy as np
import pandas as pd
import scipy.stats
from pandas import DataFrame

random.seed(1024)
np.random.seed(1024)


def makescipystatsdist(function, *params):
    def DistributionSciPy():
        return function(*params).rvs(1)
    return DistributionSciPy


def stringToarrayfloats(str1):
    vals = [float(a) for a in str1.split(",")]
    return vals


def make_data(periods=52,
              initial_inventory=10,
              demand_dist=None,
              lead_time_dist=None,
              policy=None):
    """ Return a Pandas dataFrame that contains the details of the inventory simulation.

    Keyword arguments:
    periods           -- numbers of periods of the simulation (default 52 weeks)
    initial_inventory -- initial inventory for the simulation
    demand_dist       -- distribution of the demand (default triangular min=1, mode=2, max=3)
    lead_time_dist    -- distribution of the lead time (default triangular min=1, mode=2, max=3)
    policy            -- dict that contains the policy specs (default = {'method':'Qs', 'arguments': {'Q':3,'s':5}})
    """

    period_lst = np.arange(periods)
    header = [
        "initial_on_hand",
        "demand",
        "fulfilled",
        "lost_sales",
        "final_on_hand",
        "order_due",
        # "initial_inv_pos",
        "final_inv_pos",
        "order",
        "lead_time",
        "replenishment_qty"
    ]

    df = DataFrame(index = period_lst, columns = header).fillna(0)

    # Fill DataFrame
    for period in period_lst:
        ordered_quantity = ordered_lead_time = 0
        sent = False
        if period == 0:
            # df['initial_inv_pos'][period] = initial_inventory
            df['initial_on_hand'][period] = initial_inventory
        else:
            # df['initial_inv_pos'][period] = df['final_inv_pos'][period-1]
            df['initial_on_hand'][period] = df['final_on_hand'][period-1] + \
                                            df['replenishment_qty'][period]

        demand = int(demand_dist())
        # check for negative values
        demand = max(demand, 0)
        lost_sales = 0
        check_fulfillment = df['initial_on_hand'][period] - demand
        if check_fulfillment > 0:
            fulfilled_amount = demand
        else:
            fulfilled_amount = df['initial_on_hand'][period]
            lost_sales = abs(check_fulfillment)

        df['demand'][period] = demand
        df['fulfilled'][period] = fulfilled_amount
        df['lost_sales'][period] = lost_sales
        df['final_on_hand'][period] = df['initial_on_hand'][period] - \
                                        fulfilled_amount
        df['final_inv_pos'][period] = df['final_on_hand'][period] + \
                                df['order'][period] + df['order_due'][period]

        ordered_quantity, ordered_lead_time, \
            sent = placeorder(df['final_inv_pos'][period],
                              policy,
                              lead_time_dist,
                              period)
        if sent:
            df['order'][period] = ordered_quantity
            df['lead_time'][period] = ordered_lead_time
            if ordered_lead_time == 0:
                period_ = period
            else:
                # update the next order due values for lead_amount time
                for period_ in range(period + 1, period + 1 + ordered_lead_time):
                    if period_ >= periods: continue
                    df['order_due'][period_] += ordered_quantity
            if period_ + 1 < periods:
                df['replenishment_qty'][period_ + 1] += ordered_quantity

    return df


def placeorder(final_inv_pos, policy, lead_time_dist, period):
    """Place the order acording the inventory policy:

       Keywords arguments:
       final_inv_pos    -- final inventory position of period
       policy           -- chosen policy Reorder point (Qs, Ss) or Periodic Review (RS, Rss)
       lead_time_dist   -- distribution of lead time
       period           -- actual period
    """
    lead_time = int(lead_time_dist())
    lead_time = max(lead_time, 0)

    # Qs = if we hit the reorder point s, order Q units
    if policy['method'] == 'Qs' and \
       final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['Q'], lead_time, True
    # Ss = if we hit the reorder point s, order S - final inventory pos
    elif policy['method'] == 'Ss' and \
         final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # RS = if we hit the review period and the reorder point S, order S - final inventory pos
    elif policy['method'] == 'RS' and \
         period%policy['arguments']['R'] == 0 and \
         final_inv_pos <= policy['arguments']['S']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # RSs = if we hit the review period and the reorder point s, order S - final inventory pos
    elif policy['method'] == 'RSs' and \
         period%policy['arguments']['R'] == 0 and \
         final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # If the conditions arent satisfied, do not order
    else:
        return 0, 0, False


class Order(object):
    """Object that stores basic data of an order"""
    def __init__(self, quantity, lead_time, sent):
        self.quantity = quantity
        self.lead_time = lead_time
        self.sent = sent # True if the order is already sent


def get_stepvalue(delta_fillrate):
    step_val = 0
    if delta_fillrate >= 70:
        step_val = 12000
    elif 60 <= delta_fillrate < 70:
        step_val = 8000
    elif 50 <= delta_fillrate < 60:
        step_val = 4000
    elif 30 <= delta_fillrate < 50:
        step_val = 2000
    elif 20 <= delta_fillrate < 30:
        step_val = 1000
    elif 15 <= delta_fillrate < 20:
        step_val = 500
    elif 10 <= delta_fillrate < 15:
        step_val = 250
    elif 8 <= delta_fillrate < 10:
        step_val = 150
    elif 5 <= delta_fillrate < 8:
        step_val = 80
    elif 2 <= delta_fillrate < 5:
        step_val = 50
    elif 1 <= delta_fillrate < 2:
        step_val = 20
    elif 0.8 <= delta_fillrate < 1:
        step_val = 5
    elif 0 <= delta_fillrate < 0.8:
        step_val = 1
    return step_val


def safetystock_calculations(demand_dist, lead_time_dist, Q, no_s, target_fill_rate):
    fill_rate_ = []
    count = 0
    starting_ss = 0.3 * Q
    s = int(starting_ss)
    prev_step_value = None
    prev_step_value_repeat_counter = 0
    total_simulation_count = 0
    try:
        while True:
            # import pdb;pdb.set_trace()
            print("Evaluation for s =", s)
            start_time = time.time()
            fill_rate_l = []
            for i in range(no_s):
                Qs_policy = {'method': 'Qs', 'arguments': {'Q': Q, 's': s}}

                period = 360
                df = make_data(period, s + Q, demand_dist, lead_time_dist, Qs_policy)

                total_loss = df['lost_sales'].sum()
                total_demand = df['demand'].sum()
                fill_rate = (total_demand - total_loss) / total_demand
                fill_rate_l.append(fill_rate)
            # import pdb;pdb.set_trace()
            avg_fill = float(sum(fill_rate_l)) / len(fill_rate_l)
            print("FR = ", avg_fill)
            fill_rate_.append(avg_fill)

            delta_fillrate_ = 100.0 * (target_fill_rate - avg_fill) / target_fill_rate
            delta_fillrate = abs(delta_fillrate_)
            step_val = get_stepvalue(delta_fillrate)

            print(f"Count: {count} "
                  f"Totalcount: {total_simulation_count} "
                  f"Target_fill_rate: {target_fill_rate} " 
                  f"Avg_fill_rate: {avg_fill} "
                  f"delta: {delta_fillrate_} "
                  f"step: {step_val}"
                  f"Time take: {time.time() - start_time}")
            # import pdb;pdb.set_trace()
            if avg_fill >= target_fill_rate:
                step_val = -1 * step_val
                if 0 <= delta_fillrate < 0.8 or (s == 0 and 0 <= delta_fillrate < 1):
                    count = count + 1
                if count == 3 or \
                        (total_simulation_count >= 15 and 0 <= delta_fillrate < 1):
                    return s, df, False, ''
            # final stopping criteria
            if total_simulation_count >= 20 or \
                    (total_simulation_count >= 18 and delta_fillrate <= 2) or \
                    (total_simulation_count >= 15 and delta_fillrate <= 1):
                return s, df, False, ''
            print(f"Safetystock: {s}, step_value: {step_val}")

            if prev_step_value is not None:
                if step_val == prev_step_value:
                    prev_step_value_repeat_counter += 1
                else:
                    prev_step_value_repeat_counter = 0
                # change step to come out of the local minima
                if prev_step_value_repeat_counter >= 3:
                    prev_step_value_repeat_counter = 0
                    if total_simulation_count <= 15:
                        if 0 <= delta_fillrate <= 2:
                            step_val *= 20
                        elif 2 < delta_fillrate <= 8:
                            step_val *= 10
                        else:
                            step_val *= 5

            if total_simulation_count >= 15 and 0 <= delta_fillrate < 2:
                step_val /= 2
                step_val = max(1, int(step_val))
            # import pdb;pdb.set_trace()
            s += step_val
            print(f"Safetystock: {s}, step_value: {step_val}")
            prev_step_value = step_val

            # if negative safety stock
            if s < 0:
                s = 0
                prev_step_value_repeat_counter = 0

            total_simulation_count += 1

    except Exception as e:
        # import traceback
        # print(traceback.print_exc())
        return 0, None, True, 'Error in simulations: ' + str(e)


def prepare_distributions(d_dist, demand_, LT_dist, lead_time_):
    demand_dist = makescipystatsdist(getattr(scipy.stats, d_dist), *stringToarrayfloats(demand_))
    lead_time_dist = makescipystatsdist(getattr(scipy.stats, LT_dist), *stringToarrayfloats(lead_time_))
    return demand_dist, lead_time_dist


def carry_simulation(lead_time_, LT_dist, d_dist, demand_, Q, target_fill_rate, no_of_sim):
    try:
        print("no of simulations to be carried per grain = ",no_of_sim)
        lead_time_ = lead_time_.strip("(|)")
        if LT_dist == "poisson":
            lead_time_ = lead_time_.split(",")[0]
        demand_ = demand_.strip("(|)")

        demand_dist, lead_time_dist = prepare_distributions(d_dist, demand_, LT_dist, lead_time_)

        print("Computing SS")
        s, last_simulation, is_error, error_msg = safetystock_calculations(demand_dist, lead_time_dist, Q, no_of_sim, target_fill_rate)
    except Exception as e:
        is_error = True
        error_msg = str(e)
        s = 0
        last_simulation = None
    return s, last_simulation, is_error, error_msg