import traceback
import logging

from safety_stock.data_modelling.model_mapping import python_models

logger_instance = logging.getLogger(__name__)
LOGGER = logging.LoggerAdapter(logger_instance, {})


def python_models_runner(payload):
    """
    For running the desired python model
    """
    is_error = False
    error_reason = 'SU'
    try:
        grain_data = payload
        model_name = grain_data.get('model')
        safety_stock_result = python_models[model_name](grain_data)
    except Exception as e:
        LOGGER.warning(f"Safety stock computation failed. {str(e)}")
        LOGGER.warning(traceback.print_exc())
        is_error = True
        error_reason = str(e)
        safety_stock_result = None

    safety_stock_response = {'is_error': is_error, 'error_reason': error_reason,
                             'safety_stock_result': safety_stock_result}

    return safety_stock_response