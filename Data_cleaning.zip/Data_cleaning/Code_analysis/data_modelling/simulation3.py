import pandas as pd
import numpy as np
import scipy
import time
import math
from .distribution import get_distribution
import copy
import datetime


def make_distribution(name, *params):
    func = getattr(scipy.stats, name)
    return func(*params)


def get_error_distribution(x):
    x_vals = np.asarray(x)
    Q1 = np.quantile(x_vals, 0.25)
    Q3 = np.quantile(x_vals, 0.75)
    IQR = Q3 - Q1  # IQR is interquartile range.
    x_vals = x_vals[(x_vals >= Q1 - 1.5 * IQR) & (x_vals <= Q3 + 1.5 * IQR)]
    name, pvalue, params = get_distribution(x_vals, dist_names=["norm"])
    error_stats = pd.DataFrame([[name, params]], columns=['error_distribution_name', 'error_params'])
    error_stats = {
        'error_distribution_name': name,
        'error_params': params
    }
    return error_stats


class ErrorTypes:
    def __init__(self, error_metric_type):
        self.error_metric_type = error_metric_type
        self.compute_error = self.__get_error_function()
        self.error_correction = self.__get_error_correction_function()

    def __get_error_function(self):

        def adjust_error(actual, forecast):
            error = actual - forecast
            error_multiple = (actual - forecast) / actual
            temp_error = pd.DataFrame({"old_error": error, "error_multiple": abs(error_multiple)})
            temp_error["new_error"] = np.where(temp_error["error_multiple"] > 3,
                                               (temp_error["old_error"] / temp_error["error_multiple"]) * 3,
                                               temp_error["old_error"])
            new_error = temp_error["new_error"]
            return new_error

        def percentage_error(actual, forecast):
            return 100 * (actual - forecast) / actual

        def error(actual, forecast):
            final_error = adjust_error(actual, forecast)
            return final_error

        if self.error_metric_type == 'error':
            return error
        elif self.error_metric_type == 'percentage_error':
            return percentage_error

    def __get_error_correction_function(self):
        def error_correction(forecast, error_dist):
            return forecast + error_dist

        def percentage_error_correction(forecast, error_dist):
            if int(forecast) == 0: return 0
            demand = None
            error_correction_value = (1 - (error_dist / 100.0))
            # taking care of extreme cases
            if error_correction_value <= 0:
                demand = 0
            else:
                demand = forecast / error_correction_value
            return demand

        if self.error_metric_type == 'error':
            return error_correction
        elif self.error_metric_type == 'percentage_error':
            return percentage_error_correction


#######
# Marcelo's request
'''
historical date function marcelo request is part of rb or generic 
line 103-107 
'''


def get_historical_date(start_yw, no_of_weeks):
    start = datetime.datetime.strptime(str(start_yw) + '0', '%Y%W%w')
    end = start - datetime.timedelta(weeks=no_of_weeks)
    final_date = end.strftime('%Y%W')
    return int(final_date)


def iterate_weeks(start_yw, no_of_weeks):
    count = 0
    yw = start_yw
    while count < no_of_weeks:
        if yw % 100 > 52 or yw % 100 == 0:
            yw += 1
            continue
        yield yw
        count += 1
        yw += 1


def get_lags(forecast_weeks):
    start = forecast_weeks[0]
    end = forecast_weeks[-1]
    lag_offset = {}
    for idx, week in enumerate(forecast_weeks):
        lag_offset[week] = idx
    return lag_offset


'''
create lag data horizon is a part of rb or generaic
line 136-137
'''


def create_lag_data(group_data, horizons, selected_lags, error):
    horizon_lags = list(map(int, iterate_weeks(group_data["SNAPSHOT_DATE"].iloc[0], horizons)))
    horizon_dict = get_lags(horizon_lags)
    header = [
        "MATERIAL",
        "LOCATION",
        "DATE",
        "SNAPSHOT_DATE",
        "FORECAST_QUANTITY",
        "grain",
        "DEMAND",
        "Lags",
    ]
    header_len = len(header)
    col_name2idx = {name: x for name, x in zip(header, range(header_len))}
    # df_list = group_data[header[:-1]].head(selected_lags+1).values.tolist()
    # df_list = group_data[group_data["DATE"] <= [name for name, age in horizon_dict.items() if age == 0][0] + selected_lags].values.tolist()
    df_list = group_data[header[:-1]][group_data["DATE"].isin(horizon_lags[0:selected_lags + 1])].values.tolist()

    if len(df_list) != selected_lags + 1:
        final_df = pd.DataFrame(columns=header, dtype=object)
    else:
        for key, value in horizon_dict.items():
            data_index = "NA"
            for index, row in enumerate(df_list):
                Mat = row[col_name2idx["MATERIAL"]]
                Loc = row[col_name2idx["LOCATION"]]
                SW = row[col_name2idx["SNAPSHOT_DATE"]]
                grain = row[col_name2idx["grain"]]
                if key == row[col_name2idx["DATE"]]:
                    data_index = index
                    break
            if data_index != "NA":
                df_list[index].append(value)
            else:
                df_list.append([Mat, Loc, key, SW, np.nan, grain, np.nan, value])

        # if any of the demand or forecast data is missing in lag 0 to lag 4 remove the snapshot
        final_df = pd.DataFrame(df_list, columns=header)
        if final_df["DEMAND"].head(selected_lags + 1).isnull().any() or final_df["FORECAST_QUANTITY"].head(
                selected_lags + 1).isnull().any():
            final_df = pd.DataFrame(columns=header, dtype=object)
        else:
            final_df['lag'] = final_df.apply(lambda x: "lag" + str(x["Lags"]), axis=1)
            final_df = final_df.sort_values(by='Lags', ascending=True)
            final_df['error'] = error.compute_error(final_df['DEMAND'],
                                                    final_df['FORECAST_QUANTITY'])
            final_df['error'] = final_df['error'].replace([np.inf, -np.inf], np.nan)

            ###### new changes as per Marcelo

            '''
            final error data frame as per marcelo requiest is a part of rb or generic
            line 190-198
            '''
            avg_demand = final_df["DEMAND"].dropna().mean()
            avg_forecast = final_df["FORECAST_QUANTITY"].dropna().mean()
            remaining_error = avg_demand - avg_forecast
            error_multiple = (avg_demand - avg_forecast) / avg_demand
            if abs(error_multiple) > 3:
                remaining_error = remaining_error / abs(error_multiple) * 3
            final_df['DEMAND'] = final_df['DEMAND'].fillna(avg_demand)
            final_df['FORECAST_QUANTITY'] = final_df['FORECAST_QUANTITY'].fillna(avg_forecast)
            final_df['error'] = final_df['error'].fillna(remaining_error)
            ######
            # final_df['error'] = final_df['error'].fillna(method='ffill')
            # final_df['error'] = final_df['error'].fillna(method='bfill')

            final_df = final_df.drop(['Lags'], axis=1)
    return final_df


#######

#
# def create_lag_data(group_data, all_lag_values, error):
#     group_data['lag'] = ['lag' + str(i) for i in range(group_data.shape[0])]
#     group_data = group_data[group_data['lag'].isin(all_lag_values)]
#     group_data['error'] = error.compute_error(group_data['DEMAND'],
#                                               group_data['FORECAST_QUANTITY'])
#     group_data['error'] = group_data['error'].replace([np.inf, -np.inf], np.nan)
#     group_data['error'] = group_data['error'].fillna(method='ffill')
#     group_data['error'] = group_data['error'].fillna(method='bfill')
#     # group_data = pd.concat([group_data,pd.concat([group_data[-1:]]*repeat_lags)])
#     # group_data['error'] = group_data['error'].fillna(value=100)
#     return group_data


def get_lag_offset(nlags):
    start = 0
    end = nlags
    lag_offset = {}
    for idx in range(start, end + 1):
        lag_offset[idx] = 'lag' + str(idx)
    return lag_offset


def placeorder(final_inv_pos, policy, lead_time_dist, period, moq):
    """Place the order acording the inventory policy:

       Keywords arguments:
       final_inv_pos    -- final inventory position of period
       policy           -- chosen policy Reorder point (Qs, Ss) or Periodic Review (RS, Rss)
       lead_time_dist   -- distribution of lead time
       period           -- actual period
    """
    lead_time = int(math.ceil(lead_time_dist.rvs(1)[0]))
    lead_time = max(lead_time, 0)

    # Qs = if we hit the reorder point s, order Q units
    if policy['method'] == 'Qs' and \
            final_inv_pos <= policy['arguments']['s']:
        return max(moq, policy['arguments']['Q']), lead_time, True
    # Ss = if we hit the reorder point s, order S - final inventory pos
    elif policy['method'] == 'Ss' and \
            final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # RS = if we hit the review period and the reorder point S, order S - final inventory pos
    elif policy['method'] == 'RS' and \
            period % policy['arguments']['R'] == 0 and \
            final_inv_pos <= policy['arguments']['S']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # RSs = if we hit the review period and the reorder point s, order S - final inventory pos
    elif policy['method'] == 'RSs' and \
            period % policy['arguments']['R'] == 0 and \
            final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # If the conditions arent satisfied, do not order
    else:
        return 0, 0, False


class Order(object):
    """Object that stores basic data of an order"""

    def __init__(self, quantity, lead_time, sent):
        self.quantity = quantity
        self.lead_time = lead_time
        self.sent = sent  # True if the order is already sent


def get_stepvalue(delta_fillrate, Q):
    step_val = 0
    if delta_fillrate >= 50:
        step_val = 1.2 * Q
    elif 40 <= delta_fillrate < 50:
        step_val = Q
    elif 30 <= delta_fillrate < 40:
        step_val = 0.8 * Q
    elif 20 <= delta_fillrate < 30:
        step_val = 0.6 * Q
    elif 15 <= delta_fillrate < 20:
        step_val = 0.5 * Q
    elif 10 <= delta_fillrate < 15:
        step_val = 0.4 * Q
    elif 8 <= delta_fillrate < 10:
        step_val = 0.2 * Q
    elif 5 <= delta_fillrate < 8:
        step_val = 0.1 * Q
    elif 2 <= delta_fillrate < 5:
        step_val = 0.05 * Q
    elif 1 <= delta_fillrate < 2:
        step_val = 0.01 * Q
    elif 0 <= delta_fillrate < 1:
        step_val = 1
    step_val = max(1, int(step_val))
    return step_val


def validate_step_value(s, step_value, max_ss):
    while step_value > 0 and s + step_value >= max_ss:
        step_value = int(step_value / 4)
    step_value = max(1, step_value)
    return step_value


def make_data_bs(periods,
                 initial_inventory,
                 future_forecast,
                 error_distribution_generator,
                 lag_offset,
                 moq,
                 last_lag_val,
                 error,
                 lead_time_dist,
                 date_type
                 ):
    header = [
        "inventory_cycle",
        "replenishment_qty",
        "initial_on_hand",
        "demand",
        "demand_with_backorder",
        "fulfilled",
        "lost_sales",
        "serviced",
        "final_on_hand",
        "backorders",
        "initial_inv_pos",
        "final_inv_pos",
        "order",
        "order_qty",
        "order_due",
        "lead_time"
    ]
    header_len = len(header)
    col_name2idx = {name: x for name, x in zip(header, range(header_len))}
    # if date_type == 'week':
    #     df = [[0] * header_len for _ in range(periods*7)]
    # else:
    #     df = [[0] * header_len for _ in range(periods*30)]
    inventory_cycle_count = 0
    df = [[0] * header_len for _ in range(periods)]
    # initial_inventory = s + Q
    # future_forecast = forecast_dict
    #
    # if date_type == 'week':
    #     repeat_count = 7
    #     total_days = periods * 7
    # elif date_type == 'month':
    #     repeat_count = 30
    #     total_days = periods * 30
    # repeat_count = 1
    # total_days = periods
    # start_count = 0

    # For weekly/monthly
    for period in range(periods):

        if period == 0:
            df[period][col_name2idx['initial_on_hand']] = initial_inventory
        else:
            df[period][col_name2idx['initial_on_hand']] = df[period - 1][col_name2idx['final_on_hand']] + \
                                                          df[period][col_name2idx['replenishment_qty']]
        lag_val = lag_offset[period]
        if lag_val == last_lag_val:
            break

        if df[period][col_name2idx['replenishment_qty']] > 0:
            inventory_cycle_count += 1

        forecast = future_forecast[lag_val]['FORECAST_QUANTITY']
        # forecast = future_forecast[lag_val]['Daily_forecast_quantity']
        error_dist = error_distribution_generator[lag_val].rvs(1)[0]

        demand = error.error_correction(forecast, error_dist)
        demand = max(demand, 0)
        # demand = max(moq, demand)
        demand = int(math.ceil(demand))

        lost_sales = 0
        serviced = 1

        df[period][col_name2idx['demand']] = demand

        # Reorder value to be considered as max of MOQ and order quantity
        ROV = max(moq, demand)

        # ROV = demand

        demand += df[period - 1][col_name2idx['backorders']]
        df[period][col_name2idx['demand_with_backorder']] = demand
        check_fulfillment = df[period][col_name2idx['initial_on_hand']] - demand

        if check_fulfillment >= 0:
            fulfilled_amount = demand
        else:
            fulfilled_amount = df[period][col_name2idx['initial_on_hand']]
            lost_sales = abs(check_fulfillment)
            serviced = 0

        df[period][col_name2idx['fulfilled']] = fulfilled_amount
        df[period][col_name2idx['lost_sales']] = lost_sales
        df[period][col_name2idx['serviced']] = serviced

        df[period][col_name2idx['final_on_hand']] = max(0,
                                                        df[period][col_name2idx['initial_on_hand']] - fulfilled_amount)

        # backorders
        if lost_sales > 0:
            df[period][col_name2idx['backorders']] += lost_sales
            if period > 0:
                df[period][col_name2idx['backorders']] = lost_sales

        order = 1
        order_leadtime = max(1, int(math.ceil(lead_time_dist.rvs(1)[0])))
        df[period][col_name2idx['order_qty']] = ROV
        for period_ in range(period, period + order_leadtime):
            if period_ >= periods: continue
            df[period_][col_name2idx['order_due']] += ROV

        # special case for leadtime 1
        '''
        if order_leadtime == 0:
            period_ = period

            # update the final on hand
            new_foh = df[period][col_name2idx['final_on_hand']] + ROV
            fulfilled_backorders = new_foh - df[period][col_name2idx['backorders']]
            if fulfilled_backorders > 0:
                df[period][col_name2idx['final_on_hand']] = fulfilled_backorders
                df[period][col_name2idx['backorders']] = 0
            else:
                df[period][col_name2idx['final_on_hand']] = 0
                df[period][col_name2idx['backorders']] = abs(fulfilled_backorders)
            '''

        if period_ + 1 < periods:
            df[period_ + 1][col_name2idx['replenishment_qty']] += ROV

        df[period][col_name2idx['inventory_cycle']] = f"{inventory_cycle_count}"

        df[period][col_name2idx['order']] = order
        df[period][col_name2idx['lead_time']] = order_leadtime

        df[period][col_name2idx['final_inv_pos']] = df[period][col_name2idx['final_on_hand']] + \
                                                    df[period][col_name2idx['order_due']] - df[period][
                                                        col_name2idx['backorders']]

    # FOR DAILY
    #     for period in range(periods):
    #         for row in range(start_count, start_count + repeat_count):
    #             # period,row  = 0,0
    #             if row == 0:
    #                 df[row][col_name2idx['initial_on_hand']] = initial_inventory
    #             else:
    #                 df[row][col_name2idx['initial_on_hand']] = df[row - 1][col_name2idx['final_on_hand']] + \
    #                                                           df[row][col_name2idx['replenishment_qty']]
    #             lag_val = lag_offset[period]
    #             if lag_val == last_lag_val:
    #                 break
    #
    #             if df[row][col_name2idx['replenishment_qty']] > 0:
    #                 inventory_cycle_count += 1
    #
    #             # forecast = future_forecast[lag_val]['FORECAST_QUANTITY']
    #             forecast = future_forecast[lag_val]['Daily_forecast_quantity']
    #
    #             error_dist = error_distribution_generator[lag_val].rvs(1)[0]
    #             # if error_distribution[lag_val]["error_distribution_name"] == "norm":
    #             #     lb = error_distribution[lag_val]["error_params"][0] - 1.96 * (
    #             #         error_distribution[lag_val]["error_params"][1] / np.sqrt(error_distribution[lag_val]["length"]))
    #             #     avg_error = error_distribution[lag_val]["error_params"][0]
    #             #     ub = error_distribution[lag_val]["error_params"][0] + 1.96 * (
    #             #         error_distribution[lag_val]["error_params"][1] / np.sqrt(error_distribution[lag_val]["length"]))
    #             #     if error_dist > lb and error_dist < avg_error:
    #             #         error_dist = avg_error
    #             #     elif error_dist > avg_error and error_dist < ub:
    #             #         error_dist = ub
    #             # import pdb; pdb.set_trace()
    #
    #             # print("lag_val", lag_val,"error_dist",error_dist,"Forecast",forecast)
    #             demand = error.error_correction(forecast, error_dist)
    #             demand = max(demand, 0)
    #             # demand = max(moq, demand)
    #             demand = int(math.ceil(demand))
    #
    #             lost_sales = 0
    #             serviced = 1
    #
    #             df[row][col_name2idx['demand']] = demand
    #             df[row][col_name2idx['forecast']] = forecast
    #             df[row][col_name2idx['error']] = error_dist
    #             df[row][col_name2idx['lag']] = lag_val
    #
    #             # Reorder value to be considered as max of MOQ and order quantity
    #             ROV = max(moq,demand)
    #
    #             # ROV = demand
    #
    #             demand += df[row - 1][col_name2idx['backorders']]
    #             df[row][col_name2idx['demand_with_backorder']] = demand
    #             check_fulfillment = df[row][col_name2idx['initial_on_hand']] - demand
    #
    #             if check_fulfillment >= 0:
    #                 fulfilled_amount = demand
    #             else:
    #                 fulfilled_amount = df[row][col_name2idx['initial_on_hand']]
    #                 lost_sales = abs(check_fulfillment)
    #                 serviced = 0
    #
    #             df[row][col_name2idx['fulfilled']] = fulfilled_amount
    #             df[row][col_name2idx['lost_sales']] = lost_sales
    #             df[row][col_name2idx['serviced']] = serviced
    #
    #             df[row][col_name2idx['final_on_hand']] = max(0,
    #                                                             df[row][
    #                                                                 col_name2idx['initial_on_hand']] - fulfilled_amount)
    #
    #             # backorders
    #             if lost_sales > 0:
    #                 df[row][col_name2idx['backorders']] += lost_sales
    #                 if row > 0:
    #                     df[row][col_name2idx['backorders']] = lost_sales
    #
    #             order = 1
    #             order_leadtime = max(1, int(math.ceil(lead_time_dist.rvs(1)[0])))
    #             df[row][col_name2idx['order_qty']] = ROV
    #             # import pdb;pdb.set_trace()
    #             for period_ in range(row, row + order_leadtime):
    #                 if period_ >= total_days: continue
    #                 df[period_][col_name2idx['order_due']] += ROV
    #
    #             # special case for leadtime 1
    #             '''
    #             if order_leadtime == 0:
    #                 period_ = period
    #
    #                 # update the final on hand
    #                 new_foh = df[period][col_name2idx['final_on_hand']] + ROV
    #                 fulfilled_backorders = new_foh - df[period][col_name2idx['backorders']]
    #                 if fulfilled_backorders > 0:
    #                     df[period][col_name2idx['final_on_hand']] = fulfilled_backorders
    #                     df[period][col_name2idx['backorders']] = 0
    #                 else:
    #                     df[period][col_name2idx['final_on_hand']] = 0
    #                     df[period][col_name2idx['backorders']] = abs(fulfilled_backorders)
    #                 '''
    #
    #             if period_ + 1 < total_days:
    #                 df[period_ + 1][col_name2idx['replenishment_qty']] += ROV
    #
    #             df[row][col_name2idx['inventory_cycle']] = f"{inventory_cycle_count}"
    #
    #             df[row][col_name2idx['order']] = order
    #             df[row][col_name2idx['lead_time']] = order_leadtime
    #
    #             df[row][col_name2idx['final_inv_pos']] = df[row][col_name2idx['final_on_hand']] + \
    #                                                         df[row][col_name2idx['order_due']] - df[row][
    #                                                             col_name2idx['backorders']]
    #
    #         if date_type == 'week':
    #             start_count = start_count + 7
    #         elif date_type == 'month':
    #             start_count = start_count + 30

    #           if period_ + 1 < total_days:
    #                df[period_ + 1][col_name2idx['replenishment_qty']] += ROV
    #
    #            df[row][col_name2idx['inventory_cycle']] = f"{inventory_cycle_count}"
    #
    #            df[row][col_name2idx['order']] = order
    #            df[row][col_name2idx['lead_time']] = order_leadtime
    #
    #            df[row][col_name2idx['final_inv_pos']] = df[row][col_name2idx['final_on_hand']] + \
    #                                                        df[row][col_name2idx['order_due']] - df[row][
    #                                                            col_name2idx['backorders']]
    #
    #        if date_type == 'week':
    #            start_count = start_count + 7
    #        elif date_type == 'month':
    #            start_count = start_count + 30

    data = pd.DataFrame(df, columns=header)
    # data.to_csv("/Users/nareshjamnani/Documents/SafetyStock/RB/v0/samplefolder/simulation.csv", index=False)
    return data


def make_data(periods,
              initial_inventory,
              future_forecast,
              error_distribution_generator,
              lag_offset,
              moq,
              last_lag_val,
              error,
              lead_time_dist,
              date_type,
              ss,
              horizon,
              roq=1
              ):
    header = [
        "inventory_start",
        "inventory_end",
        "replenishment_qty",
        "initial_on_hand",
        "demand",
        "demand_with_backorder",
        "fulfilled",
        "lost_sales",
        "serviced",
        "final_on_hand",
        "backorders",
        "initial_inv_pos",
        "final_inv_pos",
        "order_point",
        "order",
        "order_qty",
        "order_due",
        "lead_time"
    ]

    header_len = len(header)
    col_name2idx = {name: x for name, x in zip(header, range(header_len))}
    df = [[0] * header_len for _ in range(periods)]
    inventory_cycle_count = 0
    roq = initial_inventory * roq
    ROP = ss  # initial_inventory + ss
    ROV = roq
    order_upto = copy.deepcopy(initial_inventory)

    # For weekly/monthly
    for period in range(periods):

        if period == 0:
            df[period][col_name2idx['initial_on_hand']] = initial_inventory
        else:
            df[period][col_name2idx['initial_on_hand']] = df[period - 1][col_name2idx['final_on_hand']] + \
                                                          df[period][col_name2idx['replenishment_qty']]
        # lag_val = lag_offset[period]
        # if lag_val == last_lag_val:
        #     break
        lag_period = period % horizon
        lag_val = lag_offset[lag_period]
        if (lag_val == last_lag_val) & (period == periods - 1):
            break

        if df[period][col_name2idx['replenishment_qty']] > 0:
            inventory_cycle_count += 1

        forecast = future_forecast[lag_val]['FORECAST_QUANTITY']
        # forecast = future_forecast[lag_val]['Daily_forecast_quantity']
        error_dist = error_distribution_generator[lag_val].rvs(1)[0]

        demand = error.error_correction(forecast, error_dist)
        demand = max(demand, 0)
        # demand = max(moq, demand)
        demand = int(math.ceil(demand))

        # df[period][col_name2idx['forecast']] = forecast
        # df[period][col_name2idx['error']] = error_dist
        # df[period][col_name2idx['lag']] = lag_val

        lost_sales = 0
        serviced = 1

        df[period][col_name2idx['demand']] = demand

        # Reorder value to be considered as max of MOQ and order quantity
        # ROV = max(moq,demand)
        # if demand ==0:
        #     ROV = demand

        demand += df[period - 1][col_name2idx['backorders']]
        df[period][col_name2idx['demand_with_backorder']] = demand
        check_fulfillment = df[period][col_name2idx['initial_on_hand']] - demand

        if check_fulfillment >= 0:
            fulfilled_amount = demand
        else:
            fulfilled_amount = df[period][col_name2idx['initial_on_hand']]
            lost_sales = abs(check_fulfillment)
            serviced = 0

        df[period][col_name2idx['fulfilled']] = fulfilled_amount
        df[period][col_name2idx['lost_sales']] = lost_sales
        df[period][col_name2idx['serviced']] = serviced
        df[period][col_name2idx['order_point']] = ROP

        df[period][col_name2idx['final_on_hand']] = max(0,
                                                        df[period][col_name2idx['initial_on_hand']] - fulfilled_amount)

        # backorders
        if lost_sales > 0:
            df[period][col_name2idx['backorders']] += lost_sales
            if period > 0:
                df[period][col_name2idx['backorders']] = lost_sales

        if period == 0:
            df[period][col_name2idx['initial_inv_pos']] = df[period][col_name2idx['final_on_hand']]
        else:
            df[period][col_name2idx['initial_inv_pos']] = df[period][col_name2idx['final_on_hand']] + \
                                                          df[period][col_name2idx['order_due']] - df[period][
                                                              col_name2idx['backorders']]
        order = 0
        order_leadtime = 0
        if df[period][col_name2idx['initial_inv_pos']] <= ROP:
            # ROV = max(moq, ROP - df[period][col_name2idx['initial_inv_pos']])

            ROV = max(moq, order_upto - df[period][col_name2idx['initial_inv_pos']])
            if period - 1 > 0:
                if df[period - 1][col_name2idx['inventory_end']] == 0:
                    df[period - 1][col_name2idx['inventory_end']] = f"inv_{inventory_cycle_count}"
                else:
                    tval = df[period - 1][col_name2idx['inventory_end']]
                    df[period - 1][col_name2idx['inventory_end']] = (
                            tval + " " + f"inv_{inventory_cycle_count}").strip()
            inventory_cycle_count += 1
            order = 1

            if df[period][col_name2idx['inventory_start']] == 0:
                df[period][col_name2idx['inventory_start']] = f"inv_{inventory_cycle_count}"
            else:
                tval = df[period - 1][col_name2idx['inventory_start']]
                df[period - 1][col_name2idx['inventory_start']] = (
                        tval + " " + f"inv_{inventory_cycle_count}").strip()

            order_leadtime = max(1, int(math.ceil(lead_time_dist.rvs(1)[0])))
            df[period][col_name2idx['order_qty']] = ROV
            #             if period ==3:
            #                 import pdb;pdb.set_trace()
            #             print("Period:", period, "order_leadtime:",order_leadtime)
            for period_ in range(period, period + order_leadtime):
                #                 print("Period_:",period_)
                if period_ >= periods: continue
                df[period_][col_name2idx['order_due']] += ROV
            if period_ + 1 < periods:
                df[period_ + 1][col_name2idx['replenishment_qty']] += ROV

        df[period][col_name2idx['order']] = order
        df[period][col_name2idx['lead_time']] = order_leadtime
        if order > 0:
            df[period][col_name2idx['final_inv_pos']] = df[period][col_name2idx['initial_inv_pos']] + ROV
        else:
            df[period][col_name2idx['final_inv_pos']] = df[period][col_name2idx['initial_inv_pos']]

    data = pd.DataFrame(df, columns=header)
    # data.to_csv(f"/Users/sachinkadam/Ticket/NOVA-2612/Test/simulation{period}.csv", index=False)
    return data


def safetystock_calculation(target_fill_rate,
                            Q,
                            mean_demand,
                            mean_lt,
                            no_s,
                            nlags,
                            forecast_dict,
                            error_distribution_generator,
                            lag_offset,
                            error,
                            moq,
                            lead_time_dist,
                            date_type,
                            horizon,
                            monte_carlo_sims):
    # modelling parameters
    fill_rate_ = []
    count = 0
    starting_ss = int(0.6 * Q)
    s = int(starting_ss)
    prev_step_value = None
    prev_step_value_repeat_counter = 0
    total_simulation_count = 0
    max_ss_value = int(3.5 * Q)
    max_simulation_count = no_s
    best_ss_value = 0
    best_loss_value = np.inf
    best_simulation = None
    best_fillrate = 0
    all_delta_fillrate = []
    stop_level1 = int(0.75 * no_s)
    stop_level2 = int(0.9 * no_s)

    # last_lag_val = f"lag{nlags+1}"
    last_lag_val = f"lag{horizon}"

    try:
        while True:
            # import pdb;pdb.set_trace()
            print("Evaluation for s =", s)
            initial_inv = s

            '''
            review_period and for condition which need to add in a generic
            line 836-837
            '''
            review_period = 1
            for day in range(int(np.ceil(mean_lt)) + review_period):
                initial_inv += forecast_dict[f'lag{day}']["FORECAST_QUANTITY"]
            start_time = time.time()
            fill_rate_l = []
            for i in range(monte_carlo_sims):
                Qs_policy = {'method': 'Qs', 'arguments': {'Q': Q, 's': s}}

                # periods = nlags+1
                periods = horizon * 40

                df = make_data(periods, initial_inv,  # s+Q,
                               forecast_dict,
                               error_distribution_generator,
                               lag_offset,
                               moq,
                               last_lag_val,
                               error,
                               lead_time_dist,
                               date_type,
                               s,
                               horizon,
                               roq=1
                               )
                # df.to_csv(f"/Users/sachinkadam/Ticket/NOVA-2612/Test/{i}.csv")
                service_level = df['serviced'].mean()
                fill_rate_l.append(service_level)
            # import pdb;pdb.set_trace()
            avg_fill = float(sum(fill_rate_l)) / len(fill_rate_l)
            print("Simulation SL = ", avg_fill)
            # preventing from having high safety stock values
            # if int(avg_fill) == 1:
            #     s = int(s / 2)
            #     continue

            fill_rate_.append(avg_fill)

            delta_fillrate_ = 100.0 * (target_fill_rate - avg_fill) / target_fill_rate
            delta_fillrate = abs(delta_fillrate_)
            step_val = get_stepvalue(delta_fillrate, mean_demand)
            # TODO redeploy in prod, comment the print statements
            print(f" Count: {count} "
                  f" Totalcount: {total_simulation_count} "
                  f" Target_fill_rate: {target_fill_rate} "
                  f" Avg_fill_rate: {avg_fill} "
                  f" delta: {delta_fillrate_} "
                  f" ss : {s} "
                  f" best ss: {best_ss_value} "
                  f" step: {step_val}"
                  f" Prev step value: {prev_step_value}"
                  f" Prev step value: {prev_step_value_repeat_counter}"
                  f" Time take: {time.time() - start_time}")
            # import pdb;pdb.set_trace()
            # --- stopping criteria
            all_delta_fillrate.append(delta_fillrate)

            if (delta_fillrate >= 0) & (best_loss_value >= delta_fillrate):
                best_fillrate = avg_fill
                best_loss_value = delta_fillrate
                best_ss_value = s
                best_simulation = df

            # df.to_csv(f"/Users/sachinkadam/Ticket/NOVA-2612/Test/{total_simulation_count}.csv")

            if avg_fill >= target_fill_rate:
                step_val = -1 * step_val
                if 0 <= delta_fillrate < 1 or (s == 0 and 0 <= delta_fillrate < 1):
                    count = count + 1
                if count == 5 or \
                        (total_simulation_count >= stop_level1 and 0 <= delta_fillrate < 1):
                    print(best_ss_value, best_simulation, False, '', round(100 * best_fillrate, 4),
                          total_simulation_count, sep='\n')
                    return best_ss_value, best_simulation, False, '', round(100 * best_fillrate,
                                                                            4), total_simulation_count
            # final stopping criteria
            if total_simulation_count >= max_simulation_count or \
                    (total_simulation_count >= stop_level2 and delta_fillrate <= 2) or \
                    (total_simulation_count >= stop_level1 and delta_fillrate <= 1) or \
                    (total_simulation_count >= stop_level2 and np.mean(all_delta_fillrate[-5:]) <= 0.5):
                print(best_ss_value, best_simulation, False, '', round(100 * best_fillrate, 4), total_simulation_count,
                      sep='\n')
                return best_ss_value, best_simulation, False, '', round(100 * best_fillrate, 4), total_simulation_count
            # ---
            print(f"Safetystock: {s}, step_value: {step_val}")
            # import pdb;pdb.set_trace()
            # if step_val > 0:
            #     step_val = validate_step_value(s, step_val, max_ss_value)

            if prev_step_value is not None:
                if step_val == prev_step_value:
                    prev_step_value_repeat_counter += 1
                else:
                    prev_step_value_repeat_counter = 0
                # change step to come out of the local minima
                if prev_step_value_repeat_counter >= 3:
                    prev_step_value_repeat_counter = 0
                    if 0 <= delta_fillrate <= 1:
                        step_val *= 10
                    elif 1 < delta_fillrate <= 3:
                        step_val *= 15
                    elif 3 < delta_fillrate <= 10:
                        step_val *= 20
                    elif total_simulation_count >= stop_level1:
                        step_val *= 20
                    else:
                        step_val *= 50

            if step_val > 0:
                step_val = validate_step_value(s, step_val, max_ss_value)

            print(f"Safetystock: {s}, step_value: {step_val}, prev_step_value: {prev_step_value}")

            s += step_val

            # if negative safety stock
            if s < 0:
                s = 0
                prev_step_value_repeat_counter = 0
            prev_step_value = step_val
            total_simulation_count += 1

    except Exception as e:
        import traceback
        print(traceback.print_exc())
        return 0, None, True, 'Error in simulations: ' + str(e), 0, 0


def carry_simulation(grain_error_distribution,
                     forecast_data,
                     dict_leadtime,
                     val,
                     moq,
                     mean_demand,
                     mean_lt,
                     error,
                     selected_lags,
                     number_of_simulations,
                     current_weekmonth,
                     grain_date_type,
                     horizon
                     ):
    try:
        Q = mean_demand * mean_lt
        no_s = number_of_simulations
        target_fill_rate = val
        moq = int(moq)
        forecast_data = forecast_data
        error_distribution = grain_error_distribution
        nlags = selected_lags
        date_type = grain_date_type
        current_weekmonth = current_weekmonth

        lt_name, lt_params = dict_leadtime['LeadTime_Dist'], dict_leadtime['params']

        if lt_name == "poisson":
            lt_params = (lt_params[0],)

        lead_time_dist = make_distribution(lt_name, *lt_params)
        # lag_offset = get_lag_offset(nlags)
        lag_offset = get_lag_offset(horizon - 1)
        error_distribution_generator = {}
        for k, v in error_distribution.items():
            error_distribution_generator[k] = make_distribution(v['error_distribution_name'], *v['error_params'])

        forecast_data1 = forecast_data
        forecast_dict = {}

        for i in range(horizon):
            # if i > (nlags):
            #     forecast_dict['lag' + str(i)] = {'DATE': forecast_dict['lag' + str(i - 1)]['DATE'] + 1,
            #                                      'FORECAST_QUANTITY': forecast_dict['lag' + str(i - 1)][
            #                                          'FORECAST_QUANTITY']}
            # else:
            forecast_dict['lag' + str(i)] = forecast_data1[i]

        s, last_simulation, is_error, error_msg, last_fillrate, simulation_count = safetystock_calculation(
            target_fill_rate,
            Q,
            mean_demand,
            mean_lt,
            no_s,
            nlags,
            forecast_dict,
            error_distribution_generator,
            lag_offset,
            error,
            moq,
            lead_time_dist,
            date_type,
            horizon,
            monte_carlo_sims=100)
    except Exception as e:
        is_error = True
        error_msg = str(e)
        simulation_count = 0
        last_fillrate = 0
        s = 0
        last_simulation = None
    return s, last_simulation, is_error, error_msg, last_fillrate, simulation_count