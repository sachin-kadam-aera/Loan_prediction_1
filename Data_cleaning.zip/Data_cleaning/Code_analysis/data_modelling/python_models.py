import pandas as pd
import warnings

warnings.filterwarnings('ignore')
import random
import numpy as np
import time

from .distribution import get_demand_distribution, get_demand_distribution_ss_v2
from .distribution import update_demand_distribution
from .distribution import get_leadtime_distribution
from .simulation import carry_simulation as simulation1
from .simulation2 import carry_simulation as simulation2
from .simulation3 import carry_simulation as simulation3
from .simulation3 import create_lag_data, get_error_distribution, ErrorTypes, iterate_weeks, get_historical_date
from safety_stock.utility.constant import Constant
from safety_stock.utility.simulation_config import SimulationConfig

random.seed(1024)
np.random.seed(1024)


def ss_simulation1(grain_data):
    start_time = time.time()
    try:
        number_of_simulations = int(grain_data['number_of_simulations'].strip())
    except:
        number_of_simulations = 100

    vals = grain_data["fill_rate_desired"]
    Q_value = grain_data["Q_value"]

    if Q_value == "not available":
        Q_value = 0
    else:
        Q_value = float(Q_value)

    answer_dict = {}
    all_last_simulation = []
    error_msg = ''
    get_distribution_flag = False

    for val in vals:
        answer_dict[val] = "-"
        last_simulation = None
        try:
            if val == 0:
                error_msg += f' \n Target Service level for {val}, Skipping '
            else:
                if not get_distribution_flag:
                    dict_demand = get_demand_distribution(grain_data)
                    dict_leadtime = get_leadtime_distribution(grain_data)
                    # update the distribution to days
                    if dict_demand['error_msg'] == '' and dict_demand['dist'] != '':
                        update_demand_distribution(dict_demand, grain_data['grain_date_type'])
                    lead_time_ = str(dict_leadtime['params'])
                    LT_dist = str(dict_leadtime['LeadTime_Dist'])
                    d_dist = str(dict_demand['dist'])
                    demand_ = str(dict_demand['param'])
                    get_distribution_flag = True
                    error_msg += dict_demand['error_msg'] + ' \n ' + dict_leadtime['error_msg']
                    error_msg += error_msg.strip()

                if dict_demand['dist'] != "" and dict_leadtime != {} and dict_leadtime['LeadTime_Dist'] != '':
                    exp_fill = val * 0.01
                    Q = Q_value
                    print('Carrying Simulation')
                    s, last_simulation, is_error, error_message = simulation1(lead_time_, LT_dist, d_dist, demand_, Q,
                                                                              exp_fill, number_of_simulations)
                    print("Finised Simulation")
                    print("####### safety stock for FR = ", exp_fill, s)
                    answer_dict[val] = s
                    error_msg += error_message
                else:
                    error_msg += f' \n Error: Target Service level for {val}: No distribution found'
            if last_simulation is None:
                all_last_simulation.append(last_simulation)
            elif isinstance(last_simulation, pd.DataFrame):
                all_last_simulation.append(last_simulation.to_dict(orient='record'))
            else:
                all_last_simulation.append(None)
        except Exception as e:
            print(f"Error while simulation: {str(e)}")
            error_msg += f" \n SS simulation error: {str(e)}"

    result = {}
    result['target_service_levels'] = answer_dict
    result['last_simulation'] = all_last_simulation
    result['demand_distribution'] = dict_demand
    result['leadtime_distribution'] = dict_leadtime
    result['error_msg'] = error_msg.strip()
    for k, v in grain_data.items(): result[k] = str(v)
    result['grain_ss_compute_time_taken'] = time.time() - start_time
    return result


def ss_simulation2(grain_data):
    '''
    Faster version, with list implementations
    '''
    start_time = time.time()
    answer_dict = {}
    all_last_simulation = []
    dict_demand = {'param': '', 'dist': '', 'demand_data': '', 'p_value': ''}
    dict_leadtime = {'p_value': '', 'LeadTime_Dist': '', 'params': '', 'leadtime_data': ''}
    all_lag_errors = []
    # is_RB_flag = True if grain_data["project_id"] == Constant.RB_PROJECT else False
    # TODO: Add error for threshold in demand and rlt

    error_msg = ''
    zero_tsl_flag = False

    vals = grain_data["fill_rate_desired"]
    for val in vals:
        if int(val) == 0:
            answer_dict[val] = {'safetystock': 0, 'simulation_count': 0, 'last_service_level': 0}

    if len(vals) == len(answer_dict):
        error_msg += "Error: Target service level cannot be 0. Stopping "
        zero_tsl_flag = True

    for val in vals:
        answer_dict[val] = {'safetystock': 0, 'simulation_count': 0, 'last_service_level': 0}

    if zero_tsl_flag:
        print("Skip next computations")
    else:
        try:
            number_of_simulations = int(grain_data['number_of_simulations'].strip())
        except:
            number_of_simulations = 100

        all_last_simulation = []
        dict_demand = get_demand_distribution(grain_data)
        dict_leadtime = get_leadtime_distribution(grain_data)
        # update the distribution to days
        if dict_demand['error_msg'] == '' and dict_demand['dist'] != '':
            update_demand_distribution(dict_demand, grain_data['grain_date_type'])
        lead_time_ = str(dict_leadtime['params'])
        LT_dist = str(dict_leadtime['LeadTime_Dist'])
        d_dist = str(dict_demand['dist'])
        demand_ = str(dict_demand['param'])
        error_msg += dict_demand['error_msg'] + ' \n ' + dict_leadtime['error_msg']
        error_msg = error_msg.strip()
        if not error_msg:
            for val in vals:
                last_simulation = None
                try:
                    if int(val) == 0:
                        continue
                    else:
                        if dict_demand['dist'] != "" and dict_leadtime != {} and dict_leadtime['LeadTime_Dist'] != '':
                            exp_fill = val * 0.01
                            exp_fill = round(exp_fill, 4)
                            print('Carrying Simulation')
                            s, last_simulation, is_error, error_message, fillrate, simulation_count = simulation2(
                                lead_time_, LT_dist, d_dist, demand_, exp_fill, number_of_simulations)
                            print("Finished Simulation")
                            print("####### safety stock for FR = ", exp_fill, s)
                            result = {'safetystock': s, 'simulation_count': simulation_count,
                                      'last_service_level': fillrate}
                            answer_dict[val] = result
                            error_msg += error_message
                        else:
                            error_msg += f' \n Error: Target Service level for {val}: No distribution found'
                    if last_simulation is None:
                        all_last_simulation.append(last_simulation)
                    elif isinstance(last_simulation, pd.DataFrame):
                        all_last_simulation.append(last_simulation.to_dict(orient='record'))
                    else:
                        all_last_simulation.append(None)
                except Exception as e:
                    print(f"Error while simulation: {str(e)}")
                    error_msg += f" \n SS simulation error: {str(e)}"

    result = {}
    result['target_service_levels'] = answer_dict
    result['last_simulation'] = all_last_simulation
    result['demand_distribution'] = dict_demand
    result['leadtime_distribution'] = dict_leadtime
    result['error_msg'] = error_msg.strip()
    for k, v in grain_data.items(): result[k] = str(v)
    result['grain_ss_compute_time_taken'] = time.time() - start_time
    result['all_lag_errors'] = all_lag_errors
    return result


def ss_simulation3(grain_data):
    start_time = time.time()
    answer_dict = {}
    all_last_simulation = []
    dict_demand = {'param': '', 'dist': '', 'demand_data': '', 'p_value': '', 'error_msg': ''}
    dict_leadtime = {'p_value': '', 'LeadTime_Dist': '', 'params': '', 'leadtime_data': '',
                     'error_msg': ''}
    all_lag_errors = []
    # is_RB_flag = True if grain_data["project_id"] == Constant.RB_PROJECT else False
    error_msg = ''
    zero_tsl_flag = False
    selected_lags = int(grain_data['nlags'])
    vals = grain_data["fill_rate_desired"]
    for val in vals:
        if int(val) == 0:
            answer_dict[val] = {'safetystock': 0, 'simulation_count': 0, 'last_service_level': 0}

    if len(vals) == len(answer_dict):
        error_msg += "Error: Target service level cannot be 0. Stopping "
        zero_tsl_flag = True

    for val in vals:
        answer_dict[val] = {'safetystock': 0, 'simulation_count': 0, 'last_service_level': 0}

    if zero_tsl_flag:
        print("Skip next computations")
    else:
        try:
            number_of_simulations = int(str(grain_data['number_of_simulations']).strip())
        except:
            number_of_simulations = 100

        all_last_simulation = []
        error_msg = ''
        # to put this only for RB, ask Lokesh if horizon should be a built in feature
        # No.of horizon
        Config = SimulationConfig()
        SimConfig = getattr(Config, 'SimulationConfigs')
        if grain_data['project_id'] in SimConfig.keys():
            horizon = SimConfig[grain_data['project_id']]["horizon"]
            print(horizon)
        else:
            horizon = selected_lags + 1
            print(horizon)

        # projctID = list(SimConfig.keys())[0]
        # if projctID == grain_data['project_id']:
        #     horizon = list(list(SimConfig.values())[0].values())[0]
        #     print(horizon)
        # else:
        #     horizon = selected_lags+1
        #     print(horizon)

        try:
            current_weekmonth = int(grain_data['current_weekmonth'])
            error = ErrorTypes(grain_data['error_metric_type'])
            grain_date_type = grain_data['grain_date_type']
            demand_data = grain_data['demand_data_time']
            demand_date_col = grain_data['demand_date_column']
            forecast_snapshot_date_col = grain_data['forecast_date_column']
            threshold_dd_distribution = int(grain_data["threshold_dd_distribution"])
            threshold_lt_distribution = int(grain_data["threshold_lt_distribution"])
            lead_time_data = grain_data["lead_time_data"]
            historical_demand_weeks = Constant.HISTORICAL_DEMAND_WEEKS
            acceptable_intermitency = Constant.ACCEPTABLE_INTERMITENCY

            if len(demand_data) == 0:
                # error_msg = "Demand data not available"
                raise Exception("Demand data not available")
            elif len(demand_data) < threshold_dd_distribution:
                raise Exception("Demand data less than the threshold")

            if len(lead_time_data) == 0:
                raise Exception("Lead time data not available")
            elif sum(lead_time_data) == 0:
                raise Exception("All lead time values are zero")
            elif len(lead_time_data) < threshold_lt_distribution:
                raise Exception("Lead time data less than the threshold")

            demand_df = pd.DataFrame([[k[0], k[1], v] for k, v in demand_data.items()],
                                     columns=['grain', demand_date_col, 'DEMAND'])
            '''
            To consider when the demand_date_col is in months
            line 267 - 279
            '''
            if grain_date_type == 'week':
                demand_df[demand_date_col] = demand_df[demand_date_col].astype(int)

                demand_df = demand_df[
                    demand_df["DATE"] > get_historical_date(current_weekmonth, historical_demand_weeks)]

            # Remove leading zeros
            demand_df = demand_df[demand_df["DEMAND"].cumsum() > 0]

            # Checking intermittency percentage
            demand_length = demand_df.shape[0]
            if demand_length == 0:
                raise Exception("No demand data in last 52 weeks")
            non_zero_demand = np.count_nonzero(demand_df["DEMAND"])
            intermitency_percentage = (1 - (non_zero_demand / demand_length)) * 100

            # if intermitency_percentage > acceptable_intermitency:
            #     raise Exception("Demand data has more zeros than the acceptable limit")

            mean_demand = demand_df['DEMAND'].mean()

            # if np.isnan(mean_demand):
            #     # error_msg = "Demand data not available"
            #     raise Exception("Demand data not available")
            forecast_snapshots_df = pd.DataFrame(eval(grain_data['forecast_snapshots']))
            forecast_snapshots_df.rename({forecast_snapshot_date_col: demand_date_col}, axis=1, inplace=True)
            forecast_snapshots_df = forecast_snapshots_df[
                forecast_snapshots_df["SNAPSHOT_DATE"] > get_historical_date(current_weekmonth,
                                                                             historical_demand_weeks)]
            if grain_date_type == 'week':
                forecast_snapshots_df['SNAPSHOT_DATE'] = forecast_snapshots_df['SNAPSHOT_DATE'].astype(int)
            future_forecast = forecast_snapshots_df[
                forecast_snapshots_df['SNAPSHOT_DATE'] == current_weekmonth].reset_index(drop=True)
            ####################
            # when future forecast is not available

            future_lags = list(map(int, iterate_weeks(current_weekmonth, horizon)))

            if set(future_lags).issubset(future_forecast["DATE"].unique().tolist()):

                if grain_date_type == 'week':
                    future_forecast["Daily_forecast_quantity"] = future_forecast["FORECAST_QUANTITY"] / 7
                elif grain_date_type == 'month':
                    future_forecast["Daily_forecast_quantity"] = future_forecast["FORECAST_QUANTITY"] / 30

                forecast_data = future_forecast[[demand_date_col, 'FORECAST_QUANTITY']].reset_index(drop=True).to_dict(
                    orient='record')
                # forecast_data = future_forecast[[demand_date_col, 'Daily_forecast_quantity']].reset_index(drop=True).to_dict(orient='record')
                horizon_data = future_forecast[future_forecast[demand_date_col].isin(future_lags)][
                    [demand_date_col, 'FORECAST_QUANTITY']].reset_index(drop=True).to_dict(
                    orient='record')

                # TODO: handle the case when forecast data is all 0
                if all(int(x['FORECAST_QUANTITY']) == 0 for x in horizon_data):
                    raise Exception("Forecast sales are all 0, skipping safetystock computation")
                    # error_msg += "Forecast sales are all 0, skipping safetystock computation"
                # else:
                forecast_snapshots_df = forecast_snapshots_df[
                    forecast_snapshots_df['SNAPSHOT_DATE'] < current_weekmonth]
                forecast_snapshots_df = forecast_snapshots_df[
                    forecast_snapshots_df[demand_date_col] < current_weekmonth]
                forecast_snapshots_df = pd.merge(forecast_snapshots_df, demand_df,
                                                 on=['grain', demand_date_col],
                                                 how='left')

                all_lag_values = ['lag' + str(i) for i in range(selected_lags + 1)]

                all_snapshot_dates = forecast_snapshots_df['SNAPSHOT_DATE'].unique()

                last_snapshot_date = get_historical_date(current_weekmonth, selected_lags)

                all_snapshot_dates = all_snapshot_dates[all_snapshot_dates < last_snapshot_date]

                # all_snapshot_dates = all_snapshot_dates[all_snapshot_dates < (current_weekmonth - selected_lags)]
                '''
                if len(all_snapshot_dates) <20:
                    raise Exception("Snapshot dates less than threshold")
                '''

                if grain_date_type == 'week':
                    all_snapshot_dates = [dates for dates in list(all_snapshot_dates) if not str(dates).endswith("53")]

                forecast_snapshots_df = forecast_snapshots_df[
                    forecast_snapshots_df['SNAPSHOT_DATE'].isin(all_snapshot_dates)]
                if grain_date_type == 'week':
                    forecast_snapshots_df["DATE"] = forecast_snapshots_df["DATE"].astype(str)
                    forecast_snapshots_df = forecast_snapshots_df[~forecast_snapshots_df["DATE"].str.endswith('53')]
                    forecast_snapshots_df["DATE"] = forecast_snapshots_df["DATE"].astype(np.int64)
                forecast_snapshots_df = forecast_snapshots_df.dropna()
                forecast_snapshots_df = forecast_snapshots_df.groupby('SNAPSHOT_DATE').filter(
                    lambda x: len(x) > selected_lags)
                grain_error_df = forecast_snapshots_df.groupby('SNAPSHOT_DATE') \
                    .apply(lambda x: create_lag_data(x, horizon, selected_lags, error))
                grain_error_df.reset_index(drop=True, inplace=True)

                grain_error_df = grain_error_df[~pd.isnull(grain_error_df['error'].replace([np.inf, -np.inf], np.nan))]
                grain_error_df["absolute_error"] = abs(grain_error_df["error"])
                error_pivot_df = grain_error_df.groupby(['lag'], as_index=False).agg({'absolute_error': ['mean'],
                                                                                      'error': ['mean', 'std']}).round(
                    2)
                error_pivot_df.reset_index(drop=True, inplace=True)
                merged_columns = error_pivot_df.columns.map(lambda x: '|'.join([str(i) for i in x]))
                error_pivot_df.columns = merged_columns
                error_pivot_df.rename(columns={'lag|': 'Lags',
                                               'error|mean': 'Mean',
                                               'error|std': 'STD',
                                               'absolute_error|mean': 'MAE'}, inplace=True)
                error_pivot_df["lag"] = error_pivot_df["Lags"].str.replace('lag', '').astype(int)
                error_pivot_df = error_pivot_df.sort_values(by='lag')
                error_pivot_df['Mean'] = error_pivot_df['Mean'].fillna(0)
                error_pivot_df['STD'] = error_pivot_df['STD'].fillna(0)
                error_pivot_df['MAE'] = error_pivot_df['MAE'].fillna(0)
                del (error_pivot_df["lag"])
                all_lag_errors = error_pivot_df.to_dict(orient='record')

                if grain_date_type == 'week':
                    grain_error_df["daily_error"] = grain_error_df["error"] / 7
                elif grain_date_type == 'month':
                    grain_error_df["daily_error"] = grain_error_df["error"] / 30

                # forecast_snapshots_df.to_csv("/Users/sachinkadam/Ticket/NOVA-2612/Test/forecast_snapshot_df_v2.csv", index = False)
                # grain_error_df.to_csv("/Users/sachinkadam/Ticket/NOVA-2612/Test/grain_error_df_newversion.csv")

                grain_error_distribution = grain_error_df.groupby('lag') \
                    .apply(lambda x: get_error_distribution(x['error'])) \
                    .to_dict()
                # TODO: cases where lag variable is less or none
                for lag_ in all_lag_values:
                    if lag_ not in grain_error_distribution:
                        grain_error_distribution[lag_] = {'error_distribution_name': 'norm',
                                                          'error_params': (0.0, 0.0)}
                if len(grain_data['moq']) > 0:
                    moq = int(grain_data['moq'][0])
                else:
                    moq = 0

                ###
                # Getting demand distribution and its parameters
                '''
                get demand distribution generic and RB
                line 425
                '''
                dict_demand = get_demand_distribution_ss_v2(grain_data, demand_df["DEMAND"].to_list())
                # update the distribution to days
                # if dict_demand['error_msg'] == '' and dict_demand['dist'] != '':
                #     update_demand_distribution(dict_demand, grain_data['grain_date_type'])
                ###

                ########################
                # leadtime to week /month
                updated_lead_time = []

                for lt in grain_data["lead_time_data"]:
                    if grain_date_type == 'week':
                        lt = np.ceil(lt / 7)
                    elif grain_date_type == 'week':
                        lt = np.ceil(lt / 30)
                    updated_lead_time.append(lt)

                grain_data["lead_time_data"] = updated_lead_time
                #########################

                dict_leadtime = get_leadtime_distribution(grain_data)
                error_msg += dict_demand['error_msg'] + ' \n ' + dict_leadtime['error_msg']
                error_msg = error_msg.strip()

                for val in vals:
                    last_simulation = None
                    try:
                        if int(val) == 0:
                            continue
                        else:
                            if dict_leadtime != {} and dict_leadtime['LeadTime_Dist'] != '':
                                mean_lt = dict_leadtime['params'][0]
                                exp_fill = val * 0.01
                                exp_fill = round(exp_fill, 4)
                                '''
                                if grain_date_type == 'week':
                                    moq = moq / 7
                                    mean_demand = mean_demand / 7
                                elif grain_date_type == 'month':
                                    moq = moq / 30
                                    mean_demand = mean_demand / 30
                                '''
                                s, last_simulation, is_error, error_message, fillrate, simulation_count = simulation3(
                                    grain_error_distribution,
                                    forecast_data,
                                    dict_leadtime,
                                    exp_fill,
                                    moq,
                                    mean_demand,
                                    mean_lt,
                                    error,
                                    selected_lags,
                                    number_of_simulations,
                                    current_weekmonth,
                                    grain_date_type,
                                    horizon
                                    )
                                print("Finished Simulation")
                                print("####### safety stock for FR = ", val, s)
                                result = {'safetystock': s, 'simulation_count': simulation_count,
                                          'last_service_level': fillrate}
                                answer_dict[val] = result
                                error_msg += error_message
                            else:
                                error_msg += f' \n Error: Target Service level for {val}: No distribution found'
                        if last_simulation is None:
                            all_last_simulation.append(last_simulation)
                        elif isinstance(last_simulation, pd.DataFrame):
                            all_last_simulation.append(last_simulation.to_dict(orient='record'))
                        else:
                            all_last_simulation.append(None)
                    except Exception as e:
                        print(f"Error while simulation: {str(e)}")
                        error_msg += f" \n SS simulation error: {str(e)}"
                    # except Exception as e:
                    #     error_msg += f" \n Missing lag data"
            else:
                error_msg += f" Missing forecast data in current week"
        except Exception as e:
            error_msg += f" \n Insufficient data error: {str(e)}"

    result = {}
    result['target_service_levels'] = answer_dict
    result['last_simulation'] = all_last_simulation
    result['demand_distribution'] = dict_demand
    result['leadtime_distribution'] = dict_leadtime
    result['error_msg'] = error_msg.strip()
    for k, v in grain_data.items(): result[k] = str(v)
    result['grain_ss_compute_time_taken'] = time.time() - start_time
    result['all_lag_errors'] = all_lag_errors
    return result


'''
from safety_stock.utils.common_utility import  CommonUtility
from safety_stock.data_modelling.python_models import *
jsondata = CommonUtility.read_json_files("/private/tmp/85054dbd688547f5b5d07e41c50d5941__1072__x10051700770509x__91.5.json")
grain_data = jsondata
result = ss_simulation3(grain_data)
import time
start_time = time.time()
result = ss_simulation2(grain_data)
print(f"Time taken: {time.time() - start_time}")
----
from safety_stock.data_modelling.python_models import *
from safety_stock.data_modelling.simulation import carry_simulation

dict_demand = { 'grain1':
        {
            'param': (1840.7199109846902, 16.95224491886116, 0.015275864842636204),
            'dist': 'exponnorm',
            'p_value': 0.9698253919568331,
            'demand_data': [107.0, 66.0, 65.0, 60.0, 50.0, 26.0, 37.0, 26.0, 41.0, 22.0, 25.0, 17.0],
            'error_msg': ''
        }
}
dict_leadtime = {'grain1':
        {
            'p_value': 0.3691762586558337,
            'LeadTime_Dist': 'norm',
            'params': (73.88888888888889, 39.43896675580424),
            'leadtime_data': [86.0, 83.0, 6.0, 98.0, 80.0, 4.0, 113.0, 75.0, 120.0],
            'error_msg': ''
        }
}
dict_demand = dict_demand['grain1']
dict_leadtime = dict_leadtime['grain1']

lead_time_ = str(dict_leadtime['params'])
LT_dist = str(dict_leadtime['LeadTime_Dist'])
d_dist = str(dict_demand['dist'])
demand_ = str(dict_demand['param'])
val = 75
exp_fill = val * 0.01
Q = 58.32
number_of_simulations = 100
s, last_simulation, is_error, error_message = carry_simulation(lead_time_, LT_dist, d_dist, demand_, Q, exp_fill, number_of_simulations)
----------------------------------
import numpy as np
from safety_stock.data_modelling.simulation import *
from safety_stock.data_modelling.distribution import *
data = [42, 35, 5, 45, 27, 19, 14, 18, 23, 23, 25, 26, 20, 36, 41]
demand_data = np.asarray(data)
dist, p_value, params = get_distribution(np.array(check_nonzero(demand_data)))
dict_demand = {}
dict_demand['param'] = params
dict_demand['dist'] = dist
dict_demand['demand_data'] = demand_data
dict_demand['p_value'] = p_value

leadtime_data = np.random.uniform(30, 30, 20)
dist, p_value, params = get_distribution(leadtime_data)
dict_leadtime = {}
dict_leadtime['p_value'] = p_value
dict_leadtime['LeadTime_Dist'] = 'uniform'
dict_leadtime['params'] = params
dict_leadtime['leadtime_data'] = leadtime_data

lead_time_ = str(dict_leadtime['params'])
LT_dist = str(dict_leadtime['LeadTime_Dist'])
d_dist = str(dict_demand['dist'])
demand_ = str(dict_demand['param'])
demand_ = str((900, 50))

cycle_service_level = 90 # cycle service level
cycle_service_level = cycle_service_level * 0.01
Q = 900
number_of_simulations = 100
s, last_simulation, is_error, error_message = carry_simulation_product(lead_time_, LT_dist, d_dist, demand_, Q, cycle_service_level, number_of_simulations)

---------
data =  [42, 35, 5, 45, 27, 19, 14, 18, 23, 23, 25, 26, 20, 36, 41]
st.norm.fit(data)
st.exponnorm.fit(data)

'''