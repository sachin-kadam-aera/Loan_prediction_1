import logging
import json
import requests
import traceback
from safety_stock.utility.common_utility import Constant
from cortex.settings import CORTEX_CONFIG

logger_instance = logging.getLogger(__name__)
logger = logging.LoggerAdapter(logger_instance, {})


def api_call(api_method, body, url):
    """
    Calling the compute node
    """
    response = {}
    header = {'Content-type': 'application/json', 'Accept': 'application/json'}
    try:
        request_obj = getattr(requests, api_method.lower())
        response = request_obj(url, json=body, headers=header)
        response = json.loads(response.text)
        # response = python_models_runner(body) # testing the func directly
        logger.info("API call Successful: {}".format(str(response)))
    except Exception as e:
        logger.error("API call failed with error: {}".format(str(e)))
    return response


def compute_safety_stock(grain_data):
    SS_DNS = CORTEX_CONFIG['DNS-PROPERTIES']['SS_DNS']
    API_ENDPOINT = "{}{}".format(SS_DNS, Constant.SS_ROOT_URL)
    # local
    # API_ENDPOINT = "{}{}{}".format("http://127.0.0.1:8005",
    #                                "/aera/cortex/v2/1001/"
    #                                , "safety_stock")
    print("API_ENDPOINT>>>>>>>>", API_ENDPOINT)
    python_model_call_url = API_ENDPOINT  # Constant.PYTHON_COMPUTATION_URL
    api_method = "POST"
    response = None
    grain_data['model'] = grain_data['simulation_method']
    grain = grain_data['jobgrain']
    grain_data['demand_data_time'] = str(grain_data['demand_data_time'])
    try:
        payload = {
            "projectId": grain_data['project_id'],
            "capacityPoolId": grain_data['capacityPoolId'],
            "serviceId": grain_data['service_id'],
            "jobParams": {"jobId": grain_data['job_id']},
            "modelParams": grain_data
        }

        logger.info(f"Grain: {grain}. Sending SS computation request to {python_model_call_url}")
        response = api_call(api_method, payload, python_model_call_url)
        logger.info(f"Grain: {grain}. Completed SS computation request to {python_model_call_url}")
        logger.info(f"Grain: {grain}. Response: {response}")
    except Exception as e:
        logger.error(f"Safety stock computation failed. grain: {grain_data['jobgrain']}")
        logger.error(traceback.print_exc())
        response = {'is_error': True, 'error_reason': str(e), 'safety_stock_result': None}
    return response