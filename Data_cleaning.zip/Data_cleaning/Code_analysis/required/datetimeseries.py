import pandas as pd


def create_date_Week_Month_mapping_(date_type, start_date, end_date):
    all_days = pd.date_range(start_date, end_date, freq='D')
    daily_Data = pd.DataFrame()
    single_date = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    daily_Data['DATEVALUE'] = all_days
    if date_type == "week":
        daily_Data['week'] = daily_Data.apply(lambda x: ('0'+str(x['DATEVALUE'].isocalendar()[1]))
                                                        if (x['DATEVALUE'].isocalendar()[1] in(single_date))
                                                        else str(x['DATEVALUE'].isocalendar()[1]), axis=1)
        daily_Data['YWMS'] = daily_Data.apply(lambda x: (str(x['DATEVALUE'].isocalendar()[0])+str(x['week'])), axis=1)
    elif date_type == 'month':
        daily_Data['DATEVALUE'] = pd.to_datetime(daily_Data['DATEVALUE'])
        daily_Data['YWMS'] = daily_Data['DATEVALUE'].dt.strftime('%Y%m')
    daily_Data =  daily_Data.drop_duplicates(subset="YWMS", keep="first")
    return daily_Data


def create_datetime_series(start_month, start_year, end_month, end_year, time_grain="month"):
    start_date = str(start_year) + "-01-01"
    end_date = str(end_year) + "-12-30"
    all_dates = create_date_Week_Month_mapping_(time_grain, start_date, end_date)
    all_date_ranges = all_dates['YWMS'].astype(str).values.tolist()
    return all_date_ranges