###########################################################################
# Name: status_update.py
# Author: Aeratechnology Pvt. Ltd.
# Purpose: To define commonly usable functionlites for cortex backend
# Date                          Version                                 Created By
# 17-Mar-2020                    1.0                                    Anil Gupta(Initial Version)
###########################################################################

# Python Package & Modules
import logging
import configparser
import time
import requests
import pandas as pd

# Project Related Package & Modules
from .common_utility import CommonUtility
from .constant import Constant
from .cassandra_utility import CassandraDb
from cortex.settings import CORTEX_CONFIG

class StatusUpdateService(CassandraDb):
    """
    Usage:
        >>> db=StatusUpdateService(project_id="P1001", service_id=1001, job_id="J1001")
        >>> db.update_job_processing_result(data="result")
    """
    def __init__(self, key_space="CORTEX", project_id=None, service_id=None, job_id=None, job_name=None):
        self.query_resp = None
        self.project_id = project_id
        self.service_id = service_id
        self.job_id = job_id
        self.job_name = job_name
        self.key_space = key_space
        self.filter_by = "project_id='{}' and service_id='{}' and job_id='{}' and job_name='{}'".format(self.project_id,
                                                                                                        self.service_id,
                                                                                                        self.job_id,
                                                                                                        self.job_name)
        super(StatusUpdateService, self).__init__()
    
    def update_job_processing_result(self, data=None):
        """
        
        """
        if not data or not all([self.project_id, self.service_id, self.job_id]):
            msg = "You haven't supplied any data"
            return msg

        query = "UPDATE {} SET processing_result = '{}' WHERE {}".format(
            Constant.TBL_JOB_STATUS.format(self.key_space), data, self.filter_by)

        self.query_resp = self.query_executor(query, self.job_id)
        return self.query_resp
    
    def update_job_status(self, data=None, job_id=None):
        """
        DOCString
        """
        if not data or not all([self.project_id, self.service_id, self.job_id]):
            msg = "You haven't supplied any data"
            return msg

        query = "UPDATE {} SET processing_status='{}' WHERE {}".format(
            Constant.TBL_JOB_STATUS.format(self.key_space), data, self.filter_by)

        self.query_resp = self.query_executor(query, self.job_id)
        return self.query_resp
    
    def update_job_total_task(self, data=None, job_id=None):
        """
        DOCString
        """
        if not data or not all([self.project_id, self.service_id, self.job_id]):
            msg = "You haven't supplied any data"
            return msg

        query = "UPDATE {} SET total_task = {} WHERE {}".format(
            Constant.TBL_JOB_STATUS.format(self.key_space), data, self.filter_by)
        
        self.query_resp = self.query_executor(query, self.job_id)
        return self.query_resp

    def update_job_status_nd_processing_result(self, data=None, job_id=None):
        """
        DOCString
        """
        if not data or not all([self.project_id, self.service_id, self.job_id]):
            msg = "You haven't supplied any data"
            return msg

        query = "UPDATE {0} SET processing_status = '{1}' , processing_result='{2}', job_updated='{3}' WHERE {4}".format(
                                                    Constant.TBL_JOB_STATUS.format(self.key_space),
                                                    data.get("processing_status"),
                                                    data.get("processing_result"),
                                                    data.get("updated_at"),
                                                    self.filter_by)

        self.query_resp = self.query_executor(query, self.job_id)
        return self.query_resp

    def update_job_priority(self, data='PRIORITY', job_id=None):
        """
        DOCString
        """ 
        if not data or not all([self.project_id, self.service_id, self.job_id]):
            msg = "You haven't supplied any data"
            return msg

        query = "UPDATE {} SET job_type = '{}' WHERE {}".format(
            Constant.TBL_JOB_STATUS.format(self.key_space), data, self.filter_by)
        self.query_resp = self.query_executor(query, self.job_id)
        return self.query_resp

    def trigger_update_job_status_api(self, job_id, project_id, processing_status, processing_result, access_token):
        """
        DOCString
        """
        headers = {'Content-type': 'application/json', 'Accept': 'application/json'}

        if project_id in CORTEX_CONFIG:
            updateJobStatusPID = str(CORTEX_CONFIG[project_id]["updateJobStatusPID"])
            updateJobStatusEnvName = str(CORTEX_CONFIG[project_id]["updateJobStatusEnvName"])
        else:
            updateJobStatusPID = str(CORTEX_CONFIG["PROCESS-PROPERTIES"]["updateJobStatusPID"])
            updateJobStatusEnvName = str(CORTEX_CONFIG["PROCESS-PROPERTIES"]["updateJobStatusEnvName"])

        triggerUpdateJobStatusApiURL = "https://" + updateJobStatusEnvName + ".aeratechnology.com/ispring/client/v1/process/" + updateJobStatusPID + \
                                       "?accessToken=" + access_token

        post_request_data = {"JobID": job_id, "ProjectID": project_id, "processingStatus": processing_status, "processingResult": processing_result}
        updateJobStatus_API_response = requests.post(triggerUpdateJobStatusApiURL, json=post_request_data, headers=headers)

        print("updateJobStatus_API_response", updateJobStatus_API_response.json())
        return updateJobStatus_API_response.status_code


# class StatusUpdateService1(MySqlDb):
#     def __init__(self):
#         self.query_resp = None
#         super(StatusUpdateService, self).__init__()
       
        
#     def update_job_processing_result(self, processing_result, job_id, retry_count):
#         """
#         DOCString
#         """
#         table = app_const.JobStatusTable
#         query = 'UPDATE {} SET Processing_Result = "{}" WHERE Job_Id= "{}" '.format(
#             table, processing_result, job_id)
        
#         self.query_resp = self.query_executor(query, job_id)
#         return self.query_resp

#     def update_job_status(self, processing_status, job_id, retry_count):
#         """
#         DOCString
#         """
#         table = app_const.JobStatusTable
#         query = 'UPDATE {} SET Processing_Status = "{}" WHERE Job_Id= "{}" '.format(
#             table, processing_status, job_id)
#         self.query_resp = self.query_executor(query, job_id)
#         return self.query_resp
           
#     def update_total_grains(self, job_id, project_id, totalGrains, retry_count):
#         """
#         DOCString
#         """
#         table = app_const.JobStatusTable
#         query = 'UPDATE {} SET total_grains = "{}" WHERE Job_Id= "{}" and Project_Id = "{}"'.format(
#             table, totalGrains, job_id, project_id)
        
#         self.query_resp = self.query_executor(query, job_id)
#         return self.query_resp
        

#     def update_job_status_nd_processing_result(self, processing_status, processing_result, job_id, retry_count):
#         """
#         DOCString
#         """
#         table = app_const.JobStatusTable
#         query = 'UPDATE {} SET Processing_Status = "{}" , Processing_Result="{}" WHERE Job_Id= "{}" '.format(
#             table, processing_status, processing_result, job_id)

#         self.query_resp = self.query_executor(query, job_id)
#         return self.query_resp

#     def update_priority_job_status(self, job_id, project_id, retry_count):
#         """
#         DOCString
#         """ 
#         table = app_const.JobStatusTable
#         job_type = 'PRIORITY'
#         query = 'UPDATE {} SET Job_Type = "{}" WHERE Job_Id= "{}" and Project_Id = "{}"'.format(
#             table, job_type, job_id, project_id)
#         self.query_resp = self.query_executor(query, job_id)
#         return self.query_resp


#     def get_dq_df_dv_data(self, job_id, retry_count):
#         """
#         dq:DataQuality
#         df:DataForecasting
#         dv:DataValidation
#         """
#         message_details_table = app_const.MessageDetailDataTable
#         query = 'select * from {} where Message_Id like "{}%";'.format(message_details_table, job_id)
#         query_resp = self.query_executor(query, job_id, query_ops="read")
#         df = pd.DataFrame(self.query_data)
#         if self.query_data: # To make sure query has some records
#             df.columns = self.all_fields
#         query_resp = df
#         logger.info("Got message details data " + str(query_resp.shape[0]) + ", " + str(query_resp.shape[1]))
#         return query_resp
           

#     def get_exporter_data(self, job_id, retry_count):
#         """
#         DOCString
#         """
#         forecast_data_table = app_const.ForecastDataTable
#         message_details_table = app_const.MessageDetailDataTable

#         query = 'select f.Project_Id,f.Job_Id,f.Message_Id,f.Grain,f.Algorithm_Name,' \
#                         'f.RM_Processing_Status,f.FF_Processing_Status,f.Forecast_Result_FORECAST_DATA,' \
#                         'f.Forecast_Result_ADDITIONAL_INFORMATION,f.LowLevelInfo,f.Ranking_Metric_Result,' \
#                         'f.Ranking_Metric_Name,f.Is_used_for_Final_Forecast,f.RM_Processing_Result,' \
#                         'f.FF_Processing_Result,f.Requested_Ranks, f.Final_Forecast_Rank, f.bl_isBest, f.passed_all_tests, d.Message_Details ' \
#                         'from {} as f join {} as d where f.message_id=d.message_id and f.job_id ' \
#                         '= "{}" and (FF_Processing_Status = "FI" or Algorithm_Name="FALL_BACK_NAIVE")'.format(forecast_data_table,
#                                                                             message_details_table, job_id)
#         query_resp = self.query_executor(query, job_id, query_ops="read")
#         df = pd.DataFrame(self.query_data)
#         if self.query_data: # To make sure query has some records
#             df.columns = self.all_fields
#         query_resp = df
#         logger.info("Got message details data " + str(query_resp.shape[0]) + ", " + str(query_resp.shape[1]))
#         return query_resp
   

#     def get_job_metadata(self, job_id, retry_count):
#         """
#         DOCString
#         """
#         table = app_const.JobStatusTable
#         query = 'SELECT Project_Id, Job_Id, Job_Details, Job_Created, Job_Updated, Job_Type FROM {} where job_id="{}";'.format(table, job_id)
#         query_resp = self.query_executor(query, job_id, query_ops="read")
#         df = pd.DataFrame(self.query_data)
#         if self.query_data: # To make sure query has some records
#             df.columns = self.all_fields
#         query_resp = df
#         logger.info("Got message details data " + str(query_resp.shape[0]) + ", " + str(query_resp.shape[1]))
#         return query_resp

#     def get_client_credentials(self, project_id, retry_count):

#         """

#         :param project_id:
#         :return:client credentials
#         """
#         response = {}
#         mapping_table = app_const.OauthClientMappings
#         client_group = app_const.ClientGroup

#         query_builder = f'select * from {mapping_table} where project_id = "{project_id}" and client_group="{client_group}"; '
        
#         self.ispring_query_executor(query=query_builder, job_id="default", retry_count=1, query_ops='read')

#         if self.query_data:
#             df = pd.DataFrame(self.query_data)
#             df.columns = self.all_fields
#         else:
#             return None

#         logger.info("Got client credentials ")
#         response['project_id'] = df.iloc[0]['project_id']
#         response['client_id'] = df.iloc[0]['client_id']
#         response['client_secret'] = df.iloc[0]['client_secret']
#         response['client_name'] = df.iloc[0]['client_name']
#         response['client_description'] = df.iloc[0]['client_description']

#         return response


    # def trigger_update_job_status_api(self, job_id, project_id, processing_status, processing_result, access_token):
    #     """
    #     DOCString
    #     """
    #     headers = {'Content-type': 'application/json', 'Accept': 'application/json'}
    #     logger.info(project_id)
    #     logger.info(props)
    #     # try:
    #     #     updateJobStatusPID = str(props["projectId"]["updateJobStatusPID"])
    #     #     updateJobStatusEnvName = str(props["projectId"]["updateJobStatusEnvName"])
    #     # except Exception as e:
    #     #     updateJobStatusPID = str(props["process-properties"]["updateJobStatusPID"])
    #     #     updateJobStatusEnvName = str(props["process-properties"]["updateJobStatusEnvName"])

    #     if project_id in props:
    #         updateJobStatusPID = str(props[project_id]["updateJobStatusPID"])
    #         updateJobStatusEnvName = str(props[project_id]["updateJobStatusEnvName"])
    #     else:
    #         updateJobStatusPID = str(props["process-properties"]["updateJobStatusPID"])
    #         updateJobStatusEnvName = str(props["process-properties"]["updateJobStatusEnvName"])

    #     # logger.info("updateJobStatusPID : %s and updateJobStatusEnvName: %s", updateJobStatusPID, updateJobStatusEnvName)

    #     triggerUpdateJobStatusApiURL = "https://" + updateJobStatusEnvName + ".aeratechnology.com/ispring/client/v1/process/" + updateJobStatusPID + \
    #                                    "?accessToken=" + access_token

    #     # logger.info("triggerUpdateJobStatusApiURL :%s", triggerUpdateJobStatusApiURL)

    #     post_request_data = {"JobID": job_id, "ProjectID": project_id, "processingStatus": processing_status, "processingResult": processing_result}
    #     updateJobStatus_API_response = requests.post(triggerUpdateJobStatusApiURL, json=post_request_data, headers=headers)

    #     # logger.info("updateJobStatus_API_response : %s", updateJobStatus_API_response)
    #     print("updateJobStatus_API_response", updateJobStatus_API_response.json())
    #     return updateJobStatus_API_response.status_code