import os
import json
import logging
from kubernetes import client, config
import yaml
from kubernetes.client import configuration


class KubernetesUtility:
    """
        KubernetesUtility class for interacting with K8 cluster.
    """
    log = logging.getLogger(__name__)

    def __init__(self, **kwargs):
        print(kwargs)
        self.configuration = client.Configuration()
#         self.configuration.api_key["authorization"] = '<bearer_token>'
#         self.configuration.api_key_prefix['authorization'] = 'Bearer'
#         self.configuration.host = 'https://192.168.64.2:8443'
#         self.configuration.ssl_ca_cert = '/Users/prashantsingh/.minikube/ca.crt'
        # self.api_token = ""
        # self.configuration.api_key = {"authorization": "Bearer " + self.api_token}
        self.contexts, self.active_context = config.list_kube_config_contexts()
        self.contexts = [context['name'] for context in self.contexts]
        self.active_index = self.contexts.index(self.active_context['name'])
        self.aws_cluster = self.contexts[0]

    def connect_core(self):
        v1 = client.CoreV1Api(api_client=config.new_client_from_config(context=self.aws_cluster))
        return v1

    def connect_apps_v1(self):
        v1_apps = client.AppsV1Api(api_client=config.new_client_from_config(context=self.aws_cluster))
        return v1_apps
    def connect_batch_v1(self):
        v1_batch = client.BatchV1Api(api_client=config.new_client_from_config(context=self.aws_cluster))
        return v1_batch
    def connect_autoscaling_v1(self):
        v1_autoscaling = client.AutoscalingV1Api(api_client=config.new_client_from_config(context=self.aws_cluster))
        return v1_autoscaling

    def create_namespace_deployment_resource(self, yaml_file, namespace):
        with open(yaml_file) as f:
            dep = yaml.safe_load(f)
        k8s_apps_v1 = self.connect_apps_v1()
        resp = k8s_apps_v1.create_namespaced_deployment(
            body=dep, namespace=namespace)
        self.log("Deployment created. '%s'" % resp.metadata.name)
        self.log("Deployment created. status='%s'" % str(resp.status))

        None

    def create_namespace_job_resource(self, yaml_file, namespace):
        with open(yaml_file) as f:
            dep = yaml.safe_load(f)
        k8s_v1_batch = self.connect_batch_v1()
        resp = k8s_v1_batch.create_namespaced_job(
            body=dep, namespace=namespace)
        self.log("Job created. '%s'" % resp.metadata.name)
        self.log("Job created. status='%s'" % str(resp.status))

        None

    def create_namespace_horizontal_pod_autoscaler_resource(self, yaml_file, namespace):
        with open(yaml_file) as f:
            dep = yaml.safe_load(f)
        k8s_v1_autoscaling = self.connect_autoscaling_v1()
        resp = k8s_v1_autoscaling.create_namespaced_horizontal_pod_autoscaler(
            body=dep, namespace=namespace)
        self.log("HPA created. '%s'" % resp.metadata.name)
        self.log("HPA created. status='%s'" % str(resp.status))

        None

    def list_pods(self):
        v1 = self.connect_core()
        ret = v1.list_pod_for_all_namespaces(watch=False)
        for i in ret.items:
            self.log("%s\t%s\t%s" % (i.status.pod_ip, i.metadata.namespace, i.metadata.name))

