class CortexException(Exception):
    """Parent exception class for all custom exceptions raised in the project"""
    status_code = 10000
    error_message = 'There is some error in Aera, please try again.'

    def __init__(self, status_code, error_message):
        self.status_code = status_code
        self.error_message = error_message


