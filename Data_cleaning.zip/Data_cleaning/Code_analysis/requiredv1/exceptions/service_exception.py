# python dependencies
import logging

# Project related dependencies
from .cortex_exception import CortexException
from .read_configuration import custom_status_code
from safety_stock.utils.constant import Constant


class ServiceException(CortexException):
    """This is an exception class for all Service related exceptions raised in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.SERVICE_EXCEPTION]):
        """
        This is constructor to initialize the variable
        """
        super(ServiceException, self).__init__(status_code, error_message)
        self.log.error(self.error_message)


class InvalidKeyException(ServiceException):
    """Invalid Json key exception raised while reading json file in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.INVALID_JSON_KEY_REQUEST]):
        """
        This is constructor to initialize the variable
        """
        super(InvalidKeyException, self).__init__(
            error_message, status_code)
        self.log.error(self.error_message)



class CorruptedFileException(ServiceException):
    """CorruptedFileException raised while loading the model"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.CORRUPTED_FILE_EXCEPTION]):
        """
        This is constructor to initialize the variable
        """
        super(CorruptedFileException,self).__init__(
            error_message,status_code)
        self.log.error(self.error_message)

class FileNotFoundException(ServiceException):
    """Model not found exception raised while loading the model in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.FILE_NOT_FOUND_EXCEPTION]):
        """
        This is constructor to initialize the variable
        """
        super(FileNotFoundException,self).__init__(
            error_message,status_code)
        self.log.error(self.error_message)

class DirectoryNotExistsException(ServiceException):
    """Model not found exception raised while loading the model in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.DIRECTORY_NOT_FOUND]):
        """
        This is constructor to initialize the variable
        """
        super(DirectoryNotExistsException,self).__init__(
            error_message,status_code)
        self.log.error(self.error_message)
