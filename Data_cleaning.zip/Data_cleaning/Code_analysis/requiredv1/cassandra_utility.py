import os
import sys
import configparser
import logging
from .SecurityServices import Security

import cassandra
from cassandra.io.libevreactor import LibevConnection
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
from cortex.settings import CORTEX_CONFIG

######### MAIN CASSANDRA UTILITY CLASS ##############

class CassandraDb:
    def __init__(self, project_id=None, service_id=None, job_id=None, job_name=None):
        self.session, self.cluster = get_db_connection(job_id)
        self.query_data = []

    def _read(self, exec_response):
        """
         Read-query wrapper
        """
        self.query_data = exec_response.all()
        return True
    
    def _write(self, exec_response):
        """
         Write query wrapper
        """
        return True
    
    def query_executor(self, query, job_id, query_ops='write'):
        """
        query-executor for Cassandra
        :query str: query that is to be executred
        :job_id str: job-id
        :retry_count int:
        :query_ops str: can be 'write' or 'read'. Default is 'write'
        """
        logger_instance = logging.getLogger(__name__)
        logger = logging.LoggerAdapter(logger_instance, {'jobId': job_id})

        query_resp = None
        try:
            if self.session == None: raise Exception("Failed to create Cassandra Session!")
            if self.cluster == None: raise Exception("Failed to create Cassandra Cluster!")
            print("query>>>>", query)
            exec_response = self.session.execute(query)
            # Fetch Method (read or write)
            method = getattr(self, "_"+query_ops)
            query_resp = method(exec_response)
            
        except Exception as e:
            query_resp = False
            logger.error(str(e))
            print("ERROR", str(e))

        return query_resp

    def prepared_query_executor(self, query, values):
        """
            Use prepared query executor when repeatedly executing a statement multiple times
        """

        insert_data_cassandra = self.session.prepare(query)
        future = self.session.execute_async(insert_data_cassandra, values)
        return future
    
    def close_connection(self):
        if self.cluster != None:
            self.cluster.shutdown()

# this function is creating connection pool and returning the cursor which can be used to execute query
def get_db_connection(Job_Id):
    """
    :return: return Cassandra Db connection
    """
    logger_instance = logging.getLogger(__name__)
    logger = logging.LoggerAdapter(logger_instance, {'jobId': Job_Id})

    cluster, session = None, None
    print("CORTEX_CONFIG['CASSANDRA-PROPERTIES']['DB_USER']", CORTEX_CONFIG['CASSANDRA-PROPERTIES']['DB_USER'])
    db_user = CORTEX_CONFIG['CASSANDRA-PROPERTIES']['DB_USER']
    db_pass = CORTEX_CONFIG['CASSANDRA-PROPERTIES']['DB_PASS']
    auth_provider = PlainTextAuthProvider(username=db_user, password=Security().decrypt(db_pass))
    # auth_provider = PlainTextAuthProvider(username=db_user, password=db_pass)
    db_node_ip = CORTEX_CONFIG['CASSANDRA-PROPERTIES']['DB_HOST']
    node_ips = [db_node_ip]
    db_port = int(CORTEX_CONFIG['CASSANDRA-PROPERTIES']['DB_PORT'])

    try:
        cluster = Cluster(node_ips, port=db_port, auth_provider=auth_provider)
        cluster.connection_class = LibevConnection
        session = cluster.connect()
        logger.info("Successfully connected to Cassandra Cluster")
        print("session, cluster", session, cluster)
    except Exception as e:
        logger.warning("Failed in Getting Cassandra Connection because = %s ", e)

    return session, cluster


def prepare_msg_for_cassandra(job_id, 
                                task_id, 
                                project_id,
                                capacity_pool_id, 
                                service_id, 
                                document_type, 
                                stream_message_list, 
                                logger):
    """
        Utility that will write data to Cassandra
    """
    db_key_space = capacity_pool_id.upper()
    db_col_family = CORTEX_CONFIG['CASSANDRA-PROPERTIES']['COMPUTATION_DATA_COLUMN_FAMILY']

    # default return status
    return_status = False
    return_message = "Default error message from "
    try:
        # Try to establish a connection with Cassandra
        cass_conn = CassandraDb(job_id)
        # first row is for datatypes
        if len(stream_message_list) != 0:
            d_types_header = {k:type(v).__name__ for k,v in stream_message_list[0].items()}
            stream_message_list = [d_types_header]+stream_message_list 
        else:
            cass_conn.close_connection()
            return (True, "cassandra:///")
        for index, message in enumerate(stream_message_list):
            # cast all the messages to a string
            update_message = [message.update({k:str(v)}) for k,v in message.items()]
            # data to insert has to be an ordered list
            data_to_insert = [
                job_id,
                task_id,
                document_type,
                message,
                project_id,
                service_id,
                index
            ]
            # Prepare an insert statement
            prepared_query = "INSERT INTO {}.{} (jobid , taskid , documenttype , documentmap , projectid , serviceid, rowIndex) VALUES (?, ?, ?, ?, ?, ?, ?)".format(db_key_space, db_col_family)
            future = cass_conn.prepared_query_executor(prepared_query, data_to_insert)
            try:
                # prepared_query_executor is Async and will return a future, so block till you get an ackowledgement
                future.result()
            except Exception as e:
                logger.error("Failed to insert into Cassandra for task_id: {} and documenttype: {}. Got the following error: {}".format(task_id, document_type, str(e)))
        
        return_status = True
        return_message = "cassandra:///key_space={};column_family={};jobid={};documenttype={};tasktd={}".format(db_key_space,
                                                                                            db_col_family,
                                                                                            job_id,
                                                                                            document_type,
                                                                                            task_id)
        cass_conn.close_connection()
        logger.info('A Total of: {} messages of document type: {} were inserted into Cassandra'.format(str(len(stream_message_list)), document_type))
    except Exception as e:
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        return_status = False
        return_message = "Unknown: Failed for the following message: {}".format(str(e))
        logger.error(return_message)
        logger.error('A message could not be delivered due to: {}. Occured at line no: {}\nCaused by: {} in {}'.format(str(e), exc_tb.tb_lineno, exc_type, fname))

    return (return_status, return_message)

# can have insert, delete update etc implementation
DB_OPERATION_MAPPER = {
    "cassandra_insert":prepare_msg_for_cassandra
}

def stream_message_wrapper(stream_db_type, kwargs):
    """
        :stream_db_type: string indicating where the data is posted to (see. DB_OPERATION_MAPPER keys)

        returns tuple (status, message):
        :status: (boolean) Status indicating the success/faliure of the operations
        :message: (str) A meta-description of the operation (can contain error message or success messages etc) 
    """
    target_func = DB_OPERATION_MAPPER.get(stream_db_type, False)
    if not target_func:
        return (False, "{} is not recognized as a valid streaming method!".format(stream_db_type))

    return target_func(**kwargs)