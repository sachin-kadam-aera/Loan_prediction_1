# python dependencies
import os
import json
import shutil
import uuid
import logging
import pandas as pd
import requests
import math
import time

# HDFS related dependencies


# Project related dependencies
from .constant import Constant
from .exceptions.utility_exception import DownloadException
from .exceptions.utility_exception import UploadException
from .common_utility import CommonUtility
from .constant import Constant


class AeraPlateformUtility:
    """
        AeraPlateformUtility class for Upload and Download object from/to GCS.
    """
    log = logging.getLogger(__name__)

    def __init__(self, **kwargs):
        print(kwargs)
        self.page_size = 25000
        self.root_url = "https://{}.aeratechnology.com/ispring/client/v2/reports/"
        self.report_url = "{0}{1}?pageSize=25000&skipCache=true&enableMaxSize=true&rowStart={2}&accessToken={3}"
        self.env = kwargs.get("requested_env")
        self.access_token = kwargs.get("access_token")
        self.refresh_token = kwargs.get("refresh_token")
        self.project_id = kwargs.get("project_id")
        self.isdownloadError = False
        self.downloadErrorReason = ""
        self.max_try = 4
    
    def get_report_url(self, report_name, start_page=0):
        """
        DOCString
        """
        self.root_url = self.root_url.format(self.env)
        abs_report_url = self.report_url.format(self.root_url, report_name, start_page, self.access_token)
        print("RESPORT, URL", abs_report_url)
        return abs_report_url

    def download(self, bucket_name, file_key, unique_folder):
        """
        download function is used for downloading file from GCS and store that file in local machine
s
        @param:
            bucket_name = bucket name
            file_key = file key of aera webservice object
            unique_folder = unique folder key of 32 character

        @returns- if download is succeed function will return True & machine location where file is stored
                else it returns FALSE & failure Message

        @raises exception that could be raised if download is unsuccessful
        """

        status_flag = False
        message = Constant.BLANK
        # Handling exception when Bucket does not exist
        try:
            source_bucket = self.get_report_url(file_key)
            # Handling exception when file upload is unsuccessful
            try:
                # destination_location in which actual file is stored
                file_key_as_csv = file_key+Constant.CSV_FILE_EXT
                destination_location = self.__get_local_path_location(
                    file_key_as_csv, unique_folder)

                # Download file from Aera API
                
                data = self.get_aera_report_data(file_key, report_url=source_bucket, env=self.env, access_token=self.access_token, job_id=None)
                data.to_csv(destination_location, index=0)
                self.log.debug('Blob %s downloaded to %s.',
                               file_key_as_csv,
                               destination_location)

                message = destination_location
                status_flag = True
            except Exception as e:
                message = Constant.UNABLE_TO_DOWNLOAD_LOG.format(str(e))
                # calling function for Deleting file from local machine
                #CommonUtility.remove_file(destination_location)
                raise DownloadException(message)
        except Exception as e:
            message = Constant.BUCKET_NOT_FOUND_LOG.format(str(e))
            raise DownloadException(message)

        return status_flag, message
    
    def upload(self, local_file_path, bucket_name, bucket_folder_key, file_name):
        """
        upload function is used for uploading file from local machine to specified folder in the specified bucket of GCS

        @param:
            local_file_path: local machine path where file is stored
            bucket_name = bucket name
            bucket_folder_key = file key of GCS object
            file_name = name of file

        @returns: if uploading file is succeed func will return TRUE & the Message
                else it returns FALSE & the failure Message

        @raises exception that could be raised if upload is unsuccessful
        """
        status_flag = False
        message = Constant.BLANK
        ## TODO 
        return status_flag, message

    def __get_local_path_location(self, file_key, unique_folder):
        """
        get_local_path_location function is used to create local file path where file is downloaded

        @param:
            file_key = file key of GCS object
            unique_folder = unique folder key of 32 character

        @returns- local machine file path

        @raises exception if local file can not be created
        """
        local_path_with_uuid_for_download = CommonUtility.concat_string(
            Constant.LOCAL_LOCATION_OF_DOWNLOAD, os.path.sep, unique_folder)

        # making directory if not exits to store file in local machine
        CommonUtility.create_folder(local_path_with_uuid_for_download)

        list_source_file = file_key.split(Constant.FILE_SEPARATOR)

        # getting the file name from file path
        file_name = list_source_file[-1]

        # generate random file name
        rand_file_name = CommonUtility.uuid_with_file_extension(CommonUtility.concat_string(
            Constant.FILE_EXTENSION_SEPARATOR, file_name.split(Constant.FILE_EXTENSION_SEPARATOR)[-1]))

        # destination_location in which actual file is stored
        destination_location = os.path.join(
            local_path_with_uuid_for_download, rand_file_name)

        return destination_location

    def __get_upload_file_key(self, file_name, file_gcs_path_key):
        """
        get_upload_file_key function is used to create GCS path where file will be uploaded

        @param:
            file_name = file name
            file_gcs_path_key = file key of GCS object

        @returns- file key of GCS object

        @raises exception if gcs object key can not be created
        """

        # returning file key of GCS object
        return CommonUtility.concat_string(file_gcs_path_key, file_name)

    
    def get_aera_report_data(self, report_name, report_url=None, env=None, access_token=None, job_id=None):
        """
        :param kwargs: gets environment, reportName, accessToken
        :return: data if downloaded successfully else failure reason(if access token is expired)
        """
        datasets = pd.DataFrame()
        self.log.info("URL I am hitting %s ", report_url)
        api_resp = requests.get(report_url)
        self.log.debug("API Response %s ", api_resp)
        resp_data = json.loads(api_resp.text)
        try:
            meta_data = resp_data.get("metaData")
            data = pd.DataFrame.from_dict(resp_data.get('data')) ## If accessToken is Invalid it will throw exception here.
            number_of_rows = meta_data.get("totalReportRows")
            number_of_pages_to_download = math.ceil(number_of_rows/self.page_size)
            self.log.info("numberOfPagesToDownload %s", number_of_pages_to_download)
            if number_of_pages_to_download == 1:
                datasets = data
                return datasets

            pages = range(0, int(number_of_pages_to_download))
            trycount_local = 1
            for page in pages:
                self.log.info("Getting page number %s = ", page)
                page_data = self.download_parallely(report_name,trycount_local, page)
                self.log.info("Single page downloaded data size is %s ", page_data.shape)
                datasets = pd.concat([datasets, page_data], ignore_index=True)
            self.log.info("Downloaded data and data size is %s ", datasets.shape)
            return datasets
        except Exception as e:
            self.isdownloadError = True
            self.downloadErrorReason = str(resp_data)  ## doing out because it will be definately be accessToken Error or API is Broken
            raise DownloadException(self.downloadErrorReason)
    

    def download_parallely(self, file_key, trycount_local, count):
        """
        :param environment: environment. Ex - dev2, stg01, uat01, qa02 etc.
        :param reportName: webService Name
        :param accessToken: Access token for downloading the data
        :param trycount_local: Intailly always one. We use it to retry multiple time in case it fails somehow to download.
        :param count: nth page of report. Each page has 25000 records.
        :return:
        """
        data = pd.DataFrame()  ## Initialize
        if not self.isdownloadError:
            try:
                curr_start = self.page_size * count
                source_bucket = self.get_report_url(file_key, start_page=str(curr_start))
                r = requests.get(source_bucket)
                out = json.loads(r.text)
                data = pd.DataFrame.from_dict(out['data'])
            except Exception as e:
                trycount_local += 1
                if trycount_local == self.max_try:
                    self.isdownloadError = True
                    self.downloadErrorReason = e
                    return data
            finally:
                if trycount_local > 1 and trycount_local < self.max_try:
                    time.sleep(5)
                    self.download_parallely(file_key, trycount_local, count)
            return data
        return data