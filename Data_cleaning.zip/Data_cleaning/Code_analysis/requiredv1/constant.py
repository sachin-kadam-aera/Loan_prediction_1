
class Constant:
    """
    Constant is class used to store all string literals
    """ 
    # Setting platform env
    TIME_TO_FETCH_CONFIG = 15
    PLATFORM_GCP = 'gs'
    PLATFORM_AWS = 's3'
    PLATFORM_HDFS = 'hdfs'
    PLATFORM_AERA = 'aera'
    ENVIRONMENT = 'gs'
    PLATFORM_LOCAL = ['local','file']

    # Single Characters
    FILE_SEPARATOR = '/'
    ENV_SEPARATOR = '://'
    FILE_EXTENSION_SEPARATOR = '.'
    PROPERTIES_FILE_SEPERATOR = '=' 
    UNDERSCORE = '_'
    COLON = ':'
    BLANK = ''
    CSV_FILE_EXT = ".csv"
    JSON_FILE_EXT = ".json"
 
    # All temp file path
    LOCAL_LOCATION_OF_LOG = '/tmp/log_files/'
    LOCAL_LOCATION_OF_DOWNLOAD = '/tmp/cortex'
    LOCAL_LOCATION_OF_URL_FILE = '/tmp/url.txt'
    LOCAL_LOCATION_OF_PLATFORM_FILE = '/tmp/platform.ini'
    
    # Request & Response Key
    STATUS_CODE = 'status_code'
    STATUS = 'status'
    MESSAGE = 'message'
    RESULT = 'result'
    FAILED  = 'Failed'
    SUCCESS  = 'Success'
    DEFAULT_STATUS_CODE ='DEFAULT'
    LOCAL_LOCATION_PATH = "local_path"
    REMOTE_LOCATION_PATH = "remote_path"
    TASK_ID = "task_id"

    # Request & Response  parameter
    WEBSERVICE = 'cortex'
    TIMESTAMP = '%Y-%m-%d_%H:%M:%S.{}'
    TEST_DATA_PROPERTIES = 'test_data.properties'
    TASKS = "tasks"
    METADATA = "metadata"
    FORECAST = "forecast"

    # Status code for Validation Erros
    IMPROPER_REQUEST = 'IMPROPER_REQUEST'
    IMPROPER_RESPONSE = 'IMPROPER_RESPONSE'

    # Messages for Validation Erros
    IMPROPER_REQUEST_MESSAGE = 'Improper request'
    IMPROPER_RESPONSE_MESSAGE = 'Improper response'
    INVALID_JSON_KEY_MESSAGE = 'Key accessed was not found in the json file' 
    GRAINS_SUCCESS_MESSAGE = 'We have successfully generated grains'
    FORECAST_SUCCESS_MESSAGE = 'We have successfully generated forecast for grains.'
    DEFAULT_MESSAGE = 'Something went wrong'
    JOB_POST_PROCESS_SUCCESS_MESSAGE = 'We have successfully triggred forecast post process'
    TASK_GENERATION_MESSAGE = 'Task generation underprocess(Taking longer time), Please track Job for more detail.'
    API_SUCCESS_MESSAGE = 'API executed successfully kindly refer metadata key for more detail.'

    # Messages for Service Erros
    SERVICE_ERROR_MESSAGE = 'Service error'
    ERROR_SAVE_JSON = 'Unable to create json file of the frame'
    FILE_ERROR = '%s : Invalid File Path or File does not exist'
    JSON_FORMAT_ERROR = '%s : not a json file or incorrect json'

    # json parameter
    INPUT_PAYLOAD_LOG = 'Input Payload for JoId %s : %s'
    REMOTE_GRAIN_PATH_FORMAT = '{0}/grains/{1}'
    REMOTE_FORECAST_PATH_FORMAT = '{0}/forecast/{1}'
    REMOTE_METADATA_DEF_PATH_FORMAT = '{0}/metadata/{1}'
    REMOTE_JOB_DIRECTORY = '{0}/{1}/{2}/{3}' ## Basepath, projectId, serviceId, jobId, Then metadata path 
    # variable used in business logic
   
    # variables used in custom exception
    UTILITY_EXCEPTION = 'UTILITY_EXCEPTION'
    DOWNLOAD_EXCEPTION = 'DOWNLOAD_EXCEPTION'
    UPLOAD_EXCEPTION = 'UPLOAD_EXCEPTION'
    ENV_NOT_SUPPORTED_EXCEPTION = 'ENV_NOT_SUPPORTED_EXCEPTION'
    SERVICE_EXCEPTION = 'SERVICE_EXCEPTION'
    INVALID_JSON_KEY_REQUEST = 'INVALID_JSON_KEY_REQUEST'
    CORRUPTED_FILE_EXCEPTION = 'CORRUPTED_FILE_EXCEPTION'
    FILE_NOT_FOUND_EXCEPTION = 'FILE_NOT_FOUND_EXCEPTION'
    DIRECTORY_NOT_FOUND = 'DIRECTORY_NOT_FOUND'
    SYNTAX_ERROR_IN_JSON_EXCEPTION = 'SYNTAX_ERROR_IN_JSON_EXCEPTION'
    INVALID_LIST_FORMAT_EXCEPTION = 'INVALID_LIST_FORMAT_EXCEPTION'

    # Log messages used in services
    FOLDER_REMOVE_LOG = 'Unique folder removed: %s '
    DIRECTORY_NOT_FOUND_LOG = 'Unable to find the directory: %s'
    TOTAL_TIME_LOG = 'Total time: %s '
    OUTPUT_FILE_LOCATION_LOG = 'output file location info generated %s '
    ALL_FILE_UPLOADED_LOG = 'All File uploaded in %s '
    METADATA_LOG = 'Metadata generated in %s '
    KEY_NOT_FOUND_LOG = 'Key %s not found in %s '
    IOERROR = 'IOerror : %s '
    ATTRIBUTE_ERROR= 'Attribute error : %s'
    JSON_FILE_READ_STATUS= 'sucessfully read json file'
    CORRUPTED_FILE_LOG = 'Invalid model found : %s'
    FILE_NOT_FOUND_LOG = 'model not found : %s'
    INVALID_JSON_KEY_LOG='Key not available in json : %s'
    SYNTAX_ERROR_IN_JSON_LOG = 'syntax error in json file : %s'
    INVALID_VALUE_IN_JSON_EXCEPTION_LOG = 'invalid value of json file :%s'
    NUMBER_OF_GRAINS = "Number of Grains: {}"

    #Log message used in utils
    UNABLE_TO_DOWNLOAD_LOG ='Unable to download given file : {0}'
    BUCKET_NOT_FOUND_LOG = 'Sorry, given bucket does not exist : {0}'
    B ='Blob %s downloaded to %s.'
    CONFIG_FILE = 'service.properties'
    SPLITER = "forecast"

    # Test URLs
    TEST_URL_HTTP = 'http://'
    TEST_URL_APP = '/grains/'

    # Test Messages
    HAPPY_MESSAGE = 'We have successfully generated messages for downstream services'
    NEGATIVE_MESSAGE_500 = 'Sorry, given bucket does not exist.'

    
    # Constants used in Process Logic
    # ++++++++++++++of Process logic used Constants++++++++++++++++++++
    ## TaskGenerator
    TASK_GENERATOR_WAIT_TIME = 20 ## In Sec
    HDFS_NUMBER_OF_THREAD = 50
    # ++++++++++++++END of Process logic used Constants ++++++++++++++++++++

    CORTEX_PREFIX = "CORTEXKEY-"
    COUNTER_EXTENSION = "_COUNTER"
    JOB_LIST_EXTENSION = "_JOBLIST"
    TASK_SET_EXTENSION = "_TASKSET"
    JOB_POST_PROCESS_URL_EXTENSION = "_JOB_POST_PROCESS_REQUEST_URL"
    TASK_PROCESS_URL_EXTENSION = "_TASK_PROCESS_REQUEST_URL"
    PAYLOAD_INFO = "_PAYLOADINFO"
    POST_PROCESS_PAYLOAD_INFO = "_POSTPROCESSPAYLOADINFO"
    REQUEST_TYPE = "requestType"
    REQUEST_URL = "requesturl"
    REQUEST_HEADER = "requestHeader"
    REQUEST_BODY = "requestBody"
    DATA_URI = "dataUri"
    RESULT_URI = "resultUri"
    ACTUAL_DATA = "actualData"
    DATA_POINTER = "dataPointer"
    CURRENT_ACTIVATED_SLOTS = "_CURRENTACTIVATEDSLOTS"
    TASK_DEFINATION_POINTER = "taskDefinPointer"
    HOST = "localhost"
    PORT = 6379
    FORECAST_SERVICE_URL = "http://127.0.0.1:8002/aera/cortex/v2/forecast/"

    # Constants used for DB related
    TBL_JOB_STATUS = '{}.cortex_framework_jobs_status'
    JOB_ERROR_STATUS_CODE = "ER"
    JOB_FINSH_STATUS_CODE = "FI"
    JOB_PROGRESS_STATUS_CODE = "PR"
    JOB_VALIDATION_SUCCESS_STATUS_CODE = "SU"
    EXPORTING_PROCESS = "Task Aggregator process has {} for Job Id: {}"


    ## Constant used for logging purpose
    TASK_GENERATOR = "TaskGenerator"
    TASK_ORCHESTRATOR = "TaskOrchestrator"
    TASK_ORCHESTRATOR_APIs = "TaskOrchestratorApis"
    TASK_AGGREGATOR = "TaskAggregator"

   
   
    API_INITIATED = "API_INITIATED"
    MSG_INITIATED = "{}: API request has been initiated"
    API_PAYLOAD_VALID = "API_PAYLOAD_VALIDATION"
    MSG_VALID_PAYLOAD = "{}: API payload validation successful"
    MSG_VALID_PAYLOAD_FAILED = "{}: API payload validation failed error found: {}"
    INPUT_PAYLOAD = "{}: Payload: {}"
    API_SERVICE_INITIATED = "API_DAL_INITIATED"   ## DAL: Data Access Layer 
    MSG_API_SERVICE_INITIATED = "{}: API DAL has been initiated"
    ## In b/w We have service specific logs
    API_SERVICE_COMPLETED = "API_DAL_COMPLETED"
    MSG_API_SERVICE_COMPLETED = "{}: API DAL has been completed"
    MSG_API_SERVICE_COMPLETED_FAILED = "{}: API DAL has been failed error found: {}"
    MSG_API_SERVICE_TOTAL_TIME = "{}: API DAL has been completed in {}"

    API_COMPLETED = "API_COMPLETED"
    MSG_API_COMPLETED = "{}: API request has been completed"
    MSG_API_COMPLETED_FAILED = "{}: API request has been failed error found: {}"
    MSG_API_TOTAL_TIME = "{}: API request has been completed in {}"

