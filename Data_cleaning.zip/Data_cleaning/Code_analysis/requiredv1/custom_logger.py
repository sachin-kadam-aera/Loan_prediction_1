import time 
import logging
import json 

def action_logger(action_key = None, action_name = None):
    '''Main decorator that take keywords'''
    log = logging.getLogger(__name__)
    def decorator_function(original_function):
        '''Take Original function as argument and return as function'''
        def wrapper_function(*args,**kwargs):
            request_id = kwargs['job_id']
            start_time = time.time()
            log.info("{0}: {1} : {2} : START-TIME: {3}".format(action_key, action_name, request_id,start_time), extra=get_extra_log_keys(job_id=request_id))

            result = original_function(*args,**kwargs)

            end_time = time.time()
            log.info("{0}: {1} : {2} : END-TIME: {3}".format(action_key, action_name, request_id,start_time), extra=get_extra_log_keys(job_id=request_id))
            log.info("{0}: {1} : {2} : DIFF: {3}".format(action_key,action_name,request_id,end_time-start_time), extra=get_extra_log_keys(job_id=request_id))
            
            return result
        return wrapper_function
    return decorator_function



def get_extra_log_keys(*args, **kwargs):
    """
    >>>> log_info = {"job_id":"jjj", "service_id": "ssss", "project_id": "ppp"}
    >>>> get_extra_log_keys(**log_info)
    >>>> {'contextMap': '{"jobId": "jjj", "serviceId": "ssss", "projectId": "ppp"}'}

    >>>> log_info1 = {"jobid":"jjj", "serviceid": "ssss", "PROJECTID": "ppp"}
    >>>> get_extra_log_keys(**log_info1)
    >>>> {'contextMap': '{"jobId": "jjj", "serviceId": "ssss", "projectId": "ppp"}'}
    """
    standard_key_map = {"JOBID":"jobId", "SERVICEID":"serviceId", "PROJECTID":"projectId"}

    context_map = {}
    for key, val in kwargs.items():
        map_key = str(key).replace("_", "").upper()
        if map_key in standard_key_map.keys():
            context_map[standard_key_map.get(map_key)] = val
    
    rest_keys = set(standard_key_map.values()) - set(context_map.keys())
    for rest_key in rest_keys:
        context_map[rest_key] = "1000"
    extra = {"contextMap":json.dumps(context_map)}
    return extra