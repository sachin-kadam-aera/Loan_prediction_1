import pandas as pd
import datetime
import dateutil
# import scipy as sc
# from scipy import stats
from datetime import date, timedelta



sales_data = pd.read_csv("/Users/sachinkadam/Pulmuone/Data/1Sales_Order_Weekly.csv",skiprows=3)

sales_data["Grain"] = sales_data['Channel'].astype(str) +"-"+ sales_data["Material Number"].astype(str)
grains_1000 = list(sales_data["Grain"].drop_duplicates())[:1000]

sales_data_1kGrain = sales_data[sales_data['Grain'].isin(grains_1000)]

#sales_data_groupby = sales_data.groupby(['Grain']).size()

snapshotdate = "2021-10-04" #"2021-04-19"

## weekly sales before snapshot date

def sales_before_snapshotdate(df,snapshotdate):
    df['Week Starting'] = pd.to_datetime(df['Week Starting'])
    df = df.sort_values('Week Starting')
    df = df[(sales_data['Week Starting'] <= snapshotdate)]
    return df

sales_before_snasphot = sales_before_snapshotdate(sales_data_1kGrain,snapshotdate)

#sales_before_snasphot["Grain"] = sales_before_snaphot['Channel'].astype(str) +"-"+ sales_before_snaphot["Material Number"].astype(str)

#sales_before_snaphot_groupby = sales_before_snaphot.groupby(['Grain']).size()

def remove_last12_zero_sales(df1,snapshotdate):
    ##Remove grains (channel + sku) where sales is 0 in last 12 month
    snapshotdatev1 = pd.to_datetime(snapshotdate,format="%Y-%m-%d")
    month_12 = snapshotdatev1 - dateutil.relativedelta.relativedelta(months=12)
    
    one_yr_df = df1[(df1['Week Starting']>= month_12) & (df1['Week Starting']<= snapshotdatev1)]
    one_yr_df = one_yr_df.groupby(['Grain'])['Order Item Quantity'].sum().reset_index()
    one_yr_df = one_yr_df[one_yr_df['Order Item Quantity'] == 0]
    
    df = pd.merge(df1, one_yr_df, on=['Grain'], how='outer',indicator=True).query("_merge != 'both'").drop('_merge', axis=1).reset_index(drop=True)
    df = df.rename(columns={'Order Item Quantity_x': 'Order Item Quantity'})
    df = df.drop(['Order Item Quantity_y'], axis = 1)
    return df

last12_zero_sales = remove_last12_zero_sales(sales_before_snasphot,snapshotdate)

##Remove leading zeroes for each grain

### example remove leading zero
#CS유통	2766262
#GS CVS - 1816228
## before - last12_zero_sales1 = last12_zero_sales[(last12_zero_sales['Channel'] == 'AK분당') & (last12_zero_sales['Material Number'] == 2573037)]
#after - last12_zero_sales1 = last12_zero_sales[(last12_zero_sales['Channel'] == 'AK분당') & (last12_zero_sales['Material Number'] == 2573037)]

def remove_leading_zero(df,thresh):
    remove_leading_zero = df[df['Order Item Quantity'].ne(thresh).groupby(df['Grain']).cumsum().gt(0)]
    return remove_leading_zero

thresh = 0
remove_leading_zero_df = remove_leading_zero(last12_zero_sales,thresh)

#Impute missing weeks for each grain

def add_week(grouped_data,snapshotdate):
    min_date = grouped_data['Week Starting'].min()
    #max_date = grouped_data['Week Starting'].max()
    max_date = snapshotdate
    df_data = pd.DataFrame([pd.date_range(min_date, max_date,freq='W-MON')]).T.rename(columns={0:'Week Starting'})
    grouped_data = grouped_data.merge(df_data, on = ['Week Starting'], how = 'right')
    grouped_data[['Channel', 'Material Number','Grain']] = grouped_data[['Channel', 'Material Number','Grain']].ffill(axis = 0)
    return grouped_data

def add_missing_week(data,snapshotdate):
    data['Week Starting'] = pd.to_datetime(data['Week Starting'], format='%Y-%m-%d')
    snapshotdate =  pd.to_datetime(snapshotdate,format="%Y-%m-%d")
    data_group = data.groupby(['Channel', 'Material Number','Grain']).apply(lambda x : add_week(x,snapshotdate))
    data_group = data_group.sort_values('Week Starting')
    data_group['Order Item Quantity'] = data_group['Order Item Quantity'].fillna(0)
    return data_group.reset_index(drop=True)        

add_missing_week = add_missing_week(remove_leading_zero_df,snapshotdate)

### Add horizon dates (next 52 weeks)

def add_horizon(data,snapshotdate):
    data['Week Starting'] = pd.to_datetime(data['Week Starting'], format='%Y-%m-%d')
    snapshotdatev1 = pd.to_datetime(snapshotdate,format="%Y-%m-%d")
    next_month_12 = snapshotdatev1 + dateutil.relativedelta.relativedelta(weeks=52)
    data_group = data.groupby(['Channel', 'Material Number','Grain']).apply(lambda x : add_week_next(x,next_month_12))
    data_group = data_group.sort_values('Week Starting')
    data_group['Order Item Quantity'] = data_group['Order Item Quantity'].fillna(0)
    return data_group.reset_index(drop=True)

def add_week_next(grouped_data,next_month_12):
    min_date = grouped_data['Week Starting'].min()
    #max_date = x['Week Starting'].max()
    max_date = next_month_12
    df_data = pd.DataFrame([pd.date_range(min_date, max_date,freq='W-MON')]).T.rename(columns={0:'Week Starting'})
    grouped_data = grouped_data.merge(df_data, on = ['Week Starting'], how = 'right')
    grouped_data[['Channel', 'Material Number','Grain']] = grouped_data[['Channel', 'Material Number','Grain']].ffill(axis = 0)
    return grouped_data

add_horizo_week = add_horizon(add_missing_week,snapshotdate)

##Add new date column in format (YYYYWW) --> ISO Week number
#YW = pd.to_datetime(z1['Week Starting']).dt.strftime('%Y%W')
Preprocsses_Data = add_horizo_week
Preprocsses_Data['YYYYWW'] = pd.to_datetime(Preprocsses_Data['Week Starting']).dt.strftime('%Y%V')
Preprocsses_Data.to_csv("/Users/sachinkadam/Pulmuone/PreProc.csv")

############################# Season Daily Level ############################# 
#Read Data
input_data = pd.read_csv("/Users/sachinkadam/Pulmuone/Data/2SeasonDailyLevel.csv",skiprows=3)

#1. Remove columns
input_data = input_data.drop(['FALL','PUBLICHOLIDAY','SPRING','SUMMER','WINTER'], axis = 1)

#3. Add features 
def add_lag_and_fill_values(data, columns = []):

    print(f'running for columns -----> {col}')
    data = data[['Date', col]].reset_index(drop=True)
    data['year'] = data['Date'].dt.year

    kor_col = 'kor_' + col
    kor_col_pre = 'kor_' + col + '_pre'
    kor_col_after = 'kor_' + col + '_after'
    data[kor_col] = 0
    data[kor_col_pre] = 0
    data[kor_col_after] = 0
    data = data.sort_values('Date', ascending=True)
    if bool(any(data[data[col] == 1].index.values)) == False:
        year_date = data[data[col] == 0]['year'].unique()
        print(f'No data in {year_date[0]}\n')
#             final_df = pd.concat(x,final_df)
        return data
    else:
        lag0 = data[data[col] == 1].index.values[0]
        year_date = data[data[col] == 1]['year'].unique()
        fixed_date = data[data[col] == 1]['Date'].unique()
        print(f'Data found in {year_date[0]}')
        print(f'Data found in {fixed_date[0]}\n')
        lag1 = lag0 + 1
        lag2 = lag0 + 2
        lag_pre1 = lag0 - 1
        lag_pre2 = lag0 - 2
        lag_pre3 = lag0 - 3
        lag_3 = lag0 + 3
        lag_4 =  lag0 + 4
        lag_5 =  lag0 + 5
        data.loc[lag0:lag2,kor_col] = 1
        data.loc[lag_pre3:lag_pre1,kor_col_pre] = 1
        data.loc[lag_3:lag_5,kor_col_after] = 1
        return data
    
input_data['orignal_date'] = input_data['Date']
input_data['Date'] = pd.to_datetime(input_data['Date'])
input_data['year'] = input_data['Date'].dt.year

columns=['CHOBOK', 'CHRISTMAS', 'CHUSEOK', 'JUNGBOK', 'LUNARNY',
                           'MALBOK', 'SOLARNY',
                           'WINTERSOLSTICE', 'INDEPENDENCE_DAY', 'CHILDRENS_DAY', 'BUDDA_BDAY',
                           'MEMORIAL_DAY', 'NAT_LIBERATION_DAY', 'NAT_FOUNDATION_DAY',
                           'HANGUL_DAY']

final_df = input_data['orignal_date']
for col in columns:
    new_df = input_data.groupby(['year']).apply(lambda x : add_lag_and_fill_values(x, columns=col)).reset_index(drop=True)
    new_df.drop(['year','Date'], axis = 1,inplace=True)
    final_df = pd.concat([new_df,final_df], axis = 1)

# Remove original columns    
final_df = final_df.drop(['CHOBOK', 'CHRISTMAS', 'CHUSEOK', 'JUNGBOK', 'LUNARNY',
                           'MALBOK', 'SOLARNY',
                           'WINTERSOLSTICE', 'INDEPENDENCE_DAY', 'CHILDRENS_DAY', 'BUDDA_BDAY',
                           'MEMORIAL_DAY', 'NAT_LIBERATION_DAY', 'NAT_FOUNDATION_DAY',
                           'HANGUL_DAY'], axis = 1)

# week starting monday is added 
final_df['DateUpdated'] = pd.to_datetime(final_df['orignal_date'])
final_df['Week_start_Monday']= final_df['DateUpdated'] - pd.to_timedelta(arg=final_df['DateUpdated'].dt.weekday, unit='D')

#final_df.to_csv("/Users/sachinkadam/Pulmuone/Data/mergeddata_final_df.csv") 
#Group by and get sum of all columns
Grouped_data = final_df.groupby('Week_start_Monday',as_index= False).sum()
Grouped_data = Grouped_data.reset_index(drop=True)
Grouped_data = Grouped_data.rename(columns = {'Week_start_Monday':'Week Starting'})

#Grouped_data.to_csv("/Users/sachinkadam/Pulmuone/Data/groupdata.csv")

# Merge calender features with preprocessed data
Merged_data = pd.merge(Preprocsses_Data, Grouped_data,on = ['Week Starting'],how='left').fillna(0)

Merged_data.to_csv("/Users/sachinkadam/Pulmuone/Data/Script1_output.csv")
    
    
    
    
    
    
    
    
    
    


















      