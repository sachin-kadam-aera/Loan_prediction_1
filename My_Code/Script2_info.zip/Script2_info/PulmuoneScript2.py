import pandas as pd
import numpy as np
import datetime
import dateutil
# import scipy as sc
# from scipy import stats
from datetime import date, timedelta

sales_data = pd.read_csv("/Users/sachinkadam/Pulmuone/Data/1Sales_Order_Weekly.csv",skiprows=3)

sales_data["Grain"] = sales_data['Channel'].astype(str) +"-"+ sales_data["Material Number"].astype(str)
grains_1000 = list(sales_data["Grain"].drop_duplicates())[:1000]

sales_data_1kGrain = sales_data[sales_data['Grain'].isin(grains_1000)]


# 1. Snapshot date define 
snapshotdate = "2021-10-04" #"2021-04-19"

# 2. Filter data from 2020-03-01 to snapshot date
filter_date = "2020-03-01"

def sales_between_snapshotdate_to_filter_date(df,snapshotdate,filter_date):
    df['Week Starting'] = pd.to_datetime(df['Week Starting'])
    df = df.sort_values('Week Starting')
    df = df[(sales_data['Week Starting'] >= filter_date) & (sales_data['Week Starting'] <= snapshotdate)]
    return df

sales_before_snasphot = sales_between_snapshotdate_to_filter_date(sales_data_1kGrain,snapshotdate,filter_date)

## example -1715203	GS슈퍼-1814097

#3. Remove leading zero

def remove_leading_zero(df,thresh):
    remove_leading_zero = df[df['Order Item Quantity'].ne(thresh).groupby(df['Grain']).cumsum().gt(0)]
    return remove_leading_zero

thresh = 0
remove_leading_zero_df = remove_leading_zero(sales_before_snasphot,thresh)

# 4. ABC mapping according to last 1 year

def ABC_segmentation(df1,snapshotdate):
    ##Remove grains (channel + sku) where sales is 0 in last 12 month
    snapshotdatev1 = pd.to_datetime(snapshotdate,format="%Y-%m-%d")
    month_12 = snapshotdatev1 - dateutil.relativedelta.relativedelta(months=12)
    
    one_yr_df = df1[(df1['Week Starting']>= month_12) & (df1['Week Starting']<= snapshotdatev1)]
    grouped_abc = one_yr_df.groupby(['Grain'])["Order Item Quantity"].sum().reset_index(name="Total order qyt")
    grouped_abc['Volume share'] = grouped_abc['Total order qyt']/grouped_abc['Total order qyt'].sum()
    grouped_abc = grouped_abc.sort_values('Volume share',ascending=False)
    grouped_abc['CumSum'] = grouped_abc['Volume share'].cumsum()
    grouped_abc['ABC'] = np.where(grouped_abc.CumSum <= 0.8, 'A',
                           np.where(grouped_abc.CumSum <= 0.95,'B', 'C'))
    # 5. Drop class C grains
    ab_class = grouped_abc.loc[grouped_abc['ABC']!= 'C']
    grains_ab = list(ab_class["Grain"].drop_duplicates())
    ab_class_data = df1[df1['Grain'].isin(grains_ab)]
    return ab_class_data

ABC_data = ABC_segmentation(remove_leading_zero_df,snapshotdate)

# 6. Add missing weeks

def add_week(grouped_data,snapshotdate):
    min_date = grouped_data['Week Starting'].min()
    #max_date = grouped_data['Week Starting'].max()
    max_date = snapshotdate
    df_data = pd.DataFrame([pd.date_range(min_date, max_date,freq='W-MON')]).T.rename(columns={0:'Week Starting'})
    grouped_data = grouped_data.merge(df_data, on = ['Week Starting'], how = 'right')
    grouped_data[['Channel', 'Material Number','Grain']] = grouped_data[['Channel', 'Material Number','Grain']].ffill(axis = 0)
    return grouped_data

def add_missing_week(data,snapshotdate):
    data['Week Starting'] = pd.to_datetime(data['Week Starting'], format='%Y-%m-%d')
    snapshotdate =  pd.to_datetime(snapshotdate,format="%Y-%m-%d")
    data_group = data.groupby(['Channel', 'Material Number','Grain']).apply(lambda x : add_week(x,snapshotdate))
    data_group = data_group.sort_values('Week Starting')
    data_group['Order Item Quantity'] = data_group['Order Item Quantity'].fillna(0)
    return data_group.reset_index(drop=True)        

add_missing_week = add_missing_week(ABC_data,snapshotdate)

# 7. XYZ mapping

def xyz(record):
    if record['COV'] <= 0.5:
        return'X'
    elif record['COV'] > 0.5 and record['COV']<=0.75:
        return 'Y'
    else:
        return 'Z'

def xyz_class(data):
    xyz_class = data.groupby(['Grain'])['Order Item Quantity'].agg(['mean','std']).rename(columns={'mean':'Mean'}).reset_index()
    xyz_class['COV'] = xyz_class['std']/xyz_class['Mean']
    xyz_class['XYZ'] = xyz_class.apply(xyz, axis=1)
    
    # 8. Drop Z class
    xy_class = xyz_class.loc[xyz_class['XYZ']!= 'Z']
    grains_xy = list(xy_class["Grain"].drop_duplicates())
    xy_class_data = data[data['Grain'].isin(grains_xy)]
    return xy_class_data

XY_Class_Data = xyz_class(add_missing_week)

#XY_Class_Data.to_csv("/Users/sachinkadam/Downloads/xyclass.csv")

# 9. Find intermittency
def intermittency(data):
    Total_pointsDF = data.groupby(['Grain'])['Order Item Quantity'].count().reset_index(name='Total Data Points')
    No_of_ZeroDF = data.groupby('Grain', sort=False)['Order Item Quantity'].agg(lambda x:x.eq(0).sum()).to_frame('No of Zeros').reset_index()
    
    intermittency = pd.merge(Total_pointsDF,No_of_ZeroDF,how='inner',on = ['Grain'])
    intermittency['intermittency'] = intermittency['No of Zeros']/intermittency['Total Data Points']
    
    # 10. Drop grains have intermittency > 0.2
    hign_intermittent = intermittency.loc[intermittency['intermittency'] > 0.2]
    grains = list(hign_intermittent["Grain"].drop_duplicates())
    
    if grains:
        intermittent_dta = data[data['Grain'].isin(grains)]
    else:
        intermittent_dta = data
        
    return intermittent_dta

intermittent_DF = intermittency(XY_Class_Data)
#example - 가맹-2375250 

############# Covid indices

input_indices = pd.read_csv("/Users/sachinkadam/Downloads/2KoreaCovidIndices.csv")
input_indices = input_indices[['Date','Cancel Public Events','Close Public Transport','School Closing','Stringency Index',
                               'Workplace Closing','new_deaths','new_cases']].fillna(0)

input_indices['DateUpdated'] = pd.to_datetime(input_indices['Date'])
input_indices['Week_start_Monday']= input_indices['DateUpdated'] - pd.to_timedelta(arg=input_indices['DateUpdated'].dt.weekday, unit='D')

aggerigated = input_indices.groupby(['Week_start_Monday']).agg({'new_cases' :'sum', 'new_deaths':'sum', 'School Closing' : 'median', 'Stringency Index' : 'median', 'Workplace Closing' : 'median',
                                                                'Cancel Public Events' : 'median', 'Close Public Transport' : 'median'})

aggerigated = aggerigated.reset_index(drop=False)
##### Merge sales history with covid indices
aggerigated = aggerigated.rename(columns = {'Week_start_Monday':'Week Starting'})

#Grouped_data.to_csv("/Users/sachinkadam/Pulmuone/Data/groupdata.csv")

# Merge calender features with preprocessed data
Merged_data = pd.merge(intermittent_DF, aggerigated,on = ['Week Starting'],how='left').fillna(0)
Merged_data.to_csv("/Users/sachinkadam/Pulmuone/Data/script2output.csv")


















