

--- holiday fact table name - FACT_NA_HOLIDAY_LIST

drop table if exists temp_HolidayFedral;
create table temp_HolidayFedral as select
DD_COUNTRY,
DD_DATE_,
DD_HOLIDAY_DESCRIPTION,
DD_JURISDICTION
from FACT_NA_HOLIDAY_LIST
where DD_JURISDICTION = 'Federal';

