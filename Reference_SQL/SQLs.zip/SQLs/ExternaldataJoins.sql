
--Demo Graphic
drop table if exists temp_demographics;
create table temp_demographics as (
select a.*,
b.DD_CITY,
b.DD_COUNTY,
b.DD_CTR,
b.DD_FULL_COUNTRY_NAME,
b.DD_FULL_STATE_NAME,
b.DD_PLACE,
b.DD_POSTALCODE,
b.DD_RG
from
tmp_subprocess6_final a left join
FACT_NA_DC_DEMOGRAPHIC_DATA b on a.DD_PLANTCODE = b.DD_PLNT)

--Stringency Index
drop table if exists temp_stringencyIndex;
create table temp_stringencyIndex as (
select a.*,
b.DD_STRINGENCYINDEX from
temp_demographics a left join 
fact_NA_Covid_Stringency_Data b on 
a.DD_FULL_STATE_NAME=b.DD_REGIONNAME and a.DD_ACTUALDELIVERYDATE=b.DD_FORMATTED_DATE)

--Mobility Index

drop table if exists temp_google_covid_mobility_county;
create table temp_google_covid_mobility_county as (select DD_COUNTRY_REGION_CODE,
DD_DATE_,
DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE,
DD_RETAIL_AND_RECREATION_PERCENT_CHANGE_FROM_BASELINE,
DD_SUB_REGION_1,
DD_SUB_REGION_2 from Fact_NA_Covid_Mobility_Data where DD_SUB_REGION_2 is not null or DD_SUB_REGION_2<>'')


drop table if exists temp_google_covid_mobility_state;
create table temp_google_covid_mobility_state as (select DD_COUNTRY_REGION_CODE,
DD_DATE_,
DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE,
DD_RETAIL_AND_RECREATION_PERCENT_CHANGE_FROM_BASELINE,
DD_SUB_REGION_1,
DD_SUB_REGION_2 from Fact_NA_Covid_Mobility_Data where DD_SUB_REGION_1 is not null or DD_SUB_REGION_1<>'' and DD_SUB_REGION_2 is not null or DD_SUB_REGION_2<>'' );


drop table if exists temp_google_covid_mobility_country;
create table temp_google_covid_mobility_country as (select DD_COUNTRY_REGION_CODE,
DD_DATE_,
DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE,
DD_RETAIL_AND_RECREATION_PERCENT_CHANGE_FROM_BASELINE,
DD_SUB_REGION_1,
DD_SUB_REGION_2 from Fact_NA_Covid_Mobility_Data where DD_SUB_REGION_1 is not null or DD_SUB_REGION_1<>'' and DD_SUB_REGION_2 is not null or DD_SUB_REGION_2<>'' and DD_COUNTRY_REGION is not null or DD_COUNTRY_REGION<>'' )

drop table if exists temp_google_covid_mobility_countyM;
create table temp_google_covid_mobility_countyM as (select a.*,
b.DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE as County_grocery_and_pharmacy_percent_change_from_baseline,
b.DD_RETAIL_AND_RECREATION_PERCENT_CHANGE_FROM_BASELINE as County_retail_and_recreation_percent_change_from_baseline 
 from temp_stringencyIndex a left join temp_google_covid_mobility_county b on a.DD_CTR=b.DD_COUNTRY_REGION_CODE and a.DD_FULL_STATE_NAME=b.DD_SUB_REGION_1 and a.DD_COUNTY=b.DD_SUB_REGION_2 and a.DD_ACTUALDELIVERYDATE=b.DD_DATE_ )


drop table if exists temp_google_covid_mobility_stateM;
create table temp_google_covid_mobility_stateM as (select a.*,
b.DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE as State_grocery_and_pharmacy_percent_change_from_baseline,
b.DD_RETAIL_AND_RECREATION_PERCENT_CHANGE_FROM_BASELINE as State_retail_and_recreation_percent_change_from_baseline
 from temp_stringencyIndex a left join temp_google_covid_mobility_state b on a.DD_CTR=b.DD_COUNTRY_REGION_CODE and a.DD_FULL_STATE_NAME=b.DD_SUB_REGION_1  and a.DD_ACTUALDELIVERYDATE=b.DD_DATE_ )



drop table if exists temp_google_covid_mobility_countryM;
create table temp_google_covid_mobility_countryM as (select a.*,
b.DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE as Country_grocery_and_pharmacy_percent_change_from_baseline,
b.DD_RETAIL_AND_RECREATION_PERCENT_CHANGE_FROM_BASELINE as Country_retail_and_recreation_percent_change_from_baseline
 from temp_stringencyIndex a left join temp_google_covid_mobility_country b on a.DD_CTR=b.DD_COUNTRY_REGION_CODE and a.DD_ACTUALDELIVERYDATE=b.DD_DATE_ )







select * from temp_google_covid_mobility_countyM WHERE DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE IS NOT NULL ;


SELECT * FROM temp_stringencyIndex WHERE
DD_CTR='US' and DD_FULL_STATE_NAME='Nevada' and DD_COUNTY='Clark County' and DD_ACTUALDELIVERYDATE='2019-06-04'


SELECT * FROM Fact_NA_Covid_Mobility_Data WHERE 
DD_COUNTRY_REGION='US' and DD_SUB_REGION_1='Nevada' and DD_SUB_REGION_2='Clark County' and DD_DATE_='2019-06-04'

desc temp_stringencyIndex

desc Fact_NA_Covid_Mobility_Data


a.DD_CTR=b.DD_COUNTRY_REGION_CODE and a.DD_FULL_STATE_NAME=b.DD_SUB_REGION_1 and a.DD_COUNTY=b.DD_SUB_REGION_2 and a.DD_ACTUALDELIVERYDATE=b.DD_DATE_

left_on=["Ctr", "Full_State_Name", "County", "ActualDeliveryDate"], 
                      right_on=["country_region_code", "sub_region_1", "sub_region_2", "date"]





desc Fact_NA_Covid_Mobility_Data




DD_COUNTRY_REGION_CODE
DD_DATE_
DD_GROCERY_AND_PHARMACY_PERCENT_CHANGE_FROM_BASELINE
DD_RETAIL_AND_RECREATION_PERCENT_CHANGE_FROM_BASELINE
DD_SUB_REGION_1
DD_SUB_REGION_2


select b.* from Fact_NA_Covid_Mobility_Data b
where b.DD_SUB_REGION_1 is null or b.DD_SUB_REGION_2 is null or DD_COUNTRY_REGION is null






