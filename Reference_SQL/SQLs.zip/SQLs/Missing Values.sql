create table tem_simple_date as
select * from dim_simple_date where datevalue between (select min(DD_ACTUALDELIVERYDATE) as min_date from tmp_subprocess6_final) and (select max(DD_ACTUALDELIVERYDATE) as max_date from tmp_subprocess6_final)
order by datevalue;



drop table if exists temp_grain_date ;
create table temp_grain_date as
select distinct DD_FORECASTUNITCODE, DD_ECCCUSTOMERLEVEL7CODE, DD_PLANTCODE,DATEVALUE as 
DD_ACTUALDELIVERYDATE, 0 as CT_ACTUALDELIVEREDQUANTITY  from tmp_subprocess6_final
cross join tem_simple_date 


drop table if exists temp_prepprossed;
create table temp_prepprossed as
(select
a.DD_FORECASTUNITCODE,a.DD_ECCCUSTOMERLEVEL7CODE,a.DD_PLANTCODE,
a.DD_ACTUALDELIVERYDATE, b.DD_ACTUALDELIVERYDATE AS old_date, ifnull(b.CT_ACTUALDELIVEREDQUANTITY ,0) as CT_ACTUALDELIVEREDQUANTITY
 From temp_grain_date  a left join
tmp_subprocess6_final b
on a.DD_FORECASTUNITCODE=b.DD_FORECASTUNITCODE 
and a.DD_ECCCUSTOMERLEVEL7CODE=b.DD_ECCCUSTOMERLEVEL7CODE 
and a.DD_PLANTCODE=b.DD_PLANTCODE
and a.DD_ACTUALDELIVERYDATE=b.DD_ACTUALDELIVERYDATE);
where  a.DD_FORECASTUNITCODE='10077567721102' and 
a.DD_ECCCUSTOMERLEVEL7CODE='0030026728' and 	
a.DD_PLANTCODE='3989' AND
a.DD_ACTUALDELIVERYDATE > '2021-01-01'
order by a.DD_ACTUALDELIVERYDATE);

select * from temp_prepprossed a where  a.DD_FORECASTUNITCODE='10077567721102' and 
a.DD_ECCCUSTOMERLEVEL7CODE='0030026728' and 	
a.DD_PLANTCODE='3989' order by a.DD_ACTUALDELIVERYDATE;





