###########################################################################
# Name: update_parameters.py
# Author: naresh.jamnani@aeratechnology.com
# Purpose: To include the model and data parameters like no.of simulation, error metrics, etc

# Date                          Version                                 Created By
# 20-July-2022                    1.0                                    Naresh Jamnani(Initial Version)
###########################################################################

from safety_stock.utility.constant import Constant

class UpdateParams:
    def __init__(self,original_input):
        self.original_input = original_input

    def update_constant_params(self):

        self.original_input["modelParams"]["number_of_simulations"] = Constant.NUMBER_OF_SIMULATIONS

        approach = self.original_input["dataParams"]["approach"]
        if approach.__contains__("forecast"):
            self.original_input["modelParams"]["error_metric"] = "Error"

        self.original_input["dataParams"]["threshold_dd_distribution"] = Constant.DEMAND_THRESHOLD
        self.original_input["dataParams"]["threshold_lt_distribution"] = Constant.LEADTIME_THRESHOLD

        return self.original_input