class SimulationConfig:
    SimulationConfigs = {"0797FF95_4733_4F4A_880B_F474204228A1":
                             {
                                 "horizon": 14,
                             }
    }
