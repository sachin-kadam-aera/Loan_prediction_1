###########################################################################
# Name: common_utility.py
# Author: anil.gupta@aeratechnology.com
# Purpose: To define commonly usable functionlites for cortex backend
# Date                          Version                                 Created By
# 14-Feb-2020                    1.0                                    Anil Gupta(Initial Version)
###########################################################################

# Python Package & Modules
import logging
import os
import uuid
import json

# Project Related Package & Modules
from .constant import Constant

class CommonUtility:
    """
    DOCString
    """
    @staticmethod
    def get_logger(job_id='default', module_name=None):
        """
        get_logger: get logger object 
        """
        if not module_name:
            logger_instance = logging.getLogger(__name__)
        else:
            logger_instance = logging.getLogger(module_name)
        log = logging.LoggerAdapter(logger_instance, {Constant.JOB_ID:job_id})
        return log

    @staticmethod
    def get_config_file(module_name=None):
        """
        get_config_file: get config file abs file path 
        """
        config_file = ""
        if module_name:
            current_module_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)))
            parent_package = current_module_dir.split(Constant.SPLITER)[0]
            config_file = "".join([parent_package, Constant.SPLITER, os.sep, Constant.CONFIG_FILE])
        return config_file
    
    @staticmethod
    def concat_string(*args):
        """
        concat_string function is used to concatenate the string 

        @param:
            *args = takes variable no. of arguments 

        @returns:
            This will return newly created concatenated string 
        """
        return "".join(map(str, args))
    

    @staticmethod
    def generate_uuid():
        """ generate_uuid function is used to generate uuid of 32 character

        @returns:
            This will return 32 character uuid
        """
        return (uuid.uuid4())
    
    @staticmethod
    def dumps_json_in_files(json_file, json_data):
        """
        dumps_json_in_files function is used to dumps the json in file

        @param:
            json_file = json file
            json_data = json data dictionary
        """
        file_status = False
        with open(json_file, 'w') as file:
            json.dump(json_data, file)
            file_status = True
        file.close()
        return file_status