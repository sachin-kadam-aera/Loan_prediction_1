###########################################################################
# Name: constant.py
# Author: anil.gupta@aeratechnology.com
# Purpose: To define constant for all functionlites, will help us to reuse
# consistency of constant, ease to change constant value.

# Date                          Version                                 Created By
# 14-Feb-2020                    1.0                                    Anil Gupta(Initial Version)
###########################################################################
# Python Package & Modules
import os

# Global Initializers
BASE_DIR = os.path.dirname(os.path.realpath(__file__))


class Constant:
    BASE_PATH = BASE_DIR+"/../../../../" #"/Users/anilkumargupta/Desktop/aera/aera-cortex-be/"
    PYTHON_PROPERTIES = "python-properties"
    PRIORITY_QUEUE_MAX_GAIN = 'priorityQueueMaxGrain'
    CONFIG_FILE = 'service.properties'
    SPLITER = "forecast"

    ## POJECT Related Constant
    PROJECT_ID = "projectId"

    ## Consumer & Producer Related Constant
    CONSUMER_START_MSG = "Consumer Started for {} & Supplied Args are {}, {}, {}" ## Script name, args
    CONSUMER_EMPTY = "No Message Found"
    CONSUMER_MSG_RECIEVED = "Meassage Recieved in %s, with job id : %s get more detail: %s"  ## script name, job_id, log_path
    CONSUMER_MSG_CORRUPTED = "Got corrupted messaged %s %s" ## msg
    DEFAULT_CONSUMER_ERROR_MSG = "This is final error in Controller and may lead to close the consumer,  the error = %s" ##erro
    PRODUCER  = "{} has been {} in {}" # producer_name, started/completed/, script_name
    PUBLISHER = "{} has been {} in {}" # publisher_name, started/completed/, script_name
    CONSUMER_DOWNLOADER_TIMEOUT_MS_VALUE = 1500000 ## time in ms
    NUMBER_OF_MESSAGE = 5
    PARTITION_NUMBER = "{}"

    ## DB Related Constant
    DB_WRITER = "{} has been {} in {}" # dbwriter_name, started/completed/, script_name
    EXASOL_SUCCESS = "Data Has been written into Exasol DB {}"
    EXASOL_ERROR = "Service Failed in script {} for Job Id: {} with Error: {}"
    
    ## Kafka Related Constant
    KF_BOOTSTRAP_SERVER = "bootstrap.servers"
    KF_AUTO_COMMIT_DISABLE = False
    KF_OFFSET_RESET_VALUE = 'earliest'
    KF_MAX_POLL_INTERVAL_MS_VALUE = 600000 ## time in ms
    KF_MAX_POLL_INTERVAL_ASYNC_CONSUMER_MS_VALUE = 2520000

    ## Logger Related Constant
    JOB_ID_VALUE = "default"
    JOB_ID = 'jobId'

    SAMPLING_WARNING = "error in sampling the data"
    DATE_FORMAT_WARNING = "error in converting date format: {datetime_column_format}"
    GENERALIZED_CONSTANTS_WARNING = "Error in create_generalized_constants function"
    FORMAT_DATETIME_COLS_WARNING = "Error in format_datetime_cols function"
    DEFINE_DATATYPE_WARNING = "Error in define_datatype function"
    OUTLIER_TREATMENT_WARNING = "Error in apply_outlier_treatment function"
    DATA_AGGREGATION_DATEWISE_WARNING = "Error in data_aggregation_datewise function"
    NEGATIVE_DATA_IMPUTATION_WARNING = "Error in negative_data_imputation function"
    DATA_IMPUTATION_WARNING = "Error in data_imputation function"
    TRAIN_TEST_SPLIT_WARNING = "Error in train_test_split function"
    CREATE_DUMMY_VAR_WARNING = "Error in create_dummy_var function"

    ## Python Functionalities Related Constant
    PREPROCESSING_ERROR = "\n data preprocessing error : {function_specific} : Error = %s"
    GENERALIZED_CONSTANT = "While defining generalized constants"
    FORMAT_DATETIME_COLS = "While formatting datetime columns"
    DEFINE_DATATYPE = "While defining datatype"
    OUTLIER_TREATMENT = "While applying outlier detection method"
    DATA_AGGREGATION_DATEWISE = "While aggregating data datewise"
    NEGATIVE_DATA_IMPUTATION = "While performing negative data imputation"
    DATA_IMPUTATION = "While performing data imputation"
    TRAIN_TEST_SPLIT = "While splitting data into train and test"
    CREATE_DUMMY_VAR = "While creating dummy variables for categorigal variables"
    DAILY_DATA_MIN = "2010-12-01"
    DAILY_DATA_MAX = "2025-01-01"
    IS_FORECASTABLE_THRESHOLD = 0.8

    ## test_details Related Constant
    TEST_DETAILS_DATE_DUPLICATE = "Date duplicates found in the data"
    TEST_DETAILS_SAMPLING_ERROR = "Data sampling error : While sampling the data : Error = %s"
    TEST_DETAILS_DATE_COMPONENT = "Not in range"
    TEST_DETAILS_DATE_FORMAT_CONVERSION_ERROR = "Date conversion error for date format - {datetime_column_format}"
    TEST_DETAILS_NCHAR_CHECK = "Not all dates have {length_date_format} characters in the string date {datetime_column_format} format"

    ## Exception Related Constant
    NOT_NUMERIC_COLUMN_TYPE = "Not numeric column type"

    ## Service Related Constant
    CONTROLLER_CONSUMER_SCRIPT_NAME = "controller_consumer"
    DOWNLOADER_CONSUMER_SCRIPT_NAME  = "dataDownloader_consumer"
    SERVICE_ERROR_MSG = "Error while Processing the Message in Controller and this is the error = %s" ## ERROR
    #"This is the message which produced error in Controller %s "
    DATA_POINT_GROUPING = "Grouping of Grain Level has been {}" ## Started/Completed
    CONSUMER_SERVICE = "Consumer Service has been {} for: {}" ## Started/Completed
    REPORT_FILE_NAME = "Data.csv"

    ## ALGORITHM TRAINING RELATED
    ALGORITHM_NAME = "algorithm"
    TRAIN_X_PERIOD = "train_x"
    TRAIN_Y_PERIOD = "train_y"
    TEST_X_PERIOD = "test_x"
    TEST_Y_PERIOD = "test_y"
    TRAIN_DATES_COLUMN = "train_dates"
    HOLIDAY_EFFECTS_FLAG = "include_holiday_effects"
    FORECAST_DATA = "forecast_ouput"
    FORECAST_GENERATION_FAILURE = "forecast_failure_reason"
    FORECAST_FREQUENCY = "forecast_frequency"
    OUTPUT_FREQUENCY = "output_frequency"
    DATETIME_COL_NAME = "datetime_column_name"
    NAIVE_METHOD = "NAIVE_METHOD"
    ALGO_START_TIME = "startTime"
    ALGO_END_TIME = "endTime"
    RESULT = 'result'
    MODEL_PARAMS_FIELD = "modelParams"


    ##Job Related Constant
    JOB_MSG = "Recieved job for job_message = %s"
    JOB_ERROR_STATUS_CODE = "ER"
    JOB_FINSH_STATUS_CODE = "FI"
    JOB_PROGRESS_STATUS_CODE = "PR"
    WS_NAME = "webServiceName"
    WS_HEADER = "header"
    DATA_PARAMS = "dataParams"


    ## Execution Related Constant
    ENABLE_ASYNC = True
    DISABLE_ASYNC = False
    EXECUTION_ENV = "requestEnvironment"


    ## HDFS Related Constant
    HDFS_FILE_LOCATION = "hdfsFileLocation"
    SAVED_IN_HDFS = "Downloaded data has been saved to HDFS successfully for Job Id: {}"


    ## Downloader & Exporter Related Constant
    DOWNLOADING_PROCESS = "Downloading process has been {} for Job Id: {}" #Started/Completed
    EXPORTING_PROCESS = "Exporting process has been {} for Job Id: {}" #Started/Completed
    DATAPOINTS = "Datapoints shape: {}"

    ## Integration Test
    LOCAL_LOCATION_OF_URL_FILE =  "/tmp/url.txt"
    TEST_URL_HTTP = "http://"
    TEST_URL_APP = "/aera/cortex-be/api/v1/jobs/submit"
    INPUT_INTEGRATION_FOR_HAPPY_FLOW =  "{}/../sample_input/controller_happy_flow_input.json"
    ASSERT_DATA_INTEGRATION_FOR_HAPPY_FLOW = "{}/../sample_output/assert_data_3grains_happy_flow_input.json"
    TEST_CONTROLLER_CSV = "{}/cortex_be/tests/sample_input/test_controller_data.csv"
    TEST_CONTROLLER_CONFIG = "{}/cortex_be/tests/sample_input/test_controller_config.json"
    GZIP_UNIT_TEST_NORMAL_GZIP_PATH = "{}/cortex_be/tests/sample_input/gzip_test_normal_ip.csv"
    PYTHON_FUNCTIONALITIES_DATA_HAPPY_FLOW = "{}/cortex_be/tests/sample_input/python_functionalities_ip.csv"

    ## Data Quality Related Constant
    DATA_QUALITY_DATA_COMPLETENESS_TEST_FAILURE_REASON = "insufficient data for training"
    DATA_QUALITY_DATA_COMPLETENESS_TEST_FLAG = "Error"
    DATA_QUALITY_DATA_COMPLETENESS_NONZERO_TEST_FAILURE_REASON = "insufficient data for training excluding nonzero data"
    DATA_QUALITY_DATA_COMPLETENESS_NONZERO_TEST_FLAG = "Warning"
    DATA_QUALITY_DATA_INTERMITTENT_TEST1_FAILURE_REASON = "80% data in last 1 year having value 0 for training"
    DATA_QUALITY_DATA_INTERMITTENT_TEST1_FLAG = "Warning"
    DATA_QUALITY_DATA_INTERMITTENT_TEST2_FAILURE_REASON = "80% data in last 2 years having value 0 for training"
    DATA_QUALITY_DATA_INTERMITTENT_TEST2_FLAG = "Warning"
    DATA_QUALITY_CONSECUTIVE_ZEROS1_TEST_FAILURE_REASON = "Found 3 consecutive 0's in last 1 year data"
    DATA_QUALITY_CONSECUTIVE_ZEROS1_TEST_FLAG = "Warning"
    DATA_QUALITY_CONSECUTIVE_ZEROS2_TEST_FAILURE_REASON = "Found 3 consecutive 0's in last 2 year data"
    DATA_QUALITY_CONSECUTIVE_ZEROS2_TEST_FLAG = "Warning"
    DATA_QUALITY_INITIAL_ZEROS_TEST_FAILURE_REASON = "Found 3 initial values as 0"
    DATA_QUALITY_INITIAL_ZEROS_TEST_FLAG = "Warning"
    DATA_QUALITY_ZEROS_COUNT_TEST_FAILURE_REASON = "Found zero values"
    DATA_QUALITY_ZEROS_COUNT_TEST_FLAG = "Warning"
    DATA_QUALITY_NEGATIVE_VALUES_TEST_FAILURE_REASON = "Found negative values"
    DATA_QUALITY_NEGATIVE_VALUES_TEST_FLAG = "Warning"
    DATA_QUALITY_SUDDEN_SPIKE_TEST_FAILURE_REASON = "Found sudden spike values"
    DATA_QUALITY_SUDDEN_SPIKE_TEST_FLAG = "Warning"
    DATA_QUALITY_OUTLIER_TEST_FAILURE_REASON = "Found Outlier values"
    DATA_QUALITY_OUTLIER_TEST_FLAG = "Warning"

    ## Data Forecastability Related Constant
    DATA_FORECASTABILITY_RESIDUAL_VARIANCE_TEST_FAILURE_REASON = "Residual variance test failed "
    DATA_FORECASTABILITY_RESIDUAL_VARIANCE_TEST_FAILURE_FLAG = "Warning"
    DATA_FORECASTABILITY_STATIONARY_TEST_FAILURE_REASON = "Stationary test failed"
    DATA_FORECASTABILITY_STATIONARY_TEST_FAILURE_FLAG = "Warning"
    DATA_FORECASTABILITY_HETEROSKEDASTICITY_TEST_FAILURE_REASON = "heteroskedasticity is present "
    DATA_FORECASTABILITY_HETEROSKEDASTICITY_TEST_FAILURE_FLAG = "Warning"
    DATA_FORECASTABILITY_COV_TEST_FAILURE_REASON = "Coefficient of variation test failed"
    DATA_FORECASTABILITY_COV_TEST_FAILURE_FLAG = "Warning"
    DATA_FORECASTABILITY_APPROX_ENTROPY_TEST_FAILURE_REASON = "Approximate entropy test failed"
    DATA_FORECASTABILITY_APPROX_ENTROPY_TEST_FAILURE_FLAG = "Warning"
    DATA_FORECASTABILITY_SAMPLE_ENTROPY_TEST_FAILURE_REASON = "sample entropy test failed"
    DATA_FORECASTABILITY_SAMPLE_ENTROPY_TEST_FAILURE_FLAG = "Warning"

    ## R Model, Ensemble Related Constant
    ENSEMBLE_ERROR = "Ensemble Not SU due to ensemble models"
    R_MODEL_ERROR = "R model issue"
    R_OBJECT_CREATE_SUCCESS = "created R Object successfully"

    INTERMITTENT_DATA_THRESHOLD = 0.8
    ALL_ZERO_SALES = "all sales quanity in training period is zero(0)"
    INSUFFICIENT_DATA = "data less than min_training_period mentioned in the config"

    ## Job Validation Related Constant
    MAX_GRAIN_DAILY = 18000
    MAX_GRAIN_WEEKLY = 18000
    MAX_GRAIN_MONTHLY = 18000
    MAX_ALGO_THRESHOLD = 20
    YEAR_THRESHOLD = 5
    MONTH_UPPER_LIMIT = 13
    DAY_UPPER_LIMIT = 32
    WEEK_UPPER_LIMIT = 54

    ## Check Dates Related Constant
    DATE_FORMATS = {"YYYY-MM-DD": "%Y-%m-%d", "YYYY/MM/DD": "%Y/%m/%d", "YYYYMMDD": "%Y%m%d",
                    "YYYY-DD-MM": "%Y-%d-%m", "YYYY/DD/MM": "%Y/%d/%m", "YYYYDDMM": "%Y%d%m",
                    "MM-YYYY-DD": "%m-%Y-%d", "MM/YYYY/DD": "%m/%Y/%d", "MMYYYYDD": "%m%Y%d",
                    "MM-DD-YYYY": "%m-%d-%Y", "MM/DD/YYYY": "%m/%d/%Y", "MMDDYYYY": "%m%d%Y",
                    "DD-MM-YYYY": "%d-%m-%Y", "DD/MM/YYYY": "%d/%m/%Y", "DDMMYYYY": "%d%m%Y",
                    "DD-YYYY-MM": "%d-%Y-%m", "DD/YYYY/MM": "%d/%Y/%m", "DDYYYYMM": "%d%Y%m",
                    "YYYYMM": "%Y%m", "YYYYWW": "%Y%W", "YYYY-MM": "%Y-%m", "YYYY-WW": "%Y-%W"
                    }
    SAMPLE_DATE_CHECK = False
    SAMPLE_DATA_FRAC = 0.2

    ## Forecast Naive moving_average_over_n_periods - n_period
    N_PERIOD = 4

    ## Computational Container URL
    R_COMPUTATION_URL = "http://forecast-cortex-r-models-svc.cortex-dev.svc.cluster.local:8006/aera/cortex/v2/1001/forecast"
    PYTHON_COMPUTATION_URL = "http://forecast-cortex-python-models-svc.cortex-dev.svc.cluster.local:8007/aera/cortex/v2/1001/forecast"

    # R_COMPUTATION_URL = "http://10.101.12.180:8006/aera/cortex/v2/1001/forecast"
    # PYTHON_COMPUTATION_URL = "http://10.101.12.180:8005/aera/cortex/v2/1001/forecast"

    # SAFETY STOCK SIMULATION_ERROR_LAGS
    SIMULATION_ERROR_LAGS = "SIMULATION_ERROR_LAGS"

    ## TODO From ENV
    SS_DNS = "http://cortex-safetystock-models-svc.cortex-dev.svc.cluster.local"
    # DNS = "http://10.101.12.180:8006" #TODO change it later
    ROOT_URL = "/aera/cortex/v2/1001/forecast/"
    SS_ROOT_URL = "/aera/cortex/v2/1006/safety_stock"
    ### UNIT Test
    # Onepass Service
    EXPECTED_FORECAST_FILE = "{}/../sample_output/onepass_message_forecast.json"
    ACTUAL_FORECAST_FILE = "{}/../sample_input/onepass_message_forecast.json"

    HISTORICAL_DEMAND_WEEKS = 52
    ACCEPTABLE_INTERMITENCY = 20
    RB_PROJECT = "0797FF95_4733_4F4A_880B_F474204228A1"

    NUMBER_OF_SIMULATIONS = 50

    DEMAND_THRESHOLD = 10
    LEADTIME_THRESHOLD = 4