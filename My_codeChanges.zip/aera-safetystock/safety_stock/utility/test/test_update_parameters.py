import pytest
from unittest import mock
from safety_stock.utility.update_parameters import UpdateParams
from safety_stock.utility.constant import Constant

class TestUpdateParams():
    @classmethod
    def setup_class(cls) -> None:
        """
        """
        cls.param_dict = {'dataParams':{'threshold_dd_distribution':Constant.DEMAND_THRESHOLD,'threshold_lt_distribution':Constant.LEADTIME_THRESHOLD,
                                        'approach':'forecast'},
                                        'modelParams':{'number_of_simulations':Constant.NUMBER_OF_SIMULATIONS,'error_metric':'Error'}}
        
    def test_input_params(self):
        """
        test feature oders
        """
        input_params = UpdateParams(self.param_dict)
        resp = input_params.update_constant_params()
        assert resp["modelParams"]["number_of_simulations"] == self.param_dict["modelParams"]['number_of_simulations']
        assert resp["dataParams"]["threshold_dd_distribution"] == self.param_dict["dataParams"]['threshold_dd_distribution']
        assert resp["dataParams"]["threshold_lt_distribution"] == self.param_dict["dataParams"]['threshold_lt_distribution']
        assert resp["modelParams"]["error_metric"] == self.param_dict["modelParams"]['error_metric']
        