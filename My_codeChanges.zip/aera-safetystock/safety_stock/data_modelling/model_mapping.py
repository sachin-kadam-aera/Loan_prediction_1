from .python_models import ss_simulation1
from .python_models import ss_simulation2
from .python_models import ss_simulation3

python_models = {
    'ss_simulation_model1': ss_simulation1,
    'ss_simulation_model2': ss_simulation2,
    'ss_simulation_model3': ss_simulation3
}