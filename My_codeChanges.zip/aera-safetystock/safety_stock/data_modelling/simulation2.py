import warnings
warnings.filterwarnings('ignore')
import random
import time
import math
import numpy as np
import pandas as pd
import scipy.stats
from pandas import DataFrame

random.seed(1024)
np.random.seed(1024)


def stringToarrayfloats(str1):
    vals = [float(a) for a in str1.split(",")]
    return vals


def make_data(periods,
              initial_inventory,
              demand_dist,
              lead_time_dist):
    """ Return a Pandas dataFrame that contains the details of the inventory simulation.

    Keyword arguments:
    periods           -- numbers of periods of the simulation (default 52 weeks)
    initial_inventory -- initial inventory for the simulation
    demand_dist       -- distribution of the demand (default triangular min=1, mode=2, max=3)
    lead_time_dist    -- distribution of the lead time (default triangular min=1, mode=2, max=3)
    """

    header = [
        "inventory_cycle",
        "replenishment_qty",
        "initial_on_hand",
        "demand",
        "demand_with_backorder",
        "fulfilled",
        "lost_sales",
        "serviced",
        "final_on_hand",
        "backorders",
        "initial_inv_pos",
        "final_inv_pos",
        "order",
        "order_qty",
        "order_due",
        "lead_time"
    ]
    header_len = len(header)
    col_name2idx = {name: x for name, x in zip(header, range(header_len))}
    df = [[0] * header_len for _ in range(periods)]
    inventory_cycle_count = 0

    for period in range(periods):
        if period == 0:
            df[period][col_name2idx['initial_on_hand']] = initial_inventory
        else:
            df[period][col_name2idx['initial_on_hand']] = df[period - 1][col_name2idx['final_on_hand']] + \
                                                          df[period][col_name2idx['replenishment_qty']]

        if df[period][col_name2idx['replenishment_qty']] > 0:
            inventory_cycle_count += 1

        demand = int(math.ceil(demand_dist.rvs(1)[0]))
        demand = max(demand, 0)
        lost_sales = 0
        serviced = 1

        df[period][col_name2idx['demand']] = demand
        ROV = demand

        demand += df[period - 1][col_name2idx['backorders']]
        df[period][col_name2idx['demand_with_backorder']] = demand
        check_fulfillment = df[period][col_name2idx['initial_on_hand']] - demand

        if check_fulfillment >= 0:
            fulfilled_amount = demand
        else:
            fulfilled_amount = df[period][col_name2idx['initial_on_hand']]
            lost_sales = abs(check_fulfillment)
            serviced = 0

        df[period][col_name2idx['fulfilled']] = fulfilled_amount
        df[period][col_name2idx['lost_sales']] = lost_sales
        df[period][col_name2idx['serviced']] = serviced

        df[period][col_name2idx['final_on_hand']] = max(0,
                                                        df[period][col_name2idx['initial_on_hand']] - fulfilled_amount)

        # backorders
        if lost_sales > 0:
            df[period][col_name2idx['backorders']] += lost_sales
            if period > 0:
                df[period][col_name2idx['backorders']] = lost_sales

        order = 1
        order_leadtime = max(1, int(math.ceil(lead_time_dist.rvs(1)[0])))
        df[period][col_name2idx['order_qty']] = ROV
        for period_ in range(period, period + order_leadtime):
            if period_ >= periods: continue
            df[period_][col_name2idx['order_due']] += ROV

        # special case for leadtime 1
        '''
        if order_leadtime == 0:
            period_ = period

            # update the final on hand
            new_foh = df[period][col_name2idx['final_on_hand']] + ROV
            fulfilled_backorders = new_foh - df[period][col_name2idx['backorders']]
            if fulfilled_backorders > 0:
                df[period][col_name2idx['final_on_hand']] = fulfilled_backorders
                df[period][col_name2idx['backorders']] = 0
            else:
                df[period][col_name2idx['final_on_hand']] = 0
                df[period][col_name2idx['backorders']] = abs(fulfilled_backorders)
            '''

        if period_ + 1 < periods:
            df[period_ + 1][col_name2idx['replenishment_qty']] += ROV

        df[period][col_name2idx['inventory_cycle']] = f"{inventory_cycle_count}"

        df[period][col_name2idx['order']] = order
        df[period][col_name2idx['lead_time']] = order_leadtime

        df[period][col_name2idx['final_inv_pos']] = df[period][col_name2idx['final_on_hand']] + \
                                                    df[period][col_name2idx['order_due']] - df[period][
                                                        col_name2idx['backorders']]

    data = pd.DataFrame(df, columns=header)
    # data.to_csv("/tmp/d2.csv", index=False)
    return data


def placeorder(final_inv_pos, policy, lead_time_dist, period):
    """Place the order acording the inventory policy:

       Keywords arguments:
       final_inv_pos    -- final inventory position of period
       policy           -- chosen policy Reorder point (Qs, Ss) or Periodic Review (RS, Rss)
       lead_time_dist   -- distribution of lead time
       period           -- actual period
    """
    lead_time = int(math.ceil(lead_time_dist.rvs(1)[0]))
    lead_time = max(lead_time, 0)

    # Qs = if we hit the reorder point s, order Q units
    if policy['method'] == 'Qs' and \
       final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['Q'], lead_time, True
    # Ss = if we hit the reorder point s, order S - final inventory pos
    elif policy['method'] == 'Ss' and \
         final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # RS = if we hit the review period and the reorder point S, order S - final inventory pos
    elif policy['method'] == 'RS' and \
         period%policy['arguments']['R'] == 0 and \
         final_inv_pos <= policy['arguments']['S']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # RSs = if we hit the review period and the reorder point s, order S - final inventory pos
    elif policy['method'] == 'RSs' and \
         period%policy['arguments']['R'] == 0 and \
         final_inv_pos <= policy['arguments']['s']:
        return policy['arguments']['S'] - final_inv_pos, lead_time, True
    # If the conditions arent satisfied, do not order
    else:
        return 0, 0, False


class Order(object):
    """Object that stores basic data of an order"""
    def __init__(self, quantity, lead_time, sent):
        self.quantity = quantity
        self.lead_time = lead_time
        self.sent = sent # True if the order is already sent


def get_stepvalue(delta_fillrate, Q):
    step_val = 0
    if delta_fillrate >= 50:
        step_val = 1.2 * Q
    elif 40 <= delta_fillrate < 50:
        step_val = Q
    elif 30 <= delta_fillrate < 40:
        step_val = 0.8 * Q
    elif 20 <= delta_fillrate < 30:
        step_val = 0.6 * Q
    elif 15 <= delta_fillrate < 20:
        step_val = 0.5 * Q
    elif 10 <= delta_fillrate < 15:
        step_val = 0.4 * Q
    elif 8 <= delta_fillrate < 10:
        step_val = 0.2 * Q
    elif 5 <= delta_fillrate < 8:
        step_val = 0.1 * Q
    elif 2 <= delta_fillrate < 5:
        step_val = 0.05 * Q
    elif 1 <= delta_fillrate < 2:
        step_val = 0.01 * Q
    elif 0 <= delta_fillrate < 1:
        step_val = 1
    step_val = max(1, int(step_val))
    return step_val


def validate_step_value(s, step_value, max_ss):
    neg = 1
    if step_value < 0: neg = -1
    while step_value > 0 and s + step_value >= max_ss:
        step_value = int(step_value/2)
    step_value = max(1, step_value)
    return neg * step_value


def safetystock_calculations(demand_dist, lead_time_dist, no_s, Q, target_fill_rate):
    sim_service_levels = []
    count = 0
    starting_ss = 0.2 * Q
    mean_demand = demand_dist.mean()
    s = int(starting_ss)
    prev_step_value = None
    prev_step_value_repeat_counter = 0
    total_simulation_count = 0
    max_ss_value = int(3.5 * Q)
    max_simulation_count = no_s
    best_ss_value = 0
    best_loss_value = np.inf
    best_simulation = None
    best_fillrate = 0
    all_delta_fillrate = []
    stop_level1 = int(0.75 * no_s)
    stop_level2 = int(0.9 * no_s)
    try:
        while True:
            # import pdb;pdb.set_trace()
            print("Evaluation for s =", s)
            start_time = time.time()
            all_service_levels = []
            for i in range(30):
                period = 1000
                df = make_data(period, s + Q, demand_dist, lead_time_dist)
                service_level = df['serviced'].mean()
                all_service_levels.append(service_level)
            # import pdb;pdb.set_trace()
            avg_sl = np.mean(all_service_levels)
            print("Simulation SL = ", avg_sl)

            # preventing from having high safety stock values
            # if int(avg_sl) == 1:
            #     s = int(s/2)
            #     continue

            sim_service_levels.append(avg_sl)

            delta_fillrate_ = 100.0 * (target_fill_rate - avg_sl) / target_fill_rate
            delta_fillrate = abs(delta_fillrate_)
            step_val = get_stepvalue(delta_fillrate, mean_demand)
            # TODO redeploy in prod, comment the print statements
            print(f" Count: {count} "
                  f" Totalcount: {total_simulation_count} "
                  f" Target_fill_rate: {target_fill_rate} "
                  f" Avg_fill_rate: {avg_sl} "
                  f" delta: {delta_fillrate_} "
                  f" ss : {s} "
                  f" best ss: {best_ss_value} "
                  f" step: {step_val}"
                  f" Prev step value: {prev_step_value}"
                  f" Prev step value: {prev_step_value_repeat_counter}"
                  f" Time take: {time.time() - start_time}")
            # import pdb;pdb.set_trace()
            # --- stopping criteria
            all_delta_fillrate.append(delta_fillrate)

            if best_loss_value >= delta_fillrate:
                best_fillrate = avg_sl
                best_loss_value = delta_fillrate
                best_ss_value = s
                best_simulation = df

            if avg_sl >= target_fill_rate:
                step_val = -1 * step_val
                if 0 <= delta_fillrate < 1 or (s == 0 and 0 <= delta_fillrate < 1):
                    count = count + 1
                if count == 5 or \
                        (total_simulation_count >= stop_level1 and 0 <= delta_fillrate < 0.5):
                    return best_ss_value, best_simulation, False, '', round(100 * best_fillrate, 4), total_simulation_count
            # final stopping criteria
            if total_simulation_count >= max_simulation_count or \
                    (total_simulation_count >= stop_level2 and delta_fillrate <= 2) or \
                    (total_simulation_count >= stop_level1 and delta_fillrate <= 1) or \
                    (total_simulation_count >= stop_level2 and np.mean(all_delta_fillrate[-5:]) <= 0.5):
                return best_ss_value, best_simulation, False, '', round(100 * best_fillrate, 4), total_simulation_count
            #---
            print(f"Safetystock: {s}, step_value: {step_val}")
            # import pdb;pdb.set_trace()
            if step_val > 0:
                step_val = validate_step_value(s, step_val, max_ss_value)

            if prev_step_value is not None:
                if step_val == prev_step_value:
                    prev_step_value_repeat_counter += 1
                else:
                    prev_step_value_repeat_counter = 0
                # change step to come out of the local minima
                if prev_step_value_repeat_counter >= 3:
                    prev_step_value_repeat_counter = 0
                    if 0 <= delta_fillrate <= 1:
                        step_val *= 10
                    elif 1 < delta_fillrate <= 3:
                        step_val *= 15
                    elif 3 < delta_fillrate <= 10:
                        step_val *= 20
                    elif total_simulation_count >= stop_level1:
                        step_val *= 10
                    else:
                        step_val *= 10

            print(f"Safetystock: {s}, step_value: {step_val}, prev_step_value: {prev_step_value}")

            s += step_val

            # if negative safety stock
            if s < 0:
                s = 0
                prev_step_value_repeat_counter = 0
            prev_step_value = step_val
            total_simulation_count += 1

    except Exception as e:
        # import traceback
        # print(traceback.print_exc())
        return 0, None, True, 'Error in simulations: ' + str(e)


def make_distribution(function, *params):
    return function(*params)


def prepare_distributions(d_dist, demand_, LT_dist, lead_time_):
    demand_dist = make_distribution(getattr(scipy.stats, d_dist), *stringToarrayfloats(demand_))
    lead_time_dist = make_distribution(getattr(scipy.stats, LT_dist), *stringToarrayfloats(lead_time_))
    return demand_dist, lead_time_dist


def carry_simulation(lead_time_, LT_dist, d_dist, demand_, target_fill_rate, no_of_sim):
    try:
        print("no of simulations to be carried per grain = ",no_of_sim)
        lead_time_ = lead_time_.strip("(|)")
        if LT_dist == "poisson":
            lead_time_ = lead_time_.split(",")[0]
        demand_ = demand_.strip("(|)")
        if d_dist == "poisson":
            demand_ = demand_.split(",")[0]

        demand_dist, lead_time_dist = prepare_distributions(d_dist, demand_, LT_dist, lead_time_)

        '''
        Mean comes out as 0 when demand or leadtime is constant
        '''

        if np.isnan(demand_dist.mean()) & np.isnan(lead_time_dist.mean()):
            Q = int(float(demand_.split(",")[0].strip()) * float(lead_time_.split(",")[0].strip()))
        elif np.isnan(demand_dist.mean()) is False & np.isnan(lead_time_dist.mean()):
            Q = int(demand_dist.mean() * float(lead_time_.split(",")[0].strip()))
        elif np.isnan(demand_dist.mean()) & np.isnan(lead_time_dist.mean()) is False:
            Q = int(float(demand_.split(",")[0].strip()) * lead_time_dist.mean())
        else:
            Q = int(demand_dist.mean() * lead_time_dist.mean())

        # Q = int(demand_dist.mean() * lead_time_dist.mean())
        print("Computing SS")
        s, last_simulation, is_error, error_msg, last_fillrate, simulation_count = safetystock_calculations(demand_dist, lead_time_dist, no_of_sim, Q, target_fill_rate)
    except Exception as e:
        is_error = True
        error_msg = str(e)
        simulation_count = 0
        last_fillrate = 0
        s = 0
        last_simulation = None
    return s, last_simulation, is_error, error_msg, last_fillrate, simulation_count