# python dependencies
import os
import json
import shutil
import uuid
import logging
import pandas as pd
import requests
import math
import time
import glob
import shutil
import subprocess as sp
# HDFS related dependencies


# Project related dependencies
from .constant import Constant
from .exceptions.utility_exception import DownloadException
from .exceptions.utility_exception import UploadException
from .common_utility import CommonUtility
from .constant import Constant


class LocalPlateformUtility:
    """
        LocalPlateformUtility class for Upload and Download object from/to local.
    """
    log = logging.getLogger(__name__)

    def __init__(self, **kwargs):
        self.is_dir_upload = kwargs.get("is_dir_upload")
          
    def get_file_path(self, folder, file_key):
        """
        DOCString
        """
        abs_file_path = CommonUtility.concat_string(folder, os.sep, file_key)
        return abs_file_path

    def download(self, bucket_name, file_key, unique_folder):
        """
        download function is used for downloading file from local and store that file in local machine
        @param:
            bucket_name = bucket name
            file_key = file key of aera webservice object
            unique_folder = unique folder key of 32 character

        @returns- if download is succeed function will return True & machine location where file is stored
                else it returns FALSE & failure Message

        @raises exception that could be raised if download is unsuccessful
        """
        status_flag = False
        message = Constant.BLANK
        # Handling exception when Bucket does not exist
        try:
            source_bucket = self.get_file_path(bucket_name, file_key)
            # Handling exception when file upload is unsuccessful
            try:
                # destination_location in which actual file is stored
                destination_location = self.__get_local_path_location(
                    file_key, unique_folder)

                # Copy file from original location to working directory
                cmd = ['cp', source_bucket, destination_location]
                resp = sp.call(cmd)
                if resp ==0:
                    self.log.debug('Blob %s downloaded to %s.',
                                file_key,
                                destination_location)
                    message = destination_location
                    status_flag = True
                else:
                    raise DownloadException(message)
            except Exception as e:
                message = Constant.UNABLE_TO_DOWNLOAD_LOG.format(str(e))
                # calling function for Deleting file from local machine
                #CommonUtility.remove_file(destination_location)
                raise DownloadException(message)
        except Exception as e:
            message = Constant.BUCKET_NOT_FOUND_LOG.format(str(e))
            raise DownloadException(message)

        return status_flag, message
    
    def upload(self, local_file_path, bucket_name, file_name):
        """
        upload function is used for uploading file from local machine to specified folder in the specified bucket of local

        @param:
            local_file_path: local machine path where file is stored
            bucket_name = bucket name
            file_name = name of file

        @returns: if uploading file is succeed func will return TRUE & the Message
                else it returns FALSE & the failure Message

        @raises exception that could be raised if upload is unsuccessful
        """
        status_flag = False
        message = Constant.BLANK
        # Handling exception when Bucket does not exist
        try:
            CommonUtility().create_folder(bucket_name) ## Create folder if not exist
            if self.is_dir_upload:
                destination_location = bucket_name
                local_file_path = local_file_path.rsplit(Constant.FILE_SEPARATOR, 1)[0]
                local_file_path = local_file_path + os.path.sep +"*"
            else:
                destination_location = self.__get_upload_file_key(
                file_name, bucket_name)
                local_file_path = local_file_path

            # Handling exception when file upload is unsuccessful
            try:
                # Copy file from original location to working directory
                print("*"*30)
                print(local_file_path, "****",destination_location)
                files = glob.glob(local_file_path)
                resp = True
                for file_path in files:
                    if os.path.isfile(file_path):
                        shutil.copy(file_path, destination_location)
                    else:
                        resp = False
                if resp:
                    status_flag = True
                    # calling function for Deleting file from local machine
                    #CommonUtility.remove_file(local_file_path)
                    message = 'File Uploaded successfully.'
                    # file to be upload in local
                    self.log.debug('File uploaded to %s', destination_location)

                else:
                    message = 'Unable to upload the file.'
                    self.log.error(message)
                    raise UploadException(message)
            except:
                message = 'Unable to upload the file.'
                self.log.error(message)
                raise UploadException(message)
        except Exception as e:
            message = 'Sorry, given bucket does not exist. {}'.format(str(e))
            self.log.error(message)
            raise UploadException(message)

        return status_flag, message

    def __get_local_path_location(self, file_key, unique_folder):
        """
        get_local_path_location function is used to create local file path where file is downloaded

        @param:
            file_key = file key of local file name
            unique_folder = unique folder key of 32 character

        @returns- local machine file path

        @raises exception if local file can not be created
        """
        local_path_with_uuid_for_download = CommonUtility.concat_string(
            Constant.LOCAL_LOCATION_OF_DOWNLOAD, os.path.sep, unique_folder)

        # making directory if not exits to store file in local machine
        CommonUtility.create_folder(local_path_with_uuid_for_download)

        # destination_location in which actual file is stored
        destination_location = os.path.join(
            local_path_with_uuid_for_download, file_key)

        return destination_location

    def __get_upload_file_key(self, file_name, file_local_path_key):
        """
        get_upload_file_key function is used to create local path where file will be uploaded

        @param:
            file_name = file name
            file_local_path_key = file key of local object

        @returns- file key of local object

        @raises exception if local object key can not be created
        """

        # returning file key of local object
        return CommonUtility.concat_string(file_local_path_key, os.sep, file_name)