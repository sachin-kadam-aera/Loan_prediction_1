import base64

from Crypto import Random
from Crypto.Cipher import AES


class Security():

    def __init__(self):
        key="7EBF7942_F40D_498C_8E30_5EF96792"
        self.key = bytes(key, 'utf-8')

    def pad(self, s):
        return s + b"\0" * (AES.block_size - len(s) % AES.block_size)

    def encrypt(self,message, key_size=16):
        """
        :param message: message to be encrypted
        :param key_size: 16
        :return: return encrypted message
        """
        message = self.pad(message)
        iv = Random.new().read(AES.block_size)
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        etext = iv + cipher.encrypt(message)
        return base64.b64encode(etext)

    def decrypt(self, dtext):
        """
        :param dtext: encrypted message
        :return: returns decrypted message
        """
        ciphertext = base64.b64decode(dtext)
        iv = ciphertext[:AES.block_size]
        cipher = AES.new(self.key, AES.MODE_CBC, iv)
        plaintext = cipher.decrypt(ciphertext[AES.block_size:])
        return plaintext.rstrip(b"\0").decode("utf-8")
