import logging
import sys


def configure_logs():
    file_handler = logging.FileHandler('ss.log')
    file_handler.setLevel(logging.INFO)
    stdout_handler = logging.StreamHandler(sys.stdout)
    stdout_handler.setLevel(logging.INFO)
    handlers = [file_handler, stdout_handler]
    logging.basicConfig(level=logging.INFO, format="[%(asctime)s] {%(filename)s:%(lineno)d} %(levelname)s - %(message)s", handlers=handlers)
