# Python related dependencies
import logging

# Project related dependencies
from utils.gcp_utility import GcpStorageUtility
from utils.constant import Constant
from utils.aws_utility import AwsS3Utility
from utils.aera_plateform_utility import AeraPlateformUtility
from utils.local_plateform_utility import LocalPlateformUtility
from utils.hdfs_utility import HdfsStorageUtility
from utils.exceptions.utility_exception import EnvNotSupportedException


class DataUtility:
    """
    DataUtility will decide storage of particular platform (GCP or AWS or Aera or Local).
    "file:///Users/anilkumargupta/Desktop/aera/data/sample_data_causal_small_Header.csv"
    key_list >>> ['file', '/Users/anilkumargupta/Desktop/aera/data/sample_data_causal_small_Header.csv']
    file_key_list >>>
    """

    log = logging.getLogger(__name__)
    env = Constant.ENVIRONMENT
    bucket = Constant.BLANK
    object_key = Constant.BLANK
    def __init__(self, key):
        key_list = key.split(Constant.ENV_SEPARATOR)
        if len(key_list)>1: ## key as aws or gcp or hdfs bucket
            file_key_list = key_list[1].rsplit(Constant.FILE_SEPARATOR, 1)
            self.plateform = key_list[0]
            self.bucket = file_key_list[0]
            self.object_key = file_key_list[1]
        else:## Aera Webservice Uri as key ie. "webservice_name"
            self.plateform = Constant.PLATFORM_AERA
            self.bucket = ''
            self.object_key = key_list[0]

    def download(self, unique_folder, **kwargs):
        """
        download method used to call download function of particular platform.

        @param:
            unique_folder = unique folder key of 32 character

        @returns- if download is succeed function will return True & local file path where file is downloaded
                else it returns FALSE & failure Message
        """

        if(self.plateform == Constant.PLATFORM_GCP):
            # Download the input file from GCS to local machine
            download_status, local_file_path = GcpStorageUtility().download(
                self.bucket, self.object_key, unique_folder)
        elif(self.plateform == Constant.PLATFORM_AWS):
            # Download the input file from S3 to local machine
            download_status, local_file_path = AwsS3Utility().download(
                self.bucket, self.object_key, unique_folder)
        elif(self.plateform == Constant.PLATFORM_AERA):
            # Download the input file from aera api to local machine
            download_status, local_file_path = AeraPlateformUtility(**kwargs).download(
                self.bucket, self.object_key, unique_folder)
        elif(self.plateform in Constant.PLATFORM_LOCAL):
            # Copy the input file from local machine to local machine
            download_status, local_file_path = LocalPlateformUtility(**kwargs).download(
                self.bucket, self.object_key, unique_folder)
        elif(self.plateform in Constant.PLATFORM_HDFS):
                # Copy the input file from local machine to local machine
            download_status, local_file_path = HdfsStorageUtility(**kwargs).download(
                self.bucket, self.object_key, unique_folder)
        else:
            download_status = False
            local_file_path = "Remote platform is not supported"
            raise EnvNotSupportedException(local_file_path)
        return download_status, local_file_path

    def upload(self, local_file_path, filename=None, **kwargs):
        """
        upload method used to call upload function of particular platform.

        @param:
            local_file_path: local machine path where file is stored
            filename = name of file

        @returns: if uploading file is succeed func will return TRUE & the success Message
                else it returns FALSE & the failure Message
        """

        self.log.debug('local_file_path: %s', local_file_path)
        if(self.plateform == Constant.PLATFORM_GCP):
            # Upload the output file from local machine to GCS
            upload_status, message = GcpStorageUtility().upload(local_file_path, self.bucket,
                                                                self.object_key, filename)
        elif(self.plateform == Constant.PLATFORM_AWS):
            # Upload the output file from local machine to S3
            upload_status, message = AwsS3Utility().upload(local_file_path, self.bucket, 
                                                            self.object_key, filename)

        elif(self.plateform == Constant.PLATFORM_AERA):
            # Download the input file from aera api to local machine
            upload_status, message = AeraPlateformUtility(**kwargs).upload(local_file_path, self.bucket, 
                                                            self.object_key)
        
        elif(self.plateform in Constant.PLATFORM_LOCAL):
            # Copy the input file from local machine to local machine
            upload_status, message = LocalPlateformUtility(**kwargs).upload(local_file_path, self.bucket, 
                                                            self.object_key)
        elif(self.plateform in Constant.PLATFORM_HDFS):
            # Copy the input file from local machine to hdfs machine
            upload_status, message = HdfsStorageUtility(**kwargs).upload(local_file_path, self.bucket, 
                                                            self.object_key)
        else:
            upload_status = False
            message = "Remote platform is not supported"
            raise EnvNotSupportedException(message)
        return upload_status, message