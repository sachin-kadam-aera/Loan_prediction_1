# Python dependencies
import os
import redis
import configparser
import pandas as pd
from mysql import connector
from utils.SecurityServices import Security
from utils.cassandra_utility import CassandraDb

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIG_FILE = os.path.join(BASE_DIR, 'framework.properties')
CORTEX_CONFIG = configparser.ConfigParser()
CORTEX_CONFIG.read(CONFIG_FILE)

#print("CONFIG_FILE --- ", CONFIG_FILE)
#from cortex.settings import CORTEX_CONFIG

class DBUtility(CassandraDb):

    def __init__(self, key_space="CORTEX", project_id=None, service_id=None, job_id=None, job_name=None):
        self.query_resp = None
        self.project_id = project_id
        self.service_id = service_id
        self.job_id = job_id
        self.job_name = job_name
        self.key_space = key_space
        super(DBUtility, self).__init__()

    def fetch_db_results(self):
        """
            returns a Pandas dataframe from table cortex.cortex_services_slots and is_active flag set to True.
            returns an empty dataframe if no data found in the Cassandra DB table cortex.cortex_services_slots
        """
        SCHEMA_NAME = CORTEX_CONFIG['CASSANDRA-PROPERTIES']['KEY_SPACE']
        SLOTS_TABLE_NAME = "CORTEX_SERVICES_SLOTS"
        fetch_static_config = "SELECT * from {}.{} where is_active=True allow filtering;".format(SCHEMA_NAME, SLOTS_TABLE_NAME)
        print(fetch_static_config)
        self.query_resp = self.query_executor(fetch_static_config, self.job_id, query_ops='read')
        if self.query_resp:
            config_frame = pd.DataFrame(self.query_data)
        else:
            config_frame = pd.DataFrame()
        return config_frame
