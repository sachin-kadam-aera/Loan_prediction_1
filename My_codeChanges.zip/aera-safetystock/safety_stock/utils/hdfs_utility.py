# Python Package & Modules
import os
import logging
import sys
import pickle
import configparser
from hdfs import InsecureClient
import pandas as pd
import io
import gzip

# HDFS related dependencies

# Project related dependencies
from .constant import Constant
from .exceptions.utility_exception import DownloadException
from .exceptions.utility_exception import UploadException
from .common_utility import CommonUtility

# Global Initializers
from cortex.settings import CORTEX_CONFIG


class HdfsStorageUtility:
    """
        HdfsStorageUtility class for Upload and Download object from/to GCS.
    """
    log = logging.getLogger(__name__)

    def __init__(self, input_para_data={}, project_id=None, **kwargs):
        print(kwargs)
        project_id = '3E79211D_479A_4516_BC8C_3D67EF59868A'
        self.hdfs = HDFS(project_id=project_id)
        self.is_dir_upload = kwargs.get("is_dir_upload")

        
    def get_file_path(self, folder, file_key):
        """
        DOCString
        """
        abs_file_path = CommonUtility.concat_string(folder, Constant.FILE_SEPARATOR, file_key)
        return abs_file_path

    def download(self, bucket_name, file_key, unique_folder):
        """
        download function is used for downloading file from GCS and store that file in local machines
        @param:
            bucket_name = bucket name
            file_key = file key of GCS object
            unique_folder = unique folder key of 32 character

        @returns- if download is succeed function will return True & machine location where file is stored
                else it returns FALSE & failure Message

        @raises exception that could be raised if download is unsuccessful
        """
        status_flag = False
        message = Constant.BLANK
        # Handling exception when Bucket does not exist
        try:
            source_bucket = self.get_file_path(bucket_name, file_key)
            # Handling exception when file download is unsuccessful
            try:
                # destination_location in which actual file is stored
                destination_location = self.__get_local_path_location(
                    file_key, unique_folder)

                # Download file from hdfs
                self.log.info("Utility trying to download data from: {}>>to: {}".format(source_bucket, destination_location))
                self.hdfs.download(source_bucket, destination_location)
                self.log.debug('Blob %s downloaded to %s.',
                            file_key,
                            destination_location)
                message = destination_location
                status_flag = True
            except:
                message = Constant.UNABLE_TO_DOWNLOAD_LOG

                # calling function for Deleting file from local machine
                #CommonUtility.remove_file(destination_location)

                raise DownloadException(message)
        except:
            message = Constant.BUCKET_NOT_FOUND_LOG
            raise DownloadException(message)

        return status_flag, message
    
    def upload(self, local_file_path, bucket_name, file_name):
        """
        upload function is used for uploading file from local machine to specified folder in the specified bucket of GCS

        @param:
            local_file_path: local machine path where file is stored
            bucket_name = bucket name
            file_name = name of file

        @returns: if uploading file is succeed func will return TRUE & the Message
                else it returns FALSE & the failure Message

        @raises exception that could be raised if upload is unsuccessful
        """
        status_flag = False
        message = Constant.BLANK
        # Handling exception when Bucket does not exist
        try:
            if self.is_dir_upload:
                destination_location = bucket_name + str(os.sep)
                local_file_path = local_file_path.rsplit(Constant.FILE_SEPARATOR, 1)[0]
                local_file_path = local_file_path + str(os.sep)
            else:
                destination_location = self.__get_upload_file_key(
                    file_name, bucket_name)
                local_file_path = local_file_path
            self.log.info("HDFS trying to upload from:  {} to: {}".format(local_file_path, destination_location))
            # Handling exception when file upload is unsuccessful
            try:
                self.hdfs.upload(local_file_path, destination_location)
                self.log.debug('File uploaded to %s/%s',
                               bucket_name, destination_location)
                status_flag = True
                message = 'File Uploaded successfully.'
            except:
                message = 'Unable to upload the file.'
                self.log.error(message)
                raise UploadException(message)
        except:
            message = 'Sorry, given bucket does not exist.'
            self.log.error(message)
            raise UploadException(message)
        return status_flag, message

    def __get_local_path_location(self, file_key, unique_folder):
        """
        get_local_path_location function is used to create local file path where file is downloaded

        @param:
            file_key = file key of local file name
            unique_folder = unique folder key of 32 character

        @returns- local machine file path

        @raises exception if local file can not be created
        """
        local_path_with_uuid_for_download = CommonUtility.concat_string(
            Constant.LOCAL_LOCATION_OF_DOWNLOAD, os.path.sep, unique_folder)

        # making directory if not exits to store file in local machine
        CommonUtility.create_folder(local_path_with_uuid_for_download)

        # destination_location in which actual file is stored
        destination_location = os.path.join(
            local_path_with_uuid_for_download, file_key)

        return destination_location

    def __get_upload_file_key(self, file_name, file_hdfs_path_key):
        """
        get_upload_file_key function is used to create GCS path where file will be uploaded

        @param:
            file_name = file name
            file_hdfs_path_key = file key of GCS object

        @returns- file key of GCS object

        @raises exception if gcs object key can not be created
        """

        # returning file key of GCS object
        return CommonUtility.concat_string(file_hdfs_path_key, os.sep, file_name)

class HDFS:
    def __init__(self, project_id=None, user="hdfs", url=None):
        #logger_instance = logging.getLogger(__name__)
        #logger = logging.LoggerAdapter(logger_instance, {'jobId': jobId})
        self.client = None
        self.project_id = project_id
        self.user = user
        self.ip = None
        self.port = None
        self.file_path = None
        self.loaded_object = None
        self.load_status = False
        self.default_hdfs = False
        if not url:
            self.url = "http://{}:{}"
        else:
            self.url = url
        # Create HDFS client connection
        try:
            self._client()
        except Exception as e:
            #TODO logging
            print("HDFS connection failed with Error {}".format(str(e)))

    def _client(self):
        if self.project_id in CORTEX_CONFIG: ## Get Specialized property for that self.project_id
            self.ip = CORTEX_CONFIG[self.project_id]["hdfshost"]
            self.port = CORTEX_CONFIG[self.project_id]["hdfsport"]
        else: ## Use default hdfs properties
            self.ip = CORTEX_CONFIG["hdfs-properties"]["hdfshost"]
            self.port = CORTEX_CONFIG["hdfs-properties"]["hdfsport"]
            self.default_hdfs = True
        self.url = self.url.format(self.ip, self.port)
        self.client = InsecureClient(self.url, user=self.user)

    def _csv(self, data=None, ops="reader", read_properties={}):
        status = True
        if ops=='reader':
            try:
                with self.client.read(self.file_path+".gz") as reader:
                    compressedDataframe = reader.read()
                    decompressedByteStream = gzip.decompress(compressedDataframe)
                    read_back_to_pandas = io.StringIO(decompressedByteStream.decode("utf-8")) # encode to UTF-8
                    self.loaded_object = pd.read_csv(read_back_to_pandas, dtype = read_properties['datatypesOfTheColumns'])
                    self.load_status = True
            except Exception as e:
                # if read fails then the load_status will be false
                self.loaded_object = None
                self.load_status = False
        elif ops=='writer':
            # Intercept the ByteStream of the dataframe and gzip it before writing it to a file
            dataFrameStream = io.StringIO()
            data.to_csv(dataFrameStream,index=False)
            compressedStream = gzip.compress(dataFrameStream.getvalue().encode())
            with self.client.write(self.file_path+".gz", overwrite=True) as writer:
                writer.write(compressedStream)
        else:
            ##TODO logging
            print("Invalid HDFS Operation")
            status = False
        return status

    def _model(self, data=None, ops="reader"):
        status = True
        if ops=='reader':
            with self.client.read(self.file_path) as reader:
                self.loaded_object = pickle.load(reader)
                self.load_status = True
        elif ops=='writer':
            with self.client.write(self.file_path, overwrite=True) as writer:
                pickle.dump(data, writer, protocol=3)
        else:
            ##TODO logging
            print("Invalid HDFS Operation")
            status = False
        return status

    def write(self, data, object_type, file_path):
        """
        :param data: data which you want to write
        :param ObjectType: Type of data. Can be either "model" or "csv"
        :param FilePathLocation: Location at which you want to save the model/csv
        :return: returns nothing
        """

        self.file_path = file_path
        method = "_{}".format(object_type)
        writer =  getattr(self, method)
        try:
            resp = writer(data=data, ops="writer")
        except Exception as e:
            #TODO logging
            print(str(e))
            resp = "HDFS Writer failed to write data"
        return resp

    def read(self, job_id, object_type, file_path, read_properties):
        """
        :param ObjectType: what is the type of object you want to read. Is it model or csv
        :param FilePathLocation: HDFS location from which you want to save model
        :return: returns loaded object and load status
        """
        self.file_path = file_path
        method = "_{}".format(object_type)
        reader =  getattr(self, method)
        try:
            if object_type == 'csv':
                resp = reader(read_properties=read_properties)
            else:
                resp = reader()
        except Exception as e:
            if "not found" in str(e):
                self.load_status = "File not Found"
            #TODO logging
            print(str(e))
            resp = "HDFS Reader failed to Read data"

        return self.loaded_object, self.load_status

    def  download(self, hdfs_path, local_path):
            """
            :param ObjectType: what is the type of object you want to read. Is it model or csv
            :param FilePathLocation: HDFS location from which you want to save model
            :return: returns loaded object and load status
            """
            try:
                self.client.download(hdfs_path, local_path, overwrite=True)
                return True
            except Exception as e:
                resp = "HDFS Reader failed to Read data"
                raise(e)

    def  upload(self, local_path, hdfs_path):
            """
            :param ObjectType: what is the type of object you want to read. Is it model or csv
            :param FilePathLocation: HDFS location from which you want to save model
            :return: returns loaded object and load status
            """
            print(">>>HDFS UPLOAD", "hdfs_path, local_path", hdfs_path, "\n",local_path)
            try:
                self.client.upload(hdfs_path, local_path, overwrite=True, n_threads=Constant.HDFS_NUMBER_OF_THREAD)
                return True
            except Exception as e:
                resp = "HDFS Writer failed to Write data"
                raise(e)


                
