###########################################################################
# Name: mysqldb.py
# Author: Aeratechnology Pvt. Ltd.
# Purpose: To define  mysql functionlites for cortex backend
# Date                          Version                                 Created By
# 17-Mar-2020                    1.0                                    Anil Gupta(Initial Version)
###########################################################################

# Python Package & Modules
import logging
import pickle
import configparser
from datetime import time

import pandas as pd
import mysql.connector
from mysql.connector import Error
from mysql.connector import pooling

# Project Related Package & Modules
from forecast.cortex_be.SecurityServices import Security
from forecast.utility.common_utility import CommonUtility
# Global Initializers
props = configparser.ConfigParser()
config_file = CommonUtility().get_config_file(module_name=__file__)
props.read(config_file)


class MySqlDb:
    def __init__(self, max_try=4):
        self.max_try = max_try
        self.cursor = None
        self.conn = None
        self.query_data = []
        self.db_info = None
        self.all_fields = []

    def query_executor(self, query, job_id, retry_count=0, query_ops='write'): ##
        """
        query_ops: read/write/other
        """
        logger_instance = logging.getLogger(__name__)
        logger = logging.LoggerAdapter(logger_instance, {'jobId': job_id})

        query_resp = None
        try:
            cursor, connection_object = getDBConnection(job_id)
            if cursor:
                print("query: ", query) ##TODO Logging
                cursor.execute(query)
                if query_ops=="read":
                    try:
                        self.db_info = connection_object.get_server_info()
                        self.all_fields = [field[0] for field in cursor.description]
                        self.query_data = cursor.fetchall()
                    except Exception as e:
                        pass
                connection_object.commit()
                closeConnection(cursor, connection_object)
                query_resp = True
        except Exception as e:
            retry_count += 1
            if retry_count == self.max_try:
                logger.info("Failed to Execute updateJobProcessingResult Query, Error is  %s = ", e)
        finally:
            if retry_count > 1 and retry_count < self.max_try:
                time.sleep(5)
                self.query_executor(query, job_id, retry_count=retry_count)
        return query_resp

    def ispring_query_executor(self, query, job_id, retry_count=0, query_ops='read'): ##
        """
        query_ops: read/write/other
        """
        logger_instance = logging.getLogger(__name__)
        logger = logging.LoggerAdapter(logger_instance, {'jobId': job_id})

        query_resp = None
        try:
            cursor, connection_object = getispringDBConnection(job_id)
            if cursor:
                print("query: ", query) ##TODO Logging
                cursor.execute(query)
                if query_ops=="read":
                    try:
                        self.db_info = connection_object.get_server_info()
                        self.all_fields = [field[0] for field in cursor.description]
                        self.query_data = cursor.fetchall()
                    except Exception as e:
                        pass
                connection_object.commit()
                closeConnection(cursor, connection_object)
                query_resp = True
        except Exception as e:
            retry_count += 1
            if retry_count == self.max_try:
                logger.info("Failed to Execute updateJobProcessingResult Query, Error is  %s = ", e)
        finally:
            if retry_count > 1 and retry_count < self.max_try:
                time.sleep(5)
                self.query_executor(query, job_id, retry_count=retry_count)
        return query_resp


# this function is creating connection pool and returning the cursor which can be used to execute query
def getDBConnection(Job_Id):
    """
    :return: return mysqldb connection
    """
    logger_instance = logging.getLogger(__name__)
    logger = logging.LoggerAdapter(logger_instance, {'jobId': Job_Id})

    cursor, connection_object = None, None

    #logger.info(int(props['database-properties']['pool_size']))
    #logger.info(props['database-properties']['pool_reset_session'])
    logger.info(str(props['database-properties']['host'])[1:-1])
    logger.info(str(props['database-properties']['schema'][1:-1]))
    logger.info(str(props['database-properties']['user'][1:-1]))
    logger.info(str(props['database-properties']['password'])[1:-1])

    try:
        cursor, connection_object = create_connection_pool(pool_size=int(props['database-properties']['pool_size']),
                                        pool_reset_session=props['database-properties']['pool_reset_session'],
                                        host=str(props['database-properties']['host'])[1:-1],
                                        schema=str(props['database-properties']['schema'][1:-1]),
                                        user=str(props['database-properties']['user'][1:-1]),
                                        password=str(props['database-properties']['password'])[1:-1], Job_Id=Job_Id)
    except Exception as e:
        logger.warning("Failed in Getting MYSQL Connection because = %s ", e)

    return cursor, connection_object

def closeConnection(cursor, connection_object):
    cursor.close()
    connection_object.close()
    return

def create_connection_pool(pool_size, pool_reset_session, host, schema, user, password, Job_Id):
    global connection_object
    logger_instance = logging.getLogger(__name__)
    logger = logging.LoggerAdapter(logger_instance, {'jobId': Job_Id})

    try:
        connection_pool = mysql.connector.pooling.MySQLConnectionPool(pool_name="aera_pool",
                                                                          pool_size=pool_size,
                                                                          pool_reset_session=pool_reset_session,
                                                                          host=host,
                                                                          database=schema,
                                                                          user=user,
                                                                          password=Security().decrypt(password))
        # Get connection object from a pool
        connection_object = connection_pool.get_connection()

        if connection_object.is_connected():
            db_info = connection_object.get_server_info()
            logger.info("Connected to MySQL database using connection pool ... MySQL Server version on %s ", db_info)
            cursor = connection_object.cursor()
            return cursor, connection_object

    except Error as e:
            logger.warning("Error while connecting to MySQL using Connection pool %s ", e)


def getispringDBConnection(Job_Id):
    """
    :return: return mysqldb connection
    """
    logger_instance = logging.getLogger(__name__)
    logger = logging.LoggerAdapter(logger_instance, {'jobId': 'default'})

    cursor, connection_object = None, None

    #logger.info(int(props['database-properties']['pool_size']))
    #logger.info(props['database-properties']['pool_reset_session'])
    logger.info(str(props['ispring-properties']['host']))
    logger.info(str(props['ispring-properties']['schema']))
    logger.info(str(props['ispring-properties']['user']))
    logger.info(str(props['ispring-properties']['password']))

    try:
        cursor, connection_object = create_connection_pool(pool_size=int(props['ispring-properties']['pool_size']),
                                                           pool_reset_session=props['ispring-properties']['pool_reset_session'],
                                                           host=str(props['ispring-properties']['host']),
                                                           schema=str(props['ispring-properties']['schema']),
                                                           user=str(props['ispring-properties']['user']),
                                                           password=str(props['ispring-properties']['password']),
                                                           Job_Id='default')
    except Exception as e:
        logger.warning("Failed in Getting ispring MYSQL Connection because = %s ", e)

    return cursor, connection_object
