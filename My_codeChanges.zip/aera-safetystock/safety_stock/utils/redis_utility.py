# Python dependencies
import os
import redis
import configparser
from utils.SecurityServices import Security

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

CONFIG_FILE = BASE_DIR+'/framework.properties'
CORTEX_CONFIG = configparser.ConfigParser()
CORTEX_CONFIG.read(CONFIG_FILE)

#print("CONFIG_FILE --- ", CONFIG_FILE)
#from cortex.settings import CORTEX_CONFIG

print(CORTEX_CONFIG["REDIS"]["PASSWORD"])

class RedisUtility:
    def get_conn(self):
        sec = Security()
        conn = redis.Redis(host=CORTEX_CONFIG["REDIS"]["HOST"], port=CORTEX_CONFIG["REDIS"]["PORT"],
                            db=0, password=sec.decrypt(CORTEX_CONFIG["REDIS"]["PASSWORD"]))
        return conn
