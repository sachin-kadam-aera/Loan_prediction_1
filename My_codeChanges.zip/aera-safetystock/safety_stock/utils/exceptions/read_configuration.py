# python dependencies
import os

separator = "="
custom_status_code = {}

# read status_code.properties files and stored key-value pairs in dict obj(i.e. custom_status_code)
file_name = os.path.join(os.path.dirname(__file__),'status_code.properties')
with open(file_name,'r') as f:

   for line in f:
       if separator in line:

           # Find the name and value by splitting the string
           name, value = line.split(separator, 1)

           # Assign key value pair to dict
           # strip() removes white space from the ends of strings
           custom_status_code[name.strip()] = int(value.strip())
