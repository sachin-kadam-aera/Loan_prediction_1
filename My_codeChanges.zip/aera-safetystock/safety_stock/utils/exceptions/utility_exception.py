# python dependencies
import logging

# Project related dependencies
from .cortex_exception import CortexException
from .read_configuration import custom_status_code
from utils.constant import Constant

class UtilityException(CortexException):
    """This is a parent exception class for all gcp_utility related exceptions raised in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code = custom_status_code[Constant.UTILITY_EXCEPTION]):
        """
        This is constructor to initialize the variable
        """
        super(UtilityException, self).__init__(status_code, error_message)
        self.log.error(self.error_message)


class DownloadException(UtilityException):
    """Download exception class for all download related issues raised in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.DOWNLOAD_EXCEPTION]):
        """
        This is constructor to initialize the variable
        """
        super(DownloadException, self).__init__(error_message, status_code)
        self.log.error(self.error_message)


class UploadException(UtilityException):
    """Upload exception class for all upload related issues raised in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.UPLOAD_EXCEPTION]):
        """
        This is constructor to initialize the variable
        """
        super(UploadException, self).__init__(error_message, status_code)
        self.log.error(error_message)


class EnvNotSupportedException(UtilityException):
    """Upload exception class for all upload related issues raised in the project"""
    log = logging.getLogger(__name__)

    def __init__(self, error_message, status_code=custom_status_code[Constant.ENV_NOT_SUPPORTED_EXCEPTION]):
        """
        This is constructor to initialize the variable
        """
        super(EnvNotSupportedException, self).__init__(error_message, status_code)
        self.log.error(error_message)