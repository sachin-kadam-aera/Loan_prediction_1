import logging
import time
import traceback
import pandas as pd
from utils.status_update import StatusUpdateService
from utils.cassandra_utility import stream_message_wrapper, CassandraDb
from safety_stock.utility.constant import Constant
from cortex.settings import CORTEX_CONFIG
from datetime import date
from utils.exporter_utility import ExporterUtility
from utils.db_utility import DBUtility


def exportToCassandra(jobId, projectId, serviceId, jobName, accessToken):
    """
        :jobId: Corresponds to message ID in Cortex_Job_Status Table
        :projectId: project Id for the job
    """
    logger_instance = logging.getLogger(__name__)
    logger = logging.LoggerAdapter(logger_instance, {'jobId': jobId})
    status = False
    ExportError = None
    try:
        startTime = time.time()
        logger.info("Starting to download the data")
        cass_db = CassandraDb(project_id=projectId, service_id=serviceId, job_id=jobId)
        db_key_space = CORTEX_CONFIG['CASSANDRA-PROPERTIES']['KEY_SPACE'].upper()
        compute_data_retrieve_query = "select * from {}.COMPUTATIONAL_DATA where documenttype='COMPUTE_DATA' and serviceid='{}' and jobid='{}' allow filtering".format(
            db_key_space,
            serviceId,
            jobId,
            )
        response = cass_db.query_executor(compute_data_retrieve_query, job_id=jobId, query_ops='read')
        if not response:
            raise Exception("Exporter Failed! Failed to retrieve SAFETY_STOCK_COMPUTE!")

        safety_stock_data = cass_db.query_data
        dtypes_headers = []
        raw_data = []
        for data_row in safety_stock_data:
            if data_row.rowindex == 0:
                dtypes_headers.append(data_row)
                continue
            raw_data.append(data_row)
        safety_stock_data = [dict(row.documentmap) for row in raw_data]
        logger.info("Pulled safety stock data")
        # dtypes = {k: eval(v) for k, v in dtypes_headers[0].documentmap.items()}
        # First row is always a datatype column
        safety_stock_data = pd.DataFrame(safety_stock_data)

        grain_cols = ['DD_GRAIN1', 'DD_GRAIN2', 'DD_GRAIN3']
        safety_stock_data['grain'] = safety_stock_data[grain_cols].astype(str).apply(lambda x: '__'.join(x), axis=1)

        job_summary_data = safety_stock_data.drop_duplicates(['grain'])
        total_grains = job_summary_data['grain'].shape[0]
        grains_passed = sum(job_summary_data['DD_ERROR_MESSAGE'].apply(lambda x: x.strip() == ''))
        grains_failed = sum(job_summary_data['DD_ERROR_MESSAGE'].apply(lambda x: x.strip() != ''))
        grain_passed_percentage = 100.0 * grains_passed / total_grains
        grain_failed_percentage = 100.0 * grains_failed / total_grains

        # get the time taken for the job
        job_status_data_retrieve_query = "select * from {}.cortex_framework_jobs_status where job_id = '{}'".format(
            db_key_space,
            jobId,
            )
        response = cass_db.query_executor(job_status_data_retrieve_query, job_id=jobId, query_ops='read')
        if not response:
            raise Exception("Exporter Failed! Failed to retrieve SAFETY_STOCK_JOB_STATUS!")

        safety_stock_jobstatus_details_data = cass_db.query_data
        job_created_time = None
        for row in safety_stock_jobstatus_details_data:
            if row.job_created is not None:
                job_created_time = row.job_created
            else:
                continue
        if job_created_time is None:
            time_taken = 0
        else:
            try:
                time_taken = (pd.Timestamp.now() - job_created_time).seconds
                time_taken = round(time_taken, 2)
            except Exception as e:
                time_taken = 0

        summary_message_list = {
            'DD_JOBID': jobId,
            'CT_TOTAL_GRAINS': total_grains,
            'CT_GRAINS_SUCCESSFUL': grains_passed,
            'CT_GRAINS_FAILED': grains_failed,
            'CT_GRAIN_SUCCESSFUL_PERCENTAGE': grain_passed_percentage,
            'CT_GRAIN_FAILED_PERCENTAGE': grain_failed_percentage,
            'CT_TIME_TAKEN': time_taken
        }

        stream_message_args = {
            "job_id": jobId,
            "task_id": jobId,
            "project_id": projectId,
            "capacity_pool_id": projectId,
            "service_id": serviceId,
            "document_type": "DQDFDV_SUMMARY",
            "stream_message_list": [summary_message_list],
            "logger": logger
        }
        stream_status, stream_message = stream_message_wrapper("cassandra_insert", stream_message_args)

        if stream_status:
            logger.info("Created the final safety stock summary successfully, now streaming data to Cassandra")
            logger.info("Time required to process the exporting safety stock summary data %s", time.time() - startTime)
            logger.info("Successfully completed exporting data")
            status = True
            ExportError = str(stream_message)
        else:
            logger.error("Failed to stream summary data to Cassandra. Reason of faliure:", str(stream_message))
            status = False
            ExportError = str(stream_message)

        # get the error_df for the job
        error_lags_retrieve_query = "select * from {}.COMPUTATIONAL_DATA where documenttype='MESSAGE_DETAILS_LOGS' and serviceid = '{}' and jobid = '{}' allow filtering".format(
            db_key_space,
            serviceId,
            jobId)

        simulation_error_lags_startTime = time.time()
        response = DBUtility().get_documentmap_by_page(jobId, "MESSAGE_DETAILS_LOGS", 1)

        if not response:
            raise Exception("Exporter Failed! Failed to retrieve ERROR LAGS DATA!")

        rows = response.result()
        for row0 in rows:
            error_lags_data = [dict(row.documentmap) for row in row0]
            logger.info("Pulled error lags data")
            # dtypes = {k: eval(v) for k, v in dtypes_headers[0].documentmap.items()}
            # First row is always a datatype column
            error_lags_data = pd.DataFrame(error_lags_data)

            for index, row in error_lags_data.iterrows():
                g1, g2, g3 = row["jobgrain"].split("__")
                stream_message_list = []
                taskId = row["task_id"]
                for lag_dict in eval(row['all_lag_errors']):
                    lag_dict["jobid"] = jobId
                    lag_dict["jobName"] = jobName
                    lag_dict["projectId"] = projectId
                    lag_dict["serviceId"] = serviceId
                    lag_dict["Grain1"] = g1
                    lag_dict["Grain2"] = g2
                    lag_dict["Grain3"] = g3
                    lag_dict["ReportingDate"] = today = date.today().strftime("%Y-%m-%d")
                    stream_message_list.append(lag_dict)

                stream_message_args = {
                    "job_id": jobId,
                    "task_id": taskId,
                    "project_id": projectId,
                    "capacity_pool_id": projectId,
                    "service_id": serviceId,
                    "document_type": "SIMULATION_ERROR_LAGS",
                    "stream_message_list": stream_message_list,
                    "logger": logger
                }

                stream_status, stream_message = stream_message_wrapper("cassandra_insert", stream_message_args)


    except Exception as e:
        db = StatusUpdateService(project_id=projectId, service_id=serviceId, job_id=jobId, job_name=jobName)
        logger.warning("Error in Exporting functionality for jobId = %s", jobId)
        traceback_msg = str(traceback.print_exc())
        traceback_msg += str(e)
        ExportError = "Exporter Error : " + str(traceback_msg)
        logger.warning("Error is =  %s", str(traceback_msg))
        update_data = {"processing_status": Constant.JOB_ERROR_STATUS_CODE, "processing_result": ExportError}
        db.update_job_status_nd_processing_result(data=update_data)
        db.trigger_update_job_status_api(jobId, projectId, Constant.JOB_ERROR_STATUS_CODE, ExportError, accessToken)
        status = False

    return status, ExportError

'''
from cassandra.io.libevreactor import LibevConnection
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
import pandas as pd
import numpy as np
import logging

KEY_SPACE = "cortex_uat"
COLUMN_FAMILY = "COMPUTATIONAL_DATA"
JOB_ID = "782a8844dc764e5eb222737e67715e06"
DOC_TYPE = "COMPUTE_DATA" #FORECAST_DATA

logger_instance = logging.getLogger(__name__)
logger = logging.LoggerAdapter(logger_instance, {'jobId': JOB_ID})

auth_provider = PlainTextAuthProvider(username="cortexacc", password="uxtVEsy6rLVA")
# UAT: username=“cortexacc”, password=“uxtVEsy6rLVA”
# DEV/QA: username=“cortexacc”, password=“insightqa”
# node_ips = ["10.101.21.50"]
node_ips = ["10.102.6.30"]
db_port = 9042
cluster = Cluster(node_ips, port=db_port, auth_provider=auth_provider)
cluster.connection_class = LibevConnection
session = cluster.connect()



res = session.execute("select * from {}.{} where jobid = '{}' and documenttype='{}'".format(KEY_SPACE,
                                                                                            COLUMN_FAMILY,
                                                                                                  JOB_ID,
                                                                                                  DOC_TYPE), timeout=None)

all_safety_stock_data = res.all()
safety_stock_data = all_safety_stock_data
DOC_TYPE = "MESSAGE_DETAILS_LOGS" #FORECAST_DATA

res = session.execute("select * from {}.{} where jobid = '{}' and documenttype='{}' limit 2".format(KEY_SPACE,
                                                                                            COLUMN_FAMILY,
                                                                                                  JOB_ID,
                                                                                                  DOC_TYPE), timeout=None)

all_safety_stock_messsage_details_data = res.all()

res = session.execute("select * from {}.cortex_framework_jobs_status where job_id = '{}'".format(KEY_SPACE,
                                                                                                  JOB_ID), timeout=None)

all_safety_stock_job_status_data = res.all()
safety_stock_jobstatus_details_data = all_safety_stock_job_status_data

'''