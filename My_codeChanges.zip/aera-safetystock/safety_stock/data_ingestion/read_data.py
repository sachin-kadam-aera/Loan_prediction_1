import pandas as pd


def read_csv(filepath, sep=',', grain_cols=None):
    df = pd.read_csv(filepath, delimiter=sep)
    df.columns = [x.upper() for x in df.columns]
    for col in grain_cols:
        df[col] = df[col].astype(str).str.strip()
    return df