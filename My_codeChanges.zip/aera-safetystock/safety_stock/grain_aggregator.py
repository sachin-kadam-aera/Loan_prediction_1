from safety_stock.data_postprocessing.exporterServices import exportToCassandra


def aggregate_data(job_id, project_id, service_id, job_name, access_token):
    export_status, responseMessage = exportToCassandra(jobId=job_id,
                                                       projectId=project_id,
                                                       serviceId=service_id,
                                                       jobName=job_name,
                                                       accessToken=access_token)
    return export_status, responseMessage

'''
from cassandra.io.libevreactor import LibevConnection
from cassandra.cluster import Cluster
from cassandra.auth import PlainTextAuthProvider
import pandas as pd
import numpy as np

auth_provider = PlainTextAuthProvider(username="cassandra", password="cassandra")
node_ips = ["10.101.12.181"]
db_port = 9042
cluster = Cluster(node_ips, port=db_port, auth_provider=auth_provider)
cluster.connection_class = LibevConnection
session = cluster.connect()

KEY_SPACE = "BE8BA2A0_2B4C_48BA_B0A8_714E96548216"
COLUMN_FAMILY = "COMPUTATIONAL_DATA"
JOB_ID = "23aug_run9"
DOC_TYPE = "COMPUTE_DATA" #FORECAST_DATA

res = session.execute("select * from {}.{} where jobid = '{}' and documenttype='{}'".format(KEY_SPACE,
                                                                                            COLUMN_FAMILY,
                                                                                                  JOB_ID,
                                                                                                  DOC_TYPE), timeout=None)

all_safety_stock_data = res.all()
jobId = 'df'
'''