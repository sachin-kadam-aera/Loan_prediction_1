###########################################################################
# Name: task_aggregator.py
# Author: Aeratechnology Pvt. Ltd.
# Purpose: This module will help us to do some post processing on metadata or client deliverable data.
# Date                          Version                                 Created By
# 07-April-2022                    1.0                                    Naresh Jamnani(Initial Version)
###########################################################################

# Python Package & Modules
import uuid
import time
import logging
import traceback

from cortex_api_wrapper.base import Base
from safety_stock.data_postprocessing.exportable_data import ExportableData


class TaskAggregator(Base):

    def __init__(self, job_id=None, project_id=None, service_id=None,job_name=None, access_token=None, **kwagrs):
        self.job_id = job_id
        self.project_id = project_id
        self.service_id=service_id
        self.job_name = job_name
        self.access_token = access_token
        self.working_folder = kwagrs.get("working_folder")
        self.start_time = time.time()
        self.end_time = time.time()
        logger_instance = logging.getLogger(__name__)
        self.logger = logging.LoggerAdapter(logger_instance, {'jobId': self.job_id})

    def execute(self):
        """
        Driver method/Entry point for whole service, this method also called by cortex api framework to execute.
        """
        # export_status, responseMessage = aggregate_data(self.job_id, self.project_id, self.service_id, self.job_name, self.access_token)

        exp = ExportableData(self.job_id, self.project_id, self.service_id, self.job_name, working_folder = self.working_folder)
        export_status, responseMessage = exp.dataquality_dataforecastability_simulation_error_lags()


        if export_status:
            self.logger.info("Exporting summary report to exasol successful !")
        else:
            self.logger.error("Exporting summary report to exasol failed ! Got the following error: {}".format(responseMessage))

        self.end_time = time.time()
        print("Execution Time: {}".format(self.end_time-self.start_time))
        meta_data_info = {'is_executed': True, 'export_status': export_status}
        if export_status:
            meta_data_info['metadata'] = responseMessage
            meta_data_info['export_documents'] = ['DQDFDV_SUMMARY', 'COMPUTE_DATA', 'SIMULATION_ERROR_LAGS']
        else:
            meta_data_info['metadata'] = str(responseMessage)
        return meta_data_info