###########################################################################
# Name: task_generator.py
# Author: Aeratechnology Pvt. Ltd.
# Purpose: This module will help us to split large task/job into small-small task to achieve parallelism in downstream components.
# Date                          Version                                 Created By
# 07-April-2022                    1.0                                    Naresh Jamnani(Initial Version)
###########################################################################
import logging
import time
import traceback

from .base import Base
from safety_stock.grain_generator import GrainGenerator
from safety_stock.utility.update_parameters import UpdateParams
# from safety_stock.utils.ss_logger import configure_logs


class TaskGenerator(Base):
    def __init__(self, job_id=None, file_path=None, request_folder=None, **kwagrs):
        self.job_id = job_id
        self.file_path = file_path
        self.request_folder = request_folder
        self.start_time = time.time()
        self.end_time = time.time()
        logger_instance = logging.getLogger(__name__)
        self.logger = logging.LoggerAdapter(logger_instance, {'jobId': self.job_id})
        self.logger.info("Started Producing Messages for Job Id = %s", self.job_id)
    
    def execute(self, original_input):
        """
        Driver method/Entry point for whole service, this method also called by cortex api framework to execute. 
        """
        try:
            is_error = False
            metadata_info = ''
            updated_params = UpdateParams(original_input)
            original_input = updated_params.update_constant_params()
            self.grains_obj = GrainGenerator(file_path=self.file_path, job_id=self.job_id,
                                             request_folder=self.request_folder, original_input=original_input)
            self.logger.info("Created graingenerator object")
            data_validation_flag, data_validation_reason = self.grains_obj.check_data_validation()
            self.logger.info("Completed grain validation checks")
            if data_validation_flag:
                metadata_info = self.grains_obj.generate_all_grain_data()
                self.logger.info("Completed generating metadata for all grains")
            else:
                error_msg = f"Grain data validation failed. Error: {data_validation_reason}"
                self.logger.error(error_msg)
                metadata_info = error_msg
                is_error = True
        except Exception as e:
            is_error = True
            traceback_msg = str(traceback.print_exc())
            traceback_msg += str(e)
            metadata_info = str(traceback_msg)
            self.logger.error(f"Error in taskgenerator: {metadata_info}")
        return is_error, metadata_info


'''

### Usage
from pprint import pprint

if __name__ == "__main__":
    original_input = {
      "projectId": "BE8BA2A0_2B4C_48BA_B0A8_714E96548216",
      "mode": "Ranking Mode",
      "isSimulated": False,
      "accessToken": "b465a39a4f7fe7005eea4f64fd9b188c",
      "requestEnvironment": "local",
      "userName": "pradeep.mahato@aeratechnology.com",
      "refreshToken": "e7fa365c7f1f8af765b6e1f473bbf2cb",
      "jobId": "61a5add45f7185ad5ce5da79f106c6ab_3grains_forecast",


        "dataParams": {
			"dataUri": {
                            "target_service_level": "hdfs:///Cortex/API/sample_data/Target Service Level.csv",
                            "average_demand": "hdfs:///Cortex/API/sample_data/Average Demand Over RLT 12M.csv",
                            "demand_history": "hdfs:///Cortex/API/sample_data/Demand History.csv",
                            "lead_time_history": "hdfs:///Cortex/API/sample_data/RLT History.csv"
				},
      		"resultUri": "hdfs:///Cortex/API/sample_output/testing/ss",
			"demand_history": "/Users/pradeepkumarmahato/aera/safety_stock/safety_stock_io_skill/data/Demand History.csv",
			"lead_time_history": "/Users/pradeepkumarmahato/aera/safety_stock/safety_stock_io_skill/data/RLT History.csv",
			"average_demand": "/Users/pradeepkumarmahato/aera/safety_stock/safety_stock_io_skill/data/Average Demand Over RLT 12M.csv",
			"target_service_level": "/Users/pradeepkumarmahato/aera/safety_stock/safety_stock_io_skill/data/Target Service Level.csv",
        "granularity" : "MATERIAL,LOCATION",
        "threshold_dd_distribution" : "10",
        "threshold_lt_distribution" : "4",
        "grain_date_type" : "month",
        "demand_date_column" : "DD_PERIOD_END"
      },
      "data": None,
      "modelParams": {
        "start_month" : "05",
        "start_year" : "2016",
        "end_month" : "12",
        "end_year" : "2019",
        "number_of_simulations": 10
      },
      "jobParams": {
        "job_name" : "ss",
        "output_file_name": "output.csv",
        "job_output_type" : "hdfs"
      },
      "jobManagement": {
      }
    }


    obj = TaskGenerator(job_id="TESTING",
                        file_path={
                            'target_service_level': '/private/tmp/cortex/1b6b14c6-574f-40ba-9be1-03e2453acf5c/Target Service Level.csv',
                            'average_demand': '/private/tmp/cortex/1b6b14c6-574f-40ba-9be1-03e2453acf5c/Average Demand Over RLT 12M.csv',
                            'demand_history': '/private/tmp/cortex/1b6b14c6-574f-40ba-9be1-03e2453acf5c/Demand History.csv',
                            'lead_time_history': '/private/tmp/cortex/1b6b14c6-574f-40ba-9be1-03e2453acf5c/RLT History.csv'
                        },
                        request_folder="/tmp/test_ss")
    resp = obj.execute(original_input)
    pprint(resp)
# '''