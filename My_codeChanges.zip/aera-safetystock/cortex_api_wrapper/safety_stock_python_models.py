import time
from .base import Base
import logging
from safety_stock.data_modelling.modelling_call import python_models_runner
# from safety_stock.utils.ss_logger import configure_logs


class ForecastPythonModels(Base):

    def __init__(self, job_id=None, file_path=None, request_folder=None, **kwagrs):
        self.job_id = job_id
        self.start_time = time.time()
        self.end_time = time.time()
        logger_instance = logging.getLogger(__name__)
        self.logger = logging.LoggerAdapter(logger_instance, {'jobId': self.job_id})

    def execute(self, original_input):
        """
        Driver method/Entry point for whole service, this method also called by cortex api framework to execute.
        """
        grain_data = original_input['modelParams']
        grain_data['demand_data_time'] = eval(grain_data['demand_data_time'])
        forecast_value_object = python_models_runner(grain_data)
        return forecast_value_object