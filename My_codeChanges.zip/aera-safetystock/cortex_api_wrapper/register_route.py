###########################################################################
# Name: register_routes.py
# Author: Aeratechnology Pvt. Ltd.
# Purpose: Base class for all Downstream components 
# Date                          Version                                 Created By
# 03-June-2020                    1.0                                    Anil Gupta(Initial Version)
###########################################################################

# Python Package & Modules
import json
import os
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
routes_file_path = CURRENT_DIR + "/../dependencies/api_endpoints.json"

class RegisterRoute:
    @staticmethod
    def get_routes():
        routes = {}
        with open(routes_file_path) as f:
            routes = json.load(f)
        
        service_id = list(routes.keys())[0]
        return service_id, routes[service_id]