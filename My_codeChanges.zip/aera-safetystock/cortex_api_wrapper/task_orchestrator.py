###########################################################################
# Name: base.py
# Author: Aeratechnology Pvt. Ltd.
# Purpose: This module will help us to generate metadata.
# Date                          Version                                 Created By
# 07-April-2022                    1.0                                    Sachin Kadam(Initial Version)
###########################################################################

# Python Package & Modules
import os
import logging
import traceback
# Project related dependencies
from .base import Base
from utils.common_utility import CommonUtility
from utils.constant import Constant
from utils.exceptions.service_exception import FileNotFoundException, DirectoryNotExistsException
from safety_stock.grain_orchestrator import GrainOrchestrator
# from safety_stock.utils.ss_logger import configure_logs

class TaskOrchestrator(Base):
    def __init__(self, job_id=None,file_path=None, request_folder=None, **kwagrs):
        self.user = kwagrs.get('user', 'Aera Technology')
        self.job_id = job_id
        self.file_path = file_path
        self.request_folder = request_folder
        self.original_input_file_name = file_path.rsplit(Constant.FILE_SEPARATOR, 1)[-1]
        logger_instance = logging.getLogger(__name__)
        self.logger = logging.LoggerAdapter(logger_instance, {'jobId': self.job_id})

    def __read_grain_data(self, file_path):
        """
            Reads the grain data from file path and returns one_pass message.
            @params:
                file_path: string of file path where the grain json is located
            @return:
                status: True if grain_data is found else False
                one_message: parsed onepass_message object or None in case of Error

        """
        status = False
        one_message = None
        try:
            print("file_path in read grain ---- ", file_path)
            one_message = CommonUtility.read_file(file_path)
            status = True
            return True, one_message
        except FileNotFoundException as e:
            self.logger.error("Grain file not found at the given path: {}".format(file_path))
            self.logger.error(str(e))
            status = False
            one_message = None
        except Exception as e:
            self.logger.error("Encountered an Unknown error while reading grain from file path: {}".format(file_path))
            self.logger.error(str(e))
            status = False
            one_message = None
        return status, one_message


    def save_file(self, data, destination_path, unique_id):
        """
        save_file method save the grain metadata into a file on local directory, later uploaded this file to
        remote location.
        @params:
            data:grain metadata for downstream processes or service, this is final consumable data.
            unique_id(str): metadata file name without extention.
            destination_path(str): local folder path for current job, all relevant files will got generated here only.
        @return:
            destination_file(str): local file path for current grain which contains grain metadata.
        """
        # generates filename with its absolute path
        if not os.path.exists(destination_path):
            message = Constant.DIRECTORY_NOT_FOUND_LOG % destination_path
            raise DirectoryNotExistsException(message)
        destination_file = CommonUtility.concat_string(destination_path, os.path.sep, unique_id)
        CommonUtility.dumps_json_in_files(destination_file, data)
        return destination_file

    def execute(self, original_input):
        """
        TODO
        """
        task_response = dict(is_executed=False)
        status, message = self.__read_grain_data(self.file_path)
        if status:
            self.logger.info("Beginning forecasting for message-id: {}".format(message['message_id']))
            try:
                grain_orchestrator_obj = GrainOrchestrator(grain_data=message)
                is_error, forecast_metadata = grain_orchestrator_obj.get_safetystock()
                task_response['is_executed'] = not is_error
                task_response['metadata'] = forecast_metadata
                self.logger.info(f"Completed safety stock computations. Error status: {is_error}")
            except Exception as e:
                traceback_msg = str(traceback.print_exc())
                traceback_msg += str(e)
                task_response['is_executed'] = False
                task_response['metadata'] = traceback_msg
                self.logger.info(f"Failed safety stock computations. Error: {str(e)}")
        else:
            task_response['is_executed'] = False
            task_response['metadata'] = "Unable to read grain data: {}".format(str(message))
            self.logger.info(f"Unable to read grain data, No computation done. Error: {str(message)}")

        self.logger.info("task_response --- ", task_response)
        return task_response

'''
from safety_stock.utils.common_utility import  CommonUtility
from safety_stock.data_modelling.python_models import *
jsondata = CommonUtility.read_json_files("/Users/sachinkadam/Downloads/62ebbf90006546ecaf7aab9044c0b654__DEC4__3005758__97.0.json")
#jsondata['nlags'] = '4'
jsondata['project_id'] = 'ABCD'
result = ss_simulation3(jsondata)
safety_stock_result = result

## Usage
if __name__ == "__main__":
    original_input = {
                            "projectId": "BE8BA2A0_2B4C_48BA_B0A8_714E96548216",
                            "capacityPoolId":"BE8BA2A0_2B4C_48BA_B0A8_714E96548216",
                            "serviceId": "1006",
                            "userName": "pradeep.mahato@aeratechnology.com",
                            "jobId": "ss_teststock",
                            "jobName": "ss_teststock",
                            "taskId": "b8cbef41089b4696a8d342190a7a60b2_02340-09000---1072",
                            "dataUri": "file:///private/tmp/test_ss/grains/TESTING__10001552__US19.json",
                            "resultUri": "file:///private/temp/test_oss"}


    obj = TaskOrchestrator(job_id="TEST_JOB",
                           file_path="/private/tmp/test_ss/grains/TESTING__10008935__BR00.json",
                           request_folder="/tmp/ss_data")
    resp = obj.execute(original_input)
    pprint(resp)
'''