###########################################################################
# Name: base.py
# Author: Aeratechnology Pvt. Ltd.
# Purpose: Base class for all Downstream components 
# Date                          Version                                 Created By
# 03-June-2020                    1.0                                    Anil Gupta(Initial Version)
###########################################################################
# Python Package & Modules
import uuid
import time
from abc import ABC, abstractmethod

class Base(ABC):
    def __init__(self, file_path=None, job_id=str(uuid.uuid4()), request_folder=None, **kwargs):
        self.file_path = file_path
        self.job_id = job_id
        self.request_folder = request_folder
        self.user = kwargs.get('user', 'Aera Technology')
        self.start_time = time.time()
        self.end_time = time.time()
        super().__init__()
        
    @abstractmethod
    def execute(self):
        print("Some implementation in subclass")
        pass